import bpy
import os
import sys
import platform
from ctypes import *


def init_module():
    lib_name = "cycles_hook"
    version = bpy.app.version
    if version[:2] == (3, 3):
        lib_name += "_330_py310"
    elif version[:2] == (3, 2):
        lib_name += "_320_py310"
    elif version[:2] == (3, 1):
        lib_name += "_310_py310"
    elif version[:2] == (3, 0):
        lib_name += "_300_py39"
    elif version[:2] == (2, 93):
        if bpy.app.version[2] < 4 or (bpy.app.version[2] == 4 and bpy.app.version_cycle != 'release'):
            lib_name += "_293_py39"
        else:
            lib_name += "_2934_py39"

    dirname = os.path.dirname(__file__)

    if sys.platform.startswith("linux"):
        ext = ".so"
    else:
        assert sys.platform.startswith("darwin")
        ext = ".dylib"
        if platform.machine() == 'arm64':
            dirname += "/darwin_arm64"

    dylib = cdll.LoadLibrary(f'{dirname}/{lib_name}{ext}')
    dylib.modifiy_hair_shape.argtypes = (c_void_p, c_void_p, c_int)
    dylib.modifiy_hair_shape.restype = c_bool

    dylib.swap_session_data.argtypes = (c_void_p, c_void_p)

    dylib.switch_session_to_render_mode.argtypes = (c_void_p,)

    dylib.increase_session_reset_time.argtypes = (c_void_p,)

    dylib.cancel_session.argtypes = (c_void_p,)

    dylib.create_hair_shape_hook.restype = c_void_p

    dylib.free_hair_shape_hook.argtypes = (c_void_p,)

    dylib.is_all_hair_updated.argtypes = (c_void_p,)
    dylib.is_all_hair_updated.restype = c_bool

    return dylib


py_clib = init_module()


def modifiy_hair_shape(pysession, pyhook, updates):
    return py_clib.modifiy_hair_shape(pysession, pyhook, updates)


def swap_session_data(pysession1, pysession2):
    return py_clib.swap_session_data(pysession1, pysession2)


def switch_session_to_render_mode(session):
    return py_clib.switch_session_to_render_mode(session)


def increase_session_reset_time(session):
    return py_clib.increase_session_reset_time(session)


def cancel_session(session):
    return py_clib.cancel_session(session)


def create_hair_shape_hook():
    return py_clib.create_hair_shape_hook()


def free_hair_shape_hook(hook):
    return py_clib.free_hair_shape_hook(hook)


def is_all_hair_updated(session):
    return py_clib.is_all_hair_updated(session)
