import sys
import bpy

cycles_hook = None
if sys.platform.startswith("win"):
    if bpy.app.version >= (3, 3):
        from .win import cycles_hook_330_py310 as cycles_hook
    elif bpy.app.version >= (3, 2):
        from .win import cycles_hook_320_py310 as cycles_hook
    elif bpy.app.version >= (3, 1):
        from .win import cycles_hook_310_py310 as cycles_hook
    elif bpy.app.version >= (3, 0):
        from .win import cycles_hook_300_py39 as cycles_hook
    elif bpy.app.version >= (2, 93):
        if bpy.app.version[2] < 4 or (bpy.app.version[2] == 4 and bpy.app.version_cycle != 'release'):
            from .win import cycles_hook_293_py39 as cycles_hook
        else:
            from .win import cycles_hook_2934_py39 as cycles_hook
elif bpy.app.version >= (2, 93):
    from . import unix as cycles_hook
