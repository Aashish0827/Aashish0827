#
# Copyright 2011-2013 Blender Foundation
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

from __future__ import annotations
import bpy


def draw_hair_shape(self, context):
    if context.engine != 'CYCLESHAIR':
        return
    layout = self.layout
    cycles = context.object.particle_systems.active.settings.cycles
    layout.prop(cycles, "use_shape_random")
    if cycles.use_shape_random:
        col = layout.column(align=True)
        col.prop(cycles, "random_seed")
        col.prop(cycles, "radius_range_start")
        col.prop(cycles, "random_threshold")

    row = layout.row()
    row.prop(cycles, "use_shape_curve")
    row.operator("cycles_hair.shape_curve_preset", text='', icon="PRESET", emboss=False)
    if cycles.use_shape_curve and cycles.shape_curve and "hair_shape_curve" in cycles.shape_curve.nodes:
        layout.column().template_curve_mapping(cycles.shape_curve.nodes["hair_shape_curve"], 'mapping')


def draw_hair_type(self, context):
    if context.engine == 'CYCLESHAIR':
        layout = self.layout
        layout.prop(context.scene.render, "hair_type", expand=True)
        layout.prop(context.scene.render, "hair_subdiv")


def use_cpu(context):
    device_type = context.preferences.addons['cycles'].preferences.compute_device_type

    return device_type == 'NONE' or context.scene.cycles.device == 'CPU'


def show_device_active(context):
    cscene = context.scene.cycles
    if cscene.device != 'GPU':
        return True
    return context.preferences.addons['cycles'].preferences.has_active_device()


def draw_device(self, context):
    scene = context.scene
    layout = self.layout
    layout.use_property_split = True
    layout.use_property_decorate = False

    if context.engine == 'CYCLESHAIR':
        from cycles import engine
        cscene = scene.cycles

        col = layout.column()
        col.prop(cscene, "feature_set")

        col = layout.column()
        col.active = show_device_active(context)
        col.prop(cscene, "device")

        if engine.with_osl() and use_cpu(context):
            col.prop(cscene, "shading_system")


def draw_pause(self, context):
    layout = self.layout
    if context.engine == "CYCLESHAIR" and context.space_data.shading.type == 'RENDERED':
        cscene = context.scene.cycles
        layout.prop(cscene, "preview_pause", icon='PLAY' if cscene.preview_pause else 'PAUSE', text="")


def get_panels():
    panels = []
    for panel in bpy.types.Panel.__subclasses__():
        if hasattr(panel, 'COMPAT_ENGINES') and 'CYCLES' in panel.COMPAT_ENGINES:
            panels.append(panel)

    return panels


def register():
    bpy.types.RENDER_PT_context.append(draw_device)
    bpy.types.VIEW3D_HT_header.append(draw_pause)
    bpy.types.PARTICLE_PT_hair_shape.append(draw_hair_shape)
    if hasattr(bpy.types, "CYCLES_RENDER_PT_hair"):
        bpy.types.CYCLES_RENDER_PT_hair.append(draw_hair_type)

    for panel in get_panels():
        if type(panel.COMPAT_ENGINES) is set:
            panel.COMPAT_ENGINES.add('CYCLESHAIR')
        elif type(panel.COMPAT_ENGINES) is list:
            panel.COMPAT_ENGINES.append('CYCLESHAIR')


def unregister():
    bpy.types.RENDER_PT_context.remove(draw_device)
    bpy.types.VIEW3D_HT_header.remove(draw_pause)
    bpy.types.PARTICLE_PT_hair_shape.remove(draw_hair_shape)
    if hasattr(bpy.types, "CYCLES_RENDER_PT_hair"):
        bpy.types.CYCLES_RENDER_PT_hair.remove(draw_hair_type)

    for panel in get_panels():
        if 'CYCLESHAIR' in panel.COMPAT_ENGINES:
            panel.COMPAT_ENGINES.remove('CYCLESHAIR')
