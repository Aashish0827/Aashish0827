from math import fabs

def mat_to_list(mat):
    return [v for c in mat.col for v in c]

def mul_project_m4_v3(mat, vec):
    zfac = fabs(vec.dot(mat[3].xyz) + mat[3][3])
    return (mat @ vec) / zfac
