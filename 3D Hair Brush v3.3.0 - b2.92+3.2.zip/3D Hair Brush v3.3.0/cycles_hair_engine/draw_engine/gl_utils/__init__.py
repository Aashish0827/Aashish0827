import sys
import bpy

gl_utils = None
if not bpy.app.background:
    if sys.platform.startswith("win"):
        if bpy.app.version >= (3, 3):
            from .win import gl_utils_330_py310 as gl_utils
        elif bpy.app.version >= (3, 2):
            from .win import gl_utils_320_py310 as gl_utils
        elif bpy.app.version >= (3, 1):
            from .win import gl_utils_310_py310 as gl_utils
        elif bpy.app.version >= (3, 0):
            from .win import gl_utils_300_py39 as gl_utils
        elif bpy.app.version[:2] == (2, 93):
            if bpy.app.version[2] < 4 or (bpy.app.version[2] == 4 and bpy.app.version_cycle != 'release'):
                from .win import gl_utils_293_py39 as gl_utils
            else:
                from .win import gl_utils_2934_py39 as gl_utils
    elif bpy.app.version[:2] >= (2, 93):
        from . import unix as gl_utils
