# ##### BEGIN GPL LICENSE BLOCK #####
#
#  Copyright (C) 2022 VFX Grace - All Rights Reserved
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####

import bpy
from bpy.types import Texture, Mesh
from . import props, ui, operators, modifier_manager, hair_modifier

def register():
    props.register()
    operators.register()
    ui.register()
    modifier_manager.register_handlers()
    hair_modifier._hair_modifier.set_texture_evaluate_function(
        Texture.bl_rna.functions['evaluate'].as_pointer())
    hair_modifier._hair_modifier.set_mesh_calc_looptri_function(
        Mesh.bl_rna.functions['calc_loop_triangles'].as_pointer())
    ver = bpy.app.version
    hair_modifier._hair_modifier.set_blender_version_number(ver[0] * 1000 + ver[1] * 100 + ver[2])


def unregister():
    ui.unregister()
    operators.unregister()
    props.unregister()
    modifier_manager.unregister_handlers()


if __name__ == "__main__":
    register()
