# ##### BEGIN GPL LICENSE BLOCK #####
#
#  Copyright (C) 2022 VFX Grace - All Rights Reserved
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####

def generate_unique_name(prefix, middle, width, collection):
    keys = collection.keys()
    i = 0
    name = prefix
    while name in keys:
        i += 1
        name = (prefix + middle + str(i).zfill(width))
    return name


def get_enum_items_item(items, id, item_idx):
    for item in items:
        if item[0] == id:
            return item[item_idx]
    return None


def tag_view3d_redraw(context, force=True):
    screen = context.screen
    if context.window.parent:
        screen = context.window.parent.screen
    for area in screen.areas:
        if area.type == 'VIEW_3D':
            if force:
                v3d = area.spaces[0]
                v3d.shading.show_object_outline = not v3d.shading.show_object_outline
                v3d.shading.show_object_outline = not v3d.shading.show_object_outline
            else:
                area.tag_redraw()
