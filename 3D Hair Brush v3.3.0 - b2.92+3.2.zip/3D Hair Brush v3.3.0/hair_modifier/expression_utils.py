# ##### BEGIN GPL LICENSE BLOCK #####
#
#  Copyright (C) 2022 VFX Grace - All Rights Reserved
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####

import ast
import math
from enum import IntEnum, auto
import bl_math
from ctypes import (c_int, c_float, c_void_p, Structure, Union, pointer,
                    CFUNCTYPE, POINTER, addressof)
from _ctypes import PyObj_FromPtr

from .hair_modifier import _hair_modifier


class BuiltinVariableCode(IntEnum):
    PATH_LENGTH = 0
    CLUMP_LENGTH = 1


class ExpressionEvalContext:
    _BUILTIN_FUNCS_ = {
        # types
        "int": int,
        "float": float,
        # math funcs
        "max": max,
        "min": min,
        "abs": abs,
        "fabs": math.fabs,
        "floor": math.floor,
        "ceil": math.ceil,
        "trunc": math.trunc,
        "round": round,
        "sin": math.sin,
        "cos": math.cos,
        "tan": math.tan,
        "asin": math.asin,
        "acos": math.acos,
        "atan": math.atan,
        "atan2": math.atan2,
        "exp": math.exp,
        "log": math.log,
        "sqrt": math.sqrt,
        "pow": pow,
        "fmod": math.fmod,
        "lerp": bl_math.lerp,
        "clamp": bl_math.clamp,
        "smoothstep": bl_math.smoothstep
    }

    _BUILTIN_VARS_ = {
        "_path_length",
        "_clump_length"
    }

    class ModifierPropertyContext:
        def __init__(self, mod) -> None:
            self.__mod = mod
            self.__mod_props = mod.get_modifier_props()
            self.__cls_name = f"{mod.type.title()}Modifier"

        def __getattr__(self, name: str):
            if hasattr(self.__mod, name):
                return getattr(self.__mod, name)
            if hasattr(self.__mod_props, name):
                return getattr(self.__mod_props, name)
            raise AttributeError(f"'{self.__cls_name}' object has no attribute '{name}'")

    class ModifierCollection:
        def __init__(self, mods) -> None:
            self.mods = []
            self.mod_dict = dict()
            for mod in mods:
                mpc = ExpressionEvalContext.ModifierPropertyContext(mod)
                self.mods.append(mpc)
                self.mod_dict[mod.name] = mpc

        def __getitem__(self, key):
            if isinstance(key, int):
                if key < 0 or key >= len(self.mods):
                    raise IndexError(f"index {key} out of range, size {len(self.mods)}")
                return self.mods[key]
            if isinstance(key, str):
                if key not in self.mod_dict:
                    raise KeyError(f"key '{key}' not found")
                return self.mod_dict[key]
            raise TypeError("invalid key, must be a string or an int")

    def __init__(self, part, mod) -> None:
        self._builtin_vars = {
            "_pset": part,
            "_mods": self.ModifierCollection(part.child_modifier.modifiers),
            "_path_length": 1.0,
            "pi": math.pi
        }
        if mod.type == 'CLUMP':
            self._builtin_vars['_clump_length'] = 1.0
        self._mod = self._builtin_vars['_mods'][mod.name]

    def __getitem__(self, key):
        if key in self._BUILTIN_FUNCS_:
            return self._BUILTIN_FUNCS_[key]
        if key in self._builtin_vars:
            return self._builtin_vars[key]
        return getattr(self._mod, key)


class ExprOpCode(IntEnum):
    CONST = 0
    VARIABLE = auto()
    IF_ELSE = auto()
    NOT = auto()
    USUB = auto()
    AND = auto()
    OR = auto()
    EQ = auto()
    NOTEQ = auto()
    GT = auto()
    GTE = auto()
    LT = auto()
    LTE = auto()
    ADD = auto()
    SUB = auto()
    MULT = auto()
    DIV = auto()
    MOD = auto()
    INT = auto()
    FLOAT = auto()
    RADIANS = auto()
    DEGREES = auto()
    MIN2 = auto()
    MAX2 = auto()
    MIN3 = auto()
    MAX3 = auto()
    ABS = auto()
    FABS = auto()
    FLOOR = auto()
    CEIL = auto()
    TRUNC = auto()
    ROUND = auto()
    SIN = auto()
    COS = auto()
    TAN = auto()
    ASIN = auto()
    ACOS = auto()
    ATAN = auto()
    ATAN2 = auto()
    EXP = auto()
    LOG = auto()
    LOG2 = auto()
    SQRT = auto()
    POW = auto()
    FMOD = auto()
    LERP = auto()
    CLAMP = auto()
    SMOOTHSTE = auto()


class ExprOpArg(Union):
    _fields_ = [("opidx", c_int),
                ("opval", c_float)]


class ExprOp(Structure):
    _fields_ = [("opcode", c_int),
                ("op1", ExprOpArg),
                ("opidx2", c_int),
                ("opidx3", c_int)]


class ExpressionParsed(Structure):
    _fields_ = [("ops_count", c_int),
                ("ops", POINTER(ExprOp))]


class ExpressionCompiler:
    def __init__(self, eval_ctx) -> None:
        self.eval_ctx = eval_ctx
        self.ops = []
        self.error_msg = ""

    def _push_op_args(self, op, arg1, arg2=None, arg3=None):
        cur_opidx = len(self.ops)
        op.op1.opidx = cur_opidx
        self.ops.append(arg1)
        if arg2:
            op.opidx2 = cur_opidx + 1
            self.ops.append(arg2)
        if arg3:
            op.opidx3 = cur_opidx + 2
            self.ops.append(arg3)

    def _compile_Call(self, node: ast.Call):
        if (not isinstance(node.func, ast.Name)
                or node.func.id not in ExpressionEvalContext._BUILTIN_FUNCS_):
            return None

        args = []
        arg_ops = []
        keywords = dict()
        keyword_ops = dict()
        all_constant = True
        for arg in node.args:
            if isinstance(arg, ast.Constant):
                args.append(arg.value)
                arg_ops.append(ExprOp(ExprOpCode.CONST, ExprOpArg(opval=arg.value)))
            else:
                op = self._compile(arg)
                if op is None:
                    return None
                arg_ops.append(op)
                if op.opcode == ExprOpCode.CONST:
                    args.append(op.op1.opval)
                else:
                    all_constant = False
        for keyword in node.keywords:
            if isinstance(keyword.value, ast.Constant):
                keywords[keyword.arg] = keyword.value
                keyword_ops[keyword.arg] = ExprOp(
                    ExprOpCode.CONST, ExprOpArg(opval=keyword.value))
            else:
                op = self._compile(keyword.value)
                if op is None:
                    return None
                keyword_ops[keyword.arg] = op
                if op.opcode == ExprOpCode.CONST:
                    keywords[keyword.arg] = op.op1.opval
                else:
                    all_constant = False

        if all_constant:
            func = self.eval_ctx[node.func.id]
            ret = func(*args, **keywords)
            return ExprOp(ExprOpCode.CONST, ExprOpArg(opval=ret))
        else:
            func_name = node.func.id
            opcode_key = func_name.upper()
            op = ExprOp()
            arg_len = len(arg_ops)
            if func_name in ("min", "max"):
                if arg_len <= 1:
                    # Unsupport iterable arg.
                    return None
                if len(args) >= 2:
                    for i in range(arg_len-1 , -1, -1):
                        if arg_ops[i].opcode == ExprOpCode.CONST:
                            arg_ops.pop(i)
                    func = self.eval_ctx[node.func.id]
                    arg_ops.append(ExprOp(ExprOpCode.CONST, ExprOpArg(opval=func(args))))
                    arg_len = len(arg_ops)
                if arg_len <= 3:
                    opcode_key = opcode_key + str(arg_len)
                else:
                    # Split args.
                    func_key = ExprOpCode[opcode_key + "3"]
                    if arg_len % 2 == 1:
                        eo = ExprOp(func_key)
                        self._push_op_args(eo, arg_ops.pop(), arg_ops.pop(), arg_ops.pop())
                    else:
                        eo = ExprOp(ExprOpCode[opcode_key + "2"])
                        self._push_op_args(eo, arg_ops.pop(), arg_ops.pop())
                    while len(arg_ops) > 2:
                        o = ExprOp(func_key)
                        self._push_op_args(o, arg_ops.pop(), arg_ops.pop(), eo)
                        eo = o
                    arg_ops.append(eo)
                    opcode_key = opcode_key + "3"
            elif func_name == "log":
                if arg_len == 2:
                    opcode_key = opcode_key + "2"
            elif func_name == "clamp":
                op.op1.opidx = op.opidx2 = op.opidx3 = -1
            if len(arg_ops) > 3:
                return None
            op.opcode = ExprOpCode[opcode_key]
            self._push_op_args(op, *arg_ops)
            return op

    def _compile_Name(self, node: ast.Name):
        var_name = node.id
        if var_name in ExpressionEvalContext._BUILTIN_VARS_:
            op = ExprOp(ExprOpCode.VARIABLE,
                        ExprOpArg(opidx=BuiltinVariableCode[var_name[1:].upper()]))
        else:
            var = self.eval_ctx[var_name]
            op = ExprOp(ExprOpCode.CONST, ExprOpArg(opval=var))
        return op

    def _get_attribute_chain(self, node: ast.Attribute, chain_strs: list):
        ret = True
        if isinstance(node, ast.Attribute):
            ret = self._get_attribute_chain(node.value, chain_strs)
            chain_strs.append(f".{node.attr}")
        elif isinstance(node, ast.Name):
            chain_strs.append(node.id)
        elif isinstance(node, ast.Subscript):
            if not isinstance(node.slice, ast.Constant):
                return False
            ret = self._get_attribute_chain(node.value, chain_strs)
            if type(node.slice.value) is str:
                chain_strs.append(f"['{node.slice.value}']")
            else:
                chain_strs.append(f"[{node.slice.value}]")
        else:
            ret = False
        return ret

    def _compile_Attribute(self, node: ast.Attribute):
        attr_chain = list()
        if self._get_attribute_chain(node, attr_chain):
            try:
                ret = eval("".join(attr_chain), {'__builtins__': {}}, self.eval_ctx)
                if ret is not None:
                    return ExprOp(ExprOpCode.CONST, ExprOpArg(opval=float(ret)))
            except BaseException as e:
                self.error_msg = f"{type(e).__name__}: {str(e)}"
        return None

    def _compile_UnaryOp(self, node: ast.UnaryOp):
        op_name = node.op.__class__.__name__
        op = self._compile(node.operand)
        if op:
            if op.opcode == ExprOpCode.CONST:
                op_symbol = ast._Unparser.unop[op_name]
                if op_symbol == "not":
                    op_symbol = "not "
                op.op1.opval = float(eval(f"{op_symbol}{str(op.op1.opval)}"))
            elif op_name != "UAdd":
                opcode_key = op_name.upper()
                if opcode_key not in ExprOpCode._member_map_:
                    self.error_msg = f"Operator '{ast._Unparser.unop[op_name]}' is not supported by built in variables!"
                    return None
                self.ops.append(op)
                op = ExprOp(ExprOpCode[opcode_key],
                            ExprOpArg(opidx=len(self.ops) -1))
        return op

    def _compile_BinOp(self, node: ast.BinOp):
        op_name = node.op.__class__.__name__
        op_left = self._compile(node.left)
        op_right = self._compile(node.right)
        op = None
        if op_left and op_right:
            if (op_left.opcode == ExprOpCode.CONST and
                    op_right.opcode == ExprOpCode.CONST):
                op_symbol = ast._Unparser.binop[op_name]
                op_left.op1.opval = float(eval(f"{op_left.op1.opval} {op_symbol} {op_right.op1.opval}"))
                op = op_left
            else:
                opcode_key = op_name.upper()
                if opcode_key not in ExprOpCode._member_map_:
                    self.error_msg = f"Operator '{ast._Unparser.binop[op_name]}' is not supported by built in variables!"
                    return None
                self.ops.append(op_left)
                self.ops.append(op_right)
                op = ExprOp(ExprOpCode[opcode_key],
                            ExprOpArg(opidx=len(self.ops) - 2),
                            opidx2=len(self.ops) - 1)
        return op

    def _compile_Compare(self, node: ast.Compare):
        cond_ops = []
        prev_cmp_op = self._compile(node.left)
        if prev_cmp_op is None:
            return None
        prev_cmp_op_pos = -1
        for op, cmp in zip(node.ops, node.comparators):
            op_name = op.__class__.__name__
            opcode_key = op_name.upper()
            if opcode_key not in ExprOpCode._member_map_:
                self.error_msg = f"The compare operator '{ast._Unparser.cmpops[op_name]}' is not supported!"
                return None

            cmp_op = self._compile(cmp)
            if cmp_op is None:
                return None

            if (prev_cmp_op.opcode == ExprOpCode.CONST and
                    cmp_op.opcode == ExprOpCode.CONST):
                op_symbol = ast._Unparser.cmpops[op_name]
                # Compare chain is same as multiple conditions and.
                try:
                    if not eval(f"{prev_cmp_op.op1.opval} {op_symbol} {cmp_op.op1.opval}"):
                        return ExprOp(ExprOpCode.CONST, ExprOpArg(opval=0))
                    else:
                        prev_cmp_op = cmp_op
                        prev_cmp_op_pos = -1
                except:
                    return None
            else:
                cond_op = ExprOp(ExprOpCode[opcode_key])
                if prev_cmp_op_pos != -1:
                    cond_op.op1.opidx = prev_cmp_op_pos
                else:
                    cond_op.op1.opidx = len(self.ops)
                    self.ops.append(prev_cmp_op)
                cond_op.opidx2 = prev_cmp_op_pos = len(self.ops)
                self.ops.append(cmp_op)
                prev_cmp_op = cmp_op
                cond_ops.append(cond_op)

        if len(cond_ops) == 1:
            return cond_ops[0]

        op = ExprOp(ExprOpCode.AND)
        op.op1.opidx = op.opidx2 = op.opidx3 = -1
        if len(cond_ops) > 3:
            eo = ExprOp(ExprOpCode.AND)
            if len(cond_ops) % 2 == 1:
                self._push_op_args(eo, cond_ops.pop(), cond_ops.pop(), cond_ops.pop())
            else:
                self._push_op_args(eo, cond_ops.pop(), cond_ops.pop())
                eo.opidx3 = -1
            while len(cond_ops) > 2:
                o = ExprOp(ExprOpCode.AND)
                self._push_op_args(o, cond_ops.pop(), cond_ops.pop(), eo)
                eo = o
            cond_ops.append(eo)
        self._push_op_args(op, *cond_ops)
        return op

    def _rollback_ops(self, to_count):
        while len(self.ops) > to_count:
            self.ops.pop()

    def _compile_BoolOp(self, node: ast.BoolOp):
        op_name = node.op.__class__.__name__
        cond_ops = []
        is_and = op_name == "And"
        start_ops_count = len(self.ops)
        op = None
        for cond in node.values:
            if isinstance(cond, ast.Constant):
                cond_res = cond.value
            else:
                op_cond = self._compile(cond)
                if op_cond is None:
                    return None
                if op_cond.opcode == ExprOpCode.CONST:
                    cond_res = op_cond.op1.opval
                else:
                    cond_ops.append(op_cond)
                    continue
            if is_and:
                # and -> one fail all fail.
                if not cond_res:
                    self._rollback_ops(start_ops_count)
                    return ExprOp(ExprOpCode.CONST, ExprOpArg(opval=0))
                # or -> one pass all pass.
            elif cond_res:
                self._rollback_ops(start_ops_count)
                return ExprOp(ExprOpCode.CONST, ExprOpArg(opval=1))
        if not cond_ops:
            # all pass or all failed.
            op = ExprOp(ExprOpCode.CONST, ExprOpArg(opval=1 if is_and else 0))
        else:
            opcode = ExprOpCode.AND if is_and else ExprOpCode.OR
            op = ExprOp(opcode)
            op.op1.opidx = op.opidx2 = op.opidx3 = -1
            if len(cond_ops) > 3:
                eo = ExprOp(opcode)
                if len(cond_ops) % 2 == 1:
                    self._push_op_args(eo, cond_ops.pop(), cond_ops.pop(), cond_ops.pop())
                else:
                    self._push_op_args(eo, cond_ops.pop(), cond_ops.pop())
                    eo.opidx3 = -1
                while len(cond_ops) > 2:
                    o = ExprOp(opcode)
                    self._push_op_args(o, cond_ops.pop(), cond_ops.pop(), eo)
                    eo = o
                cond_ops.append(eo)
            self._push_op_args(op, *cond_ops)
        return op

    def _compile_IfExp(self, node: ast.IfExp):
        test_op = self._compile(node.test)
        if test_op.opcode == ExprOpCode.CONST:
            if test_op.op1.opval:
                return self._compile(node.body)
            else:
                return self._compile(node.orelse)
        else:
            op = ExprOp(ExprOpCode.IF_ELSE)
            body_op = self._compile(node.body)
            if body_op is None:
                return None
            orelse_op = self._compile(node.orelse)
            if orelse_op is None:
                return None
            self._push_op_args(op, test_op, body_op, orelse_op)
            return op

    def _compile(self, node):
        if isinstance(node, ast.Constant):
            return ExprOp(ExprOpCode.CONST, ExprOpArg(opval=node.value))
        if isinstance(node, ast.Name):
            return self._compile_Name(node)
        if isinstance(node, ast.Attribute):
            return self._compile_Attribute(node)
        if isinstance(node, ast.BinOp):
            return self._compile_BinOp(node)
        if isinstance(node, ast.Call):
            return self._compile_Call(node)
        if isinstance(node, ast.Expression):
            return self._compile(node.body)
        if isinstance(node, ast.Compare):
            return self._compile_Compare(node)
        if isinstance(node, ast.IfExp):
            return self._compile_IfExp(node)
        if isinstance(node, ast.BoolOp):
            return self._compile_BoolOp(node)
        if isinstance(node, ast.UnaryOp):
            return self._compile_UnaryOp(node)

    def compile(self, ast_node):
        self.ops.clear()
        op = self._compile(ast_node)
        if op is None:
            if not self.error_msg:
                self.error_msg = "Failed to parse Expression!"
            return False
        if op.opcode == ExprOpCode.CONST:
            self.ops.clear()
        self.ops.append(op)
        return True


def has_dynamic_variable(expr_str: str):
    for vn in ExpressionEvalContext._BUILTIN_VARS_:
        if expr_str.find(vn) != -1:
            return True
    return False


@CFUNCTYPE(c_int, c_void_p, c_int, c_int, c_void_p)
def update_expression(pset_id, mod_idx, expr_idx, modifier_ptr):
    update_status = -1
    part = PyObj_FromPtr(pset_id)
    if part.is_evaluated:
        part = part.original
    mod = part.child_modifier.modifiers[mod_idx]
    eval_ctx = ExpressionEvalContext(part, mod)
    expr_prop = mod.expressions[expr_idx]
    expr_parsed = ExpressionParsed(ops_count = 0)
    if expr_prop.is_enabled and expr_prop.is_valid:
        if has_dynamic_variable(expr_prop.expression):
            expr_ast = ast.parse(expr_prop.expression, mode='eval')
            expr_compiler = ExpressionCompiler(eval_ctx)
            if expr_compiler.compile(expr_ast):
                expr_parsed.ops_count = len(expr_compiler.ops)
                expr_parsed.ops = (ExprOp * len(expr_compiler.ops))(*expr_compiler.ops)
            else:
                expr_prop.error_msg = expr_compiler.error_msg
                expr_prop.is_valid = False
        else:
            ret = expr_prop.validate_expression(mod, eval_ctx)
            if ret is not None:
                op = ExprOp(opcode=ExprOpCode.CONST, op1=ExprOpArg(opval=ret))
                expr_parsed.ops_count = 1
                expr_parsed.ops = pointer(op)
        if expr_parsed.ops_count > 0:
            if _hair_modifier.update_hair_modifier_expression(
                    modifier_ptr, expr_prop.name, addressof(expr_parsed)):
                update_status = 1
            else:
                update_status = 0
    return update_status
