# ##### BEGIN GPL LICENSE BLOCK #####
#
#  Copyright (C) 2022 VFX Grace - All Rights Reserved
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####

import sys
import bpy

particle_hook = None
if sys.platform.startswith("win"):
    if bpy.app.version >= (3, 3):
        from .win import hair_brush_3d_330_py310 as particle_hook
    elif bpy.app.version >= (3, 2):
        from .win import hair_brush_3d_320_py310 as particle_hook
    elif bpy.app.version >= (3, 1):
        from .win import hair_brush_3d_310_py310 as particle_hook
    elif bpy.app.version >= (3, 0):
        from .win import hair_brush_3d_300_py39 as particle_hook
    elif bpy.app.version[:2] == (2, 93):
        if bpy.app.version[2] < 4 or (bpy.app.version[2] == 4 and bpy.app.version_cycle != 'release'):
            from .win import hair_brush_3d_293_py39 as particle_hook
        else:
            from .win import hair_brush_3d_2934_py39 as particle_hook
elif bpy.app.version[:2] >= (2, 93):
    from . import unix as particle_hook
