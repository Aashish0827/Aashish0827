# ##### BEGIN GPL LICENSE BLOCK #####
#
#  Copyright (C) 2022 VFX Grace - All Rights Reserved
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####

import os
import bpy
import bl_ui.space_toolsystem_common
from bl_ui.space_toolsystem_common import ToolSelectPanelHelper, ToolDef, _icon_cache
from bl_ui.space_toolsystem_toolbar import VIEW3D_PT_tools_active, _defs_particle

from .particle_hook import particle_hook
from .utils import (hair_color_loading, hair_color_saving,
                    sync_hair_color_on_deps_update,
                    subscribe_rna_change_callback, get_addon_name)


addon_name = get_addon_name()
tool_changed_event_handlers = []
activate_by_id_func = None


class HAIRBRUSH_OT_CloneRotate(bpy.types.Operator):
    bl_idname = "hair_brush_3d.clone_rotate"
    bl_label = "Rotate Clone Brush"
    bl_description = "Rotate clone brush"
    bl_options = {"REGISTER", "UNDO"}

    rotate_mode: bpy.props.EnumProperty(
        name="Rotate mode",
        items=[("ADD", "Add", "Add rotation", 0),
               ("SUB", "Sub", "Sub rotation", 1)],
        options={'HIDDEN'})

    @classmethod
    def poll(cls, context: bpy.types.Context):
        tc = ToolSelectPanelHelper.tool_active_from_context(context)
        return tc.idname.lower() == "hair_brush_3d.clone"

    def execute(self, context):
        hb3 = context.scene.hair_brush_3d
        if self.rotate_mode == 'ADD':
            hb3.clone_rotation_angle += 1
        else:
            hb3.clone_rotation_angle -= 1
        return {'FINISHED'}


@classmethod
def brush3d_tools_from_context(cls, context, mode=None):
    if mode is None:
        mode = context.mode
    for tools in (cls._tools[None], cls._tools.get(mode, ())):
        for item in tools:
            if not (type(item) is ToolDef) and callable(item):
                if (mode == 'PARTICLE' and context.preferences.addons[addon_name].preferences.collapse_intern
                        and item == _defs_particle.generate_from_brushes):
                    yield item(context)
                else:
                    yield from item(context)
            else:
                yield item


def patch_VIEW3D_PT_tools_active():
    VIEW3D_PT_tools_active.tools_from_context__ = VIEW3D_PT_tools_active.tools_from_context
    VIEW3D_PT_tools_active.tools_from_context = brush3d_tools_from_context


def restore_VIEW3D_PT_tools_active():
    VIEW3D_PT_tools_active.tools_from_context = VIEW3D_PT_tools_active.tools_from_context__
    del VIEW3D_PT_tools_active.tools_from_context__


def brush3d_activate_by_id(context, space_type, idname, *, as_fallback=False):
    for handler in tool_changed_event_handlers:
        handler(context, idname)
    if activate_by_id_func:
        return activate_by_id_func(context, space_type, idname, as_fallback=as_fallback)


def patch_activate_by_id_func():
    global activate_by_id_func
    activate_by_id_func = bl_ui.space_toolsystem_common.activate_by_id
    bl_ui.space_toolsystem_common.activate_by_id = brush3d_activate_by_id


def restore_activate_by_id_func():
    global activate_by_id_func
    bl_ui.space_toolsystem_common.activate_by_id = activate_by_id_func
    activate_by_id_func = None


def register_icons():
    icons_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "icons")
    if not os.path.exists(icons_dir):
        return

    for fn in os.listdir(icons_dir):
        icon_name = os.path.splitext(fn)[0]
        if icon_name in _icon_cache:
            continue

        try:
            icon_value = bpy.app.icons.new_triangles_from_file(os.path.join(icons_dir, fn))
            _icon_cache[icon_name] = icon_value
        except Exception as ex:
            pass


def register():
    from . import particle_tools, particle_brush, pie_menu, props
    from bpy.utils import register_class
    patch_VIEW3D_PT_tools_active()
    patch_activate_by_id_func()
    register_icons()
    props.register()
    register_class(HAIRBRUSH_OT_CloneRotate)
    particle_brush.register()
    pie_menu.register()
    particle_tools.register()
    bpy.app.handlers.save_pre.append(hair_color_saving)
    bpy.app.handlers.load_post.append(hair_color_loading)
    bpy.app.handlers.depsgraph_update_post.append(sync_hair_color_on_deps_update)

    particle_hook.set_mesh_calc_normals_function(
        bpy.types.Mesh.bl_rna.functions['calc_normals'].as_pointer())
    particle_hook.set_mesh_calc_normals_split_function(
        bpy.types.Mesh.bl_rna.functions['calc_normals_split'].as_pointer())
    particle_hook.set_mesh_calc_looptri_function(
        bpy.types.Mesh.bl_rna.functions['calc_loop_triangles'].as_pointer())
    particle_hook.set_object_closest_point_on_mesh_function(
        bpy.types.Object.bl_rna.functions['closest_point_on_mesh'].as_pointer())
    ver = bpy.app.version
    particle_hook.set_blender_version_number(ver[0] * 1000 + ver[1] * 100 + ver[2])
    subscribe_rna_change_callback()


def unregister():
    from . import pie_menu, particle_tools, particle_brush, props
    from bpy.utils import unregister_class
    restore_VIEW3D_PT_tools_active()
    restore_activate_by_id_func()
    props.unregister()
    particle_brush.unregister()
    unregister_class(HAIRBRUSH_OT_CloneRotate)
    pie_menu.unregister()
    particle_tools.unregister()
    bpy.app.handlers.save_pre.remove(hair_color_saving)
    bpy.app.handlers.load_post.remove(hair_color_loading)
    bpy.app.handlers.depsgraph_update_post.remove(sync_hair_color_on_deps_update)
    bpy.msgbus.clear_by_owner(particle_hook)
