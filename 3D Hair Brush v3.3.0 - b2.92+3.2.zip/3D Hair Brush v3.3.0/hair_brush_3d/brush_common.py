# ##### BEGIN GPL LICENSE BLOCK #####
#
#  Copyright (C) 2022 VFX Grace - All Rights Reserved
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####

import bpy
from bpy.types import WorkSpaceTool
import gpu
from gpu_extras.batch import batch_for_shader
from mathutils import Vector, Matrix
import numpy as np
from .utils import get_circle_wire_2d, calc_projected_radius, calc_unprojected_radius, get_enum_item_num
from .props import (OrientModeEnumItems, WeightModeEnumItems,
                    CloneCoordinateEnumItems, get_noise_flag)
from .particle_hook import particle_hook


CIRCLE_WIRE_2D_POINTS = get_circle_wire_2d(0, 0, 40)
CIRCLE_WIRE_3D_POINTS = [(v[0], v[1], 0) for v in CIRCLE_WIRE_2D_POINTS]

vertex_shader = '''
    uniform mat4 ModelViewProjectionMatrix;

    in vec3 pos;

    void main()
    {
        gl_Position = ModelViewProjectionMatrix * vec4(pos, 1.0);
    }
'''

fragment_shader = '''
    void main()
    {             
    }
'''


class EditArgsFlag:
    USE_3D = 1
    ON_MESH = 2
    FOR_RENDER = 4
    USE_SCALE = 8


class RuntimeData:
    def __init__(self) -> None:
        self.on_mesh = False
        self.loc_world = Vector()
        self.nor_world = Vector()
        self.rad_3d = 0.0
        self.brush_size = 0.0
        self.pack_source_circle = False
        self.source_circle = []
        self.show_clone_circle = False
        self.has_clone_source = False

    def update_on_mesh_status(self, on_mesh, obmat, loc, nor):
        self.on_mesh = on_mesh
        if on_mesh:
            self.loc_world = obmat @ loc
            self.nor_world = obmat.to_quaternion() @ nor
        else:
            self.loc_world.zero()
            self.nor_world.zero()

    def update_brush_size(self, hb3, brush, obmat, loc, region, rv3d):
        if not hb3.scale_size or brush.size != self.brush_size:
            self.rad_3d, hb3.unprojected_rad = calc_unprojected_radius(
                obmat, loc, region, rv3d, brush.size)
            if brush.size != self.brush_size:
                self.brush_size = brush.size
        else:
            brush.size = self.brush_size = calc_projected_radius(
                obmat, region, rv3d, hb3.unprojected_rad, self.loc_world)


def gpu_draw_shader(shader_name, type, color, coords, indices=None, line_width=1):
    shader = gpu.shader.from_builtin(shader_name)
    gpu.state.blend_set('ALPHA')
    # gl_line_smooth(True)
    gpu.state.line_width_set(line_width)
    batch = batch_for_shader(shader, type, {"pos": coords}, indices=indices)
    shader.bind()
    shader.uniform_float("color", color)
    batch.draw(shader)
    gpu.state.line_width_set(1)
    # gl_line_smooth(False)
    gpu.state.blend_set('NONE')


def draw_circle_cursor_2d(xy, rad, color, line_width):
    with gpu.matrix.push_pop():
        gpu.matrix.translate(xy)
        gpu.matrix.scale_uniform(rad)
        gpu_draw_shader('2D_UNIFORM_COLOR', 'LINE_STRIP', color, CIRCLE_WIRE_2D_POINTS, None, line_width)


def draw_circle_cursor_3d(context, obmat, loc, nor, rad, runtime_data: RuntimeData, clone_source=None):
    with gpu.matrix.push_pop():
        window = context.window
        region = context.region
        rv3d = context.region_data
        obmat_ = obmat @ Matrix.Translation(loc)
        z_axis = Vector((0, 0, 1))
        rotmat = z_axis.rotation_difference(nor).to_matrix().to_4x4()
        gpu.state.viewport_set(region.x, region.y, region.width, region.height)
        gpu.matrix.load_identity()
        gpu.matrix.push_projection()
        gpu.matrix.load_projection_matrix(rv3d.window_matrix)
        gpu.matrix.load_matrix(rv3d.view_matrix)

        if runtime_data.pack_source_circle:
            runtime_data.source_circle.clear()
            runtime_data.pack_source_circle = False
            for point in CIRCLE_WIRE_3D_POINTS:
                runtime_data.source_circle.append(obmat_ @ rotmat @ (Vector(point) * rad))
        if runtime_data.show_clone_circle and runtime_data.source_circle:
            gpu_draw_shader('3D_UNIFORM_COLOR', 'LINE_STRIP', (1, 0, 0, 0.7), runtime_data.source_circle, None, 2)

        if clone_source:
            gpu_draw_shader('3D_UNIFORM_COLOR', 'LINES', (0, 1, 0, 0.7), clone_source[0], clone_source[1])

        gpu.matrix.push()
        gpu.matrix.multiply_matrix(obmat_)
        gpu.matrix.multiply_matrix(rotmat)
        gpu.matrix.scale_uniform(rad)
        # bgl.glEnable(bgl.GL_LINE_SMOOTH)
        gpu_draw_shader('3D_UNIFORM_COLOR', 'LINE_STRIP', (1, 1, 0, 0.7), CIRCLE_WIRE_3D_POINTS, None, 2)
        gpu_draw_shader('3D_UNIFORM_COLOR', 'LINES', (1, 1, 0, 0.7), [(0, 0, 0), (0, 0, 2)], None, 2)
        # bgl.glDisable(bgl.GL_LINE_SMOOTH)
        gpu.matrix.pop()

        gpu.matrix.pop_projection()
        gpu.state.viewport_set(0, 0, window.width, window.height)


class BrushType:
    COMB = 0
    SMOOTH = 1
    ADD = 2
    LENGTH = 3
    PUFF = 4
    SNAKE_HOOK = 5
    ORIENT = 6
    BEND = 7
    TWIST = 8
    PART = 9
    NOISE = 10
    ATTRACT = 11
    WEIGTH = 12
    CLONE = 13
    COLOR = 14

    @classmethod
    def add(cls, brush_cls):
        if brush_cls.bl_idname not in cls._BRUSH_TYPES:
            cls._BRUSH_TYPES[brush_cls.bl_idname] = brush_cls

    @classmethod
    def get(cls, brush_idname: str) -> 'HairBrush3D':
        return cls._BRUSH_TYPES[brush_idname]

    @classmethod
    def contains(cls, brush_idname: str):
        return brush_idname in cls._BRUSH_TYPES


class HairBrush3D(WorkSpaceTool):
    bl_space_type = 'VIEW_3D'
    bl_widget = None
    builtin_brush_id = ""
    support_2d = True
    support_3d = True

    @classmethod
    def can_cancel(cls, hb3, on_mesh):
        return hb3.use_3d_brush and not hb3.auto_switch_mode and not on_mesh

    @classmethod
    def can_to_builtin(cls, hb3, on_mesh):
        if not cls.builtin_brush_id:
            return False
        return not hb3.use_3d_brush or (hb3.auto_switch_mode and not on_mesh)

    @classmethod
    def can_update_3d_cursor(cls, hb3):
        return hb3.use_3d_brush


class HairBrush3DEdit:
    def get_view3d_clip_range(self, context: bpy.types.Context):
        clip_start = 0.1
        clip_end = 100

        v3d = context.space_data
        rv3d = context.region_data
        if v3d and rv3d:
            clip_start, clip_end = v3d.clip_start, v3d.clip_end
            if rv3d.view_perspective == 'CAMERA':
                if v3d.camera and v3d.camera.type == 'CAMERA':
                    deps = context.evaluated_depsgraph_get()
                    cam = v3d.camera.evaluated_get(deps)
                    clip_start, clip_end = cam.data.clip_start, cam.data.clip_end
            elif rv3d.view_perspective == 'ORTHO':
                clip_end *= 0.5
                clip_start = -clip_end
        return clip_start, clip_end

    def create_mesh_surface_batch(self, mesh):
        mesh.calc_loop_triangles()

        vertices = np.empty((len(mesh.vertices), 3), 'f')
        indices = np.empty((len(mesh.loop_triangles), 3), 'i')

        mesh.vertices.foreach_get("co", np.reshape(vertices, len(mesh.vertices) * 3))
        mesh.loop_triangles.foreach_get("vertices", np.reshape(indices, len(mesh.loop_triangles) * 3))

        fmt = gpu.types.GPUVertFormat()
        fmt.attr_add(id="pos", comp_type='F32', len=3, fetch_mode='FLOAT')
        vbo = gpu.types.GPUVertBuf(len=len(vertices), format=fmt)
        vbo.attr_fill("pos", vertices)
        ibo = gpu.types.GPUIndexBuf(type='TRIS', seq=indices)
        return gpu.types.GPUBatch(type='TRIS', buf=vbo, elem=ibo)

    def get_object_depth_buffers(self, context, obj, symm_axis=None, symm_obmat=None):
        region = context.region
        rv3d = context.region_data

        size = (region.width, region.height)

        bs = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
        batch = batch_for_shader(bs, 'POINTS', {"pos": ((1, 1),)})
        shader = gpu.types.GPUShader(vertex_shader, fragment_shader)
        depth_tex = gpu.types.GPUTexture(size, format='DEPTH_COMPONENT24')
        frame_buf = gpu.types.GPUFrameBuffer(depth_slot=depth_tex)
        # frame_buf.viewport_set(region.x, region.y, size[0], size[1])
        depth_bufs = []
        view_mats = [rv3d.view_matrix]

        with frame_buf.bind():
            gpu.state.depth_test_set('LESS_EQUAL')
            gpu.state.depth_mask_set(True)
            mesh_batch = None
            ori_batch = None
            for view_mat in view_mats:
                frame_buf.clear(color=(0, 0, 0, 1), depth=1.0)
                # gpu.state.color_mask_set(False, False, False, False)
                with gpu.matrix.push_pop():
                    gpu.matrix.load_identity()
                    gpu.matrix.load_projection_matrix(rv3d.window_matrix)
                    gpu.matrix.load_matrix(view_mat)
                    gpu.matrix.multiply_matrix(obj.matrix_world)
                    if mesh_batch is None:
                        ori_batch = particle_hook.set_mesh_surface_gpu_batch(batch, obj.data.as_pointer())
                        if ori_batch:
                            mesh_batch = batch
                        else:
                            mesh_batch = self.create_mesh_surface_batch(obj.data)
                    mesh_batch.draw(shader)
                    depth_bufs.append(depth_tex.read())
            if ori_batch:
                particle_hook.restore_gpu_batch(batch, ori_batch)
            gpu.matrix.load_matrix(rv3d.view_matrix)
            gpu.state.depth_mask_set(False)
            gpu.state.depth_test_set('NONE')

        return depth_bufs

    def set_common_edit_args(self, context, edit_args, hb3, brush_type, runtime_data, flag):
        edit_args['brush_type'] = brush_type.brush_type
        edit_args['rad_3d'] = runtime_data.rad_3d
        edit_args['flag'] = flag
        edit_args['strength_adjust'] = hb3.strength_adjust
        edit_args['smooth_mode'] = 0 if hb3.smooth_mode == 'SHAPE' else 1
        edit_args['limited_length'] = hb3.limited_length
        edit_args['orient_mode'] = get_enum_item_num(OrientModeEnumItems, hb3.orient_mode, 0)
        edit_args['curving'] = hb3.curving
        edit_args['weight_mode'] = get_enum_item_num(WeightModeEnumItems, hb3.weight_mode, 0)
        edit_args['attract_method'] = 0 if hb3.attract_method == "HEAD" else 1
        edit_args['continuous_attract'] = hb3.continuous_attract
        edit_args['random_control'] = hb3.random_control
        edit_args['percent_control'] = hb3.percent_control
        edit_args['attract_mode'] = 0 if hb3.attract_mode == "POINT" else 1
        edit_args['head_strength'] = hb3.head_strength
        edit_args['middle_strength'] = hb3.middle_strength
        edit_args['endpoint_strength'] = hb3.endpoint_strength
        edit_args['rough_seed'] = hb3.rough_seed
        edit_args['noise_flag'] = get_noise_flag(hb3)
        edit_args['clip_range'] = self.get_view3d_clip_range(context)
        edit_args['clone_mode'] = 0 if hb3.clone_mode == "CLONE_DRAW" else 1
        edit_args['clone_coordinate'] = get_enum_item_num(CloneCoordinateEnumItems, hb3.clone_coordinate, 0)
        edit_args['clone_rotation_angle'] = hb3.clone_rotation_angle
        edit_args['brush_color'] = (hb3.brush_color.r, hb3.brush_color.g, hb3.brush_color.b)
        edit_args['falloff_shape'] = 0 if hb3.falloff_shape == "SPHERE" else 1
        edit_args['rotation_direction'] = 0 if hb3.rotation_direction == "CCW" else 1
        edit_args['direction_random'] = hb3.direction_random
        edit_args['strength_random'] = hb3.strength_random

    def ensure_apply_do(self, on_mesh):
        if not self.brush_support_3d:
            return True
        if self.use_3d:
            return not (self.start_on_mesh ^ on_mesh)
        return self.brush_support_2d

    def brush_edit_exit(self, context):
        if self.edit_data:
            particle_hook.free_brush_edit_data(self.edit_data)
            self.edit_data = None

    def apply_brush_edit(self, obj, event: bpy.types.Event, runtime_data):
        if particle_hook.apply_brush_edit(
                self.edit_data,
                (event.mouse_region_x, event.mouse_region_y),
                runtime_data.loc_world.to_tuple(),
                runtime_data.nor_world.to_tuple(),
                event.pressure,
                event.shift):
            obj.update_tag(refresh={'DATA'})
            return True
        return False


class HairBrush3DToolOptions:
    bl_label = "3D Brush Options"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tool"

    def draw_options(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False  # No animation.
        hb3 = context.scene.hair_brush_3d

        layout.prop(hb3, "use_3d_brush")
        col = layout.column()
        col.prop(hb3, "auto_switch_mode")
        col.prop(hb3, "scale_size")
        col.enabled = hb3.use_3d_brush
