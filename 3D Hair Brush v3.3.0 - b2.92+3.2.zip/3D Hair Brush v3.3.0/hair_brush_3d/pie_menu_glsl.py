# ##### BEGIN GPL LICENSE BLOCK #####
#
#  Copyright (C) 2022 VFX Grace - All Rights Reserved
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####

solid_circle_vs = '''
in vec2 vert_pos;
uniform mat4 ModelViewProjectionMatrix;
uniform vec2 center;
void main(){
    gl_Position=ModelViewProjectionMatrix*vec4(vert_pos+center,0,1);
}
'''

solid_circle_fs = '''
out vec4 frag_color;
uniform vec4 color;

void main(){
    frag_color=blender_srgb_to_framebuffer_space(color);
}
'''

radial_lines_vs = '''
in vec2 vert_pos;
uniform mat4 ModelViewProjectionMatrix;
uniform vec2 center;
void main(){
    gl_Position=ModelViewProjectionMatrix*vec4(vert_pos+center,0,1);
}
'''

radial_lines_fs = '''
out vec4 frag_color;

void main(){
    frag_color=blender_srgb_to_framebuffer_space(vec4(0.7, 0.7, 0.7, 1));
}
'''

acr_active_vs = '''
in vec2 vert_pos;
uniform mat4 ModelViewProjectionMatrix;
uniform vec2 center;
uniform float index;

float seg_rad=radians(60*index+ 5*vert_pos.x);

void main()
{
vec4 pos;
if(vert_pos.x==0 && vert_pos.y==0)
    pos=vec4(center.x,center.y,0,1);
else
    pos=vec4(center.x+cos(seg_rad)*vert_pos.y , center.y+sin(seg_rad)*vert_pos.y, 0, 1);

gl_Position=ModelViewProjectionMatrix*pos;
}
'''

acr_active_fs = '''
out vec4 frag_color;
uniform vec4 color;

void main(){
    frag_color=blender_srgb_to_framebuffer_space(color);
}
'''

icon_2d_vs = '''
in vec2 vert_pos;
in vec2 tex_coord;
uniform mat4 ModelViewProjectionMatrix;
uniform vec2 center;
out vec2 tex_cord;
void main(){
    gl_Position=ModelViewProjectionMatrix*vec4(vert_pos+center,0,1);
    tex_cord=tex_coord;
}
'''

icon_2d_fs = '''
out vec4 frag_color;
uniform sampler2D image;
in vec2 tex_cord;

void main(){
    frag_color=blender_srgb_to_framebuffer_space(texture(image, tex_cord));
}
'''