# ##### BEGIN GPL LICENSE BLOCK #####
#
#  Copyright (C) 2022 VFX Grace - All Rights Reserved
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####

import bpy
from bpy.types import Operator, Panel
from bpy.props import BoolProperty, IntProperty, EnumProperty
from bl_ui.space_toolsystem_common import ToolSelectPanelHelper
from .utils import ColorGroupManager, get_enum_item_num, isect_object_from_2d_coord
from .brush_common import (BrushType, HairBrush3D, HairBrush3DEdit, HairBrush3DToolOptions,
                           RuntimeData, EditArgsFlag, draw_circle_cursor_2d,
                           draw_circle_cursor_3d)
from .props import HairBrush3DCommonProps, HairColorFlag, CloneCoordinateEnumItems
from .draw_hair import update_hair_color, ColorUpdateFlag, hide_guide_path
from .particle_hook import particle_hook
from . import tool_changed_event_handlers

CURSOR_COLOR_2D = (1, 1, 1, 0.6)

G_runtime_data = RuntimeData()


class ParticleBrushType(BrushType):
    _BRUSH_TYPES = {}


class ParticleBrush3D(HairBrush3D):
    bl_context_mode = 'PARTICLE'
    bl_keymap = (
        ("particle.brush3d_edit", {"type": 'LEFTMOUSE', "value": 'PRESS'}, {"properties": []}),
        ("particle.brush3d_edit", {"type": 'LEFTMOUSE', "value": 'PRESS', "shift": True}, {"properties": []}),)

    @staticmethod
    def poll(obj):
        def is_psys_shown_hair(obj, psys):
            for mod in obj.modifiers:
                if mod.type == 'PARTICLE_SYSTEM' and mod.particle_system == psys:
                    return mod.show_viewport and psys.settings.type == 'HAIR'
            return False

        if (obj and obj.hide_viewport is False and obj.particle_systems.active and
                is_psys_shown_hair(obj, obj.particle_systems.active)):
            return True
        return False

    @staticmethod
    def draw_common_options(context, layout, draw_strenght=True, draw_adjust=True):
        pe = context.tool_settings.particle_edit
        hb3 = context.scene.hair_brush_3d
        layout.prop(pe.brush, "size", slider=True)
        if draw_strenght:
            layout.prop(pe.brush, "strength", slider=True)
        if draw_adjust:
            layout.prop(hb3, "strength_adjust")

    @staticmethod
    def draw_common_cursor(context, xy, tool):
        brush = context.tool_settings.particle_edit.brush
        region = context.region
        rv3d = context.region_data
        if not hasattr(context.scene, "hair_brush_3d"):
            return

        hb3 = context.scene.hair_brush_3d
        if tool.support_3d and tool.can_update_3d_cursor(hb3):
            on_mesh, loc, nor = isect_object_from_2d_coord(region, rv3d, context.object, xy)
            obmat = context.object.matrix_world
            G_runtime_data.update_on_mesh_status(on_mesh, obmat, loc, nor)

            if hb3.use_3d_brush:
                if on_mesh:
                    clone_source = None
                    G_runtime_data.update_brush_size(hb3, brush, obmat, loc, region, rv3d)
                    if (hb3.clone_realtime_show and G_runtime_data.show_clone_circle
                            and G_runtime_data.source_circle):
                        clone_source = particle_hook.get_clone_source_for_draw(
                            0,
                            context.scene.as_pointer(),
                            context.object.as_pointer(),
                            context.object.particle_systems.active.as_pointer(),
                            G_runtime_data.loc_world.to_tuple(),
                            G_runtime_data.nor_world.to_tuple(),
                            G_runtime_data.rad_3d,
                            get_enum_item_num(CloneCoordinateEnumItems, hb3.clone_coordinate, 0),
                            hb3.clone_rotation_angle)
                    draw_circle_cursor_3d(
                        context, obmat, loc, nor, hb3.unprojected_rad, G_runtime_data, clone_source)
                    return
                else:
                    if not hb3.auto_switch_mode:
                        return

        draw_circle_cursor_2d(xy, brush.size, CURSOR_COLOR_2D, 2)

    def draw_cursor(context, tool, xy):
        if ParticleBrush3D.poll(context.object) and ParticleBrushType.contains(tool.idname):
            ParticleBrush3D.draw_common_cursor(context, xy, ParticleBrushType.get(tool.idname))


class BaseOperator(Operator):
    bl_label = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context: bpy.types.Context):
        obj = context.object
        return obj and obj.mode == 'PARTICLE_EDIT' and obj.particle_systems.active.settings.type == 'HAIR'


class PARTICLE_OT_HairBrush3DEdit(BaseOperator, HairBrush3DEdit):
    bl_idname = "particle.brush3d_edit"
    bl_label = "Brush 3D Edit"
    bl_description = "Apply brush 3D edit"

    def brush_edit_exit(self, context):
        HairBrush3DEdit.brush_edit_exit(self, context)
        if self.cur_active_tool == "hair_brush_3d.Color":
            ColorGroupManager.generate_color_groups(context.object.particle_systems.active)
            update_hair_color(context, ColorUpdateFlag.FORCE_TEX)

    def modal(self, context, event: bpy.types.Event):
        context.area.tag_redraw()
        if event.type in ('LEFTMOUSE', 'MIDDLEMOUSE', 'RIGHTMOUSE'):
            if event.value == 'RELEASE':
                self.brush_edit_exit(context)
                return {'FINISHED'}
        elif event.type == 'MOUSEMOVE' and self.ensure_apply_do(G_runtime_data.on_mesh):
            if (self.apply_brush_edit(self.obj, event, G_runtime_data)
                    and self.cur_active_tool == "hair_brush_3d.Color"
                    and self.update_color_realtime):
                update_hair_color(context, ColorUpdateFlag.FORCE_TEX)
        return {'RUNNING_MODAL'}

    def build_edit_args(self, context, hb3, brush_type, flag):
        edit_args = dict()
        edit_args['hair_type'] = 0
        self.set_common_edit_args(context, edit_args, hb3, brush_type, G_runtime_data, flag)
        brush_data = HairBrush3DCommonProps.get_brush_data(hb3)
        if hb3.brush_data is None:
            hb3.brush_data = brush_data
        brush_data.curve.update()
        edit_args['brush_data'] = brush_data.as_pointer()
        return edit_args

    def invoke(self, context: bpy.types.Context, event):
        if not ParticleBrush3D.poll(context.object):
            return {'CANCELLED'}

        hb3 = context.scene.hair_brush_3d
        self.cur_active_tool = ToolSelectPanelHelper.tool_active_from_context(context).idname
        if not ParticleBrushType.contains(self.cur_active_tool):
            return {'CANCELLED'}

        brush_type = ParticleBrushType.get(self.cur_active_tool)
        if brush_type.can_cancel(hb3, G_runtime_data.on_mesh):
            return {'CANCELLED'}

        if (self.cur_active_tool == "hair_brush_3d.Clone" and hb3.clone_mode != "CLONE_SOURCE"
                and not event.shift and not G_runtime_data.source_circle):
            return {'CANCELLED'}

        pe = context.tool_settings.particle_edit
        if brush_type.builtin_brush_id:
            brush = pe.brush
            cur_count = brush.count
            cur_size = brush.size
            cur_steps = brush.steps
            cur_strength = brush.strength
            bpy.ops.wm.tool_set_by_id(name=brush_type.builtin_brush_id)
            brush = pe.brush
            brush.count = cur_count
            brush.size = cur_size
            brush.steps = cur_steps
            brush.strength = cur_strength
            if brush_type.can_to_builtin(hb3, G_runtime_data.on_mesh):
                bpy.ops.particle.brush_edit('INVOKE_DEFAULT')
                bpy.ops.wm.tool_set_by_id(name=self.cur_active_tool)
                return {'FINISHED'}
            bpy.ops.wm.tool_set_by_id(name=self.cur_active_tool)

        self.obj = context.object
        deps = context.evaluated_depsgraph_get()
        evaled_obj = context.object.evaluated_get(depsgraph=deps)
        depth_bufs = self.get_object_depth_buffers(context, evaled_obj)
        if not depth_bufs:
            self.report({'ERROR'}, "Failed to get the depth of the object, please make sure it's visible in view")
            return {'CANCELLED'}

        psys = context.object.particle_systems.active
        par_num = len(psys.particles)
        if self.cur_active_tool == "hair_brush_3d.Color" and par_num:
            if "hair_color__" not in psys.settings:
                psys.settings["hair_color__"] = [0.0] * (3 * par_num)
            elif len(psys.settings["hair_color__"]) != 3 * par_num:
                self.report({'ERROR'},
                            "The hair count is different from that recorded in the color groups. Please delete all color groups and then repaint the hair.")
                return {"CANCELLED"}

        self.brush_support_2d = brush_type.support_2d
        self.brush_support_3d = brush_type.support_3d
        self.start_on_mesh = False
        self.use_3d = False
        flag = 0
        if (hb3.use_3d_brush and self.brush_support_3d) or not self.brush_support_2d:
            flag |= EditArgsFlag.USE_3D
            self.use_3d = True
        if G_runtime_data.on_mesh:
            self.start_on_mesh = True
            if self.brush_support_3d:
                flag |= EditArgsFlag.ON_MESH
        if hb3.scale_size:
            flag |= EditArgsFlag.USE_SCALE

        edit_args = self.build_edit_args(context, hb3, brush_type, flag)
        if self.cur_active_tool == "hair_brush_3d.SnakeHook" and hb3.falloff_shape == 'SPHERE':
            on_mesh, loc, nor = isect_object_from_2d_coord(
                context.region, context.region_data, context.object, (event.mouse_region_x, event.mouse_region_y))
            if on_mesh:
                edit_args['flag'] |= EditArgsFlag.ON_MESH
                obmat = context.object.matrix_world
                G_runtime_data.update_on_mesh_status(on_mesh, obmat, loc, nor)
            edit_args['widget_unit'] = particle_hook.get_widget_unit(context.preferences.as_pointer())

        self.edit_data = particle_hook.init_brush_edit_data(
            context.as_pointer(),
            deps.as_pointer(),
            context.scene.as_pointer(),
            self.obj.as_pointer(),
            psys.as_pointer(),
            context.region.as_pointer(),
            context.space_data.as_pointer(),
            depth_bufs,
            edit_args
        )
        if self.edit_data is None:
            return {'CANCELLED'}

        if self.cur_active_tool == "hair_brush_3d.Clone":
            if hb3.clone_mode == "CLONE_SOURCE" or event.shift:
                G_runtime_data.pack_source_circle = True
                G_runtime_data.has_clone_source = particle_hook.set_clone_source(
                    self.edit_data,
                    (event.mouse_region_x, event.mouse_region_y),
                    G_runtime_data.loc_world.to_tuple(),
                    G_runtime_data.nor_world.to_tuple()) > 0
                G_runtime_data.show_clone_circle = G_runtime_data.has_clone_source
            else:
                self.apply_brush_edit(self.obj, event, G_runtime_data)
                context.area.tag_redraw()
            self.brush_edit_exit(context)
            return {'FINISHED'}

        if self.cur_active_tool == "hair_brush_3d.Color":
            ColorGroupManager.backup_hair_color(psys.settings, backup_all=True)
        self.update_color_realtime = hb3.update_color_realtime
        self.apply_brush_edit(self.obj, event, G_runtime_data)

        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}


class PARTICLE_TOOL_Brush3DComb(ParticleBrush3D):
    # The prefix of the idname should be your add-on name.
    bl_idname = "hair_brush_3d.Comb"
    bl_label = "Comb"
    bl_icon = "brush3d.particle.comb"

    builtin_brush_id = "builtin_brush.Comb"
    brush_type = BrushType.COMB

    def draw_settings(context: bpy.types.Context, layout: bpy.types.UILayout, tool):
        ParticleBrush3D.draw_common_options(context, layout)
        settings = context.tool_settings.particle_edit
        layout.prop(settings, "use_emitter_deflect", text="Deflect Emitter")
        sub = layout.row()
        sub.active = settings.use_emitter_deflect
        sub.prop(settings, "emitter_distance", text="Distance")


class PARTICLE_TOOL_Brush3DSmooth(ParticleBrush3D):
    bl_idname = "hair_brush_3d.Smooth"
    bl_label = "Smooth"
    bl_icon = "brush3d.particle.smooth"

    builtin_brush_id = "builtin_brush.Smooth"
    brush_type = BrushType.SMOOTH

    @classmethod
    def can_to_builtin(cls, hb3, on_mesh):
        return hb3.smooth_mode == 'SHAPE' and HairBrush3D.can_to_builtin(hb3, on_mesh)

    def draw_settings(context, layout, tool):
        ParticleBrush3D.draw_common_options(context, layout, draw_adjust=False)
        hb3 = context.scene.hair_brush_3d
        layout.prop(hb3, "smooth_mode", expand=True)


class PARTICLE_TOOL_Brush3DAdd(ParticleBrush3D):
    bl_idname = "hair_brush_3d.Add"
    bl_label = "Add"
    bl_icon = "brush3d.particle.add"

    builtin_brush_id = "builtin_brush.Add"
    brush_type = BrushType.ADD

    @classmethod
    def can_cancel(cls, hb3, on_mesh):
        return hb3.use_3d_brush and not on_mesh

    def draw_settings(context, layout, tool):
        ParticleBrush3D.draw_common_options(context, layout, False, draw_adjust=False)
        settings = context.tool_settings.particle_edit
        brush = settings.brush
        layout.prop(brush, "count")
        layout.prop(settings, "use_default_interpolate")
        layout.prop(brush, "steps", slider=True)
        layout.prop(settings, "default_key_count", slider=True)


class PARTICLE_TOOL_Brush3DLength(ParticleBrush3D):
    bl_idname = "hair_brush_3d.Length"
    bl_label = "Length"
    bl_description = "Works in 2D mode only"
    bl_icon = "brush3d.particle.length"

    builtin_brush_id = "builtin_brush.Length"
    support_3d = False
    brush_type = BrushType.LENGTH

    @classmethod
    def can_cancel(cls, hb3, on_mesh):
        return False

    @classmethod
    def can_to_builtin(cls, hb3, on_mesh):
        return hb3.limited_length == 0.0

    def draw_settings(context, layout, tool):
        ParticleBrush3D.draw_common_options(context, layout, draw_adjust=False)
        brush = context.tool_settings.particle_edit.brush
        hb3 = context.scene.hair_brush_3d
        layout.row().prop(brush, "length_mode", expand=True)
        layout.prop(hb3, "limited_length")

    def draw_cursor(context, tool, xy):
        if ParticleBrush3D.poll(context.object):
            draw_circle_cursor_2d(
                xy, context.tool_settings.particle_edit.brush.size, CURSOR_COLOR_2D, 2)


class PARTICLE_TOOL_Brush3DPuff(ParticleBrush3D):
    bl_idname = "hair_brush_3d.Puff"
    bl_label = "Puff"
    bl_icon = "brush3d.particle.puff"

    builtin_brush_id = "builtin_brush.Puff"
    brush_type = BrushType.PUFF

    def draw_settings(context, layout, tool):
        ParticleBrush3D.draw_common_options(context, layout, draw_adjust=False)
        brush = context.tool_settings.particle_edit.brush
        layout.row().prop(brush, "puff_mode", expand=True)
        layout.prop(brush, "use_puff_volume")


class PARTICLE_TOOL_Brush3DSnakeHook(ParticleBrush3D):
    bl_idname = "hair_brush_3d.SnakeHook"
    bl_label = "Snake Hook"
    bl_icon = "brush3d.particle.snake_hook"

    support_3d = False
    brush_type = BrushType.SNAKE_HOOK

    @classmethod
    def can_cancel(cls, hb3, on_mesh):
        return False

    @classmethod
    def draw_falloff_settings(cls, layout, brush, prop_text=""):
        col = layout.column(align=True)
        row = col.row(align=True)
        row.prop(brush, "curve_preset", text=prop_text)

        if brush.curve_preset == 'CUSTOM':
            layout.template_curve_mapping(brush, "curve", brush=True)

            col = layout.column(align=True)
            row = col.row(align=True)
            row.operator(PARTICLE_OT_BrushCurvePreset.bl_idname, icon='SMOOTHCURVE', text="").shape = 'SMOOTH'
            row.operator(PARTICLE_OT_BrushCurvePreset.bl_idname, icon='SPHERECURVE', text="").shape = 'ROUND'
            row.operator(PARTICLE_OT_BrushCurvePreset.bl_idname, icon='ROOTCURVE', text="").shape = 'ROOT'
            row.operator(PARTICLE_OT_BrushCurvePreset.bl_idname, icon='SHARPCURVE', text="").shape = 'SHARP'
            row.operator(PARTICLE_OT_BrushCurvePreset.bl_idname, icon='LINCURVE', text="").shape = 'LINE'
            row.operator(PARTICLE_OT_BrushCurvePreset.bl_idname, icon='NOCURVE', text="").shape = 'MAX'

    def draw_settings(context, layout, tool):
        region_type = context.region.type
        ParticleBrush3D.draw_common_options(context, layout, draw_adjust=False)
        hb3 = context.scene.hair_brush_3d
        layout.prop(hb3, "falloff_shape", expand=True)
        if region_type == 'TOOL_HEADER':
            layout.popover("VIEW3D_PT_tools_particle_brush_falloff")
        else:
            PARTICLE_TOOL_Brush3DSnakeHook.draw_falloff_settings(
                layout, HairBrush3DCommonProps.get_brush_data(hb3), "Falloff Curve")

    def draw_cursor(context, tool, xy):
        if ParticleBrush3D.poll(context.object):
            draw_circle_cursor_2d(
                xy, context.tool_settings.particle_edit.brush.size, CURSOR_COLOR_2D, 2)


class PARTICLE_TOOL_Brush3DOrient(ParticleBrush3D):
    bl_idname = "hair_brush_3d.Orient"
    bl_label = "Orient"
    bl_icon = "brush3d.particle.orient"

    brush_type = BrushType.ORIENT

    @classmethod
    def can_update_3d_cursor(cls, hb3):
        return hb3.use_3d_brush or hb3.orient_mode in {'SUNDER', 'REPEL'}

    def draw_settings(context: bpy.types.Context, layout: bpy.types.UILayout, tool):
        ParticleBrush3D.draw_common_options(context, layout)
        hb3 = context.scene.hair_brush_3d
        layout.prop(hb3, "orient_mode", expand=True)
        layout.prop(hb3, "curving")


class PARTICLE_TOOL_Brush3DBend(ParticleBrush3D):
    bl_idname = "hair_brush_3d.Bend"
    bl_label = "Bend"
    bl_icon = "brush3d.particle.bend"

    brush_type = BrushType.BEND

    def draw_settings(context: bpy.types.Context, layout: bpy.types.UILayout, tool):
        ParticleBrush3D.draw_common_options(context, layout, draw_adjust=False)


class PARTICLE_TOOL_Brush3DTwist(ParticleBrush3D):
    bl_idname = "hair_brush_3d.Twist"
    bl_label = "Twist"
    bl_icon = "brush3d.particle.twist"

    support_2d = False
    brush_type = BrushType.TWIST

    @classmethod
    def can_cancel(cls, hb3, on_mesh):
        return not hb3.use_3d_brush or not on_mesh

    def draw_settings(context: bpy.types.Context, layout: bpy.types.UILayout, tool):
        ParticleBrush3D.draw_common_options(context, layout)
        hb3 = context.scene.hair_brush_3d
        layout.prop(hb3, "rotation_direction", expand=True)
        layout.prop(hb3, "direction_random", slider=True)
        layout.prop(hb3, "strength_random", slider=True)


class PARTICLE_TOOL_Brush3DPart(ParticleBrush3D):
    bl_idname = "hair_brush_3d.Part"
    bl_label = "Part"
    bl_icon = "brush3d.particle.part"

    brush_type = BrushType.PART

    @classmethod
    def can_update_3d_cursor(cls, hb3):
        return True

    def draw_settings(context: bpy.types.Context, layout: bpy.types.UILayout, tool):
        ParticleBrush3D.draw_common_options(context, layout, draw_adjust=False)


class PARTICLE_TOOL_Brush3DWeight(ParticleBrush3D):
    bl_idname = "hair_brush_3d.Weight"
    bl_label = "Weight"
    bl_description = "Works in 2D mode only"
    bl_icon = "brush3d.particle.weight"

    builtin_brush_id = "builtin_brush.Weight"
    support_3d = False
    brush_type = BrushType.WEIGTH

    @classmethod
    def can_cancel(cls, hb3, on_mesh):
        return False

    @classmethod
    def can_to_builtin(cls, hb3, on_mesh):
        return hb3.weight_mode == 'DEFAULT'

    def draw_settings(context: bpy.types.Context, layout: bpy.types.UILayout, tool):
        ParticleBrush3D.draw_common_options(context, layout, draw_adjust=False)
        hb3 = context.scene.hair_brush_3d
        layout.prop(hb3, "weight_mode", expand=True)

    def draw_cursor(context, tool, xy):
        if ParticleBrush3D.poll(context.object):
            draw_circle_cursor_2d(
                xy, context.tool_settings.particle_edit.brush.size, CURSOR_COLOR_2D, 2)


class PARTICLE_TOOL_Brush3DNoise(ParticleBrush3D):
    bl_idname = "hair_brush_3d.Noise"
    bl_label = "Noise"
    bl_icon = "brush3d.particle.noise"

    brush_type = BrushType.NOISE

    def draw_settings(context: bpy.types.Context, layout: bpy.types.UILayout, tool):
        hb3 = context.scene.hair_brush_3d
        if not hb3.use_rough:
            ParticleBrush3D.draw_common_options(context, layout, True, False)
            layout.prop(hb3, "use_rough")
            layout.prop(hb3, "head_strength", slider=True)
            layout.prop(hb3, "middle_strength", slider=True)
        else:
            ParticleBrush3D.draw_common_options(context, layout, False, False)
            layout.prop(hb3, "use_rough")
            layout.prop(hb3, "reset_pose")
            layout.prop(hb3, "head_strength", text="Uniform", slider=True)
            layout.prop(hb3, "endpoint_strength", text="Endpoint", slider=True)
            layout.prop(hb3, "middle_strength", text="Random", slider=True)
            if not hb3.automatic_seed:
                layout.prop(hb3, "rough_seed")
            layout.prop(hb3, "automatic_seed")

        row = layout.row(align=True)
        row.label(icon='LOCKED')
        sub = row.row(align=True)
        sub.scale_x = 0.7
        sub.prop(hb3, "use_lock_x", text="X", toggle=True)
        sub.prop(hb3, "use_lock_y", text="Y", toggle=True)
        sub.prop(hb3, "use_lock_z", text="Z", toggle=True)


class PARTICLE_TOOL_Brush3DAttract(ParticleBrush3D):
    bl_idname = "hair_brush_3d.Attract"
    bl_label = "Attract"
    bl_icon = "brush3d.particle.attract"

    brush_type = BrushType.ATTRACT

    def draw_settings(context: bpy.types.Context, layout: bpy.types.UILayout, tool):
        ParticleBrush3D.draw_common_options(context, layout)
        hb3 = context.scene.hair_brush_3d
        row = layout.row(align=True)
        row.scale_x = 0.8
        row.prop(hb3, "attract_method")
        layout.prop(hb3, "continuous_attract")
        layout.prop(hb3, "random_control", slider=True)
        layout.prop(hb3, "percent_control", slider=True)
        layout.prop(hb3, "attract_mode", expand=True)


class PARTICLE_TOOL_Brush3DClone(ParticleBrush3D):
    bl_idname = "hair_brush_3d.Clone"
    bl_label = "Clone"
    bl_icon = "brush3d.particle.clone"
    bl_description = "Works in 3D mode only"
    bl_keymap = (
        ("particle.brush3d_edit", {"type": 'LEFTMOUSE', "value": 'PRESS'}, {"properties": []}),
        ("particle.brush3d_edit", {"type": 'LEFTMOUSE', "value": 'PRESS', "shift": True}, {"properties": []}),
        ("hair_brush_3d.clone_rotate",
         {"type": 'WHEELUPMOUSE', "value": 'PRESS', "ctrl": True},
         {"properties": [("rotate_mode", 'ADD')]}),
        ("hair_brush_3d.clone_rotate",
         {"type": 'WHEELDOWNMOUSE', "value": 'PRESS', "ctrl": True},
         {"properties": [("rotate_mode", 'SUB')]}))

    support_2d = False
    brush_type = BrushType.CLONE

    @classmethod
    def can_cancel(cls, hb3, on_mesh):
        return not hb3.use_3d_brush or not on_mesh

    def draw_settings(context: bpy.types.Context, layout: bpy.types.UILayout, tool):
        ParticleBrush3D.draw_common_options(context, layout, False, False)
        hb3 = context.scene.hair_brush_3d
        layout.prop(hb3, "clone_mode", expand=True)
        layout.prop(hb3, "clone_coordinate")
        layout.prop(hb3, "clone_rotation_angle")
        layout.prop(hb3, "clone_realtime_show")


class PARTICLE_TOOL_Brush3DColor(ParticleBrush3D):
    bl_idname = "hair_brush_3d.Color"
    bl_label = "Color"
    bl_description = "Works in 2D mode only"
    bl_icon = "brush3d.particle.color"

    support_3d = False
    brush_type = BrushType.COLOR

    @classmethod
    def can_cancel(cls, hb3, on_mesh):
        return False

    def draw_settings(context: bpy.types.Context, layout: bpy.types.UILayout, tool):
        ParticleBrush3D.draw_common_options(context, layout, False, False)
        hb3 = context.scene.hair_brush_3d
        layout.prop(hb3, "show_hair_color")
        layout.prop(hb3, "update_color_realtime")
        row = layout.row(align=True)
        row.scale_x = 0.58
        row.prop(hb3, "brush_color")

    def draw_cursor(context, tool, xy):
        if ParticleBrush3D.poll(context.object):
            draw_circle_cursor_2d(
                xy, context.tool_settings.particle_edit.brush.size, CURSOR_COLOR_2D, 2)


class VIEW3D_PT_tools_particle_brush_3d_options(HairBrush3DToolOptions, Panel):
    bl_context = ".particlemode"
    bl_parent_id = "VIEW3D_PT_tools_particlemode_options"

    @classmethod
    def poll(cls, context):
        tc = ToolSelectPanelHelper.tool_active_from_context(context)
        return ParticleBrushType.contains(tc.idname) and ParticleBrushType.get(tc.idname).support_3d

    def draw(self, context):
        tc = ToolSelectPanelHelper.tool_active_from_context(context)
        if tc.idname == "hair_brush_3d.Color":
            return
        self.draw_options(context)


class PARTICLE_OT_DeleteColorGroup(BaseOperator):
    bl_idname = "particle.delete_color_group"
    bl_description = "Delete the active color group and reset the hair color"

    index: IntProperty(default=0, options={'HIDDEN', 'SKIP_SAVE'})

    def execute(self, context: bpy.types.Context):
        psys = context.object.particle_systems.active
        pset = psys.settings
        groups = pset.hair_color_groups
        if self.index >= len(groups):
            return {'CANCELLED'}

        if self.index == -1 or len(groups) <= 1:
            ColorGroupManager.backup_hair_color(pset, backup_all=True)
            ColorGroupManager.clear_color_groups(pset, ColorUpdateFlag.FORCE_TEX, context)
        else:  # self.index < len(groups)
            rgb = tuple(groups[self.index].rgb)
            ColorGroupManager.backup_hair_color(pset, rgb=rgb)
            ColorGroupManager.modify_color_groups(self, context, rgb, HairColorFlag.OP_DELETE, psys,
                                                  ColorUpdateFlag.FORCE_TEX)
        context.area.tag_redraw()
        return {'FINISHED'}


class PARTICLE_OT_UndoDelColorGroup(BaseOperator):
    bl_label = "Undo"
    bl_idname = "particle.undo_hair_color"
    bl_description = "Undo painting hair color or deleting color group. Note, once you change the amount of hairs then you can't undo anymore"

    @classmethod
    def poll(cls, context: bpy.types.Context):
        return BaseOperator.poll(context) and ColorGroupManager.undo_stack

    def execute(self, context: bpy.types.Context):
        psys = context.object.particle_systems.active
        if len(psys.particles) * 3 != ColorGroupManager.undo_stack[-1][-1]:
            ColorGroupManager.undo_stack = []
            self.report({'ERROR'}, "The count of the hair has changed, can't undo!")
            return {'CANCELLED'}

        ColorGroupManager.undo_hair_color(psys, context)
        context.area.tag_redraw()
        return {'FINISHED'}


class PARTICLE_OT_AssignColor2Selected(BaseOperator):
    bl_label = "Assign Color"
    bl_idname = "particle.assign_color2selected"
    bl_description = "Assign brush color to the selected hair"

    show_ui: BoolProperty(default=False, options={'HIDDEN', 'SKIP_SAVE'})

    def invoke(self, context: bpy.types.Context, event):
        if self.show_ui:
            return context.window_manager.invoke_props_popup(self, event)
        else:
            return self.execute(context)

    def draw(self, context):
        if self.show_ui:
            hb3 = context.scene.hair_brush_3d
            self.layout.prop(hb3, "brush_color")

    def execute(self, context: bpy.types.Context):
        psys = context.object.particle_systems.active
        pset = psys.settings
        if 'hair_color__' not in pset:
            pset["hair_color__"] = [0.0] * (3 * len(psys.particles))
        rgb = tuple(context.scene.hair_brush_3d.brush_color)
        ColorGroupManager.modify_color_groups(self, context, rgb, HairColorFlag.OP_ASSIGN, psys,
                                              ColorUpdateFlag.FORCE_TEX)

        context.area.tag_redraw()
        return {'FINISHED'}


class PARTICLE_OT_SelectInGroup(BaseOperator):
    bl_idname = "particle.select_hair_in_group"
    bl_label = ""
    option: IntProperty(default=HairColorFlag.OP_SELECT_ONLY, options={'HIDDEN', 'SKIP_SAVE'})

    @classmethod
    def description(cls, context, props):
        if props.option == HairColorFlag.OP_SELECT_ONLY:
            return "Select the hair in the active color group"
        else:
            return "Add the hair in the active color group to selection"

    def execute(self, context: bpy.types.Context):
        psys = context.object.particle_systems.active
        groups = psys.settings.hair_color_groups
        idx = psys.settings.color_group_idx
        if 0 <= idx < len(groups):
            rgb = tuple(groups[idx].rgb)
            particle_hook.set_hair_color_group(psys.as_pointer(), rgb, self.option)
            select_mode = context.tool_settings.particle_edit.select_mode
            context.tool_settings.particle_edit.select_mode = select_mode
        return {'FINISHED'}


class PARTICLE_OT_BrushCurvePreset(BaseOperator):
    """Set brush shape"""
    bl_idname = "particle.brush_curve_preset"
    bl_label = "Preset"
    bl_options = set()

    shape: EnumProperty(
        name="Mode",
        items=[('SMOOTH', "SMOOTH", "", 0),
               ('ROUND', "Round", "", 1),
               ('ROOT', "Root", "", 2),
               ('SHARP', "Sharp", "", 3),
               ('LINE', "Line", "", 4),
               ('MAX', "Max", "", 5)])

    def ensure_points_num(self, curve: bpy.types.CurveMap, num):
        while len(curve.points) < num:
            curve.points.new(1, 1)
        while len(curve.points) > num:
            curve.points.remove(curve.points[-1])

    def execute(self, context: bpy.types.Context):
        hb3 = context.scene.hair_brush_3d
        brush = HairBrush3DCommonProps.get_brush_data(hb3)
        if hb3.brush_data is None:
            hb3.brush_data = brush
        if len(brush.curve.curves) == 0:
            brush.curve.initialize()
        curve = brush.curve.curves[0]
        if self.shape == 'SMOOTH':
            self.ensure_points_num(curve, 4)
            curve.points[0].location = 0, 1
            curve.points[1].location = 0.25, 0.94
            curve.points[2].location = 0.75, 0.06
            curve.points[3].location = 1, 0
        elif self.shape == 'ROUND':
            self.ensure_points_num(curve, 4)
            curve.points[0].location = 0, 1
            curve.points[1].location = 0.5, 0.9
            curve.points[2].location = 0.86, 0.5
            curve.points[3].location = 1, 0
        elif self.shape == 'ROOT':
            self.ensure_points_num(curve, 4)
            curve.points[0].location = 0, 1
            curve.points[1].location = 0.25, 0.95
            curve.points[2].location = 0.75, 0.44
            curve.points[3].location = 1, 0
        elif self.shape == 'SHARP':
            self.ensure_points_num(curve, 4)
            curve.points[0].location = 0, 1
            curve.points[1].location = 0.25, 0.5
            curve.points[2].location = 0.75, 0.04
            curve.points[3].location = 1, 0
        elif self.shape == 'LINE':
            self.ensure_points_num(curve, 2)
            curve.points[0].location = brush.curve.clip_min_x, brush.curve.clip_max_y
            curve.points[1].location = brush.curve.clip_max_x, brush.curve.clip_min_y
        elif self.shape == 'MAX':
            self.ensure_points_num(curve, 2)
            curve.points[0].location = 0, 1
            curve.points[1].location = 1, 1
        brush.curve.update()
        return {'FINISHED'}


class PARTICLE_UL_color_group(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        row = layout.row(align=True)
        row.label(text=item.name)
        row.prop(item, "rgb_show", text="")


class VIEW3D_PT_hair_color_options(Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Tool"
    bl_context = ".particlemode"
    bl_label = "Hair Color Groups"

    # bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context: bpy.types.Context):
        return context.object.particle_systems.active.settings.type == 'HAIR'

    def draw(self, context):
        layout = self.layout
        layout.use_property_decorate = False  # No animation.
        self.draw_layout(layout, context)

    @classmethod
    def draw_layout(cls, layout, context, show_in_piemenu=False):
        hb3 = context.scene.hair_brush_3d
        pset = context.object.particle_systems.active.settings
        layout.prop(hb3, "show_hair_color", emboss=not show_in_piemenu)
        if not show_in_piemenu:
            layout.separator()
        row = layout.row(align=True)
        row.prop(hb3, "brush_color", text="")
        if show_in_piemenu:
            row.operator(PARTICLE_OT_AssignColor2Selected.bl_idname, text="Change Color").show_ui = True
            layout.separator()
            layout.operator(PARTICLE_OT_AssignColor2Selected.bl_idname).show_ui = False
            layout.separator()
        else:
            row.operator(PARTICLE_OT_AssignColor2Selected.bl_idname).show_ui = False
        layout.template_list("PARTICLE_UL_color_group", "", pset,
                             "hair_color_groups", pset, "color_group_idx")
        if "hair_color__" in pset and pset["hair_color__"]:
            row = layout.row(align=True)
            row.operator(PARTICLE_OT_SelectInGroup.bl_idname, text="Select  ").option = HairColorFlag.OP_SELECT_ONLY
            row.operator(PARTICLE_OT_SelectInGroup.bl_idname, text="Add  ").option = HairColorFlag.OP_SELECT_ADD
            row = layout.row(align=True)
            row.operator(PARTICLE_OT_DeleteColorGroup.bl_idname, text="Delete All").index = -1
            row.operator(PARTICLE_OT_DeleteColorGroup.bl_idname, text="Delete Active").index = pset.color_group_idx
            row.operator(PARTICLE_OT_UndoDelColorGroup.bl_idname)
        elif ColorGroupManager.undo_stack:
            layout.operator(PARTICLE_OT_UndoDelColorGroup.bl_idname)


class VIEW3D_PT_tools_particle_brush_falloff(Panel):
    bl_context = ".particlemode"  # dot on purpose (access from topbar)
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'TOOL_HEADER'
    bl_label = "Falloff"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        PARTICLE_TOOL_Brush3DSnakeHook.draw_falloff_settings(
            self.layout,
            HairBrush3DCommonProps.get_brush_data(context.scene.hair_brush_3d))


def on_tool_changed(context: bpy.context, idname):
    if context.mode != 'PARTICLE':
        return
    G_runtime_data.show_clone_circle = G_runtime_data.has_clone_source and idname == "hair_brush_3d.Clone"
    pe = context.tool_settings.particle_edit
    if idname == "hair_brush_3d.Weight" and pe.tool != 'WEIGHT':
        from . import activate_by_id_func
        activate_by_id_func(context, 'VIEW_3D', "builtin_brush.Weight")
    elif ParticleBrushType.contains(idname) and idname != "hair_brush_3d.Weight" and pe.tool == 'WEIGHT':
        from . import activate_by_id_func
        activate_by_id_func(context, 'VIEW_3D', "builtin_brush.Comb")


def draw_hide_guide_path(self, context):
    hb3 = context.scene.hair_brush_3d
    self.layout.prop(hb3, "hide_guide_path")


tools = (PARTICLE_TOOL_Brush3DComb, PARTICLE_TOOL_Brush3DSmooth,
         PARTICLE_TOOL_Brush3DAdd, PARTICLE_TOOL_Brush3DLength,
         PARTICLE_TOOL_Brush3DPuff, PARTICLE_TOOL_Brush3DSnakeHook,
         PARTICLE_TOOL_Brush3DOrient, PARTICLE_TOOL_Brush3DBend,
         PARTICLE_TOOL_Brush3DTwist, PARTICLE_TOOL_Brush3DPart,
         PARTICLE_TOOL_Brush3DNoise, PARTICLE_TOOL_Brush3DAttract,
         PARTICLE_TOOL_Brush3DWeight, PARTICLE_TOOL_Brush3DClone,
         PARTICLE_TOOL_Brush3DColor)

classes = [
    PARTICLE_OT_HairBrush3DEdit, VIEW3D_PT_tools_particle_brush_3d_options,
    PARTICLE_UL_color_group, VIEW3D_PT_hair_color_options, PARTICLE_OT_DeleteColorGroup,
    PARTICLE_OT_AssignColor2Selected, PARTICLE_OT_SelectInGroup, PARTICLE_OT_UndoDelColorGroup,
    PARTICLE_OT_BrushCurvePreset, VIEW3D_PT_tools_particle_brush_falloff
]


def register():
    from bpy.utils import register_class, register_tool
    tool_changed_event_handlers.append(on_tool_changed)
    for cls in classes:
        register_class(cls)

    for i, tool in enumerate(tools):
        ParticleBrushType.add(tool)
        register_tool(tool, separator=bool(i == 0))
    bpy.types.VIEW3D_PT_tools_particlemode_options_display.append(draw_hide_guide_path)

    particle_hook.set_particle_edit_tool_update_func(
        bpy.types.ParticleEdit.bl_rna.properties['tool'].as_pointer(), 1)


def unregister():
    from bpy.utils import unregister_class, unregister_tool
    for cls in reversed(classes):
        unregister_class(cls)

    for tool in tools:
        unregister_tool(tool)
    bpy.types.VIEW3D_PT_tools_particlemode_options_display.remove(draw_hide_guide_path)
    hide_guide_path(bpy.context, False)
    particle_hook.set_particle_edit_tool_update_func(
        bpy.types.ParticleEdit.bl_rna.properties['tool'].as_pointer(), 0)
