
def get_addon_preferences(context):
    return context.preferences.addons[__package__].preferences
