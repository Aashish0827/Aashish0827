# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
# Copyright (C) 2017 JOSECONSCO
# Created by JOSECONSCO

import bpy
import bmesh
from bmesh.utils import edge_split
import numpy as np
from .utils.curve_wrapper import get_tips_pts, Splines, get_len_masked
from .utils.helper_functions import clamp, gold_random
from os import path
import random
from mathutils import Vector
from mathutils.geometry import intersect_line_line_2d
from bpy.props import  IntProperty

def assing_uv_boxes_to_splines(curve_obj, spl_ids, boxes_ids, seed):
    random.seed(seed)
    g_seed = random.random()  #cos we need float..
    box_cnt = len(boxes_ids)
    for spl_id in spl_ids:
        idx = int(gold_random(spl_id, g_seed)*box_cnt)
        curve_obj.data.splines[spl_id].material_index = boxes_ids[idx]

def uv_slice_curls(bm, first_mat):
    #* we are un (0,1) uv range now
    RandomFlipX = bpy.context.preferences.addons['hair_tool'].preferences.flipUVRandom
    bm.verts.ensure_lookup_table()
    uv_layer = bm.loops.layers.uv[0]
    # get islands and skew uvs

    bm.faces.ensure_lookup_table()
    per_island_faces = []
    prev_face_x = bm.faces[0].loops[0][uv_layer].uv.x
    faces_row = []
    island_faces = []
    for i,face in enumerate(bm.faces):
        # NOTE: use f.loop[0].uv.x to detect if we jumped to next row
        face_x = face.loops[0][uv_layer].uv.x # first loop is always top edge of face
        if abs(face_x-prev_face_x) < 0.001: # we are still on current line
            pass
        elif face_x > prev_face_x+0.001: # we jumped next row
            island_faces.append(faces_row)
            faces_row = []
        else: # we must have jumped to next island
            island_faces.append(faces_row)
            per_island_faces.append(island_faces)
            island_faces = []
            faces_row = []
        # print([f.index for f in faces_row])
        faces_row.append(face)
        prev_face_x = face_x
    island_faces.append(faces_row) #special case for last isnald - since detection by next face.uv.x fails for it
    per_island_faces.append(island_faces) #menaually add last island

         #we know island verts now. Can skip if no curls_freq
    island_to_skip = []
    island_cut_lines = []
    # TODO: do bbox per face too?
    per_islands_rows_bbox = [] #for quick initial intersection check
    for idx, island_faces in enumerate(per_island_faces): #for each island...
        first_row_face = island_faces[0][0]
        mat_idx = first_row_face.material_index
        uv_box_idx = mat_idx // 2 if RandomFlipX else mat_idx
        hair_uv_data = first_mat.ht_props.hair_uv_points[uv_box_idx]
        curls_freq = hair_uv_data.curls_freq_m if RandomFlipX and mat_idx % 2 else hair_uv_data.curls_freq
        curls_influence_start = hair_uv_data.curls_influence_start_m if RandomFlipX and mat_idx % 2 else hair_uv_data.curls_influence_start
        curls_gravity = hair_uv_data.curls_gravity_m+1 if RandomFlipX and mat_idx % 2 else hair_uv_data.curls_gravity+1

        # skew the uvs Y-axis (top/down...) using uv.x (we are before 90deg UV rotation)
        if abs(curls_freq) < 0.01 or curls_influence_start == 1: # no need to do anything
            island_to_skip.append(idx)
            continue

        mul = 1/(1-curls_influence_start) #optimization. Remapping: (x-min)/(max-min)
        island_rows_bbox = []
        for f_row in island_faces:
            row_min_y = 1000  # for calc of row bbox
            row_max_y = -1000  # for calc of row bbox
            for f_idx, f in enumerate(f_row):
                for l in f.loops:
                    remapped_v = clamp((l[uv_layer].uv.x-curls_influence_start)*mul, 0, 1)  # 0 (t < tresh) else (t-tr)/(1-tr)   --/
                    l[uv_layer].uv.y += pow(remapped_v, curls_gravity) * curls_freq
                    if f_idx in {0,1}: #needed only for first and last
                        row_max_y = max(row_max_y, l[uv_layer].uv.y)
                        row_min_y = min(row_min_y, l[uv_layer].uv.y)
            island_rows_bbox.append((row_min_y, row_max_y))
        per_islands_rows_bbox.append(island_rows_bbox)

        #* calculate x-axis 2d_lines for slices.  More slices fro big curls_freq
        slices = int((curls_freq) // 1)
        if curls_freq > 0:
            slices += 1 # sometimes we miss last slice... so add it manually
            horizontal_lines = [[Vector((0, i+1)), Vector((1, i+1))] for i in range(slices)] #top x-axis slice, starts at top y=1 height
        else:
            horizontal_lines = [[Vector((0, i)), Vector((1, i))] for i in range(0, slices, -1)]  # bottom x-axis slice, starts at top y=0 height

        island_cut_lines.append(horizontal_lines)
    # print(per_islands_rows_bbox)
    for idx in reversed(island_to_skip):
        del per_island_faces[idx]
    # print([[[f.index for f in row] for row in island_faces] for island_faces in per_island_faces])
    #* end while  #####################################################

    # horizontal_line = [Vector((0, 0)), Vector((1, 0))]
    import time
    start_time = time.time()
    def calc_face_uv_x(f):
        uvx = 0
        for l in f.loops:
            uvx += l[uv_layer].uv.x
        return uvx/len(f.loops)

    for i,island_faces  in enumerate(per_island_faces): #for each island...
        horizontal_lines = island_cut_lines[i]
        island_rows_bbox = per_islands_rows_bbox[i]
        start_idx = 0
        for hl_idx, h_line in enumerate(horizontal_lines):
            bridge_verts = [] #holds [(vert, uv.x)]
            faces_for_slice = []
            faces_id = [] # locate slice face in -   per_island_faces
            init_cut = False  # detecs first ht slice
            for row_idx,(islandf_row, row_bbox) in enumerate(zip(island_faces[start_idx:], island_rows_bbox[start_idx:]),start_idx):
                # print(f'row {row_idx}')
                if h_line[0].y < row_bbox[0] or h_line[0].y > row_bbox[1]: #skip checking if hline is outside of row bbxo
                    if init_cut: #break if not slice after initial cut
                        # print(f'BBox Ending hl cut:{hl_idx}, next row start_idx = {row_idx-1}')
                        start_idx = max(0, row_idx-1)
                        break
                    else:
                        continue
                end_of_slice = True # if false then hline slicing must be over
                for fr_id, f in enumerate(islandf_row):
                    intersect_pts = set() # holds vert that lay on the hline
                    skip_next_loop = False # XXX: make sure this works
                    face_intersect_cnt = 0
                    for l in f.loops:
                        if skip_next_loop:
                            skip_next_loop = False
                            continue # if not even one pointis selected
                        uv_edge = [l[uv_layer].uv, l.link_loop_next[uv_layer].uv]
                        uv_intersection = intersect_line_line_2d(uv_edge[0], uv_edge[1], h_line[0], h_line[1])
                        if uv_intersection:
                            factor = (uv_intersection-uv_edge[0]).length/(uv_edge[1]-uv_edge[0]).length
                            if factor < 0.0001: #rather move vert to new uv_inter...
                                intersect_pts.add(l.vert)
                            elif factor > 0.9999: # mark vert and skip next loop
                                intersect_pts.add(l.link_loop_next.vert)
                                skip_next_loop = True  # since we cut at  v(n) ---- *v(n+1)  then skip checkgin v(n+1)
                            else:
                                # cut_data = (l.edge, l.vert, factor, uv_intersection.x)
                                (new_edge, new_vert) = edge_split(l.edge, l.vert, factor) # (e,v, fac)
                                intersect_pts.add(new_vert)
                        # if cut_data:
                        face_intersect_cnt = len(intersect_pts)
                        if face_intersect_cnt == 2:
                            break
                    # print(f'face[{f.index}] loops: {len(f.loops)}, set:  {face_intersect_cnt}')
                    if face_intersect_cnt == 1:
                        break # basically it means we did perfec top-down cut along edge == no other face will be cut at this row
                    elif face_intersect_cnt == 2:
                        init_cut = True
                        bridge_verts.append(intersect_pts)
                        faces_for_slice.append(f)
                        faces_id.append((i, row_idx, fr_id))
                        if init_cut: #when we started cutting, detect the end slice
                            end_of_slice = False


                if init_cut and end_of_slice: #break searching following f_rows
                    # print(f'Slice Ending hl cut:{hl_idx}, next row start_idx = {row_idx-1}')
                    start_idx = max(0, row_idx-1)
                    break
            # bridge_verts.extend(intersect_pts)

            # bridge_verts = sorted(bridge_verts, key=lambda pt: pt[1])  # sort by uv.x...
            for f,vert_pair, f_id in zip(faces_for_slice,bridge_verts, faces_id):
                verts = list(vert_pair)
                try:
                    new_edge = bm.edges.new(verts)
                    # bmesh.utils.face_split(face, verts[0], verts[1]) #why it wont detect verts as member of face.../
                except Exception as e:
                    pass #basically edge exist
                    # print(e)
                else: #went ok - replace remaining per_island_faces - sliced face with the one more on right (down after rotat)
                    new_faces = bmesh.utils.face_split_edgenet(f, [new_edge])
                    if len(new_faces) == 2:
                        if calc_face_uv_x(new_faces[0]) > calc_face_uv_x(new_faces[1]):
                            per_island_faces[f_id[0]][f_id[1]][f_id[2]] = new_faces[0]  #(i, row_idx, fr_id)
                        else:
                            per_island_faces[f_id[0]][f_id[1]][f_id[2]] = new_faces[1]  #(i, row_idx, fr_id)
                # connect_vert_pair(bm, verts=list(vert_pair))
            # for vert_pair in bridge_verts:
            #     connect_vert_pair(bm, verts=list(vert_pair))


    print(f'I took --- {time.time() - start_time} seconds ---')

    # offset uvs from adj uv tiles to (0,1) range
    for f in bm.faces:
        avg_y = 0
        for l in f.loops:
            avg_y += l[uv_layer].uv.y
        avg_y /= len(f.loops)
        offset_int = -1*(avg_y // 1) #full part of modula
        if offset_int:
            for l in f.loops:
                l[uv_layer].uv.y += offset_int


def build_vert_islands(bm):
    ''' only works for mesh from curves - it has ordered verts per island.
    have to handle extra uv_curls verts separately - by v.linked_verts
    '''
    islands = []
    island = []  #  [[verts_row1], [verts_row2], ...]

    vert_row = [] # island is list of rows of vert ids
    prev_loop = bm.verts[0].link_loops[0]
    uv_lay = bm.loops.layers.uv['HairTool_UV']
    # go through all verts and build islands - based on UV[1]. Curl verts are added separately

    def add_linked_verts(vert):
        for e in vert.link_edges:
            add_vert(e.other_vert(vert))

    def add_vert(vert):
        if not vert.tag:
            vert.tag = True
            island.append(vert)

    for v in bm.verts: # DONE: deal with curly uvs... - ignore len(vert_row_ids) == 1 ?
        v.tag = False
    for v in bm.verts: # DONE: deal with curly uvs... - ignore len(vert_row_ids) == 1 ?
        loop = v.link_loops[0] # all should have same uv
        diff = abs(loop[uv_lay].uv[1] - prev_loop[uv_lay].uv[1])
        if diff < 0.98:  # NOTE: moved to next row
            add_vert(v)
            add_linked_verts(v)
        else:             # NOTE: we moved to new island
            islands.append(island)
            island = []
            add_vert(v)
            add_linked_verts(v)
        prev_loop = v.link_loops[0]
    island.extend(vert_row) # single vert anyway
    islands.append(island) #no next island, thus conditions from loop above wont be triggered
    # for island in islands:
    #     print([v.index for v in island])
    return islands



def writeHairUvToMesh(self, context, depsgraph, hairMesh, curve_obj):  #? wont work if we do not pass depsgraph...
    '''writes curve uvs to mesh UV'''
    # print('UV transform method')

    braid_deform_mod = False
    if curve_obj.ht_props.braid_settings.is_braid:
        if 'BraidDeform' in curve_obj.modifiers.keys():
            braid_deform_mod = curve_obj.modifiers['BraidDeform']
            braid_deform_mod.show_viewport = False
            depsgraph = context.evaluated_depsgraph_get() #refresh deps, to disable deform mod

    curveHairRibbon_eval = curve_obj.evaluated_get(depsgraph)
    meCurv = curveHairRibbon_eval.to_mesh()  # hair curve with modifiers must be

    meCurv.uv_layers.new(name='HairTool_UV')  # for vert veights and colors helper layer add secpnd uv's
    me = hairMesh.data  # will write bmesh from curves to this output mesh hair
    if len(me.uv_layers) == 0:
        me.uv_layers.new(name='UVMap')
    if 'HairTool_UV' not in me.uv_layers.keys():
        me.uv_layers.new(name='HairTool_UV')  # for vert veights and colors helper layer add secpnd uv's

    bm = bmesh.new()
    bm.from_mesh(meCurv)
    bm.faces.ensure_lookup_table()
    bm.loops.layers.uv.verify()

    curveHairRibbon_eval.to_mesh_clear() #clean up new mesh from evaluated cure
    if braid_deform_mod: #restore braid deform mod if exist
        braid_deform_mod.show_viewport = True


    uv_layer = bm.loops.layers.uv[0]
    # bm.faces.layers.tex.verify()  # currently blender needs both layers.


    if curve_obj.data.materials:
        first_mat = curve_obj.material_slots[0].material
        uvBoxes = len(first_mat.ht_props.hair_uv_points)

        if uvBoxes == 0:  # if no uv box, then initialize with empty or last used
            first_mat.ht_props.hair_uv_points.add()
            first_mat.ht_props.hair_uv_points[-1].start_point = [0, 1]
            first_mat.ht_props.hair_uv_points[-1].end_point = [1, 0]

        uvBoxes = len(first_mat.ht_props.hair_uv_points)
        RandomFlipX = bpy.context.preferences.addons['hair_tool'].preferences.flipUVRandom
        proper_mat_cnt = 2*uvBoxes if RandomFlipX else uvBoxes
        if  len(curve_obj.data.materials) != proper_mat_cnt:
            self.report({'WARNING'}, 'Material setup seems wrong. Consider running "Material/UV Refresh" operator or UVs may look wrong')
            return

        uv_slice_curls(bm, first_mat)
        for f in bm.faces:
            fmat_idx = f.material_index
            uvRectIndex = fmat_idx // 2 if RandomFlipX else fmat_idx
            hair_uv_data = first_mat.ht_props.hair_uv_points[uvRectIndex]
            x1, y1 = hair_uv_data.start_point
            x2, y2 = hair_uv_data.end_point
            offset_tip = hair_uv_data.offset_tip
            offset_root = hair_uv_data.offset_root

            def offset_adjust(x): #must be same as in OffsetNode
                p1 = 1 - pow(1-x, 5*offset_root+1)
                p2 = pow(x, 5*offset_tip+1)
                return (p1 + p2)/2

            for l in f.loops:
                x, y = l[uv_layer].uv
                x_off = offset_adjust(x)
                if not hair_uv_data.flip_y:
                    xOut = y * (x2 - x1) + x1  # rot -90, scale , translate
                    yOut = -x_off * (y1 - y2) + y1
                else:
                    xOut = y * (x1 - x2) + x2  # rot +90, scale , translate
                    yOut = -x_off * (y2 - y1) + y2
                if RandomFlipX and f.material_index % 2 == 0:  #? flipping X (for odd? even mat ids)
                    xOut = -xOut + x1 + x2
                l[uv_layer].uv = xOut, yOut

        uv_layer2 = bm.loops.layers.uv['HairTool_UV']  # rotate second uv (help uvs)
        for f in bm.faces:
            for l in f.loops:
                x, y = l[uv_layer2].uv
                l[uv_layer2].uv = y, x  # rot -90

    # NOTE: copy vertex group weights from old mesh
    if len(hairMesh.vertex_groups) > 0:
        dlayer = bm.verts.layers.deform.verify()
        bm.verts.ensure_lookup_table()
        for vi in range(len(bm.verts)):
            if vi >= len(me.vertices):
                break
            for g in me.vertices[vi].groups:
                bm.verts[vi][dlayer][g.group] = g.weight
        if len(bm.verts) != len(me.vertices):
            self.report({'WARNING'}, '[Hair Tools] Vertex count was changed. Restored vertex weighs may be corrupted.')

    # if len(bm.verts) != len(me.vertices): # when we have uv_curls - mech - gives skewing on uvs
    #     bm.verts.ensure_lookup_table()
    #     vert_islands = build_vert_islands(bm) # velding uv_curls verts
    #     for vert_island in vert_islands:
    #         e_len = 0.5 * (vert_island[0].link_edges[0].calc_length() + vert_island[0].link_edges[1].calc_length())
    #         # print(e_len)
    #         bmesh.ops.remove_doubles(bm, verts=vert_island, dist=0.1*e_len)

    bm.to_mesh(me)
    bm.free()
    # me.update()


data_types = ['images', 'materials', 'node_groups']  # , 'textures' from gpro

def import_default_hair_mat():
    ''' create new and store last mat '''
    nodes_for_update = []
    hair_node_groups = ['BlendFloat', 'AverageTB', 'HairShaderMain', 'HairParameters', 'Anisotropic BSDF']  # 'Saturate'
    original_datas = {}
    for attr in data_types:
        original_datas[attr] = {data_id.name: data_id for data_id in getattr(bpy.data, attr)}

    imported_datas_names = {}
    if 'HairMatAniso' not in bpy.data.materials.keys():
        with bpy.data.libraries.load(path.dirname(__file__)+"\hair_lib.blend") as (data_from, data_to):
            for attr in data_types:
                setattr(data_to, attr, getattr(data_from, attr))
                imported_datas_names[attr] = [data_name for data_name in getattr(data_from, attr)]
                if imported_datas_names[attr]:
                    print(f'Imported {attr}: {imported_datas_names[attr]}')


        for attr, orig_data in original_datas.items():
            new_data_ids = getattr(data_to, attr)  # eg: data_to.collections
            data = getattr(bpy.data, attr)  # eg. bpy.data.collections
            for orig_name, old_data in orig_data.items():  # eg. for collections, objs, textures etc.
                if orig_name in imported_datas_names[attr]:
                    new_data = new_data_ids[imported_datas_names[attr].index(orig_name)]
                    print(f'remapping: {orig_name}:{new_data.name}')
                    old_data.user_remap(new_data)
                    new_data.name = orig_name
                    data.remove(old_data)

    bpy.context.scene.ht_props.last_hair_settings.material = bpy.data.materials['HairMatAniso']
    return bpy.data.materials['HairMatAniso']


def import_node_group(node_name):
    ''' import node gr. from ht_nodes.blend '''
    #TODO: we should also udpate inner group nodes....
    node_for_remap = bpy.data.node_groups.get(node_name)
    with bpy.data.libraries.load(path.dirname(__file__)+"\ht_nodes.blend") as (data_from, data_to):
        data_to.node_groups = [node_n for node_n in data_from.node_groups if node_n == node_name]
        imported_gr_names = [node_n for node_n in data_from.node_groups if node_n == node_name]  # stores names

    if node_for_remap:
        node_for_remap.user_remap(data_to.node_groups[0])
        data_to.node_groups[0].name = node_name

    return data_to.node_groups[0]

class HTOOL_OT_CurvesUVRefresh(bpy.types.Operator):
    bl_label = "Material / UV Refresh"
    bl_idname = "object.curve_uv_refresh"
    bl_description = "Propagates hair material changes from first slot to next ones. Also updates UV on material, from drawn UV boxes."
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        self.uvCurveRefresh(context.active_object, refresh_everything=True)
        return {"FINISHED"}

    @staticmethod
    def curve_update_materials(obj, RandomFlipX):
        '''Referesg materals slots to obj to match uvBoxes count '''
        first_mat = obj.material_slots[0].material
        bpy.context.scene.ht_props.last_hair_settings.material = first_mat
        first_mat.use_nodes = True

        uvBoxes = len(first_mat.ht_props.hair_uv_points)
        new_mats = [first_mat] + [first_mat.copy() for i in range(1, uvBoxes * RandomFlipX)]  # duplicate first mat to rest of slots

        instances_using_first_mat = [data for data in bpy.data.curves if data.materials and data.materials[0] == first_mat]  # get data blocks that are usin first_mat
        sorted_data_instances = sorted(instances_using_first_mat, key=lambda data_o: len(data_o.materials), reverse=True) #get instance with longest mats
        first_loop = True
        for data_o in sorted_data_instances:  # for all objs that are using mat First Mat, update mat/uv
            for i, m in reversed(list(enumerate(data_o.materials))): #removes empty slot
                if m is None:
                    data_o.materials.pop(index=i)

            old_mat_count = len(data_o.materials)
            # old_mat_count = len(data_o.materials)
            #each material is linked to uv. If we change UV then it means change mat. Change mat == override it with first_mat.copy()
            i = 0
            for i in range(1, uvBoxes * RandomFlipX):  # duplicate first mat to rest of slots
                oldMat = data_o.materials[i] if i < old_mat_count else None
                if oldMat:  # replace old_material on objs using it
                    data_o.materials[i] = new_mats[i]  # else add new slot with material duplicate
                    if oldMat.users == 0:
                        # print(f'removing old mat:{oldMat.name}')
                        bpy.data.materials.remove(oldMat)
                else:  # there was no slot i, so add new mat
                    data_o.materials.append(new_mats[i])  # else add new slot with material duplicate

            while (old_mat_count - 1) - i > 0:
                i += 1
                oldMat = data_o.materials[-1]
                data_o.materials.pop()
                if oldMat and oldMat.users == 0:
                    bpy.data.materials.remove(oldMat)
            first_loop = False

        for i in range(1, uvBoxes * RandomFlipX):  # use old material names (we kind of overrdie old mat)
            if RandomFlipX == 2:
                box_id = i//2 # full part of mod
                new_mats[i].name = first_mat.name + str(box_id) + '_Mirrored' if i % 2 else first_mat.name + str(box_id)
            else:
                new_mats[i].name = first_mat.name + str(i)

    @staticmethod
    def get_node_type(node_tree, type, sub=None, clear=False):
        if sub:
            nodes = [node for node in node_tree.nodes if node.type == type and node.node_tree.name == sub] # for node group
        else:
            nodes = [node for node in node_tree.nodes if node.type == type]  # link maping node to img
        if clear:
            for n in reversed(nodes):
                node_tree.nodes.remove(n)
        else:
            return nodes


    @staticmethod
    def update_mapping_nodes(first_mat):
        ''' add OffsetNode and Mapping '''
        get_node_type = HTOOL_OT_CurvesUVRefresh.get_node_type
        # get_node_type(first_mat.node_tree, 'MAPPING', clear=True)

        offset_node_gr = bpy.data.node_groups.get('OffsetNode')
        if not offset_node_gr:
            offset_node_gr = import_node_group('OffsetNode')  # for offesting uvs toward tip/root
        # NOTE: we have to update OffsetNode to latest ver in all mats that use OffsetNode
        first_mat_was_fixed = False
        if 'Location' not in offset_node_gr.inputs.keys(): # detect old OffsetNode that needs updating (with its materials)
            mat_to_update = [mat for mat in bpy.data.materials if mat.node_tree and mat.node_tree.nodes.get('OffsetNode')]
            for mat in mat_to_update:
                if mat == first_mat:
                    first_mat_was_fixed = True
                old_offset_node = mat.node_tree.nodes.get('OffsetNode')
                old_loc =  old_offset_node.location.to_tuple()
                # get_node_type(first_mat, 'GROUP',sub='OffsetNode', clear=True)
                import_node_group('OffsetNode')   # remaps old offset node
                new_offset_node = mat.node_tree.nodes.get('OffsetNode')
                new_offset_node.location = old_loc
                links = mat.node_tree.links
                if len(new_offset_node.outputs[0].links) == 1: #try create links from offset_node to mappint outputs. Later del mapping node
                    target_node = new_offset_node.outputs[0].links[0].to_node
                    if target_node.type == 'MAPPING':
                        for out_link in target_node.outputs[0].links:
                            links.new(new_offset_node.outputs[0], out_link.to_socket)
                get_node_type(mat.node_tree, 'MAPPING', clear=True) # usuaaly after Offset Node
                get_node_type(mat.node_tree, 'TEX_COORD', clear=True) # not needed since 2.3.3

            hair_shader_main = bpy.data.node_groups.get('HairShaderMain') # try updating HairParameters too use Attribute: ht_props.is_curve
            if hair_shader_main:
                aniso_nodes = get_node_type(hair_shader_main, 'GROUP', sub='Anisotropic BSDF') # we will link new node to Anisotropic rot
                if aniso_nodes:
                    loc = -1000, - 500
                    attribute_node = hair_shader_main.nodes.new("ShaderNodeAttribute")
                    attribute_node.attribute_type = 'OBJECT'
                    attribute_node.attribute_name = 'ht_props.is_curve'
                    attribute_node.location = loc[0] - 200, loc[1]

                    math_node1 = hair_shader_main.nodes.new("ShaderNodeMath")
                    math_node1.operation = 'MULTIPLY_ADD'
                    math_node1.inputs[1].default_value = -1
                    math_node1.inputs[2].default_value = 1
                    math_node1.location = loc[0], loc[1]

                    math_node2 = hair_shader_main.nodes.new("ShaderNodeMath")
                    math_node2.operation = 'MULTIPLY'
                    math_node2.inputs[1].default_value = 0.25
                    math_node2.location = loc[0]+200, loc[1]

                    links = hair_shader_main.links
                    links.new(attribute_node.outputs['Fac'], math_node1.inputs[0])
                    links.new(math_node1.outputs[0], math_node2.inputs[0])
                    for aniso_node in aniso_nodes:
                        links.new(math_node2.outputs[0], aniso_node.inputs['Rotation'])



        if not first_mat_was_fixed:
            offset_node = first_mat.node_tree.nodes.get('OffsetNode')
            if not offset_node:
                offset_node = first_mat.node_tree.nodes.new("ShaderNodeGroup")
                offset_node.name = 'OffsetNode'
                offset_node.node_tree = offset_node_gr
                offset_node.location = -500, 200
            # elif offset_node.node_tree.name != 'OffsetNode':#proper name bug bad group...
            #     offset_node.node_tree = offset_node_gr

                links = first_mat.node_tree.links
                if len(offset_node.outputs[0].links) == 1: #try create links from offset_node to mappint outputs. Later del mapping node
                    target_node = offset_node.outputs[0].links[0].to_node
                    if target_node.type == 'MAPPING':
                        for out_link in target_node.outputs[0].links:
                            links.new(offset_node.outputs[0], out_link.to_socket)

                else:
                    img_nodes = get_node_type(first_mat.node_tree, 'TEX_IMAGE')
                    hair_param = get_node_type(first_mat.node_tree, 'GROUP', sub='HairParameters')
                    for node in img_nodes+hair_param:
                        links.new(offset_node.outputs[0], node.inputs[0])

                get_node_type(first_mat.node_tree, 'MAPPING', clear=True) # usuaaly after Offset Node
                get_node_type(first_mat.node_tree, 'TEX_COORD', clear=True) # not needed since 2.3.3

    @staticmethod
    def uvCurveRefresh(curve_obj, refresh_everything=False):
        ''' By default only refreshes materials assigned to splines id's
            If refresh_everything: then reassing materials based on uvBoxes count, and refresh mat UVs (mMapping node)
        '''
        #force refresh everything if no material is assigned, or UV box coutn != len(mat.slots)
        RandomFlipX = 2 if bpy.context.preferences.addons['hair_tool'].preferences.flipUVRandom else 1
        if not refresh_everything:
            if not curve_obj.material_slots or not curve_obj.material_slots[0].material:
                refresh_everything = True
            else:
                first_mat = curve_obj.material_slots[0].material
                if len(first_mat.ht_props.hair_uv_points)*RandomFlipX != len(curve_obj.material_slots):
                    refresh_everything = True
        # print(f'UV refresh = {refresh_everything}')
        if refresh_everything:
            last_hair_settings = bpy.context.scene.ht_props.last_hair_settings
            last_global_mat = last_hair_settings.material

            #* get first mat, or create new one and assign
            if not curve_obj.material_slots or not curve_obj.material_slots[0].material:  # Create new mat
                first_mat = last_global_mat if last_global_mat else import_default_hair_mat()
                if len(curve_obj.material_slots) == 0:  # make sure first slot is assigned
                    curve_obj.data.materials.append(first_mat)
                elif curve_obj.material_slots[0].material == None:
                    curve_obj.material_slots[0].material = first_mat
            else:
                first_mat = curve_obj.material_slots[0].material

            uvBoxes = len(first_mat.ht_props.hair_uv_points)
            if uvBoxes == 0:  # if no uv box, then initialize with empty or last used
                first_mat.ht_props.hair_uv_points.add()
                first_mat.ht_props.hair_uv_points[-1].start_point = [0, 1]
                first_mat.ht_props.hair_uv_points[-1].end_point = [1, 0]

            HTOOL_OT_CurvesUVRefresh.update_mapping_nodes(first_mat)  # add mapping node, OffsetNode if do not exist, before making mat copies
            HTOOL_OT_CurvesUVRefresh.curve_update_materials(curve_obj, RandomFlipX)  # make mat copies for each uv box
            uvBoxes = len(first_mat.ht_props.hair_uv_points)
            for m_id, mat in enumerate(curve_obj.data.materials):  # now we can set mapping nodes for each mat slot
                # offset_node_gr = bpy.data.node_groups['OffsetNode']
                offset_node = mat.node_tree.nodes['OffsetNode']  # created in update_mapping_nodes
                # mappingNode = mat.node_tree.nodes['Mapping']  # created in update_mapping_nodes
                uvRectIndex = m_id//RandomFlipX  # full part of modulo

                hair_uv_data = first_mat.ht_props.hair_uv_points[uvRectIndex]
                x1, y1 = hair_uv_data.start_point
                x2, y2 = hair_uv_data.end_point

                flip_y = -1 if hair_uv_data.flip_y else 1  # ? flip rot tip?
                if m_id % 2 or RandomFlipX == 1:  # non flipped  X version
                    offset_node.inputs['Location'].default_value = Vector((x1, y1, 0)) if flip_y == 1 else Vector((x2, y2, 0))
                    offset_node.inputs['Rotation'].default_value[2] = flip_y*1.57  # 90deg
                    offset_node.inputs['Scale'].default_value = Vector((y2-y1, x1-x2, 1))
                else:  # use filipped X transform
                    offset_node.inputs['Location'].default_value = Vector((x2, y1, 0)) if flip_y == 1 else Vector((x1, y2, 0))
                    offset_node.inputs['Rotation'].default_value[2] = flip_y*1.57  # 90deg
                    offset_node.inputs['Scale'].default_value = Vector((y2-y1, x2-x1, 1))

                #handle offset uvs trick.
                offset_node.inputs['Offset Tip'].default_value = hair_uv_data.offset_tip
                offset_node.inputs['Offset Root'].default_value = hair_uv_data.offset_root

                offset_node.inputs['Curls Range'].default_value = hair_uv_data.curls_freq_m if RandomFlipX and m_id % 2 else hair_uv_data.curls_freq
                offset_node.inputs['Curls Threshold'].default_value = hair_uv_data.curls_influence_start_m if RandomFlipX and m_id % 2 else hair_uv_data.curls_influence_start
                offset_node.inputs['Curls Gravity'].default_value = hair_uv_data.curls_gravity_m if RandomFlipX and m_id % 2 else hair_uv_data.curls_gravity

        else:
            first_mat = curve_obj.material_slots[0].material
            uvBoxes = len(first_mat.ht_props.hair_uv_points)

        if curve_obj.ht_props.use_auto_uv:
            HTOOL_OT_AssignRegionsFromObjProps.update_assigned_uv_regions(curve_obj)
        #* update box material slots on other objs, which are using current hair mat
        # data_using_first_mat = [data for data in bpy.data.curves if data.materials and data.materials[0] == first_mat]  # get data blocks that are usin first_mat
        # mat_count = uvBoxes*RandomFlipX
        # for data_o in data_using_first_mat:  # refresh mateerials per spline for all Mat/UV instances data
        #     np.random.seed(data_o.ht_props.uv_seed)
        #     for spl_id, spline in enumerate(data_o.splines):
        #         rand_mat_id = divmod(spl_id+np.random.randint(mat_count), mat_count)[1]  # pick randomm material # no need. use old spl.mat_idx instead.


        # curve_obj.update_tag()


class HTOOL_OT_LoadHairMat(bpy.types.Operator):
    bl_idname = "hair.load_hair_mat"
    bl_label = "Import Default Hair Material"
    bl_description = "Import and assigns default hair material to selected object"
    bl_options = {"REGISTER", "UNDO"}

    keep_uvs: bpy.props.BoolProperty(name='Keep uvs', description='', default=True)

    @classmethod
    def poll(self, context):  # make selection only false, if obj mode
        obj = context.active_object
        return obj and obj.type == 'CURVE'

    @staticmethod
    def copy_settings(from_mat, target_mat):
        target_uv_pts = target_mat.ht_props.hair_uv_points
        for _ in range(len(from_mat.ht_props.hair_uv_points)-1): # cos target/new imported mat already has one uv point
            target_uv_pts.add()

        for i,uv_pt in enumerate(from_mat.ht_props.hair_uv_points):
            for d in uv_pt.bl_rna.properties.keys():
                if d in {'name', 'rna_type'}:
                    continue
                target_uv_pts[i][d] = getattr(uv_pt, d)  # to avoid runing prop update...
        from_uv_curls = from_mat.ht_props.uv_curls
        for d in from_mat.ht_props.uv_curls.bl_rna.properties.keys():
            if d in {'name', 'rna_type'}:
                continue
            setattr(target_mat.ht_props.uv_curls, d, getattr(from_uv_curls, d))  # to avoid runing prop update...


    def execute(self, context):
        obj = context.active_object
        bpy.context.scene.ht_props.last_hair_settings.material = None  # to force assignemt of new mat, rather than last used
        mat_count = len(obj.data.materials)
        for _ in range(mat_count-1):
            mat = obj.data.materials[-1]
            obj.data.materials.pop() #new
            if mat and mat.users == 0:
                bpy.data.materials.remove(mat)
        old_aniso = bpy.data.materials.get('HairMatAniso')
        if old_aniso:
            old_aniso.name += '_Old'
        new_mat = import_default_hair_mat()
        # N: copy uv data to new mat
        first_mat = obj.data.materials[0] if obj.data.materials else None
        if first_mat:
            if self.keep_uvs:
                self.copy_settings(first_mat, new_mat) #copy uv boxes settings
            obj.data.materials.pop() #new
            if first_mat.users == 0:
                    bpy.data.materials.remove(first_mat)

        obj.data.materials.append(new_mat)

        HTOOL_OT_CurvesUVRefresh.uvCurveRefresh(obj, refresh_everything=True)

        old_aniso = bpy.data.materials.get('HairMatAniso_Old')
        if old_aniso and old_aniso.users == 0:
            bpy.data.materials.remove(old_aniso)
        return {"FINISHED"}


class HTOOL_OT_AssignLastMaterial(bpy.types.Operator):
    bl_idname = "hair.assign_last_hair_mat"
    bl_label = "Assign last Hair Material"
    bl_description = "Assign last used Hair Material. Last material is material from object, onto which you used 'Curve uv refresh' last time"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(self, context):  # make selection only false, if obj mode
        obj = context.active_object
        return obj and obj.type == 'CURVE' and obj.data.bevel_object

    def execute(self, context):
        obj = context.active_object
        last_global_mat = bpy.context.scene.ht_props.last_hair_settings.material

        mat_count = len(obj.material_slots)
        for i in range(mat_count):
            mat = obj.data.materials[-1]
            obj.data.materials.pop(update_data=True)
            if mat and mat.users == 0:
                bpy.data.materials.remove(mat)
        firstMat = last_global_mat if last_global_mat else import_default_hair_mat()
        obj.data.materials.append(firstMat)
        HTOOL_OT_CurvesUVRefresh.uvCurveRefresh(obj, refresh_everything = True)
        bpy.context.scene.ht_props.last_hair_settings.material = firstMat
        return {"FINISHED"}

BOX_ITEMS  = []
def uv_box_items(self, context):
    curve_obj = context.active_object
    first_mat = curve_obj.material_slots[0].material
    uvBoxes = len(first_mat.ht_props.hair_uv_points)
    random_flip_x = context.preferences.addons['hair_tool'].preferences.flipUVRandom
    global BOX_ITEMS
    if random_flip_x:
        if len(BOX_ITEMS) != 2*uvBoxes:
            BOX_ITEMS = [(str(i), str(i//2) + '\'' if i % 2 else str(i//2), '') for i in range(uvBoxes*2)]
    else:
        if len(BOX_ITEMS) != uvBoxes:
            BOX_ITEMS = [(str(i), 'UV box:'+str(i), '') for i in range(uvBoxes)]
    return BOX_ITEMS

class HTOOL_OT_SetUvRegion(bpy.types.Operator):
    bl_idname = "hair.set_uv_region"
    bl_label = "Set UV Region"
    bl_description = "Set selected strands UV to specific region by its ID number"
    bl_options = {"REGISTER", "UNDO"}

    uv_regions: bpy.props.EnumProperty(name='UV Region ID', description='Pick UV region that will be assinged to selected strands',
                                   items=uv_box_items,  options={'ENUM_FLAG'})
    seed: IntProperty(name="Seed", description='Randomize how UV regions are assigned per selected strand',  default=0, min=0, max=1000)

    @classmethod
    def poll(self, context):  # make selection only false, if obj mode
        obj = context.active_object
        return obj and obj.type == 'CURVE' and (obj.data.bevel_object or obj.data.bevel_depth) and len(obj.data.materials) > 1

    def draw(self, context):
        layout = self.layout
        if len(self.uv_regions) > 1:
            layout.prop(self, 'seed')
        layout.label(text='Select UVs that will be assigned to strands:')
        layout.prop(self, 'uv_regions')

    def invoke(self, context, event):
        global BOX_ITEMS
        BOX_ITEMS.clear()
        curve_obj = context.active_object
        self.uv_regions = set() #deselect by default all mats...
        self.seed = curve_obj.ht_props.uv_seed

        called_from_ht_wspace = context.workspace.tools.from_space_view3d_mode(mode=context.mode).idname == "hair_tool.hair_transform"
        onlySelection = True if curve_obj.mode == 'EDIT' else called_from_ht_wspace
        self.spl_ids, _ , _ = get_tips_pts(context, curve_obj, world_space=False, only_sel=onlySelection)
        return self.execute(context)

    def execute(self, context):
        if not self.uv_regions:
            return {"FINISHED"}
        boxes_ids = [int(box) for box in self.uv_regions]
        assing_uv_boxes_to_splines(context.active_object, self.spl_ids, boxes_ids, self.seed)
        # HTOOL_OT_CurvesUVRefresh.uvCurveRefresh(curve_obj, refresh_everything=False)
        return {"FINISHED"}


class HTOOL_OT_AssignRegionsFromObjProps(bpy.types.Operator):
    bl_idname = "hair.update_assigned_uv_regions"
    bl_label = "Assign UVs Regions"
    bl_description = "Assign UVs Regions to hair strands (curves)"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(self, context):  # make selection only false, if obj mode
        obj = context.active_object
        return obj and obj.type == 'CURVE' and (obj.data.bevel_object or obj.data.bevel_depth) and len(obj.data.materials) > 1 and obj.ht_props.use_auto_uv

    def invoke(self, context, event):
        # called_from_ht_wspace = context.workspace.tools.from_space_view3d_mode(mode=context.mode).idname == "hair_tool.hair_transform"
        # onlySelection = True if curve_obj.mode == 'EDIT' else called_from_ht_wspace
        splines = Splines(context.active_object, onlySelection=False, spline_type='SIMPLE')  # 2x faster than 'FLAT'....
        self.euclid_lens = np.array([s.euclidean_len for s in splines.splines])
        return self.execute(context)

    def execute(self, context):
        curve_obj = context.active_object
        if not curve_obj.ht_props.use_auto_uv:
            self.report({'WARNING'}, f'Auto assignign of UV regions is disabled for this object. See UV image editor -> Right Sidebar [Hair Tool UV] Tab')
            return {'CANCELLED'}
        obj_uv_props = curve_obj.ht_props
        default_boxes_cnt = len(obj_uv_props.uv_regions) if obj_uv_props.default_uv_region == 'MANUAL' else len(curve_obj.material_slots)
        if not default_boxes_cnt:
            self.report({'WARNING'}, f'No default UV region were assigned to {curve_obj.name}. Cancelling!')
            return {'CANCELLED'}
        self.update_assigned_uv_regions(curve_obj, self.euclid_lens)
        return {"FINISHED"}

    @staticmethod
    def update_assigned_uv_regions(curve_obj, euclid_lens=None):
        if euclid_lens is None:
            splines = Splines(curve_obj, onlySelection=False, spline_type='SIMPLE')  # 2x faster than 'FLAT'....
            euclid_lens = np.array([s.euclidean_len for s in splines.splines])

        max_l = np.max(euclid_lens)
        len_norms = euclid_lens/max_l
        obj_uv_props = curve_obj.ht_props
        if obj_uv_props.default_uv_region == 'MANUAL':
            default_boxes_ids = [int(box) for box in obj_uv_props.uv_regions]
        else:
            default_boxes_ids = [i for i in range(len(curve_obj.material_slots))]
        if default_boxes_ids:
            all_spl_ids = [i for i in range(len_norms.shape[0])]
            assing_uv_boxes_to_splines(curve_obj, all_spl_ids, default_boxes_ids, obj_uv_props.uv_seed)
            if obj_uv_props.use_length_mask_uv:
                for i, len_mask_props in enumerate(obj_uv_props.threshold_mask): # threshold for assignign UV region by strand len
                    boxes_ids = [int(box) for box in len_mask_props.uv_regions]
                    if boxes_ids:
                        #* convert threshodl always to relative val..
                        rel_threshold = len_mask_props.rel_threshold if len_mask_props.treshold_mode == 'RELATIVE' else len_mask_props.len_threshold/max_l
                        sel_ids = get_len_masked(len_norms, rel_threshold, len_mask_props.margin, seed=len_mask_props.seed)
                        if len_mask_props.invert:
                            sel_ids = list(set(all_spl_ids)-set(sel_ids))  # invert by sub
                        assing_uv_boxes_to_splines(curve_obj, sel_ids, boxes_ids, len_mask_props.seed)


class HTOOL_OT_AdjustUvCurls(bpy.types.Operator):
    bl_idname = "curve.hair_curls_uv"
    bl_label = "Hair UV Curls"
    bl_description = "Hair UV Curls"
    bl_options = {'REGISTER', "UNDO"}

    curls_freq: bpy.props.FloatProperty(name='Curls Frequency', description='Define amount of curls for each strand', default= 4, soft_min=-10, soft_max=10)
    curls_freq_rand: bpy.props.FloatProperty(name='Frequency Rand', description='', default=0, min=0, max=1, subtype='FACTOR')

    curls_influence_start: bpy.props.FloatProperty(name='Influence Start', description='Start curls effect from given threshold factor of strand length', default=0, min=0.0, max=0.8, subtype='FACTOR')
    start_rand: bpy.props.FloatProperty(name='Start Random', description='', default=0, min=0.0, max=1.0, subtype='FACTOR')

    curls_gravity: bpy.props.FloatProperty(name='Curl Gravity', description='Fake gravity effect (should be at least 1.0 when threshold non-zero value)', default=1, min=0.0, max=10)
    gravity_random: bpy.props.FloatProperty(name='Gravity Random', description='', default=0, min=0.0, max=1, subtype='FACTOR')

    randomDirection: bpy.props.BoolProperty(name="Random Direction", description="Random curls direction angle randomly from CW to CCW", default=False)
    Seed: IntProperty(name="Noise Seed", default=1, min=1, max=500)

    first_run = True

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'CURVE' and len(obj.data.materials)

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)

        col.label(text='Curls')
        split = col.split(factor=0.7, align=True)
        split.prop(self, 'curls_freq', text = 'Frequency')
        split.prop(self, 'curls_freq_rand', text='Rand')

        split = col.split(factor=0.7, align=True)
        # split.label(text='Influence Start')
        split.prop(self, 'curls_influence_start', text='Influence Start')
        split.prop(self, 'start_rand', text='Rand')

        split = col.split(factor=0.7, align=True)
        # split.label(text='Gravity')
        split.prop(self, 'curls_gravity', text='Gravity')
        split.prop(self, 'gravity_random', text='Rand')

        col = layout.column(align=True)
        col.prop(self, 'randomDirection', icon='ARROW_LEFTRIGHT')
        col.prop(self, 'Seed')


    def save_settings(self, target_obj):  # to object  rand_tilt_settings
        for d in self.properties.bl_rna.properties.keys():
            if d in {'rna_type'}:
                continue
            setattr(target_obj.data.materials[0].ht_props.uv_curls, d, getattr(self.properties, d))


    def load_settings(self, source_obj):  # from  braid_settings
        # skip loading affected_mat on re-run (else we stuck in same affected_mat mode)
        skip_props = {'name', 'rna_type'}# if self.first_run else {'name', 'rna_type', 'affected_mat'}
        self.first_run = False
        for d in source_obj.data.materials[0].ht_props.uv_curls.bl_rna.properties.keys():
            if d in skip_props:
                continue
            setattr(self.properties, d, getattr(source_obj.data.materials[0].ht_props.uv_curls, d))


    def invoke(self, context, event):
        offset_node_gr = bpy.data.node_groups['OffsetNode'] if 'OffsetNode' in bpy.data.node_groups.keys() else import_node_group('OffsetNode')
        if 'Curls Range' not in offset_node_gr.inputs.keys(): #update to the one with tilt input...
            offset_node_gr = import_node_group('OffsetNode')

        #INFO: load cache from uv_points (for operator redo)
        self.load_settings(context.active_object)
        return self.execute(context)


    def execute(self, context):
        curve_obj = context.active_object
        RandomFlipX = context.preferences.addons['hair_tool'].preferences.flipUVRandom

        def set_curls_offset_node(mat_idx, curls_freq, curls_influence_start, curls_gravity):
            mat = curve_obj.data.materials[mat_idx]
            uv_box_idx = mat_idx // 2 if RandomFlipX else mat_idx
            HTOOL_OT_CurvesUVRefresh.update_mapping_nodes(mat)  # add mapping node, OffsetNode if do not exist, before making mat copies
            offset_node = mat.node_tree.nodes.get('OffsetNode')
            hair_uv_data = curve_obj.data.materials[0].ht_props.hair_uv_points[uv_box_idx]  # holds ht_props.hair_uv_points
            if offset_node:
                offset_node.inputs['Curls Range'].default_value = curls_freq
                offset_node.inputs['Curls Threshold'].default_value = curls_influence_start
                offset_node.inputs['Curls Gravity'].default_value = curls_gravity
                # then store uv settings in permanent settings
                if RandomFlipX and mat_idx % 2:
                    hair_uv_data.curls_freq_m = curls_freq
                    hair_uv_data.curls_influence_start_m = curls_influence_start
                    hair_uv_data.curls_gravity_m = curls_gravity
                else:
                    hair_uv_data.curls_freq = curls_freq
                    hair_uv_data.curls_influence_start = curls_influence_start
                    hair_uv_data.curls_gravity = curls_gravity

            else:
                print('no offset node...')

        uv_boxes = uv_box_items(self, context)
        sel_boxes_ids = [int(box[0]) for box in uv_boxes]
        first_mat = curve_obj.material_slots[0].material
        uvBoxes = len(first_mat.ht_props.hair_uv_points)
        mat_cnt = 2*uvBoxes if RandomFlipX else uvBoxes

        np.random.seed(self.Seed)
        rand_curls_freq = np.random.rand(mat_cnt)*self.curls_freq*self.curls_freq_rand+self.curls_freq*(1-self.curls_freq_rand)  # remapped
        if self.randomDirection:
            rand_curls_freq = rand_curls_freq * np.random.choice([1, -1], mat_cnt)

        np.random.seed(self.Seed+187)
        rand_curls_influence_start = np.random.rand(mat_cnt)*self.curls_influence_start*self.start_rand+self.curls_influence_start*(1-self.start_rand)  # remapped
        np.random.seed(self.Seed+472)
        rand_curls_gravity = np.random.rand(mat_cnt)*self.curls_gravity*self.gravity_random+self.curls_gravity*(1-self.gravity_random)  # remapped
        for box_id in range(mat_cnt):
            if box_id in sel_boxes_ids:
                # mat = curve_obj.data.materials[box_id]
                set_curls_offset_node(box_id, rand_curls_freq[box_id], rand_curls_influence_start[box_id], rand_curls_gravity[box_id])
        self.save_settings(curve_obj)
        # bpy.ops.ed.undo_push() # prevents restoring the settings on operator redo
        return {'FINISHED'}


class HTOOL_OT_ResetUvCurls(bpy.types.Operator):
    bl_idname = "curve.reset_hair_curls_uv"
    bl_label = "Reset  UV Curls"
    bl_description = "Reset UV Curls"
    bl_options = {'REGISTER', "UNDO"}


    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'CURVE' and len(obj.data.materials)


    def save_settings(self, target_obj):  # to object  rand_tilt_settings
        for d in self.properties.bl_rna.properties.keys():
            if d in {'rna_type'}:
                continue
            setattr(target_obj.data.materials[0].ht_props.uv_curls, d, getattr(self.properties, d))


    def execute(self, context):
        curve_obj = context.active_object
        RandomFlipX = context.preferences.addons['hair_tool'].preferences.flipUVRandom

        def set_curls_offset_node(mat_idx, curls_freq, curls_influence_start, curls_gravity):
            mat = curve_obj.data.materials[mat_idx]
            uv_box_idx = mat_idx // 2 if RandomFlipX else mat_idx
            HTOOL_OT_CurvesUVRefresh.update_mapping_nodes(mat)  # add mapping node, OffsetNode if do not exist, before making mat copies
            offset_node = mat.node_tree.nodes.get('OffsetNode')
            hair_uv_data = curve_obj.data.materials[0].ht_props.hair_uv_points[uv_box_idx]  # holds ht_props.hair_uv_points
            if offset_node:
                offset_node.inputs['Curls Range'].default_value = curls_freq
                offset_node.inputs['Curls Threshold'].default_value = curls_influence_start
                offset_node.inputs['Curls Gravity'].default_value = curls_gravity
                # then store uv settings in permanent settings
                if RandomFlipX and mat_idx % 2:
                    hair_uv_data.curls_freq_m = curls_freq
                    hair_uv_data.curls_influence_start_m = curls_influence_start
                    hair_uv_data.curls_gravity_m = curls_gravity
                else:
                    hair_uv_data.curls_freq = curls_freq
                    hair_uv_data.curls_influence_start = curls_influence_start
                    hair_uv_data.curls_gravity = curls_gravity

            else:
                print('no offset node...')

        uv_boxes = uv_box_items(self, context)
        sel_boxes_ids = [int(box[0]) for box in uv_boxes]
        first_mat = curve_obj.material_slots[0].material
        uvBoxes = len(first_mat.ht_props.hair_uv_points)
        mat_cnt = 2*uvBoxes if RandomFlipX else uvBoxes
        for box_id in range(mat_cnt):
            if box_id in sel_boxes_ids:
                set_curls_offset_node(box_id, 0, 0, 0)
        # save settings to obj.uv_curls
        obj_uv_curls = curve_obj.data.materials[0].ht_props.uv_curls
        obj_uv_curls.curls_freq = 0
        obj_uv_curls.curls_freq_rand = 0
        obj_uv_curls.curls_influence_start = 0
        obj_uv_curls.start_rand = 0
        obj_uv_curls.curls_gravity = 0
        obj_uv_curls.gravity_random = 0
        obj_uv_curls.randomDirection = False
        obj_uv_curls.Seed = 1
        return {'FINISHED'}





