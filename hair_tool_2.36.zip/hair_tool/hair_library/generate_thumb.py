import bpy
import sys
from math import cos, pi, radians, sin
import os


def purge(data):
    # RENDER PREVIEW SCENE PREPARATION METHODS
    for el in data:
        if el.users == 0:
            data.remove(el)

def clean_scene():
    # clean scene
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.object.delete(use_global=True)
    purge(bpy.data.collections)
    purge(bpy.data.objects)
    purge(bpy.data.particles)
    purge(bpy.data.materials)
    purge(bpy.data.textures)
    purge(bpy.data.images)
    purge(bpy.data.collections)

def prepare_scene():
    # set output
    eevee = bpy.context.scene.eevee
    render = bpy.context.scene.render
    eevee.use_ssr_refraction = True
    eevee.use_ssr = True
    eevee.use_gtao = True
    eevee.gtao_distance = 1
    
    render.engine = 'CYCLES' #OR EEVEE
    bpy.context.scene.cycles.film_transparent = True
    render.alpha_mode = 'TRANSPARENT'
    render.resolution_x = 150
    render.resolution_y = 150
    render.image_settings.color_mode = 'RGBA'
    render.image_settings.file_format = 'PNG'

    bpy.context.scene.cycles.samples = 32
    bpy.context.scene.cycles.max_bounces = 2
    if 'render_export' not in bpy.data.worlds.keys():
        world = bpy.data.worlds.new(name='render_export')
    else:
        world = bpy.data.worlds['render_export']

    world.use_nodes = False
    world.color = (1,1,1)
    bpy.context.scene.world = world


def add_camera():
    bpy.ops.object.camera_add(rotation=(pi / 2, 0, -pi / 6))
    cam = bpy.context.active_object
    cam.data.shift_y = -.3
    cam.data.lens = 71
    bpy.data.scenes[0].camera = cam
    cam.data.lens = 70


def append_element(blendFile):
    coll_name = os.path.splitext(os.path.basename(blendFile))[0].title()
    obj_coll = bpy.data.collections.new(coll_name)
    active_scene = bpy.context.scene
    active_scene.collection.children.link(obj_coll)
    with bpy.data.libraries.load(blendFile) as (data_from, data_to):
        scenes = [{'name': name} for name in data_from.scenes]
        data_to.scenes = data_from.scenes
    # bpy.ops.wm.append(directory=blendFile + "/Scene/", files=scenes)
    imp_scene = bpy.data.scenes[scenes[0]['name']]
    master_scn = bpy.context.window.scene
    bpy.context.window.scene = imp_scene
    back_obj_vis = {}
    for obj in imp_scene.collection.objects:
        back_obj_vis[obj.name] = obj.hide_get()
        obj_coll.objects.link(obj)

    bpy.context.window.scene = master_scn
    bpy.data.scenes.remove(imp_scene)
    for name, visible in back_obj_vis.items():
        bpy.data.objects[name].hide_set(visible)


if __name__ == '__main__':
    all_thumbs = True if 'all_thumbs' in sys.argv else False
    if not all_thumbs:
        file_name = bpy.path.display_name(bpy.context.blend_data.filepath)  # without extension
        folder = os.path.split(bpy.context.blend_data.filepath)[0]
        out_folder = os.path.join(folder, file_name)
        prepare_scene()
        bpy.context.scene.render.filepath = out_folder
        add_camera()
        bpy.ops.object.select_all(action='SELECT')
        bpy.ops.view3d.camera_to_view_selected()
        
        for area in bpy.context.screen.areas:
            area.type = 'VIEW_3D'
            space = area.spaces[0]
            space.region_3d.view_perspective = 'CAMERA'
            space.shading.type = 'MATERIAL'
            space.overlay.show_overlays = False
        bpy.ops.render.render(write_still=True)
    else: #render all thumbs for all files in library
        # print(sys.argv, len(sys.argv))
        # pref = bpy.context.preferences.addons['garment_tool'].preferences
        lib_path = sys.argv[8]
        force_rerender = True if 'force_rerender' in sys.argv else False
        for dirpath, dirnames, filenames in os.walk(lib_path):
            for file_name in filenames:
                if file_name.endswith('.blend'):
                    prepare_scene()
                    blendFile = os.path.join(dirpath, file_name)
                    png_path = blendFile[:-5] + 'png'
                    # print(f'Blend file: {blendFile}\n\n\n')
                    if not force_rerender and os.path.exists(png_path):  # if not force rerendering then skip
                        continue
                    bpy.context.scene.render.filepath = png_path
                    clean_scene()
                    append_element(blendFile)
                    add_camera()
                    bpy.ops.object.select_all(action='SELECT')
                    bpy.ops.view3d.camera_to_view_selected()

                    for area in bpy.context.screen.areas:
                        area.type = 'VIEW_3D'
                        space = area.spaces[0]
                        space.region_3d.view_perspective = 'CAMERA'
                        space.shading.type = 'RENDERED'
                        space.overlay.show_overlays = False
                    # bpy.ops.render.opengl(write_still=True)
                    bpy.ops.render.render(write_still=True)

    bpy.ops.wm.quit_blender()
