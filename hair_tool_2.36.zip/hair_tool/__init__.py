'''
Copyright (C) 2017 JOSECONSCO
Created by JOSECONSCO

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
#DONE: add converting curves (eg from zbrush) to blender Particle Hair
#DONE: randomize spacing by randomizing   t_ins? +- rand dt (same dt over length (in resample 2d)
#DONE: why flipps happnes?? cos bitangetn is 180deg from VectSurfHit. Not a bug (almost like gimaball lock)
#DONE: Resample output point count  proprotional to len of strand
#DONE: Add flip uv to options
#BUG_IN_BLENDER: GP to PartHair still sometimes is broken (depending on viewing angle)... - cos blender messes up attached hair keys,
#                Comb fix dosent always work
#DONE: GenerateVerColorRandom per strand
#CANNOTDO: ribbon profile curve if possible  - Wont work in f6 mode
#DONE: Edit Curve profile option - more complex profile like " /\/\/\ " <- 3 peaks per one curve
#DONE: option to edit uv boxes (delete, resize)
#DONE: fix align curve random flipping
#DONE: fix last material setup
#done: fix undo in modal uv draw?
#DONE: fix double update when modal hair update generates to muuch undo history
#DONE: why aligning wont work?
#DONE add spline drawwign offset...
#DONE: fix t_in_s in modal particle hair crash
#DONE: Add reset tilt in modal particle hair
#DONE: Added/improved embed operator
#DONE: Fixed Wrong aligning when in edit mode
#DONE: added multi curve attach as particle hair.
#DONE: texturing implementation
#DONE: Diffuse bake
#DONE: fix id baking for curves
#DONE: Add render size for settins
#DONE: Hair baking - make preview settings same as render settings - eg. particle count, spline res etc.
#DONE: add ability to change suffixes for baked textures?
#DONE: add tilt support for child particles
#DONE: Apply curve rotation when aligning titl to prevetn weird rotaton problems
#DONE: add similar to Division strands painitng.. https://www.youtube.com/watch?time_continue=16&v=phanI1WkWgU
#DONE: Include Parents in iinteractive hair with children.
#CANT_REPRODUCE: combing getting slover over time... interactive..
#DONE: randomize curve tilt -> add positive and negative dir.
#DONE: align curve tilt only on sel -> works on whole sel crve now. Make it only on real selection
#DONE: Create Hairs Following Within Geometry Volume ( Like Hair Farm ) - build in blender it seems - Shape Cut
#DONE: add 'use default material' option
#DONE: clumping
#DONE: fix jumping particle whne converting curves to particle hair
#DONE: Allow Rendering 8k Cards
#CANT: change align tilt to Paralel transport - actually slower than current fake method
#DONE: fix goint in and out of mesh -> curve mode - broken uv - caused by braids code - reverted it
#DONE: converting ribbons to mesh - it should link - curve ribbon mat -> mesh ribbon mat.
#DONE: Project on surface - use point normal for projection (instead of snapping) - for curves from grid surface
#DONE: Make website like eg. https://xyz.github.io ?
#DONEx: bake : flatten scalp ? Seams?
#DONE: add editing curve ribbons in obj mode -> to draw hidden splines by bias?


bl_info = {
    "name": "Hair Tool",
    "description": "Make hair planes from curves",
    "author": "Bartosz Styperek",
    "blender": (2, 93, 0),
    "location": "View 3D > Tools > Hair Tool",
    "version": (2, 36, 0),
    "warning": "",
    "wiki_url": "https://joseconseco.github.io/HairToolDocs_28/",
    "tracker_url": "https://discord.gg/cxZDbqH",
    "category": "Object"
}


# load and reload submodules
##################################

if "bpy" in locals():
    import importlib

    importlib.reload(hair_tool_ui)
    importlib.reload(gpu_helpers)
    importlib.reload(curve_wrapper)
    importlib.reload(general_utils)
    importlib.reload(helper_functions)
    importlib.reload(finalize_to_copy)
    importlib.reload(hair_common)
    importlib.reload(profile_operations)
    importlib.reload(generate_braids)
    importlib.reload(curves_from_grid)
    importlib.reload(ribbons_operations)
    importlib.reload(material_operators)
    importlib.reload(resample2d)
    importlib.reload(hair_curve_helpers)
    importlib.reload(hair_mesh_helpers)
    importlib.reload(curve_simplify)
    importlib.reload(particle_hair)
    importlib.reload(uv_draw_boxes)
    importlib.reload(interactive_hair_combing)
    importlib.reload(curves_resample)
    importlib.reload(drawing_curves)
    importlib.reload(hair_tool_props)
    importlib.reload(hair_bake)
    importlib.reload(hair_bake_ui)
    importlib.reload(hair_bake_nodes)
    importlib.reload(ht_image_operators)
    importlib.reload(hair_geometry_nodes)
    importlib.reload(mi_utils_base)
    importlib.reload(mi_widget_linear_deform)
    importlib.reload(deformer_curve)
    importlib.reload(generate_curls)
    importlib.reload(hair_workspace_tool)
    importlib.reload(update_addon)
    importlib.reload(hair_lib)
    importlib.reload(modal_save_hair)
    importlib.reload(jiggle_chain)
else:
    from . import hair_tool_ui
    from .utils import gpu_helpers
    from .utils import curve_wrapper
    from .utils import general_utils
    from .utils import helper_functions
    from .utils import finalize_to_copy
    from .utils import hair_common
    from . import profile_operations
    from . import generate_braids
    from . import curves_from_grid
    from . import ribbons_operations
    from . import material_operators
    from . import resample2d
    from . import hair_curve_helpers
    from . import hair_mesh_helpers
    from . import curve_simplify
    from . import particle_hair
    from . import uv_draw_boxes
    from . import interactive_hair_combing
    from . import curves_resample
    from . import drawing_curves
    from . import hair_tool_props
    from .hair_baking import hair_bake
    from .hair_baking import hair_bake_ui
    from .hair_baking import hair_bake_nodes
    from .hair_baking import ht_image_operators
    from .hair_baking import hair_geometry_nodes
    from .linear_deformer import mi_utils_base
    from .linear_deformer import mi_widget_linear_deform
    from .linear_deformer import deformer_curve
    from . import generate_curls
    from . import hair_workspace_tool
    from . import update_addon
    from .hair_library import hair_lib
    from .hair_library import modal_save_hair
    from . import jiggle_chain


# register
##################################
import bpy
from bpy.app.handlers import persistent
from . import auto_load
from .drawing_curves import change_draw_keymap
# from .hair_workspace_tool import GiGroup
# from .hair_workspace_tool import HTOOL_OT_ToolModelHair
auto_load.init()


def draw_curve_sel(self, context):
    layout = self.layout
    layout.separator()
    layout.operator_context = "INVOKE_DEFAULT"
    op = layout.operator("curve.ht_select_next", text="Select Next")
    op.previous = False
    op = layout.operator("curve.ht_select_next", text="Select Previous")
    op.previous = True
    layout.separator()
    layout.operator("curve.select_tips", text="Select Roots").roots = True
    layout.operator("curve.select_tips", text="Select Tips").roots = False

def draw_curve_sel_obj(self, context):
    called_from_ht_wspace = context.workspace.tools.from_space_view3d_mode(mode=context.mode).idname == "hair_tool.hair_transform"
    obj = context.active_object
    if called_from_ht_wspace and obj and obj.type == 'CURVE':
        layout = self.layout
        layout.separator()
        layout.operator_context = "INVOKE_DEFAULT"
        layout.operator("curve.select_tips")


def draw_save_file_node(self, context):
    layout = self.layout
    node = context.active_node
    if context.active_node and context.active_node.type == 'OUTPUT_FILE':
        layout.operator("node.save_image_file_node")
        layout.separator()


@persistent
def post_load(scene):
    #Scene is None, when addosn is initiailzed. And Keymap'Grease Pencilt' it none too. Lines below work only on new blend load. :<
    use_custom_hair_drawing = bpy.context.scene.ht_props.hair_drawing.runModalHair
    change_draw_keymap(use_custom_hair_drawing)


def register():
    # bpy.utils.register_class(hair_workspace_tool.GiGroup)
    auto_load.register()
    bpy.utils.register_tool(hair_workspace_tool.HTOOL_OT_ToolModelHair, after={"builtin.scale_cage"}, separator=True, group=True)

    print("Registered Hair Tool")

    addon_prefs = general_utils.get_addon_preferences()
    addon_prefs.update_text = ''

    hair_tool_props.register_properties()
    hair_bake_nodes.registerNode()

    # lets add ourselves to the main header
    bpy.types.VIEW3D_MT_select_edit_curve.append(draw_curve_sel)
    bpy.types.VIEW3D_MT_select_object.append(draw_curve_sel_obj)
    bpy.types.NODE_PT_active_node_properties.prepend(draw_save_file_node)
    bpy.app.timers.register(hair_tool_ui.register_keymap, first_interval=1)
    # hair_tool_ui.register_keymap()
    # hair_tool_ui.update_panel(None, bpy.context) # just complicates thing

    bpy.app.handlers.load_post.append(post_load)
    bpy.types.Scene.last_stroke = {}

    hair_lib.reg()
    uv_draw_boxes.append_IMAGE_HT_header()


def unregister():
    obj = bpy.context.active_object
    if obj: #disable interactive combing
        obj.ht_props.modal_hair.runModalHair = False
    uv_draw_boxes.remove_IMAGE_HT_header()
    hair_lib.unreg()

    bpy.app.handlers.load_post.remove(post_load)
    hair_bake_nodes.unregisterNode()
    bpy.context.scene.ht_props.hair_drawing.runModalHair = False  # disable hair drawing, since it wont work on F8 anyway
    hair_tool_ui.unregister_keymap()
    hair_tool_props.unregister_properties()

    bpy.utils.unregister_tool(hair_workspace_tool.HTOOL_OT_ToolModelHair)
    # bpy.utils.unregister_class(hair_workspace_tool.GiGroup)
    auto_load.unregister()
    del bpy.types.Scene.last_stroke
    print("Unregistered Hair Tool.")

    bpy.types.VIEW3D_MT_select_edit_curve.remove(draw_curve_sel)
    bpy.types.NODE_PT_active_node_properties.remove(draw_save_file_node)
    bpy.types.VIEW3D_MT_select_object.remove(draw_curve_sel_obj)


if __name__ == "__main__":
    register()
