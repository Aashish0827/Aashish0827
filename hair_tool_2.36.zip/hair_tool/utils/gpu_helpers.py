'''
Copyright (C) 2017 JOSECONSCO
Created by JOSECONSCO

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import gpu
import bgl
from gpu_extras.batch import batch_for_shader
import blf


def draw_text_line(lines, left_margin= 30, bottom_margin = 30, width_override = False):
    h1_font_size = 17
    p_font_size = 15
    line_height_h1 = int(1.4*h1_font_size)
    line_height_p = int(1.3*p_font_size)
    font_id = 0

    if width_override:
        box_width = width_override
    else:
        max_string_len = len(max(lines, key=lambda p: len(p[0]))[0])
        box_width = max_string_len * (0.5*p_font_size) 
    draw_background_box(width=box_width, height=(len(lines)+2)*line_height_p, left_margin=left_margin-line_height_p, bottom_margin=bottom_margin-line_height_h1)

    accum_y_pos = bottom_margin  # go down line by line from top
    blf.color(font_id, 1.0, 1.0, 1.0, 1.0)
    for line in reversed(lines):
        text, line_type = line
        font_size = h1_font_size if line_type == 'H1' else p_font_size
        blf.size(font_id, font_size, 60)
        blf.position(font_id, left_margin, accum_y_pos, 0)
        blf.draw(font_id, text)
        if line_type == 'H1':
            accum_y_pos += line_height_h1
        else:
            accum_y_pos += line_height_p
    


shader2d = gpu.shader.from_builtin('2D_UNIFORM_COLOR')

def draw_background_box(width, height, left_margin, bottom_margin, alpha = 0.3):
    '''  0  - 1
         |  / |
         2  - 3
    '''
    bgl.glEnable(bgl.GL_BLEND)
    vertices = ((left_margin, bottom_margin+height), (left_margin+width, bottom_margin+height),
                (left_margin, bottom_margin), (left_margin+width, bottom_margin))
    indices = ((0, 1, 2), (2, 3, 1))
    batch = batch_for_shader(shader2d, 'TRIS', {"pos": vertices}, indices=indices)

    shader2d.bind()
    shader2d.uniform_float("color", (0., 0., 0., alpha))
    batch.draw(shader2d)
    bgl.glDisable(bgl.GL_BLEND)



smooth_shader_2d = gpu.shader.from_builtin('2D_SMOOTH_COLOR')
def draw_gradient_box(x0, y0, x1, y1, color_top=(1, 1, 1, 0), color_bottom=(1, 1, 1, 1)):
    '''  0  - 1
         |  / |
         2  - 3
    '''
    bgl.glEnable(bgl.GL_BLEND)

    vertices = ((x0, y0), (x1, y0),
                (x0, y1), (x1, y1))
    indices = ((0, 1, 2), (2, 3, 1))
    
    colors_grad_verts = [color_top, color_top, color_bottom, color_bottom] #per vert color
    batch = batch_for_shader(smooth_shader_2d, 'TRIS', {"pos": vertices, "color": colors_grad_verts}, indices=indices)
    smooth_shader_2d.bind()
    batch.draw(smooth_shader_2d)
    bgl.glDisable(bgl.GL_BLEND)
