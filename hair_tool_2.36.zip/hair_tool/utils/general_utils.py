# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

import bpy
from mathutils import Vector

def get_addon_name():
    return __package__.split(".")[0]

def addon_name_lowercase():
    return get_addon_name().lower()

def get_addon_preferences():
    return bpy.context.preferences.addons[get_addon_name()].preferences

def clear_parent(obj):
    parent = obj.parent
    if parent:
        obj.matrix_basis = parent.matrix_world @ obj.matrix_parent_inverse @ obj.matrix_basis
        obj.parent = None


def set_parent(obj, new_parent):
    if obj.parent:
        old_parent_m_w = obj.parent.matrix_world.copy() #backup cos we will change obj.parent below, so backup
        backup_obj_mpi = obj.matrix_parent_inverse.copy()  # bug in blender: obj.parent = new_parent clears obj.matrix_parent_inverse so backup it
        obj.parent = new_parent
        new_m_p_inv = new_parent.matrix_world.inverted() @ old_parent_m_w @ backup_obj_mpi
        obj.matrix_parent_inverse = new_m_p_inv
    else:
        obj.parent = new_parent
        obj.matrix_parent_inverse = new_parent.matrix_world.inverted()

def assign_material(obj, material_name, clear_materials=True):
    '''Add material to obj. If clear_material is True - reomve all slots exept first.'''
    mat = bpy.data.materials.get(material_name)
    if not mat:
        print('Material %s dosen\'t exist!' % (material_name))
        return
    if clear_materials is True:
        while len(obj.material_slots) > 1:
            obj.data.materials.pop()
    if len(obj.material_slots) == 0:  # make sure first slot is assigned
        obj.data.materials.append(mat)
    else:
        obj.material_slots[0].material = mat


def unlink_from_scene(obj):
    for col in obj.users_collection:
        col.objects.unlink(obj)
    if obj.name in bpy.context.scene.collection.objects.keys():
        bpy.context.scene.collection.objects.unlink(obj)
    obj.use_fake_user = True


def link_child_to_collection(parent_obj, clone):
    ''' Link clone to collection where parent_obj is located '''
    if parent_obj.users_collection:
        for col in parent_obj.users_collection:
            if clone.name not in col.objects.keys():
                col.objects.link(clone)
            # else:
            #     return
    else:
        if clone.name not in bpy.context.scene.collection.objects.keys():
            bpy.context.scene.collection.objects.link(clone)
        else:
            return

def replace_material(old_mat, new_mat):
    ''' replace old_mat in objs slots '''
    for data in bpy.data.curves:
        for slot_id, mat in enumerate(data.materials):
            if mat == old_mat:
                data.materials[slot_id] = new_mat
    for data in bpy.data.meshes:
        for slot_id, mat in enumerate(data.materials):
            if mat == old_mat:
                data.materials[slot_id] = new_mat
    old_name = old_mat.name
    # if old_mat.users != 0: #wont work sice curve.ht_props.linked_mesh_mat - is not cleared...
        # print(f'Somethign went wrong, material {old_name} should have been replaced.')
    bpy.data.materials.remove(old_mat)
    new_mat.name = old_name

def get_seam_edges(bm):
    '''get edges that are seams but non border '''
    seam_edges = []
    # uv_lay = bm.loops.layers.uv['UB']
    uv_lay = bm.loops.layers.uv.active
    for e in bm.edges:
        #noo need to split this since alrady border
        # if len(e.link_faces) == 1:
        #     e.select = True
        if len(e.link_faces) == 2:
            e_loop1 = e.link_loops[0]
            e_loop2 = e.link_loops[1]
            if e_loop1[uv_lay].uv != e_loop2.link_loop_next[uv_lay].uv or e_loop2[uv_lay].uv != e_loop1.link_loop_next[uv_lay].uv:
                seam_edges.append(e)
    return seam_edges


def deleteGroup(currentGroup):
    for groupObj in currentGroup.objects:
        bpy.data.objects.remove(groupObj)
    for obj in bpy.data.objects:    # then delete all empties in scene that used that group  -- including currentEmpty (which is now linked to scene)
        # or if different empties are left empty, then delete those too
        if obj.type == 'EMPTY' and obj.instance_collection and (obj.instance_collection.name == currentGroup.name or len(obj.instance_collection.objects) == 0):
            bpy.data.objects.remove(obj)
    bpy.data.collections.remove(currentGroup, do_unlink=True)

def link_obj_to_same_collections(source_obj, clone, force_linking = True):
    ''' Link obj to collections where source_obj is located '''
    was_linked = False
    for source_obj_coll_parent in source_obj.users_collection:
        if clone.name not in source_obj_coll_parent.objects.keys():
            source_obj_coll_parent.objects.link(clone)
            was_linked = True

    if source_obj.name in bpy.context.scene.collection.objects.keys():
        if clone.name not in bpy.context.scene.collection.objects.keys():
            bpy.context.scene.collection.objects.link(clone)
            was_linked = True
    if not was_linked and force_linking: #link to at least one collection
        bpy.context.scene.collection.objects.link(clone)


def link_coll_to_same_collections(source_obj, clone_coll):
    ''' Link clone col to collections where source_obj is located '''
    for source_obj_coll_parent in source_obj.users_collection:
        if clone_coll.name not in source_obj_coll_parent.children.keys():
            source_obj_coll_parent.children.link(clone_coll)
    if source_obj.name in bpy.context.scene.collection.objects.keys():
        if clone_coll.name not in bpy.context.scene.collection.children.keys():
            bpy.context.scene.collection.children.link(clone_coll)


def find_create_collection(parent_col, searched_col_name):
    ''' Try to find searched collection name in parent childrens. If not found create it and link it to master'''
    def find_coll(p_coll, search_col):
        if search_col == p_coll.name:
            return True
        if search_col in p_coll.children.keys():
            return True
        else:
            for child_col in p_coll.children:
                if find_coll(child_col, search_col):
                    return True
        return False

    if find_coll(parent_col, searched_col_name):
        collection = bpy.data.collections[searched_col_name]
    else:
        if searched_col_name in bpy.data.collections.keys():
            collection = bpy.data.collections[searched_col_name]
        else:
            collection = bpy.data.collections.new(searched_col_name)
        parent_col.children.link(collection)
    return collection



def unlink_obj_from_scene(context, obj, exclude_coll = None):
    ''' ulink form all collections, exept exclude_coll'''
    obj.use_fake_user = True
    for coll in obj.users_collection:
        if exclude_coll and coll == exclude_coll:
            continue
        coll.objects.unlink(obj)  # needs to be visible for matrix transform to work so we hide it now
    if obj.name in context.scene.collection.objects.keys():  # if in master collection unlinke it
        context.scene.collection.objects.unlink(obj)

def link_to_scene_coll(context, obj):
    if obj.name not in context.scene.collection.objects.keys():
        context.scene.collection.objects.link(obj)


def unlink_col_from_coll_children_nested(parent_col, remove_coll):
    '''unlink remove_coll from parent_col.children recursive '''
    for child_coll in parent_col.children:  # and its child cools
        unlink_col_from_coll_children_nested(child_coll, remove_coll)
    if remove_coll.name in parent_col.children.keys():
        parent_col.children.unlink(remove_coll)

def vec3d_to_screen2d(context, co_3d):
    r3d = context.region_data
    #r3d.view_matrix - cam mat world
    #r3d.window_matrix - only fov ?
    # perspective_matrix = window_matrix * view_matrix
    co_cam_3d = r3d.perspective_matrix @ co_3d.to_4d()  # should be (x,y,z,1) - point
    cam_co_2d_normalized = Vector((co_cam_3d.x/co_cam_3d.w, co_cam_3d.y/co_cam_3d.w))  # in <-1,1> range
    # print(cam_co_2d_normalized)
    cam_co_2d = Vector((context.region.width, context.region.height)) * (cam_co_2d_normalized + Vector((1, 1)))/2  # remap to (0, win_width)
    # print(cam_co_2d)
    return cam_co_2d


def create_new_curve_obj(obj_name, parent_obj = None, set_active = True):
    curveData = bpy.data.curves.new(obj_name+'curve', type='CURVE')
    curveData.dimensions = '3D'
    curveData.bevel_resolution = 2
    curveData.fill_mode = 'FULL'
    curveData.resolution_u = 3
    # curveData.use_uv_as_generated = True
    curveData.use_auto_texspace = True
    new_curve_obj = bpy.data.objects.new(obj_name, curveData)
    if parent_obj:
        link_obj_to_same_collections(parent_obj, new_curve_obj)
    else:
        bpy.context.scene.collection.objects.link(new_curve_obj)

    if set_active:
        bpy.context.view_layer.objects.active = new_curve_obj
        new_curve_obj.select_set(True)
        parent_obj.select_set(False)

    return new_curve_obj
