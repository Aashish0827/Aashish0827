# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
# Copyright (C) 2017 JOSECONSCO
# Created by JOSECONSCO

import bpy
import os


class HTOOL_OT_OutputImageSave(bpy.types.Operator):
    bl_idname = "node.save_image_file_node" 
    bl_label = "Save Output Images"
    bl_description = "Save output images from File Output node"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        return context.active_object

    def execute(self, context):
        # bpy.ops.render.render(write_still=True)
        node_tree = context.scene.node_tree
        if 'File Output' not in node_tree.nodes.keys():
            self.report({'ERROR'}, f'Create and connect \'File Output\' node first')
            return {'CANCELLED'}
        file_output_node = node_tree.nodes['File Output']
        bpy.context.scene.render.use_compositing = True

        # comp_node = node_tree.nodes['Composite']
        out_folder = file_output_node.base_path
        bpy.ops.render.render(animation=False, write_still=False, use_viewport=False)
        for node_input, file_slot in zip(file_output_node.inputs, file_output_node.file_slots):
            # from_node = node_input.links[0].from_node
            # from_socket = node_input.links[0].from_socket
            if node_input.links:  # is input of output File node connected?
                out_format = file_output_node.format if file_slot.use_node_format else file_slot.format
                out_path = os.path.join(bpy.path.abspath(out_folder), file_slot.path+'.' + out_format.file_format.lower())
                broken_path = os.path.join(bpy.path.abspath(out_folder), file_slot.path+'0001.' + out_format.file_format.lower())
                os.replace(broken_path, out_path)
                self.report({'INFO'}, f'File {out_path} saved sucesfully')
                
                # bpy.data.images['Render Result'].save_render(filepath=out_path)

        bpy.context.scene.render.use_compositing = False

        return {"FINISHED"}



class HTOOL_OT_SaveImage(bpy.types.Operator):
    bl_idname = "image.save_img"
    bl_label = "save img"
    bl_description = "Save image"
    bl_options = {"REGISTER","UNDO"}

    image_name: bpy.props.StringProperty()
    image_path: bpy.props.StringProperty()
    image_format: bpy.props.StringProperty(default='PNG')

    def execute(self, context):
        suffix = 'png' if self.image_format=='PNG' else 'tga'
        img_name = self.image_name +'.'+suffix
        if img_name in bpy.data.images.keys():
            outputImg = bpy.data.images[img_name]
            outputImg.file_format = self.image_format
            abs_path = bpy.path.abspath(self.image_path+img_name)
            outputImg.filepath_raw = abs_path
            outputImg.save()
        return {"FINISHED"}
