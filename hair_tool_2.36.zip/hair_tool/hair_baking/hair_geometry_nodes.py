# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
# Copyright (C) 2021 JOSECONSCO
# Created by JOSECONSCO

import bpy
from os import path
from ..utils.helper_functions import  clamp

hair_nodes_groups = ('Noise Deform', 'Curls', 'Clump', 'Twist', 'Trim') # node_tree.name
helper_node_groups = ('Show Parents',)        # node_tree.name
hair_helper_nodes = {'Sample Parent Strands'}  # do not count this into node stack
profile_node_name = 'Add Profile'
draw_parents_node_name = 'Add Parent Curves'      # node.name
parents_reroute_node_name = 'Parents Reroute'


join_with_parent_node_name = 'Add Parent Curves'  # node.name
input_capture_node_name = 'Curve Attributes'
final_capture_node_name = 'Capture Curve Attributes'
parent_sampler_node_name = 'Sample Parent Strands'
generate_strands_node_name = 'Generate Strands'
separate_parent_components_node_name = 'Separate Parent Components'

hair_gen_mod_node_gr_name = 'Hair_Gen_Main' # XXX: main hair generation node group

# for curve guide
guide_curve_node_name = 'Curve Guide'
guide_mod_node_group_name = 'Guide_Curve'  # XXX: main load curve mod node group
set_guide_mod_name = 'SetGuide'

# DONE: importing nodes borkn when old exist.  Bring back mat importer - that check for old nodes - and overrides them (from default hair mat importer?)
# DONE: add reload gnodes from library?
# DONE: taper and profile edit
# TODO: add parent outside of Hair Stack (from scene objs)
# TODO: faster inter com for radius calc
# TODO: Disable resample on trim - if not parent - not worth the time..

# done: add global lock icon for eg. steps, len?

def is_node_hair_type(node):
    ''' check if node is hair type '''
    if node.type == 'GROUP' and node.node_tree.name in hair_nodes_groups:
        return True
    else:
        return False

def get_hair_stack_nodes(node_tree, with_setup_node = False):
    # main_group_input = node_tree.nodes.get('Group Input')
    # main_group_output = node_tree.nodes.get('Group Output')
    starting_node = node_tree.nodes.get(parent_sampler_node_name) # we plug final geo into its inputs['Geometry']
    ending_node = node_tree.nodes.get(join_with_parent_node_name) # in theory hair nodes stack should end with this node
    if starting_node.outputs[0].links:
        link = starting_node.outputs[0].links[0]  # skip first link - since it is just passing main mesh geometry
        nodes_stack = []
        if with_setup_node:
            nodes_stack.append(node_tree.nodes.get(generate_strands_node_name))
        while link.to_node and link.to_node != ending_node:
            nodes_stack.append(link.to_node)
            link = link.to_node.outputs[0].links[0]
        return nodes_stack
    else:
        return None


def get_hair_mod_list(obj):
    return  [m for m in obj.modifiers if m.type=='NODES' and m.name.startswith('GenerateHair')] # or m.node_group.name.startswith('GenerateHair')

def hair_mod_by_idx(mod_idx, obj):
    hair_mods = get_hair_mod_list(obj)
    return hair_mods[mod_idx]

def get_node_group_by_type(node_tree, node_type):
    for node in node_tree.nodes:
        if node.type == 'GROUP' and node.node_tree.name == node_type:
            return node.node_tree


def connect_curve_attributes(node_tree, node, use_sampler_node=False):
    ''' connect position, tangent, normal etc to node '''
    links = node_tree.links
    if use_sampler_node: # connect to sampler node (parent setup)
        curve_attributes = node_tree.nodes.get(parent_sampler_node_name)
    else:  # connect to curve attributes node (non child setup)
        curve_attributes = node_tree.nodes.get(input_capture_node_name)
    position = curve_attributes.outputs['Position']
    tangent = curve_attributes.outputs['Tangent']
    normal = curve_attributes.outputs['Normal']
    length = curve_attributes.outputs['Length Factor']
    id = curve_attributes.outputs['ID']
    resolution = curve_attributes.outputs['Resolution']

    # NOTE:  try connect these
    if 'Position' in node.inputs:
        links.new(position, node.inputs['Position'])
    if 'Tangent' in node.inputs:
        links.new(tangent, node.inputs['Tangent'])
    if 'Normal' in node.inputs:
        links.new(normal, node.inputs['Normal'])
    if 'Length Factor' in node.inputs:
        links.new(length, node.inputs['Length Factor'])
    if 'ID' in node.inputs:
        links.new(id, node.inputs['ID'])
    if 'Resolution' in node.inputs:
        links.new(resolution, node.inputs['Resolution'])


def switch_node_space(self, context):
    gnode = self
    gnode_idx = int(gnode.path_from_id()[-2]) # particleModalSettings type
    mod_idx = int(gnode.path_from_id()[-17]) # 'ht_props.hair_system.gmod_stack[0].gnode_stack[1]
    obj = gnode.id_data  # owner of gnode_stack[n]
    hair_mod = hair_mod_by_idx(mod_idx, obj)
    node_tree = hair_mod.node_group
    sel_node = get_node_by_idx(node_tree, gnode_idx)
    connect_curve_attributes(node_tree, sel_node, use_sampler_node=gnode.use_parent_space)


def show_in_viewport(self, context):
    obj = context.active_object
    mod_idx = int(self.path_from_id()[-2]) # particleModalSettings type

    hair_mods = get_hair_mod_list(obj)
    vis_mods_ids = [i for i,hmod in enumerate(hair_mods) if hmod.show_viewport]
    # XXX: self.show_in_viewport - is state is inverted --> when we hide self.show_in_viewport = True, and vice versa
    # NOTE: if we hide mod_idx, and it is last visible, and not the only visible:
    hair_mod =  hair_mod_by_idx(mod_idx, obj)
    if not self.show_in_viewport and mod_idx == vis_mods_ids[-1] and len(vis_mods_ids)>1: # if we disabled last visible mod
        # unhide profile of previous (before last) visible mod
        prev_vis_mod_idx = vis_mods_ids[-2]
        prev_mod = hair_mods[prev_vis_mod_idx]
        enable_profile(prev_mod, enable = True) # show if we disabled last visible mod

        enable_profile(hair_mod, enable = False) # show if we enabled first visible mod
    # NOTE: if we show mod, and there are other visible mods, and it is after last visible
    elif self.show_in_viewport and len(vis_mods_ids)>0 and mod_idx > vis_mods_ids[-1] : # if we enabled first visible mod
        # hide profile of last visible mod
        last_vis_mod_idx = vis_mods_ids[-1]
        last_vis_mod = hair_mods[last_vis_mod_idx]
        enable_profile(last_vis_mod, enable = False) # show if we enabled first visible mod

        hair_mod =  hair_mod_by_idx(mod_idx, obj)
        enable_profile(hair_mod, enable = True) # show if we enabled first visible mod

    hair_mod.show_viewport = self.show_in_viewport


def set_as_child_mod(self, context):
    obj = context.active_object
    mod_idx = int(self.path_from_id()[-2]) # particleModalSettings type

    hair_mod = hair_mod_by_idx(mod_idx, obj)
    node_tree = hair_mod.node_group

    sampler_node = node_tree.nodes.get(parent_sampler_node_name)
    sampler_node.mute = not self.set_as_child

    join_node = node_tree.nodes.get(join_with_parent_node_name)
    join_node.mute = False if not self.set_as_child else join_node.mute  # draw parents if not chidl

    nodes_list = get_hair_stack_nodes(node_tree)
    if nodes_list:
        for base_node in nodes_list:
            connect_curve_attributes(hair_mod.node_group, base_node, use_sampler_node=self.set_as_child)

    # NOTE: set above hair mods 'steps' in 'Generate Strands' node to same value as current gmod sytem
    sync_steps_from_current(mod_idx, obj)


def change_active_mod(self, context):
    '''self - hair_system'''
    obj = context.active_object
    mod_idx = self.gmod_idx
    hair_mod = hair_mod_by_idx(mod_idx, obj)
    obj.modifiers.active = hair_mod

def change_attribute_mod(self, context, attr, selected_gmod = None):
    ''' self - hair_system, attr - Length, Steps, etc '''
    hair_sytem = self
    obj = context.active_object
    for mod_idx, gmod_item in enumerate(hair_sytem.gmod_stack):
        # if getattr(gmod_item, f'use_global_{attr.lower()}'):
        use_global = getattr(gmod_item, f'use_global_{attr.lower()}')
        if use_global or (selected_gmod and gmod_item == selected_gmod):
            hair_mod = hair_mod_by_idx(mod_idx, obj)
            node_tree = hair_mod.node_group
            gen_strands_node = node_tree.nodes.get(generate_strands_node_name)
            global_value = getattr(hair_sytem, f'global_{attr.lower()}')
            gen_strands_node.inputs[attr].default_value = global_value

    # NOTE: special case for Guide Curves mod
    guide_curve_mod = obj.modifiers.get(set_guide_mod_name)
    if guide_curve_mod:
        node_tree = guide_curve_mod.node_group
        guide_curve = node_tree.nodes.get(guide_curve_node_name) if node_tree else None
        guide_curve.inputs['Steps'].default_value = hair_sytem.global_steps


def get_node_by_idx(hair_node_tree, gnode_idx):
    node_stack = get_hair_stack_nodes(hair_node_tree, with_setup_node=True)
    return node_stack[gnode_idx] if gnode_idx < len(node_stack) else None # we put new node after current node


class GMOD_UL_List(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        # mod_idx = int(item.path_from_id()[-2]) # particleModalSettings type
        # gmod_idx = data.gmod_idx
        mod_idx = index
        obj = context.active_object
        hair_system = obj.ht_props.hair_system
        gmod_item = hair_system.gmod_stack[mod_idx]
        hair_mod = hair_mod_by_idx(mod_idx, obj)

        # target_psys_name = obj.particle_systems[idx].name if idx < len(obj.particle_systems) else 'No Target'

        split = layout.split(factor=0.5)
        row = split.row(align=True)
        row.prop(item, 'mod_name', text='', emboss=False)

        row = split.row(align=True)
        row.alignment = 'RIGHT'
        node_tree = hair_mod.node_group
        if node_tree.users > 1:
            op = row.operator('object.make_system_unique', text=str(node_tree.users), emboss=True)
            op.index = mod_idx
        # row.label(text=item.mod_name, icon= 'NODE' )
        # row.prop(hair_mod, 'show_viewport', text='', icon='RESTRICT_VIEW_ON', emboss=False, icon_only=True)
        row.prop(gmod_item, 'show_in_viewport', text='', icon='RESTRICT_VIEW_OFF' if gmod_item.show_in_viewport else 'RESTRICT_VIEW_ON', emboss=False, icon_only=True)
        row.prop(gmod_item, 'set_as_child', text='', emboss=False, icon='LINKED' if gmod_item.set_as_child else 'UNLINKED')
        # if gmod_item.set_as_child:
        draw_parent_node = node_tree.nodes.get(draw_parents_node_name)
        if gmod_item.set_as_child:
            row.prop(draw_parent_node, 'mute', text='', emboss=False, icon='RESTRICT_RENDER_ON' if draw_parent_node.mute else 'RESTRICT_RENDER_OFF', icon_only=True)

class GNODE_UL_List(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        # data -> gmod_item
        # item -> gnode_item
        # gnode_idx = int(item.path_from_id()[-2])
        gnode_idx = index # XXX: does it work
        obj = context.active_object
        hair_system = obj.ht_props.hair_system
        gmod_stack = hair_system.gmod_stack
        gmod_item = data
        gmod_idx = int(data.path_from_id()[-2])
        gnode_item = item
        hair_mod = hair_mod_by_idx(gmod_idx, obj)
        node_tree = hair_mod.node_group
        node = get_node_by_idx(node_tree, gnode_idx)
        # target_psys_name = obj.particle_systems[idx].name if idx < len(obj.particle_systems) else 'No Target'
        if node:
            row = layout.row(align=True)
            row.label(text=node.node_tree.name, icon= 'NODE' )
            if node:
                row.prop(node, 'mute', text='', emboss=False, icon='HIDE_ON' if node.mute else 'HIDE_OFF')


class OBJECT_OT_Clear_Hair_Systems(bpy.types.Operator):
    bl_idname = "object.clear_hair_systems"
    bl_label = "Remove all Hair Systems"
    bl_description = "Remove all Hair Systems, including all geometry nodes modifiers"
    bl_options = {"REGISTER","UNDO"}

    @classmethod
    def poll(cls, context):
        return context.active_object

    def execute(self, context):
        obj = context.active_object
        cnt = len(obj.ht_props.hair_system.gmod_stack)
        obj.ht_props.hair_system.gmod_stack.clear()
        hair_mods = get_hair_mod_list(obj)
        for hair_mod in hair_mods:
            obj.modifiers.remove(hair_mod)
        obj.ht_props.hair_system.is_using_gnodes = False
        self.report({'INFO'}, f'Removed {cnt} Hair Systems')

        return {"FINISHED"}


class OBJECT_OT_Make_System_Unique(bpy.types.Operator):
    bl_idname = "object.make_system_unique"
    bl_label = "Make Hair System unique"
    bl_description = "Make Hair System unique"
    bl_options = {"REGISTER","UNDO"}

    index: bpy.props.IntProperty(name="Index", default=0)

    @classmethod
    def poll(cls, context):
        return context.active_object

    def execute(self, context):
        obj = context.active_object
        hair_system = obj.ht_props.hair_system
        # gmod_stack = hair_system.gmod_stack
        hair_mod = hair_mod_by_idx(self.index, obj)
        hair_mod.node_group = hair_mod.node_group.copy()
        return {"FINISHED"}


class HT_MT_HairSystemMenu(bpy.types.Menu):
    bl_idname = "HT_MT_HairSystemMenu"
    bl_label = "Hair System Menu"

    def draw(self, context):
        layout = self.layout
        layout.operator("object.clear_hair_systems", icon='CANCEL')
        props = layout.operator('object.move_hair_system', icon='TRIA_UP', text="Move Hair System Up")
        props.direction = 'UP'
        props = layout.operator('object.move_hair_system', icon='TRIA_DOWN', text="Move Hair System Down")
        props.direction = 'DOWN'

class HT_MT_HairNodesMenu(bpy.types.Menu):
    bl_idname = "HT_MT_HairNodesMenu"
    bl_label = "Hair Nodes Menu"

    def draw(self, context):
        layout = self.layout
        layout.operator('object.revert_hair_node', icon='FILE_REFRESH')

        props = layout.operator("node.move_hair_node", icon='TRIA_UP', text="Move Deformer Up")
        props.direction = 'UP'
        props = layout.operator("node.move_hair_node", icon='TRIA_DOWN', text="Move Deformer Down")
        props.direction = 'DOWN'


class OBJECT_OT_Revert_Hair_Node(bpy.types.Operator):
    bl_idname = "object.revert_hair_node"
    bl_label = "Reset Hair Node"
    bl_description = "Reverts selected Hair Node to its default configuration\nAlso usefull to update node to its latest version"
    bl_options = {"REGISTER","UNDO"}

    @classmethod
    def poll(cls, context):
        return context.active_object

    def execute(self, context):
        obj = context.active_object
        hair_system = obj.ht_props.hair_system
        gmod_stack = hair_system.gmod_stack
        gmod_item = gmod_stack[hair_system.gmod_idx]

        hair_mod = hair_mod_by_idx(hair_system.gmod_idx, obj)
        hair_node_tree = hair_mod.node_group
        current_node = get_node_by_idx(hair_node_tree, gmod_item.gnode_idx)

        import_node_group(current_node.node_tree.name, force_update=True)
        self.report({'INFO'}, f'Updated {current_node.node_tree.name} node group from Hair Tool library')

        return {"FINISHED"}

class HT_GeoPanel:
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Hair Tool"

class  HTOOL_PT_HairSystemPanel(HT_GeoPanel, bpy.types.Panel):
    bl_label = "Hair Nodes"
    bl_idname = "HTOOL_PT_HairSystemPanel"
    bl_space_type = 'VIEW_3D'
    bl_options = {'DEFAULT_CLOSED'}
    # bl_context = "object"

    @classmethod
    def poll(cls, context):
        return context.active_object and context.mode  == 'OBJECT' and context.active_object.type == 'MESH'

    def draw(self, context):
        layout = self.layout
        if bpy.app.version < (3, 0, 0):
            layout.label(text="Upgrade to Blender 3.0 to use this feature", icon='ERROR')
            return
        obj = context.active_object
        hair_system = obj.ht_props.hair_system
        guide_curve_mod = obj.modifiers.get(set_guide_mod_name)
        if guide_curve_mod:
            col = layout.column(align=True)
            node_tree = guide_curve_mod.node_group
            guide_curve_node = node_tree.nodes.get(guide_curve_node_name) if node_tree else None
            for input in guide_curve_node.inputs:
                # row.prop(hair_system, 'global_steps') - it is using global steps in background
                if input.name != 'Steps': #show global steps
                    row = col.row(align=True)
                    row.prop(input, 'default_value', text=input.name)
                    row.operator("object.delete_guide_curves", icon='CANCEL', text='')
            row = col.row(align=True)
            row.enabled = guide_curve_node.inputs['Curve'].default_value is not None
            row.operator("object.bind_guide_curve", icon='CON_FOLLOWPATH')
        else:
            layout.operator("object.setup_curve_guide", icon='LINKED')
        # layout.label(text='Hair Systems')
        row = layout.row(align=True)
        row.template_list("GMOD_UL_List", "", hair_system, "gmod_stack", hair_system, "gmod_idx", rows=2)
        col = row.column(align=True)
        col.operator('object.add_hair_modifier', icon='ADD', text='')
        col.operator('object.delete_hair_modifier', icon='REMOVE', text='')
        col.menu("HT_MT_HairSystemMenu", text='', icon='DOWNARROW_HLT')

        gmod_stack = hair_system.gmod_stack
        # layout.label(text=f'gmod idx: {hair_system.gmod_idx+1}/{len(gmod_stack)}')
        gmod_idx = hair_system.gmod_idx
        gmod_item = gmod_stack[gmod_idx] if gmod_idx < len(gmod_stack) else None
        if not gmod_item:
            return


class HTOOL_PT_GNodePanel(HT_GeoPanel, bpy.types.Panel):
    bl_parent_id = "HTOOL_PT_HairSystemPanel"
    bl_idname = 'HTOOL_PT_GNodePanel'
    bl_label = "Deformers"

    @classmethod
    def poll(cls, context):
        return context.active_object

    # def draw_header(self, context):
    #     obj_uv_props = context.active_object.ht_props
    #     self.layout.prop(obj_uv_props, 'use_auto_uv', text='')

    def draw(self, context):
        layout = self.layout
        obj = context.active_object
        hair_system = obj.ht_props.hair_system
        gmod_stack = hair_system.gmod_stack
        # layout.label(text=f'gmod idx: {hair_system.gmod_idx+1}/{len(gmod_stack)}')
        gmod_idx = hair_system.gmod_idx
        gmod_item = gmod_stack[gmod_idx] if gmod_idx < len(gmod_stack) else None
        if not gmod_item:
            return
        box = layout
        # box.label(text='Deformers', icon='DOWNARROW_HLT')
        row = box.row(align=True)
        row.template_list("GNODE_UL_List", "", gmod_item, "gnode_stack", gmod_item, "gnode_idx", rows=3)
        col = row.column(align=True)
        col.operator_menu_enum('object.add_hair_geo_node', property='new_node', icon='ADD', text='')
        col.operator('object.delete_hair_geo_node', icon='REMOVE', text='')

        col.separator()

        col.menu("HT_MT_HairNodesMenu", text='', icon='DOWNARROW_HLT')

        col = box.column()
        node_idx = gmod_item.gnode_idx
        # layout.label(text=f'gnode idx: {gmod_item.gnode_idx+1}/{len(gmod_item.gnode_stack)}')
        if node_idx < len(gmod_item.gnode_stack):
            gnode_item = gmod_item.gnode_stack[node_idx]
            hair_mod = hair_mod_by_idx(gmod_idx, obj)
            node_tree = hair_mod.node_group if hair_mod else None
            if node_tree:
                node = get_node_by_idx(node_tree, node_idx) # with_setup_node
                col = box.column(align=True)
                for input in node.inputs:
                    if not input.is_linked:
                        row = col.row(align=True)
                        if input.name == 'Steps': #show global steps
                            if gmod_item.use_global_steps:
                                row.prop(hair_system, 'global_steps')
                            else:
                                row.prop(input, 'default_value', text=input.name)
                            row.prop(gmod_item, 'use_global_steps', text='', icon='LOCKED' if gmod_item.use_global_steps else 'UNLOCKED')

                        elif input.name == 'Length': #show global steps
                            if gmod_item.use_global_length:
                                row.prop(hair_system, 'global_length')
                            else:
                                row.prop(input, 'default_value', text=input.name)
                            row.prop(gmod_item, 'use_global_length', text='', icon='LOCKED' if gmod_item.use_global_length else 'UNLOCKED')
                            # op = row.operator('object.sync_steps', icon='FILE_REFRESH', text='')
                            # op.gmod_idx = gmod_idx
                        else:
                            row.prop(input, 'default_value', text=input.name)
                if node.node_tree.name == generate_strands_node_name:
                    profile_node = node_tree.nodes.get(profile_node_name)
                    col = box.column(align=True)
                    row = col.row(align=True)
                    row.label(text='Profile:')
                    for input in profile_node.inputs:
                        if not input.is_linked:
                            row = col.row(align=True)
                            row.prop(input, 'default_value', text=input.name)

                if node.node_tree.name == 'Curls':
                    row = col.row(align=True)
                    row.enabled = gmod_item.set_as_child
                    row.prop(gnode_item, 'use_parent_space', icon='FILE_PARENT')


class NODE_OT_Move_HairSystem(bpy.types.Operator):
    bl_idname = "object.move_hair_system"
    bl_label = "Move Hair System"
    bl_description = "Move Hair System"
    bl_options = {"REGISTER","UNDO"}

    direction: bpy.props.EnumProperty(name='Direction', description='',
        items=[
            ('UP', 'Up', ''),
            ('DOWN', 'Down', '')
        ], default='UP')


    @classmethod
    def poll(cls, context):
        return context.active_object

    def execute(self, context):
        obj = context.active_object
        hair_system = obj.ht_props.hair_system

        gmod_stack = hair_system.gmod_stack
        gmod_idx = hair_system.gmod_idx

        current_hair_mod = hair_mod_by_idx(gmod_idx, obj)
        stack_cnt = len(gmod_stack)
        if self.direction == 'UP': # move left
            swap_index = clamp(gmod_idx - 1, 0, stack_cnt - 1)
            if swap_index != gmod_idx:
                current_hair_mod['Output_8_attribute_name'] = '' # is going up
                current_hair_mod['Output_9_attribute_name'] = ''
                current_hair_mod['Output_10_attribute_name'] = ''
                current_hair_mod['Output_11_attribute_name'] = ''
                if gmod_stack[swap_index].show_in_viewport: # if above is visible, then we do not need profile
                    enable_profile(current_hair_mod, enable=False)

                above_hair_mod = hair_mod_by_idx(swap_index, obj) # is going down
                above_hair_mod['Output_8_attribute_name'] = 'Normal'
                above_hair_mod['Output_9_attribute_name'] = 'Tangent'
                above_hair_mod['Output_10_attribute_name'] = 'Factor'
                above_hair_mod['Output_11_attribute_name'] = 'Random'
                if swap_index == stack_cnt - 2: # seems we move from n-1 to n-2. So above_mod becomes last
                    enable_profile(above_hair_mod, enable=gmod_stack[swap_index].show_in_viewport)

                gmod_stack.move(swap_index, gmod_idx)
                bpy.ops.object.modifier_move_up(modifier=current_hair_mod.name)
                hair_system.gmod_idx = swap_index
        else: # move down
            swap_index = clamp(gmod_idx + 1, 0, stack_cnt - 1)
            if swap_index != gmod_idx:
                current_hair_mod['Output_8_attribute_name'] = 'Normal'  # is going down
                current_hair_mod['Output_9_attribute_name'] = 'Tangent'
                current_hair_mod['Output_10_attribute_name'] = 'Factor'
                current_hair_mod['Output_11_attribute_name'] = 'Random'
                if swap_index == stack_cnt - 1: # only enable profile if it's the last one
                    enable_profile(current_hair_mod, enable=gmod_stack[gmod_idx].show_in_viewport)

                below_hair_mod = hair_mod_by_idx(swap_index, obj)   # is going up
                below_hair_mod['Output_8_attribute_name'] = ''
                below_hair_mod['Output_9_attribute_name'] = ''
                below_hair_mod['Output_10_attribute_name'] = ''
                below_hair_mod['Output_11_attribute_name'] = ''
                if gmod_stack[gmod_idx].show_in_viewport: # if below is visible, then we do not need profile
                    enable_profile(below_hair_mod, enable=False)

                gmod_stack.move(swap_index, gmod_idx)
                bpy.ops.object.modifier_move_down(modifier=current_hair_mod.name)
                hair_system.gmod_idx = swap_index
        return {"FINISHED"}


class NODE_OT_Move_Hair_Node(bpy.types.Operator):
    bl_idname = "node.move_hair_node"
    bl_label = "Move node"
    bl_description = "Move hair node"
    bl_options = {"REGISTER","UNDO"}

    direction: bpy.props.EnumProperty(name='Direction', description='',
        items=[
            ('UP', 'Up', ''),
            ('DOWN', 'Down', '')
        ], default='UP')


    @classmethod
    def poll(cls, context):
        return context.active_object

    def move_node(self, node_tree, current_node):
        links = node_tree.links
        if self.direction == 'UP': # left
            before_node = current_node.inputs[0].links[0].from_node
            if not is_node_hair_type(before_node):
                return
            before_node_from_socket = before_node.inputs[0].links[0].from_socket
            current_node_to_socket = current_node.outputs[0].links[0].to_socket

            backup_current_location = current_node.location.copy()
            current_node.location = before_node.location
            before_node.location = backup_current_location
            links.new(before_node_from_socket, current_node.inputs[0])
            links.new(before_node.outputs[0], current_node_to_socket)
            links.new(current_node.outputs[0], before_node.inputs[0])
        else: # right
            after_node = current_node.outputs[0].links[0].to_node
            if not is_node_hair_type(after_node):
                return
            after_node_to_socket = after_node.outputs[0].links[0].to_socket
            current_node_from_socket = current_node.inputs[0].links[0].from_socket

            backup_current_location = current_node.location.copy()
            current_node.location = after_node.location
            after_node.location = backup_current_location

            links.new(current_node_from_socket, after_node.inputs[0])
            links.new(current_node.outputs[0], after_node_to_socket)
            links.new(after_node.outputs[0], current_node.inputs[0])


    def execute(self, context):
        obj = context.active_object
        hair_system = obj.ht_props.hair_system

        gmod_idx = hair_system.gmod_idx
        gmod_item = hair_system.gmod_stack[gmod_idx]

        hair_mod = hair_mod_by_idx(gmod_idx, obj)
        hair_node_tree = hair_mod.node_group

        gnode_idx = gmod_item.gnode_idx
        current_node = get_node_by_idx(hair_node_tree, gnode_idx)
        if current_node:
            self.move_node(hair_node_tree, current_node)
        # current_gnode = gmod_item.gnode_stack[gnode_idx]
        gnode_stack = gmod_item.gnode_stack
        gnode_cnt = len(gnode_stack)
        if self.direction == 'UP': # move left
            swap_index = clamp(gnode_idx - 1, 0, gnode_cnt - 1)
        else: # move right
            swap_index = clamp(gnode_idx + 1, 0, gnode_cnt - 1)
        if swap_index != gnode_idx:
            # swap_gnode = gmod_item.gnode_stack[swap_index]
            gnode_stack.move(swap_index, gnode_idx)
            gmod_item.gnode_idx = swap_index

        return {"FINISHED"}


def save_settings(from_props, target_props):  # from grid_hair_settings
    # what exception could occur here??
    for d in from_props.bl_rna.properties.keys():
        if d in {'name', 'rna_type'}:
            continue
        if hasattr(target_props, d):
            # setattr(target_props, d, getattr(from_props, d))
            target_props[d] = getattr(from_props, d)  # to avoid runing prop update...

def backup_settings(from_props):  # from grid_hair_settings
    backup = {}
    for k in from_props.bl_rna.properties.keys():
        if k in {'name', 'rna_type'}:
            continue
        backup[k] = getattr(from_props, k)
    return backup

def load_backup_settings(target_props, backup):  # from grid_hair_settings
    backup = {}
    for k in target_props.keys():
        if hasattr(backup, k):
            target_props[k] = backup[k]


class HTOOL_OT_CopyGNodeSettings(bpy.types.Operator):
    bl_label = "Copy GNode Settings"
    bl_idname = "particles.copy_gnode_settings"
    bl_description = "Copy Hair Node Settings"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        obj = context.active_object
        hair_system = obj.ht_props.hair_system
        index = hair_system.gnode_idx
        sel_settings = hair_system.gnode_stack[index]
        # save_settings(sel_settings, copy_buffer)
        return {"FINISHED"}


class HTOOL_OT_PasteGNodeSettings(bpy.types.Operator):
    bl_label = "Paste GNode Settings"
    bl_idname = "particles.paste_gnode_settings"
    bl_description = "Paste Hair Node Settings"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        obj = context.active_object
        hair_system = obj.ht_props.hair_system
        index = hair_system.gnode_idx
        copy_buffer = context.scene.ht_props.copy_modal_hair
        sel_settings = context.active_object.ht_props.modal_hair.gnode_stack[index]
        save_settings(copy_buffer, sel_settings)
        return {"FINISHED"}



class HTOOL_OT_ReimportMat(bpy.types.Operator):
    bl_label = "Update Material(s)"
    bl_idname = "material.update_pass_material"
    bl_description = "Update selected passes material from Hair Tool baking scene. Usefull to get new material version if it was updated in main baking scene"

    def execute(self, context):
        bake_settings = context.scene.ht_props.hair_bake_settings
        sel_passes = list(bake_settings.render_passes)
        for pass_name in sel_passes:
            import_pass_mat(pass_name)
        return {'FINISHED'}


# function to get all node groups in a node tree recursively
def get_nested_node_groups(node_tree):
    node_groups = []
    for node in node_tree.nodes:
        if node.bl_idname == 'GeometryNodeGroup':
            node_groups.append(node.node_tree)
            node_groups.extend(get_nested_node_groups(node.node_tree))
    return set(node_groups) # withotu duplicates


data_types = ['node_groups']  # 'materials', 'textures' etc from gpro

def import_node_group(node_name, force_update=False):
    ''' import node gr. from ht_nodes.blend '''
    #TODO: we should also udpate inner group nodes....
    old_node_gr = bpy.data.node_groups.get(node_name)

    # store name now before it gets overridden
    original_node_groups = {node_group.name: node_group for node_group in bpy.data.node_groups}

    if not old_node_gr or force_update:
        old_node_for_remap = bpy.data.node_groups.get(node_name)
        with bpy.data.libraries.load(path.dirname(__file__)+"\hair_geo_nodes.blend") as (data_from, data_to):
            data_to.node_groups = [node_n for node_n in data_from.node_groups if node_n == node_name]
            imported_gr_names = [node_n for node_n in data_from.node_groups if node_n == node_name]  # stores names
            print(f"{imported_gr_names=}")
            all_lib_node_groups_names = data_from.node_groups[:] # part gets imported

        if old_node_for_remap: #remap main node
            old_node_for_remap.user_remap(data_to.node_groups[0])
            data_to.node_groups[0].name = node_name
        # imported node_gr - may contain nested node groups - scan for them and remap old ngroups to new ones
        imported_node_groups = get_nested_node_groups(data_to.node_groups[0])
        for orig_node_gr_name, old_node_gr in original_node_groups.items(): # old name: Twist
            for imported_node_gr in imported_node_groups: # imported name: Twist.001
                if imported_node_gr.name.startswith(orig_node_gr_name):   # 'Twist.001'.startswith('Twist')
                    # new_data = data_to.node_groups[all_lib_node_groups_names.index(orig_node_gr_name)] # we acces by index
                    print(f'remapping: {orig_node_gr_name} to new: {imported_node_gr.name}')
                    old_node_gr.user_remap(imported_node_gr)
                    imported_node_gr.name = orig_node_gr_name
                    bpy.data.node_groups.remove(old_node_gr)

        return data_to.node_groups[0]
    else:
        return old_node_gr


def offset_following_nodes(current_node):
    prev_node = current_node
    next_node = current_node.outputs[0].links[0].to_node
    while next_node:
        next_node.location[0] = prev_node.location[0] + 250
        prev_node = next_node
        try:
            next_node = next_node.outputs[0].links[0].to_node
        except:
            next_node = None



def clean_imported_geo_nodes(imported_gn):
    nodes_for_removal = hair_nodes_groups + helper_node_groups
    for node in imported_gn.nodes:
        if node.type == 'GROUP' and node.node_tree.name in nodes_for_removal:
            imported_gn.nodes.remove(node)
    parent_sampler_node = imported_gn.nodes.get(parent_sampler_node_name)
    final_out_node = imported_gn.nodes.get(join_with_parent_node_name)
    links = imported_gn.links
    links.new(parent_sampler_node.outputs[0], final_out_node.inputs[0])
    parent_sampler_node.mute = True


def import_ht_main_geo_nodes():
    import_node_group(hair_gen_mod_node_gr_name)
    imported_gn = bpy.data.node_groups.get(hair_gen_mod_node_gr_name)
    return imported_gn


def get_node_group(node_name):
    node_group = bpy.data.node_groups.get(node_name)
    if not node_group:
        import_node_group(node_name)    # XXX: does it actually works (node.name vs node.node_tree.name)
        node_group = bpy.data.node_groups.get(node_name)
    return node_group

def add_parent_strands(hair_mod, use = True):
    ''' if True modifier output will include parent strands, otherwise only output current strands '''
    join_parent_curves_node = hair_mod.node_group.nodes.get(join_with_parent_node_name)
    join_parent_curves_node.mute = not use

def enable_profile(hair_mod, enable = True):
    ''' if True modifier will output curves instead of mesh strands '''
    profile_node = hair_mod.node_group.nodes.get(profile_node_name)
    profile_node.mute = not enable

def get_guide_curve_mod(obj):
    guide_curve_mod = [m for m in obj.modifiers if m.type=='NODES' and m.node_group.name == guide_mod_node_group_name]
    return guide_curve_mod[0] if guide_curve_mod else None

class HTOOL_OT_SetupHairGuide(bpy.types.Operator):
    bl_idname = "object.setup_curve_guide"
    bl_label = "Setup Curve Guide"
    bl_description = "Use selected curve object, as guide for Hair System.\nCurve guide object - has to have NO PROFILE, or it wont work!"
    bl_options = {"REGISTER","UNDO"}

    @classmethod
    def poll(cls, context):
        return context.active_object

    def execute(self, context):
        obj = context.active_object
        hair_system = obj.ht_props.hair_system

        guide_curve_mod = get_guide_curve_mod(obj)

        if guide_curve_mod:
            self.report({'WARNING'}, f'Loading Parent Curve modifier already exists on {obj.name}. Cancelling')
            hair_system.gmod_idx = 0
            return {"CANCELLED"}
        else:
            seg_guide_ng = bpy.data.node_groups.get(guide_mod_node_group_name)
            if not seg_guide_ng:
                seg_guide_ng = import_node_group(guide_mod_node_group_name)
                seg_guide_ng.use_fake_user = True

            guide_curve_mod = obj.modifiers.new(name=set_guide_mod_name, type='NODES')
            guide_curve_mod.node_group = seg_guide_ng

            # nove it before ht_mods
            ht_mod_ids = [idx for idx,m in enumerate(obj.modifiers) if m.type=='NODES' and m.name.startswith('GenerateHair')] # or m.node_group.name.startswith('GenerateHair')
            firts_hair_mod_idx = ht_mod_ids[0] if ht_mod_ids else 0
            bpy.ops.object.modifier_move_to_index(modifier=guide_curve_mod.name, index=firts_hair_mod_idx)
        # hair_mod = hair_mod_by_idx(gmod_idx, obj)
        guide_node = guide_curve_mod.node_group.nodes.get(guide_curve_node_name)
        guide_node.inputs['Steps'].default_value = hair_system.global_steps
        guide_node.mute = True
        return {"FINISHED"}



class HTOOL_OT_Delete_Guide_Curves(bpy.types.Operator):
    bl_idname = "object.delete_guide_curves"
    bl_label = "Delete Guide Curves"
    bl_description = "Delete guide curves"
    bl_options = {"REGISTER","UNDO"}

    @classmethod
    def poll(cls, context):
        return context.active_object

    def execute(self, context):
        obj = context.active_object
        hair_system = obj.ht_props.hair_system

        guide_curve_mod = get_guide_curve_mod(obj)
        if guide_curve_mod:
            bpy.ops.object.modifier_remove(modifier=guide_curve_mod.name)

            if len(hair_system.gmod_stack):
                first_gmod = hair_system.gmod_stack[0]
                first_gmod.set_as_child = False
            self.report({'INFO'}, f'Removed Guide settings')
            return {"CANCELLED"}

        return {"FINISHED"}

class HTOOL_OT_Bind_Guide_Curves(bpy.types.Operator):
    bl_idname = "object.bind_guide_curve"
    bl_label = "Bind Guide Curve"
    bl_description = "Bind guide curve. What it does is:\n - removes profile from guide curve,\n - set first Hair System as child,\n - set same Steps value for Guide and child Hair System"
    bl_options = {"REGISTER","UNDO"}

    @classmethod
    def poll(cls, context):
        return context.active_object

    def execute(self, context):
        obj = context.active_object
        hair_system = obj.ht_props.hair_system

        guide_curve_mod = get_guide_curve_mod(obj)
        if not guide_curve_mod:
            bpy.ops.object.setup_curve_guide()
            guide_curve_mod = get_guide_curve_mod(obj)
        node_tree = guide_curve_mod.node_group
        guide_node = node_tree.nodes.get(guide_curve_node_name)
        guide_object = guide_node.inputs['Curve'].default_value
        if not guide_object:
            self.report({'WARNING'}, f'No guide curve object was set')
            return {"CANCELLED"}
        if guide_object.type != 'CURVE':
            self.report({'WARNING'}, f'Selected object is not a curve')
            return {"CANCELLED"}
        # clear guid_object profile
        guide_object.data.bevel_mode = 'ROUND'
        guide_object.data.bevel_depth = 0.0
        if len(hair_system.gmod_stack)==0:
            self.report({'WARNING'}, f'Setup at least one Hair System')
            return {"CANCELLED"}
        first_gmod = hair_system.gmod_stack[0]
        first_gmod.set_as_child = True
        first_gmod.use_global_steps = True
        guide_node = guide_curve_mod.node_group.nodes.get(guide_curve_node_name)
        guide_node.inputs['Steps'].default_value = hair_system.global_steps
        guide_node.mute = False
        # first_mod = hair_mod_by_idx(0, obj)
        # node_tree = first_mod.node_group
        return {"FINISHED"}


class HTOOL_OT_AddHairGeoNode(bpy.types.Operator):
    bl_idname = "object.add_hair_geo_node"
    bl_label = "Add Effect"
    bl_description = "Add hair effect: hair distiortion, curls, trim etc."
    bl_options = {"REGISTER", "UNDO"}

    new_node: bpy.props.EnumProperty(name='Pick Node', description='',
        items=[
            ('Noise Deform', 'Noise Deform', ''),
            ('Curls', 'Curls/Waves', ''),
            ('Clump', 'Clump (child)', ''),
            ('Twist', 'Twist (child)', ''),
            ('Trim', 'Trim', ''),
        ], default='Noise Deform')


    def insert_node(self, node_tree, prev_node, new_node):
        ''' insert new_node after prev_node '''
        # group_input_node = node_tree.nodes.get('Group Input')
        # group_output_node = node_tree.nodes.get('Group Output')
        # sample_parent_node = node_tree.nodes.get(parent_sampler_node_name)
        # capture_output_curve = node_tree.nodes.get(final_capture_node_name) # we plug final geo into its inputs['Geometry']

        links = node_tree.links
        connect_curve_attributes(node_tree, new_node, use_sampler_node = self.set_as_child)

        next_node = prev_node.outputs[0].links[0].to_node
        links.new(prev_node.outputs[0], new_node.inputs[0])
        links.new(new_node.outputs[0], next_node.inputs[0])
        new_node.location = prev_node.location.copy()
        new_node.location[0] += 300
        new_node.location[1] -= 50

        offset_following_nodes(new_node)

    def execute(self, context):
        obj = context.active_object
        hair_system = obj.ht_props.hair_system
        gmod_idx = hair_system.gmod_idx
        gmod_item = hair_system.gmod_stack[gmod_idx]
        self.set_as_child = gmod_item.set_as_child
        current_index = gmod_item.gnode_idx

        gnode_cnt = len(gmod_item.gnode_stack)
        # if gnode_cnt == 0: # first node - 'Generate Strands' - is always inside Hair_Gen_Main node_tree
        #     first_gnode_item = gmod_item.gnode_stack.add()
        #     current_index = 0
        #     gnode_cnt = 1

        gmod_item.gnode_stack.add()
        gnode_cnt += 1
        if current_index+1 != gnode_cnt - 1:
            gmod_item.gnode_stack.move(gnode_cnt - 1, current_index+1)

        # hair_gen_ng = bpy.data.node_groups.get(ht_geo_node_name)
        # if not hair_gen_ng:
        #     hair_gen_ng = import_ht_main_geo_nodes()
        #     clean_imported_geo_nodes(hair_gen_ng)

        hair_mod = hair_mod_by_idx(gmod_idx, obj)
        hair_node_tree = hair_mod.node_group
        if current_index == 0: # for empty setup -> set parent_sampler as first node
            parent_sampler_node = hair_node_tree.nodes.get(parent_sampler_node_name)
            prev_node = parent_sampler_node
        else:
            prev_node = get_node_by_idx(hair_node_tree, current_index)

        new_node = hair_node_tree.nodes.new('GeometryNodeGroup')
        new_node_tree = get_node_group(self.new_node)
        new_node.node_tree = new_node_tree

        self.insert_node(hair_node_tree, prev_node, new_node)

        new_index = current_index + 1
        if new_index >= len(gmod_item.gnode_stack):
            new_index = len(gmod_item.gnode_stack)-1
        gmod_item.gnode_idx = new_index
        hair_system.is_using_gnodes = True
        return {'FINISHED'}


owner = object() # smgbus ovner


# def sync_steps_above(gmod_idx, obj):
#     ''' child and parent (above in stack) have to have same steps resolution '''
#     this_hair_mod = hair_mod_by_idx(gmod_idx, obj)
#
#     node_tree = this_hair_mod.node_group
#     gen_strands_node = node_tree.nodes.get(generate_strands_node_name)
#     current_steps = gen_strands_node.inputs['Steps'].default_value
#     hair_mods = get_hair_mod_list(obj)
#     for idx, mod in enumerate(hair_mods):
#         if idx < gmod_idx:
#             node_tree = mod.node_group
#             gen_strands = node_tree.nodes.get(generate_strands_node_name)
#             gen_strands.inputs['Steps'].default_value = current_steps
#

def get_last_child_idx(gmod_stack):
    last_child_idx = -1
    for idx, gmod_item in enumerate(gmod_stack):
        if gmod_item.set_as_child:
            last_child_idx = idx
    return last_child_idx



def sync_steps_from_current(current_gmod_idx, obj):
    ''' sync steps prop, for all items - that are above last child (or else some nodes like clump - wont work correctly)'''
    this_hair_mod = hair_mod_by_idx(current_gmod_idx, obj)
    node_tree = this_hair_mod.node_group
    gen_strands_node = node_tree.nodes.get(generate_strands_node_name)
    current_steps = gen_strands_node.inputs['Steps'].default_value

    hair_system = obj.ht_props.hair_system
    gmod_stack = hair_system.gmod_stack
    last_child_idx = get_last_child_idx(gmod_stack)

    if current_gmod_idx > last_child_idx: # current gmod is not affected by any child below
        return
    #  p, p, curr,  c, n, n
    # else current_gmod_idx <= last_child_idx -> thus update all affected gmods
    hair_mods = get_hair_mod_list(obj)
    for idx, mod in enumerate(hair_mods):
        if idx <= last_child_idx and idx != current_gmod_idx:
            affected_node_tree = mod.node_group
            gen_strands = affected_node_tree.nodes.get(generate_strands_node_name)
            gen_strands.inputs['Steps'].default_value = current_steps


class OBJECT_OT_Sync_Steps(bpy.types.Operator):
    bl_idname = "object.sync_steps"
    bl_label = "Sync steps"
    bl_description = "Copies 'Steps' property to other Hair Systems. Use if your hair looks wrong after using Child option"
    bl_options = {"REGISTER","UNDO"}

    gmod_idx: bpy.props.IntProperty(name="Idx", description='', default= 1, min=0)

    def execute(self, context):
        obj = context.active_object
        sync_steps_from_current(self.gmod_idx, obj)
        self.report({'INFO'}, f'Steps synchronized')
        return {"FINISHED"}


class HTOOL_OT_AddHairModifier(bpy.types.Operator):
    bl_idname = "object.add_hair_modifier"
    bl_label = "Add Hair System"
    bl_description = "Add Hair System. Each hairs sytem is based on Blender's geometry nodes modifier"
    bl_options = {"REGISTER", "UNDO"}


    def execute(self, context):
        obj = context.active_object
        hair_system = obj.ht_props.hair_system

        gmod_stack_len = len(hair_system.gmod_stack)
        # NOTE: convert prevoius system to curve (from mesh) by muting profile node
        if gmod_stack_len >= 1:
            prev_hair_mod = hair_mod_by_idx(gmod_stack_len-1, obj)
            enable_profile(prev_hair_mod, enable=False)
            # NOTE: prevent crash untill this is fixed: https://developer.blender.org/T93782
            prev_hair_mod['Output_8_attribute_name'] = ''
            prev_hair_mod['Output_9_attribute_name'] = ''
            prev_hair_mod['Output_10_attribute_name'] = ''
            prev_hair_mod['Output_11_attribute_name'] = ''

        new_stack_item = hair_system.gmod_stack.add()
        if gmod_stack_len > 0:
            new_stack_item.mod_name = f'Hair System.{gmod_stack_len:02d}'
        # always add new one element to gnode_stack - for default 'Generate Strands' node
        new_stack_item.gnode_idx = 0
        new_stack_item.gnode_stack.add()
        hair_gen_ng = bpy.data.node_groups.get(hair_gen_mod_node_gr_name)
        if not hair_gen_ng:
            hair_gen_ng = import_ht_main_geo_nodes()
            hair_gen_ng.use_fake_user = True
            clean_imported_geo_nodes(hair_gen_ng)

        hair_mod = obj.modifiers.new('GenerateHair', 'NODES')
        hair_mod.node_group = hair_gen_ng.copy()
        hair_mod['Output_8_attribute_name'] = 'Normal'
        hair_mod['Output_9_attribute_name'] = 'Tangent'
        hair_mod['Output_10_attribute_name'] = 'Factor'
        hair_mod['Output_11_attribute_name'] = 'Random'
        add_parent_strands(hair_mod, use=True)

        new_gmod_idx = len(hair_system.gmod_stack)-1
        hair_system.gmod_idx = new_gmod_idx
        hair_system.is_using_gnodes = True
        return {'FINISHED'}


class HTOOL_OT_DeleteHairGeoNode(bpy.types.Operator):
    bl_label = "Delete Hair Node"
    bl_idname = "object.delete_hair_geo_node"
    bl_description = "Delete the active hair node"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if context.active_object:
            hair_system = context.active_object.ht_props.hair_system
            gmod_idx = hair_system.gmod_idx
            if len(hair_system.gmod_stack) <= gmod_idx:
                return False
            gmod_item = hair_system.gmod_stack[gmod_idx]
            gnode_stack = gmod_item.gnode_stack
            gnode_idx = gmod_item.gnode_idx
            if len(gnode_stack) <= gnode_idx or gnode_idx == 0: # ignore first 'Generate Strands' node
                return False
        return True


    def remove_node(self, hair_node_tree, current_node):
        before_node = current_node.inputs[0].links[0].from_node
        after_node = current_node.outputs[0].links[0].to_node

        hair_node_tree.nodes.remove(current_node)
        links = hair_node_tree.links
        links.new(before_node.outputs[0], after_node.inputs[0])
        offset_following_nodes(before_node)

    def execute(self, context):
        obj = context.active_object

        hair_system = context.active_object.ht_props.hair_system
        gmod_idx = hair_system.gmod_idx
        gmod_item = hair_system.gmod_stack[gmod_idx]
        gnode_idx = gmod_item.gnode_idx
        hair_mod = hair_mod_by_idx(gmod_idx, obj)
        if hair_mod:
            hair_node_tree = hair_mod.node_group
            current_node = get_node_by_idx(hair_node_tree, gnode_idx)
            if current_node:
                self.remove_node(hair_node_tree, current_node)

        gmod_item.gnode_stack.remove(gnode_idx)
        gmod_item.gnode_idx = clamp(gnode_idx, 0, len(gmod_item.gnode_stack) - 1)

        return {"FINISHED"}


class HTOOL_OT_DeleteHairModifier(bpy.types.Operator):
    bl_idname = "object.delete_hair_modifier"
    bl_label = "Delete Hair"
    bl_description = "Delete Hair"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        obj = context.active_object
        hair_system = obj.ht_props.hair_system
        gmod_idx = hair_system.gmod_idx

        gmod_stack_len = len(hair_system.gmod_stack)
        if gmod_stack_len > 1:  #NOTE: unmute profile in previous mod (it will output meshed profile)
            prev_hair_mod = hair_mod_by_idx(gmod_stack_len-2, obj)
            enable_profile(prev_hair_mod, True)
            # NOTE: prevent crash untill this is fixed: https://developer.blender.org/T93782
            prev_hair_mod['Output_8_attribute_name'] = 'Normal'
            prev_hair_mod['Output_9_attribute_name'] = 'Tangent'
            prev_hair_mod['Output_10_attribute_name'] = 'Factor'
            prev_hair_mod['Output_11_attribute_name'] = 'Random'

        hair_mod = hair_mod_by_idx(gmod_idx, obj)
        obj.modifiers.remove(hair_mod)

        hair_system.gmod_stack.remove(gmod_idx)

        hair_system.gmod_idx = len(hair_system.gmod_stack)-1
        hair_system.is_using_gnodes = len(hair_system.gmod_stack) > 0
        return {'FINISHED'}

