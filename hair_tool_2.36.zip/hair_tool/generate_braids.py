# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
# Copyright (C) 2017 JOSECONSCO
# Created by JOSECONSCO

import bpy
from mathutils import Vector
from .utils.curve_wrapper import SplineFlat, Splines
from .utils.general_utils import create_new_curve_obj
from bpy.props import EnumProperty, FloatProperty, BoolProperty, IntProperty
from .utils.helper_functions import calc_exponent
from .material_operators import HTOOL_OT_CurvesUVRefresh
import numpy as np


class HTOOL_OT_BraidMaker(bpy.types.Operator):
    bl_label = "Generate Braid"
    bl_idname = "object.braid_make"
    bl_description = "Generate braid from selected curve spline"
    bl_options = {"REGISTER", "UNDO"}

    # hairType: bpy.props.EnumProperty(name="Hair Type", default="NURBS",
    #                                   items=(("NURBS", "Nurbs", ""),
    #                                          ("POLY", "Poly", "")))
    pts_per_cycle: IntProperty(name="Points per interlace", default=4, min=3, max=10)
    length_end: FloatProperty(name="Length", description="braid length multiplier (actual length is calculated from selected spline length)", default=1, min=0.1, max=1)
    braid_freq: FloatProperty(name="Frequency", description="Frequency describes how many times hair strand interlacing will occur", default=1, min=0.1, soft_max=4)
    Radius: FloatProperty(name="Main Radius", description="Overall braid radius", default=1, soft_min=0.1, max=2)
    strand_radius: FloatProperty(name="Strand Radius", description="Individual strands radius", default=1, min=0.01, soft_max=1)
    rad_fallof: FloatProperty(name="Radius falloff", description="Change braid size over strand length (tapers the braid on the tip)", default=0.5, min=0, max=1, subtype='PERCENTAGE')
    equalize_radii: FloatProperty(name="Equalize radii", description="Equalize radii for braids with different lengths (when generating multiple braids)", default=0, min=0, max=1)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, 'braid_freq')
        col = layout.column(align=True)
        col.prop(self, 'pts_per_cycle')
        col.prop(self, 'length_end')

        col = layout.column(align=True)
        row = col.row(align=True)
        row.prop(self, 'Radius')
        row.prop(self, 'strand_radius')
        col.prop(self, 'rad_fallof')
        obj = context.active_object
        if not obj.ht_props.braid_settings.is_braid:
            col.prop(self, 'equalize_radii')

    def generate_braid_points(self, braid_index, braid_absolute_len, rad):
        braid_xy_offset = 0.0
        freq = self.braid_freq
        # rad = self.Radius * braid_absolute_len/20
        if braid_index == 2:
            braid_xy_offset = -4/3*np.pi
        elif braid_index == 3:
            braid_xy_offset = 4/3*np.pi
        cpow = calc_exponent(self.rad_fallof-1)
        min_dist = 2*np.pi / (self.pts_per_cycle * freq *10)
        z = np.arange(0, braid_absolute_len * self.length_end, min_dist)
        z = z[::-1]
        length = z.size
        freq_multiplier = np.power(np.linspace(1, 1/length, length), cpow)
        arg_z = z * freq *10 + braid_xy_offset
        x = 0.5*rad * freq_multiplier * np.sin(arg_z)
        y = rad * freq_multiplier * np.cos(0.5 * arg_z)
        z = z * freq_multiplier - z[0]  #reduce size and radius
        return np.array([x,y,z]).T  #so we have point1(x,y,z), point2 ...


    def save_settings(self, target_obj):  # Tto object  braid_settings
        for d in self.properties.bl_rna.properties.keys():
            if d == 'rna_type':
                continue
            setattr(target_obj.ht_props.braid_settings, d, getattr(self.properties, d))

    def load_settings(self, source_obj):  # from  braid_settings
        # what exception could occur here??
        for d in source_obj.ht_props.braid_settings.bl_rna.properties.keys():
            if d in {'name', 'rna_type', 'is_braid'}:
                continue
            setattr(self.properties, d, getattr(source_obj.ht_props.braid_settings, d))

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'CURVE'


    def invoke(self, context, event):
        obj = context.active_object
        self.orig_spl_cnt = len(obj.data.splines)
        if obj.ht_props.braid_settings.is_braid:  #already exising braid
            self.load_settings(obj)  #so load cached settings
            if 'BraidDeform' in obj.modifiers.keys():
                deform_curve = obj.modifiers['BraidDeform'].object
                self.braid_absolute_lens = [deform_curve.data.splines[0].calc_length()]
                self.sel_splines_wrapper = Splines(deform_curve, onlySelection=False, with_clear=False) #assi,e there is only one spline in defromer spl
            else:
                self.report({'WARNING'}, 'Could not obtain braid deformer object!')
                return {'CANCELLED'}
                # self.braid_absolute_len = 0.8 * obj.data.splines[0].calc_length() #use any spline from braid to get len.
                #the rest of params is from cache

        else:  # assume it is deformer for braid
            called_from_ht_wspace = context.workspace.tools.from_space_view3d_mode(mode=context.mode).idname == "hair_tool.hair_transform"
            self.onlySelection = True if obj.mode == 'EDIT' else called_from_ht_wspace
            clear = True if self.orig_spl_cnt > 1 else False # if only one spline then we will use it as deformer
            self.sel_splines_wrapper = Splines(obj, self.onlySelection, with_clear=clear)
            self.braid_absolute_lens = [spl_w.euclidean_len for spl_w in self.sel_splines_wrapper.splines]
            self.braid_freq = 20 / (2*np.pi * self.braid_absolute_lens[0])
            bpy.ops.ed.undo_push()  # to prevent restoring curve from step above on execute()
        return self.execute(context)


    def execute(self, context):
        active_obj = context.active_object
        avg_rad = sum(self.braid_absolute_lens) / len(self.braid_absolute_lens) / 20
        for idx, deform_spl_w in enumerate(self.sel_splines_wrapper.splines):
            abs_len = self.braid_absolute_lens[idx]
            # if context.active_object and  context.active_object.type == 'CURVE': #if no selection, or selection is not curve
            if active_obj.ht_props.braid_settings.is_braid:
                braid_obj = active_obj
                deform_curve = active_obj.modifiers['BraidDeform'].object
            else:
                braid_obj = create_new_curve_obj('braid_ht', active_obj) if self.orig_spl_cnt > 1 else active_obj  #if we had only one spline, then use it as deform_curve
                braid_obj.ht_props.braid_settings.is_braid = True

                #setup deform_curve
                deform_curve = create_new_curve_obj('Braid_Deformer', active_obj)
                deform_spl_w.write_to_blender_spl(deform_curve, 0)
                deform_curve.matrix_world = active_obj.matrix_world #copy mw from active obj

                deform_mod = braid_obj.modifiers.new("BraidDeform", 'CURVE')
                deform_mod.deform_axis = 'NEG_Z'
                deform_mod.show_in_editmode = True
                deform_mod.object = deform_curve

            # braid_obj.data.show_normal_face = False
            braid_obj.data.fill_mode = 'FULL'
            # braid_obj.data.use_uv_as_generated = True #no more since 2.82
            braid_obj.data.use_auto_texspace = True
            main_rad = (1-self.equalize_radii) * (self.Radius * abs_len/20) + avg_rad * self.equalize_radii
            braid_obj.data.bevel_mode = 'ROUND'
            braid_obj.data.bevel_depth = self.strand_radius * main_rad
            braid_obj.data.splines.clear()
            braid_obj.matrix_world = deform_curve.matrix_world


            deform_curve.data.resolution_u = 2
            deform_curve.data.resolution_u = 2
            deform_curve.data.fill_mode = 'FULL'
            deform_curve.data.bevel_depth = 1.4*main_rad
            deform_curve.data.bevel_resolution = 0
            deform_curve.data.materials.clear()
            deform_curve.display_type = 'WIRE'
            deform_curve.hide_render = True
            if bpy.app.version < (3, 0):
                deform_curve.hide_render = True
                deform_curve.cycles_visibility.camera = False
                deform_curve.cycles_visibility.diffuse = False
                deform_curve.cycles_visibility.glossy = False
                deform_curve.cycles_visibility.transmission = False
                deform_curve.cycles_visibility.scatter = False
                deform_curve.cycles_visibility.shadow = False
            else:
                deform_curve.visible_camera = False
                deform_curve.visible_diffuse = False
                deform_curve.visible_glossy = False
                deform_curve.visible_transmission = False
                deform_curve.visible_volume_scatter = False
                deform_curve.visible_shadow = False

            # constraint = Curve.constraints.new(type='CHILD_OF')
            # constraint.target = deform_curve
            # constraint.inverse_matrix = deform_curve.matrix_world.inverted()

            cpow = calc_exponent(self.rad_fallof-1)
            for braid_i in range(3):
                braid_points = self.generate_braid_points(braid_i+1, abs_len, main_rad)
                braid_spl_wrapper = SplineFlat()
                curve_length = braid_points.shape[0]
                # freq_multiplier = np.array( [math.pow((i+1) / curve_length, cpow) for i in range(curve_length)])
                braid_spl_wrapper.points_co = np.array([Vector((point[0], point[1], point[2])) for point in braid_points], 'f')
                braid_spl_wrapper.points_radii = np.power(np.linspace(1, 1/curve_length, curve_length), cpow)
                braid_spl_wrapper.write_to_blender_spl(braid_obj, braid_i)

            braid_obj.data.resolution_u = 3
            HTOOL_OT_CurvesUVRefresh.uvCurveRefresh(braid_obj)
            self.save_settings(braid_obj)
        if not active_obj.data.splines:  # if no spline left in original obj
            bpy.data.objects.remove(active_obj)
        #! fix vanishing braids (blender wrong calculation of dimensions, causes them to vanish, if geo is far away from camera frustum...)
        for obj in context.scene.objects:
            if obj.type == 'CURVE':
                obj.update_tag()
        # context.view_layer.objects.active = braid_obj
        # bpy.ops.object.curve_uv_refresh()
        return {"FINISHED"}


