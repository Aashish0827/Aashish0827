# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
# Copyright (C) 2017 JOSECONSCO
# Created by JOSECONSCO
# import sys
# dir = 'C:\\Users\\JoseConseco\\AppData\\Local\\Programs\\Python\\Python36\\Lib\\site-packages'
# if not dir in sys.path:
#     sys.path.append(dir )
# import ipdb

import bpy
from math import log
import numpy as np
from bpy.props import StringProperty, IntProperty, FloatProperty, BoolProperty
from .hair_baking.hair_bake import setup_pass, ht_channel_mixing
from .hair_baking.hair_geometry_nodes import set_as_child_mod, change_active_mod, switch_node_space, change_attribute_mod, show_in_viewport
from .interactive_hair_combing import ParticleModalSettings, ModalHairSettings
from .drawing_curves import ModalDrawingSettings
from .material_operators import HTOOL_OT_AssignRegionsFromObjProps
from .hair_library.hair_lib import enum_previews_from_directory_items
from .utils.general_utils import get_addon_preferences
from .hair_library import hair_lib
import os

class hairUVPoints(bpy.types.PropertyGroup):
    start_point: bpy.props.FloatVectorProperty(name="", description="", default=(0.0, 0.0), size=2)
    end_point: bpy.props.FloatVectorProperty(name="", description="", default=(1.0, 1.0), size=2)
    offset_tip: FloatProperty(name="Offset to tip", description="Move uv's toward tip", default=0, min=0, max=1, subtype='PERCENTAGE')
    offset_root: FloatProperty(name="Offset to root", description="Move uv's toward root", default=0, min=0, max=1, subtype='PERCENTAGE')
    curls_freq: FloatProperty(name="Curl Tilt", description="Curl Tilt", default=0, min=-100, max=100)
    curls_influence_start: FloatProperty(name="Curl Threshold", description="Curl Threshold", default=0, min=0, max=1)
    curls_gravity: FloatProperty(name="Curl Gravity", description="Curl Gravity", default=0, min=0.0, max=10)
    curls_freq_m: FloatProperty(name="Curl Tilt", description="Curl Tilt mirrored", default=0, min=-100, max=100)
    curls_influence_start_m: FloatProperty(name="Curl Threshold", description="Curl Threshold mirrored", default=0, min=0.0, max=1)
    curls_gravity_m: FloatProperty(name="Curl Gravity", description="Curl Gravity mirrored", default=0, min=0.0, max=10)
    flip_y: bpy.props.BoolProperty(name='flip y', description='Flip uv hair root to tip direction', default=False)

BOX_ITEMS  = []
def uv_box_items(self, context):
    curve_obj = context.active_object
    first_mat = curve_obj.material_slots[0].material
    uvBoxes = len(first_mat.ht_props.hair_uv_points)
    random_flip_x = context.preferences.addons['hair_tool'].preferences.flipUVRandom
    global BOX_ITEMS
    if random_flip_x:
        if len(BOX_ITEMS) != 2*uvBoxes:
            BOX_ITEMS = [(str(i), str(i//2) + '\'' if i % 2 else str(i//2), '') for i in range(uvBoxes*2)]
    else:
        if len(BOX_ITEMS) != uvBoxes:
            BOX_ITEMS = [(str(i), 'UV box:'+str(i), '') for i in range(uvBoxes)]
    return BOX_ITEMS

class UVCurls(bpy.types.PropertyGroup):
    # affected_mat: bpy.props.EnumProperty(name='Affected Materials/UVs', description='Affect all or active materials when generating curls',
    #                                items=uv_box_items,  options={'ENUM_FLAG'})
    curls_freq: bpy.props.FloatProperty(name='Curls Frequency', description='Define amount of curls for each strand', default=4, soft_min=-10, soft_max=10)
    curls_freq_rand: bpy.props.FloatProperty(name='Frequency Random', description='', default=0, min=0, max=1, subtype='FACTOR')

    curls_influence_start: bpy.props.FloatProperty(name='Influence Start', description='Start curls effect from given threshold factor of strand length', default=0, min=0.0, max=0.8, subtype='FACTOR')
    start_rand: bpy.props.FloatProperty(name='Influence Random', description='', default=0, min=0.0, max=1.0, subtype='FACTOR')

    curls_gravity: bpy.props.FloatProperty(name='Curl Gravity', description='Fake gravity effect (should be at least 1.0 when threshold non-zero value)', default=1, min=0.0, max=10)
    gravity_random: bpy.props.FloatProperty(name='Gravity Random', description='', default=0, min=0.0, max=1, subtype='FACTOR')

    randomDirection: BoolProperty(name="Random Direction", description="Random curls direction angle randomly from CW to CCW", default=False)
    Seed: IntProperty(name="Noise Seed", default=1, min=1, max=500)


class hair_ribbons_props(bpy.types.PropertyGroup):
    hair_mesh_parent: StringProperty(name="", default="")
    hair_curve_child: StringProperty(name="", default="")


class last_hair_settings(bpy.types.PropertyGroup):
    # material: StringProperty(name="", default="")
    material: bpy.props.PointerProperty(type=bpy.types.Material)
    # hair_uv_points: bpy.props.CollectionProperty(type=hairUVPoints)

class profile_props(bpy.types.PropertyGroup):
    strandResU: IntProperty(name="Resolution along strand length", default=3, min=1, max=5, description="Additional subdivision along strand length")
    strandResV: IntProperty(name="Profile Resolution", default=2, min=0, max=5, description="Subdivisions perpendicular to strand length ")
    strandWidth: FloatProperty(name="Strand Width", default=0.5, min=0.0, max=900)
    strandPeak: FloatProperty(name="Strand Height", default=0.3, min=0.0, max=1,
                               description="Describes how much middle point of ribbon will be elevated")
    strandUplift: FloatProperty(name="Strand uplift", default=0.0, min=-1, max=1, description="Moves whole ribbon up or down")

passes = (
    ("AO", "Ambient Occlusion", "Ambient Occlusion"),
    ("DIFFUSE", "Diffuse", "Diffuse mask"),
    ("OPACITY", "Opacity", "Opacity mask"),
    ("NORMAL", "Normal map", "Normal map"),
    ("ROOT", "Root map", "Gradient from hair root to tip"),
    ("ID", "Random ID", "Random grayscale value per hair strands"),
    ("COLOR", "Random Color", "Random color per hair strands"),
    ("FLOW", "Flow map", "Drives direction of anisotropic specular (alternative to Directional map)"),
    ("DIRECTIONAL", "Directional map", "Alternative to Flow map - drives direction of anisotropic specular"),
    ("DEPTH", "Depth map", "Depth map"))


class HairBakeSettings(bpy.types.PropertyGroup):
    def update_materials(self, context):
        if len(self.render_passes)>0:
            setup_pass(context, self.render_passes.pop())

    def update_compose(self, context):
        if len(self.render_passes) > 0 and self.hair_bake_composite:
            ht_channel_mixing(context)

    def change_particle_step(self, context):
        particle_objs = [obj for obj in bpy.data.objects if obj.type=='MESH' and len(obj.particle_systems)]
        for particle_obj in particle_objs:
            for particle_system in particle_obj.particle_systems:
                if particle_system.settings.type == 'HAIR':
                    particle_system.settings.display_step = self.particle_display_step

    def change_particle_radius(self, context):
        particle_objs = [obj for obj in bpy.data.objects if obj.type=='MESH' and len(obj.particle_systems)]
        for particle_obj in particle_objs:
            for particle_system in particle_obj.particle_systems:
                if particle_system.settings.type == 'HAIR':
                    particle_system.settings.radius_scale = self.particle_width

    def update_pad(self, context):
        if self.padding_mode == 'AUTO':
            self['padding_size'] = int(int(self.bakeResolution_x)/64)

    def update_ratio(self, context):
        if self.lock_ratio:
            self.bakeResolution_y = self.bakeResolution_x

    def update_res_x_ratio(self, context):
        if self.lock_ratio:
            self.bakeResolution_y = self.bakeResolution_x
        self.update_res_common(context)

    def update_res_common(self, context):
        render = context.scene.render
        render.resolution_x = int(self.bakeResolution_x)
        render.resolution_y = int(self.bakeResolution_y)
        cam = bpy.data.objects['Camera_render']
        x_to_y = render.resolution_x/render.resolution_y
        y_to_x = 1 / x_to_y
        def cam_shift_calc(div_ratio):
            c = int(log(div_ratio, 2)) # 2 ^y = div_ratio
            exponents = np.array(range(int(c)))+2
            return np.sum(np.power(0.5, exponents))
        cam.data.ortho_scale = max(pow(2, log(x_to_y*2, 2)), pow(2, log(y_to_x*2, 2)))
        # cam.data.shift_x = -1*cam_shift_calc(y_to_x) if y_to_x > 1 else 0
        # cam.data.shift_y = cam_shift_calc(x_to_y) if x_to_y > 1 else 0
        self.update_pad(context)


    def change_particle_shape(self, context):
        particle_objs = [obj for obj in bpy.data.objects if obj.type=='MESH' and len(obj.particle_systems)]
        for particle_obj in particle_objs:
            for particle_system in particle_obj.particle_systems:
                if particle_system.settings.type == 'HAIR':
                    particle_system.settings.shape = self.particle_shape

    render_quality: bpy.props.EnumProperty(name="Quality", default="2", description='Multiplier: [16 base samples] * [quality] -(1)Low, (2)Normal, (4)High, (8)Ultra',
                                           items=(
                                               ("1", "Low (16)", ""),
                                               ("2", "Normal (32)", ""),
                                               ("4", "High (64)", ""),
                                               ("8", "Ultra (128)", ""),
                                           ))
    lock_ratio: bpy.props.BoolProperty(name='Lock Ratio', description='Keep X and Y resolution the same', default=True, update=update_ratio)
    bakeResolution_x: bpy.props.EnumProperty(name="Resolution X", default="1024",
                                            items=(("256",  "256", ""),
                                                   ("512",  "512", ""),
                                                   ("1024", "1024", ""),
                                                   ("2048", "2048", ""),
                                                   ("4096", "4096", ""),
                                                   ("8192", "8192", "")),
                                             update=update_res_x_ratio)
    bakeResolution_y: bpy.props.EnumProperty(name="Resolution Y", default="1024",
                                            items=(("256",  "256", ""),
                                                   ("512",  "512", ""),
                                                   ("1024", "1024", ""),
                                                   ("2048", "2048", ""),
                                                   ("4096", "4096", ""),
                                                   ("8192", "8192", "")),
                                             update=update_res_common)
    render_passes: bpy.props.EnumProperty(name="Pass", default={"NORMAL"},
                                           items=passes,
                                           options={'ENUM_FLAG'},
                                           update=update_materials)

    padding_mode: bpy.props.EnumProperty(name='Padding Mode', description='Prevents background color beeding into texture',
                                               items=[
                                                   ('AUTO', 'Automatic Padding', 'Padding will be set to around 1% of texture size'),
                                                   ('FIXED', 'Fixed Padding', 'Set padding size by hand')
                                               ], default='AUTO', update=update_pad)
    padding_size: bpy.props.IntProperty(name='Padding', description='Add color margin around bake result (0 - disabled)\nWarning - may be slow on big images', default = 10, min=0, soft_max=40)
    preview_background: bpy.props.EnumProperty(name='Background', description='Background for bake preview only',
        items=[
            ('TRANSPARENT', 'Transparent Background', 'Transparent'),
            ('SOLID', 'Solid Background', 'Solid')
        ], default='SOLID', update=update_materials)


    hair_bake_path: StringProperty(name="Path", default="", description="Baking output path", subtype='DIR_PATH')
    hair_bake_file_name: StringProperty(name="Name", default="Hair", description="Output texture name prefix")

    hair_bake_composite: BoolProperty(name="Mix Baked Channels", description="Mix RGBA channels of baked textures in HTool 'Texture Channel Mixing' nodes editor", default=False, update=update_compose)
    particle_display_step: IntProperty(name="Particle Display step", default=3, min=1, max=7, update = change_particle_step)
    particle_width: FloatProperty(name="Particle Width", default=0.01, min=0.001, max=0.1, update=change_particle_radius)
    particle_shape: FloatProperty(name="Particle Shape", default=0.0, min=-1.0, max=1.0, update=change_particle_shape)

    my_items = (
        ('PNG', "PNG", ""),
        ('TARGA', "TGA", ""),
        ('JPEG', "JPEG", "")
    )
    output_format: bpy.props.EnumProperty(name="Format", description="Format", items=my_items, default='PNG')


class curly_hair_settings(bpy.types.PropertyGroup):
    was_created_from_curls: BoolProperty(name="Created from Curls", description="Was curls operator used on current curve?", default=False)
    hairType: bpy.props.EnumProperty(name="Output Curve Type", default="NURBS",
                                     items=(("BEZIER", "Bezier", ""),
                                            ("NURBS", "Nurbs", ""),
                                            ("POLY", "Poly", "")))
    points_per_cycle: IntProperty(name="Points per cycle", description="How many to generate points per curl. Bigger values gives smoother curls", default=4, min=2, soft_max=10)
    curl_freq: FloatProperty(name="Curl frequency", description='Will generate more curls but also higher point count', default=5, min=0.4, soft_max=15)

    contrast: FloatProperty(name="Transition Contrast", description="Curls transition contrast", default=0.5, min=0, soft_max=1)
    offset: FloatProperty(name="Offset", description="Offset curls more toward the root or tip", default=0, min=-1, max=1)

    radius: FloatProperty(name="Radius", description="Curls Radius", default=1, min=0, soft_max=10)

    direction: bpy.props.EnumProperty(name='Direction', description='Curls Direction',
                                      items=[
                                          ('CW', 'Clockwise', ''),
                                          ('CCW', 'Counterclockwise', '')
                                      ], default='CW')

    random_direction: BoolProperty(name="Random direction", description="Flip curls direction randomly from clockwise to canterclockwise", default=False)

    gravity_tension: FloatProperty(name="Gravity ", description="Gravity weight pulls the curls down along the hair strand. O - disabled, 0.5 - natural gravity pull",
                                   default=0, min=0, max=1, subtype='PERCENTAGE')
    align_method: bpy.props.EnumProperty(name='Tilt align method', description='Tilt align method',
                                         items=[('ZUP', 'Z-up', 'Good of you have hair going down'),
                                                ('MINIMUM', 'Minimum', 'Not great but better than nothing')], default='MINIMUM')

    align_tilt: BoolProperty(name="Align Tilt", description="Make curve profile face outwards direction.\nIt is slow - usually it is best to enable it at last step", default=False)
    radomize_freq: FloatProperty(name="Randomize frequency", description="Randomize frequency", default=0, min=0, max=1, subtype='PERCENTAGE')
    # fix_angle: FloatProperty(name="fix_angle", description="Randomize frequency", default=0, min=-3.2, max=3.2)
    Seed: IntProperty(name="Noise Seed", default=1, min=1, max=500)

    uniformPointSpacing: BoolProperty(name="Uniform spacing", description="Distribute stand points with uniform spacing", default=True)
    # onlySelection: BoolProperty(name="Only Selected", description="Affect only selected splines", default=False)

class grid_hair_settings(bpy.types.PropertyGroup):
    was_created_from_grid: BoolProperty(name="Created from Grid", description="Was current curve created from grid?", default=False)
    gen_method: bpy.props.EnumProperty(name="Generation Method", default="edge",
                                       items=(("edge", "Edge Centers", "Use edge rings centers for guiding curves"),
                                              ("vert", "Vertex position", "Use edge rings vertices for guiding curves")))
    hairType: bpy.props.EnumProperty(name="Hair Type", default="NURBS",
                                     items=(("BEZIER", "Bezier", ""),
                                            ("NURBS", "Nurbs", ""),
                                            ("POLY", "Poly", "")))
    # Radius: FloatProperty(name="Radius", description="Radius for bezier curve", default=1, min=0, soft_max=100)
    out_spl_count: IntProperty(name="Strands count", default=10, min=1, soft_max=400)
    uniform_strands: BoolProperty(name="Uniform Strands", description="Distribute strands uniformly", default=True)
    points_count: IntProperty(name="Points per strand", description="How many points generate for each strand", default=7, min=3, soft_max=20)
    uniform_points: BoolProperty(name="Uniform Points", description="Distribute points on strand uniformly", default=True)

    offset_tip: FloatProperty(name="Offset to tip", description="Move spline points more toward tip", default=0, min=0, max=1, subtype='PERCENTAGE')
    offset_root: FloatProperty(name="Offset to root", description="Move spline points more toward root", default=0, min=0, max=1, subtype='PERCENTAGE')

    randomize_spacing: FloatProperty(name="Randomize Spacing", description="Randomize spacing between strands", default=30, min=0, max=100, subtype='PERCENTAGE')
    shortenStrandLen: FloatProperty(name="Randomize Length", description="Shorten strand length", default=0.1, min=0, max=1, subtype='PERCENTAGE')
    len_seed: IntProperty(name="Seed", description="Randomize Length seed", default=1, min=1, max=1000)

    Seed: IntProperty(name="Seed", description="noise seed gives different hair flow for each value", default=1, min=1, max=1000)
    noise_amp: FloatProperty(name="Noise Amplitude", default=0.0, min=0.0, soft_max=10.0)
    freq: FloatProperty(name="Noise frequency", description="Gives more detail to hair flow. Higher frequency produces smaller detail on hair strands", default=0.5, min=0.0, soft_max=5.0)
    contrast: FloatProperty(name="Transition Contrast", description="Contrast between areas with no noise to full noise influence over strand length", default=0.5, min=0, soft_max=1)
    offset: FloatProperty(name="Transition Offset", description="Offset noise influence more toward the root (or tip) of strand", default=0.0, min=-1, max=1)

    noiseMixFactor: FloatProperty(name="Per strand noise", description="Blend additional noise for each strand to break uniform look", default=0.1, min=0, max=1, subtype='PERCENTAGE')
    noiseMixVsAdditive: BoolProperty(name="Mix / Add", description="Add or mix extra strand noise", default=False)
    mix_noise_seed: IntProperty(name="Seed", default=1, min=1, max=1000)
    strand_freq: FloatProperty(name="Frequency", description="Per strand noise frequency. Higher frequency produces samller detail on hair strands",  default=0.5, min=0.0, soft_max=5.0)

    offsetAbove: FloatProperty(name="Offset Above", description="Offset strands above source grid surface", default=0.0, min=-1.0, soft_max=1.0)

    snapAmount: FloatProperty(name="Snap Amount", default=0.0, min=0.0, max=1.0, subtype='PERCENTAGE')
    constrain: FloatProperty(name="Constrain", description="Constrain strand to grid surface", default=1.0, min=0.0, max=1.0, subtype='PERCENTAGE')

    # generateRibbons: BoolProperty(name="Generate Ribbons", description="Add curve profile ot generated strands", default=False)
    alignToSurface: BoolProperty(name="Align tilt", description="Align tilt to Surface", default=False)

    clumps_effect: FloatProperty(name="Clumps", default=0, min=0, max=1, description="Clump hair together. Higher values produce bigger clumps", subtype='PERCENTAGE')
    clump_Seed: IntProperty(name="Seed", default=1, min=1, max=1000)
    clump_influence: FloatProperty(name="Clump influence", description="Clumping influence. 0 - disabled", default=1, min=0, max=1, subtype='PERCENTAGE')
    clump_falloff: FloatProperty(name="Clump fallof", description="Clumping influence over strand length", default=0, min=-1.0, max=1)

    # strandWidth: FloatProperty(name="Strand Width", default=0.5, min=0.0, soft_max=10)


class braid_settings(bpy.types.PropertyGroup):
    is_braid: bpy.props.BoolProperty(name="is_braid", default=False)
    pts_per_cycle: IntProperty(name="Points per interlace", default=4, min=3, max=10)
    length_end: FloatProperty(name="Length", default=1, min=0.1, max=1)
    braid_freq: FloatProperty(name="Frequency", description="Frequency describes how many times hair strand interlacing will occur", default=1, min=0.1, soft_max=4)
    Radius: FloatProperty(name="Main Radius", description="Overall Radius", default=1, soft_min=0.1, max=2)
    strand_radius: FloatProperty(name="Strand Radius", description="Strand Radius", default=1, min=0.01, soft_max=1)
    rad_fallof: FloatProperty(name="Radius falloff", description="Change braid size over strand length", default=0.5, min=0, max=1, subtype='PERCENTAGE')
    equalize_radii: FloatProperty(name="Equalize radii", description="Equalize raddi for braids with different lengths (when generating multiple braids)", default=0, min=0, max=1)

class rand_tilt_settings(bpy.types.PropertyGroup):
    reset_first: BoolProperty(name="Reset on init", description="Clear tilt before randimizing it", default=True)
    # onlySelection: BoolProperty(name="Only Selected", description="Affect only selected points", default=True)
    tilt: FloatProperty(name="Tilt Angle", description="Add unifrom tilt to strands", default=1.5, min=-100, max=100, step=145, subtype='ANGLE')
    min_tilt: FloatProperty(name="Randomize", description="Tilt randomization strength", default=0.5, min=0, max=1, subtype='PERCENTAGE')
    tilt_transition_fallof: FloatProperty(name="Tilt falloff", description="Change braid tilt over strand length", default=0, min=0, max=1, subtype='PERCENTAGE')
    root_influence: FloatProperty(name="Root Influence", description="Make the hair tilt uniform across whole strand length", default=0, min=0, max=1, subtype='PERCENTAGE')
    randomDirection: BoolProperty(name="Flip Direction", description="When false hair will twist only clockwise", default=False)
    Seed: IntProperty(name="Noise Seed", default=1, min=1, max=500)


class radius_from_length_settings(bpy.types.PropertyGroup):
    min_radius: bpy.props.FloatProperty(name='Min Radius', description='', default= 0.5, min=0, max=1.0)
    max_radius: bpy.props.FloatProperty(name='Max Radius', description='', default= 1.0, min=0, max=1.0)
    len_threshold: bpy.props.FloatProperty(name='Transition threshold', description='Radius change will affect only strands close to given length threshold', default= 0.5, min=0, max=1)
    margin: bpy.props.FloatProperty(name='Transition Smoothness', description='Smooth out affected strand radius chagne transition', default=1.0, min=0, max=1.0)


BOX_ITEMS = []
def uv_box_items(self, context):
    curve_obj = self.id_data
    first_mat = curve_obj.material_slots[0].material
    uvBoxes = len(first_mat.ht_props.hair_uv_points)
    flipUVRandom = context.preferences.addons['hair_tool'].preferences.flipUVRandom
    global BOX_ITEMS
    box_cnt = 2*uvBoxes if flipUVRandom else uvBoxes
    if flipUVRandom:
        if len(BOX_ITEMS) != box_cnt:
            BOX_ITEMS = [(str(i), str(i//2) + 'M' if i % 2 else str(i//2), '') for i in range(uvBoxes*2)]
    else:
        if len(BOX_ITEMS) != box_cnt:
            BOX_ITEMS = [(str(i), 'UV box:'+str(i), '') for i in range(uvBoxes)]
    return BOX_ITEMS


class RegToLenProps(bpy.types.PropertyGroup):
    def assign_uv_regions(self, context):
        obj = self.id_data
        HTOOL_OT_AssignRegionsFromObjProps.update_assigned_uv_regions(obj)

    treshold_mode: bpy.props.EnumProperty(name='Treshold Mode', description='',
        items=[
            ('RELATIVE', 'Relative (%}', 'Relative as fraction of longest strand length'),
            ('ABSOLUTE', 'Absolute (m)', 'Absolute unit [Blender Units/Meters]')
        ], default='RELATIVE', update=assign_uv_regions)
    rel_threshold: bpy.props.FloatProperty(name='Threshold', description='Target strands that are longer than this relative (to longest strand) threshold value', default=0.5, min=0, max=1, subtype='FACTOR', update=assign_uv_regions)
    len_threshold: bpy.props.FloatProperty(name='Threshold', description='Target strands that are longer than this absolute (meters) threshold value',
                                           default=0.5, min=0, soft_max=1, subtype='DISTANCE', update=assign_uv_regions)
    margin: bpy.props.FloatProperty(name='Tolerance', description='Smooth out UV region transition by increasing length threshold tolerance', default=0.0, min=0, max=1.0, subtype='FACTOR', update=assign_uv_regions)
    seed: IntProperty(name="Seed", description='Randomize UV assigment', default=0, min=0, max=1000, update=assign_uv_regions)
    invert: bpy.props.BoolProperty(name='Invert', description='By default target strands longer than threshod. If invert - then target shorter strands than treshold', default=False, update=assign_uv_regions)
    uv_regions: bpy.props.EnumProperty(name='UV Region ID', description='Pick UV region that will be assinged to selected strands',
                                       items=uv_box_items,  options={'ENUM_FLAG'}, update=assign_uv_regions)


class GNodesNodeItem(bpy.types.PropertyGroup):
    def switch_space(self, context):
        switch_node_space(self, context)

    node_name: bpy.props.StringProperty(name='Node type', description='', default='')
    use_parent_space: bpy.props.BoolProperty(name='Use parent space', description='Use parent space coordinates when generating deformation.\nOnly availible when current system is child', default=True, update=switch_space)

class GModifierItem(bpy.types.PropertyGroup):
    def update_child(self, context):
        for gnode in self.gnode_stack: # force all gnodes to use parent strands as guides
            gnode.use_parent_space = self.set_as_child or gnode.use_parent_space
        set_as_child_mod(self, context)

    def update_show_viewport(self, context):
        show_in_viewport(self, context)

    def update_global_length(self, context):
        obj = self.id_data
        change_attribute_mod(obj.ht_props.hair_system, context, 'Length', selected_gmod = self)

    def update_global_steps(self, context):
        obj = self.id_data
        change_attribute_mod(obj.ht_props.hair_system, context, 'Steps', selected_gmod = self)

    mod_name: bpy.props.StringProperty(name='Name', description='', default='Hair System')
    show_in_viewport: bpy.props.BoolProperty(name='Show in Viewport', description='Show Hair System in viewport', default=True, update=update_show_viewport)

    gnode_stack: bpy.props.CollectionProperty(type=GNodesNodeItem)
    gnode_idx: bpy.props.IntProperty(name="Active index", description='', default=1, min=0, max=100 )
    set_as_child: bpy.props.BoolProperty(name="Set as child", description='Use strands from previous Hair System as target for some operations\n(usefull for eg. clumping and twisting of hair strands)', default=False, update=update_child)

    use_global_length: bpy.props.BoolProperty(name='Use global length', description='Use same Length value for all Hair Systems', default=False, update=update_global_length)
    use_global_steps: bpy.props.BoolProperty(name='Use global steps', description='Use same Steps value for all Hair Systems', default=False, update=update_global_steps)


class HairSystem(bpy.types.PropertyGroup):
    def idx_change(self, context):
        change_active_mod(self, context)

    def length_change(self, context):
        change_attribute_mod(self, context, 'Length')

    def steps_change(self, context):
        change_attribute_mod(self, context, 'Steps')

    def update_global_steps(self, context):
        obj = self.id_data
        change_attribute_mod(obj.ht_props.hair_system, context, 'Steps')

    gmod_stack: bpy.props.CollectionProperty(type=GModifierItem)
    gmod_idx: bpy.props.IntProperty(name="Active index", description='', default=1, min=0, max=100, update=idx_change)
    is_using_gnodes: bpy.props.IntProperty(name='Is using gnodes', description='', default=0)

    global_length: bpy.props.FloatProperty(name='Global length', description='Use same Length value for all Hair Systems', default=1.0, min=0.0, soft_max=100.0, update=length_change)
    global_steps: bpy.props.IntProperty(name='Global steps', description='Use same Steps value for all Hair Systems', default=3, min=1, max=8, update=steps_change)


class JBone(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name='Name', description='Jiggle physics settings name', default='Jiggle')
    mass: bpy.props.FloatProperty(name='Mass', description='Mass of each spring segment', default=1., min=0.01, soft_max=10)
    stiffness: bpy.props.FloatProperty(name='Stiffness', description='Stiffnes of each spring segment', default=10., min=0.01, max=60)
    gravity: bpy.props.FloatProperty(name='Gravity', description='Gravity strength', default=9.81, min=0.0, max=20)
    damping: bpy.props.FloatProperty(name='Damping', description='Damping of each spring segment', default=2., min=0.01, soft_max=10)

class JiggleBoneProps(bpy.types.PropertyGroup):
    physics_props: bpy.props.CollectionProperty(type=JBone)
    time_step_mode: bpy.props.EnumProperty(name='Time Step', description='Time Step mode',
        items=[
            ('FPS', 'Use scene FPS', 'Fps'),
            ('CUSTOM', 'Custom', 'Custom')
        ], default='FPS')
    time_step: bpy.props.FloatProperty(name='Time Step', description='Lower time step gives smoother animation', default=0.04, min=0.01, max=1 )
    active_index: bpy.props.IntProperty(name="Active index", description='', default=1, min=0, max=100 )



class ObjHTPropertyGroup(bpy.types.PropertyGroup):
    def assign_uv_regions_on_off(self, context):
        if self.use_auto_uv:
            obj = self.id_data
            HTOOL_OT_AssignRegionsFromObjProps.update_assigned_uv_regions(obj)

    def assign_uv_regions(self, context):
        obj = self.id_data
        HTOOL_OT_AssignRegionsFromObjProps.update_assigned_uv_regions(obj)

    is_curve: bpy.props.IntProperty(name='Is curve',default=1, min=0, max=1) # for OffsetNode attribute
    hair_settings: bpy.props.PointerProperty(type=hair_ribbons_props)
    profile_props: bpy.props.PointerProperty(type=profile_props)
    grid_hair_settings: bpy.props.PointerProperty(type=grid_hair_settings)
    curly_hair_settings: bpy.props.PointerProperty(type=curly_hair_settings)
    braid_settings: bpy.props.PointerProperty(type=braid_settings)
    rand_tilt_settings: bpy.props.PointerProperty(type=rand_tilt_settings)
    radius_from_length_settings: bpy.props.PointerProperty(type=radius_from_length_settings)
    target_obj: StringProperty(name="Target", description="Target of operation")
    modal_hair: bpy.props.PointerProperty(type=ModalHairSettings)

    def filter_armature(self, obj):
        return obj.type == 'ARMATURE'

    target_rig: bpy.props.PointerProperty(name='Target rig', description="If set, generated bones will be automatically assigned to that armature object", type=bpy.types.Object, poll=filter_armature)
    pin_bone: bpy.props.StringProperty(name='Parent bone', description='Generated bones will be automatically set as child of this bone (in most cases it is same as Head bone)', default='')

    used_uv_pick: bpy.props.BoolProperty(name='had uv sample', description='', default=False)
    used_weight_pick: bpy.props.BoolProperty(name='had weight sample', description='', default=False)

    use_auto_uv: bpy.props.BoolProperty(name='Auto UV', description='Automaticaly assign UV regions to hair strands when generating/updating hair', default=False, update=assign_uv_regions_on_off)
    use_length_mask_uv: bpy.props.BoolProperty(name='Use Length Mask', description='Assing UV regions based on strand length', default=False, update=assign_uv_regions)

    default_uv_region: bpy.props.EnumProperty(name='Default UV Region',
        description='',
        items=[
            ('MANUAL', 'UV: Pick Regions Manualy', 'Manually select UV regions that will be assigned to hair strands'),
            ('ALL', 'UV:  Use All Regions', 'All UV regions will be automatically assigned to hair strands')
        ],
        default='ALL',
        update=assign_uv_regions)

    uv_regions: bpy.props.EnumProperty(name='UV Region ID', description='Pick UV region that will be assinged to selected strands', items=uv_box_items, options={'ENUM_FLAG'}, update=assign_uv_regions)
    uv_seed: IntProperty(name="Seed", description='Randomize UV assigment', default=0, min=0, max=1000, update=assign_uv_regions)
    threshold_mask: bpy.props.CollectionProperty(type=RegToLenProps)

    jiggle_props: bpy.props.PointerProperty(type=JiggleBoneProps)

    hair_system: bpy.props.PointerProperty(type=HairSystem)




FOLDER_ITEMS = {}  # for keeping reference in python to items - fix enum bug in blender
def folder_items(self, context):
    global FOLDER_ITEMS
    pref = get_addon_preferences()
    lib_path_len = len(pref.lib_path)
    curr_sub_dir = context.scene.ht_props.lib_relative_sub_path
    lib_extended_path = os.path.join(pref.lib_path, curr_sub_dir)
    if not hair_lib.FORCE_UPDATE_FOLDERS and lib_extended_path in FOLDER_ITEMS.keys():
        return FOLDER_ITEMS[lib_extended_path]

    # print(f'Updating. Force update was {FORCE_UPDATE_FOLDERS}')
    items = []
    if os.path.exists(lib_extended_path):
        for fn in os.listdir(lib_extended_path):
                file_path = os.path.join(lib_extended_path, fn)
                if os.path.isdir(file_path):
                    relative_sub_dir = file_path[lib_path_len:]
                    items.append((relative_sub_dir, '+', fn))
        FOLDER_ITEMS[lib_extended_path] = items
        hair_lib.FORCE_UPDATE_FOLDERS = False
        return FOLDER_ITEMS[lib_extended_path]
    else:
        return items


class ScnHTPropertyGroup(bpy.types.PropertyGroup):
    def reset_offset(self, context):
        self.select_offset = 0
        bpy.ops.curve.hair_select_all(select=False)

    lib_relative_sub_path: bpy.props.StringProperty(name="Folder Path", subtype='DIR_PATH', description='Holds library subfolder', default="")
    lib_previews: bpy.props.EnumProperty(items=enum_previews_from_directory_items, description='Holds previews')
    export_merged_name: bpy.props.StringProperty(name="Merged name", description="When saving multiple hairs, define output name", default="Merged")
    save_with_screen_grab: bpy.props.BoolProperty(name="Save with Screen Grab", description="Save with Screen Grab", default=True)
    bool_folders: bpy.props.EnumProperty(name='Folders select', description='Checkbox for folders to perform operation on',
                                         items=folder_items,
                                         options={'ENUM_FLAG'})

    last_hair_settings: bpy.props.PointerProperty(type=last_hair_settings)
    hair_bake_settings: bpy.props.PointerProperty(type=HairBakeSettings)
    hair_drawing: bpy.props.PointerProperty(type=ModalDrawingSettings)
    active_end: bpy.props.EnumProperty(name='Active end',
                                      items=(
                                          ('ROOTS', 'Model Roots', ''),
                                          ('TIPS', 'Model Tips', '')),
                                       default='TIPS', update=reset_offset)
    higlight_bias: bpy.props.FloatProperty(name="Draw bias", description="Draw strand points closer to camera", min=0.0, soft_max=1.0, default=0.5, subtype='FACTOR')
    higlight_range: bpy.props.IntProperty(name='Higlight adjacent range', description='', default=1, min=0, max=2)
    select_offset: bpy.props.IntProperty(name='Selection Offset', description='', default=0, min=0, max=32)
    clump_falloff: bpy.props.FloatProperty(name="Strand stiffness", description="Strand will resist deformation more", default=0.5, min=0, max=1)
    influence_rad: bpy.props.FloatProperty(name="Proportianl Size", description="Proportianl Size", default=0.5, min=0.001, soft_max=10)
    circle_sel_rad2d: bpy.props.IntProperty(name="Circle Select Size", description="Proportianl Size", default=100, min=10, soft_max=500)
    align_tilt: bpy.props.BoolProperty(name='Align Tilt', description='', default=True)
    move_mode: bpy.props.EnumProperty(name='Mode',
                                       items=(
                                           ('FK', 'Normal', 'Transform hair with proportional fallof'),
                                           ('IK', 'Chain', 'Move hair as chains')),
                                       default='IK')

    copy_modal_hair: bpy.props.PointerProperty(type=ParticleModalSettings)

    jiggle_sim_on: bpy.props.BoolProperty(name='Jiggle sim on', description='', default=False)


class MatHTPropertyGroup(bpy.types.PropertyGroup):
    hair_uv_points: bpy.props.CollectionProperty(type=hairUVPoints)
    uv_curls: bpy.props.PointerProperty(type=UVCurls)
    linked_mesh_mat: bpy.props.PointerProperty(type=bpy.types.Material)


class IntCollection(bpy.types.PropertyGroup):
    spl_id: bpy.props.IntProperty(name="", default=-1, min=-1)
    mat_id: bpy.props.IntProperty(name="", default=-1, min=-1, max=32) #assume no more than 32 materials per obj

class CurveHTPropertyGroup(bpy.types.PropertyGroup):
    uv_seed: IntProperty(name="UV Seed", default=20, min=1, max=1000)
    # mat_overrides: bpy.props.CollectionProperty(type=IntCollection)

class PBoneHTPropertyGroup(bpy.types.PropertyGroup):
    jiggle_index: bpy.props.IntProperty(name="Jiggle Index", default=-1, min=-1, max=32)
    jiggle_collision: bpy.props.BoolProperty(name='Add Collision', description='Other bones will collide with this bone.\nCollision shape is described by bone envelope - Tip and Head Radius.\nCollision margin is described by bone envelope size', default=False)
    friction: bpy.props.FloatProperty(name='Friction', description='', default=0.4, min=0, max=10)


def register_properties():
    bpy.types.Object.ht_props = bpy.props.PointerProperty(type=ObjHTPropertyGroup)
    bpy.types.Scene.ht_props = bpy.props.PointerProperty(type=ScnHTPropertyGroup)
    bpy.types.Material.ht_props = bpy.props.PointerProperty(type=MatHTPropertyGroup)
    bpy.types.Curve.ht_props = bpy.props.PointerProperty(type=CurveHTPropertyGroup)
    bpy.types.PoseBone.ht_props = bpy.props.PointerProperty(type=PBoneHTPropertyGroup)


def unregister_properties():
    del bpy.types.Object.ht_props
    del bpy.types.Scene.ht_props
    del bpy.types.Material.ht_props
    del bpy.types.Curve.ht_props
    del bpy.types.PoseBone.ht_props
