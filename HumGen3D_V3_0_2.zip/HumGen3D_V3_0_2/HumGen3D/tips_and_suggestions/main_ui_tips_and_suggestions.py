import bpy


def get_main_ui_tips_from_context(context, sett, hg_rig):
    yield main_tutorial
    


main_tutorial = [
'Quickstart tutorial',
'HELP',
"""You can find the quick start
guide again here:
""",
(
    'WINDOW',
    'hg3d.draw_tutorial',
    'Open tutorial in Blender',
    'tutorial_name',
    'get_started_tutorial'
)
]
