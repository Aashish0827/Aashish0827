import bpy

def get_extras_menu_tips_from_context(context, sett, hg_rig):
    pass