import bpy  # type:ignore

hg_body = bpy.data.objects['HG_Body']
