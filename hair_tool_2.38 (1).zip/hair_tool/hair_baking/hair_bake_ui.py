# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
# Copyright (C) 2017 JOSECONSCO
# Created by JOSECONSCO

import bpy
# import sys
# dir = 'C:\\Users\\JoseConseco\\AppData\\Local\\Programs\\Python\\Python35\\Lib\\site-packages'
# if not dir in sys.path:
#     sys.path.append(dir )
# import ipdb


# class HTOOL_PT_SaveImageFilePath(bpy.types.Panel):
#     bl_space_type = 'NODE_EDITOR'
#     bl_region_type = 'UI'
#     bl_category = "Item"
#     bl_label = "Save File Output slots"
#     bl_options = {'DEFAULT_CLOSED'}

#     @classmethod
#     def poll(cls, context):
#         return context.active_node is not None

#     def draw(self, context):
#         layout = self.layout
#         node = context.active_node
#         # set "node" context pointer for the panel layout
#         layout.context_pointer_set("node", node)
#         layout.operator("node.save_image_file_node")



class  HTOOL_PT_Hair_Panel_Bake(bpy.types.Panel):
    bl_label = "Hair Bake"
    bl_idname = "HTOOL_PT_Hair_Panel_Bake"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_options = {'DEFAULT_CLOSED'}
    bl_category = 'Hair Tool'
    # bl_context = "object"

    @classmethod
    def poll(cls, context):
        return context.mode in {'OBJECT', 'EDIT_CURVE', 'EDIT_MESH'}

    def draw(self, context):
        layout = self.layout
        if 'BakingHair' == context.scene.name:
            bake_settings = context.scene.ht_props.hair_bake_settings
            # row = layout.row(align=True)
            col = layout.column(align=True)
            col.operator("object.bake_hair", icon='RESTRICT_RENDER_OFF')
            col = layout.column(align=True)
            col.prop(bake_settings, 'hair_bake_path')
            col.prop(bake_settings, 'hair_bake_file_name')
            row = col.row(align=True)
            split = row.split(factor=0.25, align=True)
            split.label(text='Resolution')
            split.prop(bake_settings, 'bakeResolution_x', text='')
            s_row = split.row(align=True)
            s_row.enabled = not bake_settings.lock_ratio
            s_row.prop(bake_settings, 'bakeResolution_y', text='')
            ic = 'DECORATE_LOCKED' if bake_settings.lock_ratio else 'DECORATE_UNLOCKED'
            row.prop(bake_settings, 'lock_ratio', icon_only=True, icon=ic, emboss=True)
            col.prop(bake_settings,'render_quality')
            col.prop(bake_settings, 'output_format')

            row = col.row(align=True)
            split = row.split(factor=0.70, align=True)
            split.prop(bake_settings, 'padding_mode', text='')
            if bake_settings.padding_mode == 'FIXED':
                split.prop(bake_settings, 'padding_size', text='')
            else:
                sub_r = split.row(align=True)
                sub_r.enabled = False
                sub_r.prop(bake_settings, 'padding_size', text='')
            col.prop(bake_settings, 'preview_background', text='')
            col.prop(bake_settings, 'hair_bake_composite', icon='NODE_COMPOSITING', expand=True)
            col = layout.column(align=True)
            col.prop(bake_settings, 'render_passes',expand=True)
            col.operator('material.update_pass_material')
            layout.separator()
            box = layout.box()
            col = box.column()
            col.label(text='Particle Hair Display Settings')
            col.prop(bake_settings, 'particle_display_step')
            col.prop(bake_settings, 'particle_width')
            col.prop(bake_settings, 'particle_shape')
        row = layout.row(align=True)
        obj = context.active_object
        if obj and obj.type == 'MESH' and obj.data.shape_keys and obj.data.shape_keys.key_blocks.get('uv_flat') and obj.data.shape_keys.key_blocks['uv_flat'].value > 0.99:
            row.operator("object.uv_to_shapekey_hair", text="Unflatten object")
        else:
            row.operator("object.uv_to_shapekey_hair")

        row = layout.row(align=True)
        row.operator("object.open_hair_bake")
        if 'BakingHair' == context.scene.name:
            row.operator("object.reload_hair_baking", icon='FILE_REFRESH', text='')


