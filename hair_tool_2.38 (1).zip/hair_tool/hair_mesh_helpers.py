# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
# Copyright (C) 2017 JOSECONSCO
# Created by JOSECONSCO

import bpy
import bmesh
import math
import numpy as np
from bpy.props import StringProperty, BoolProperty, IntProperty, FloatProperty
from mathutils import Vector, kdtree
from mathutils.geometry import intersect_point_line
from .utils.helper_functions import calc_exponent, get_obj_mesh_bvht
from .utils.helper_functions import  clamp
from mathutils.interpolate import poly_3d_calc
from .jiggle_chain import OBJECT_OT_Assign_Bones_Jiggle

# TODO: origin at hair obj, or at vec(0,0,0)?
# TODO: better bone gen for  cylinder profile
# DONE: offset to tip of bone
# DONE: bone for all sel islands mode

class HTOOL_OT_GenerateBones(bpy.types.Operator):
    bl_label = "Generate Bones"
    bl_idname = "object.ribbon_to_bones"
    bl_description = "Create bones from selected mesh hair strands.\nStrand with active mesh element will be used to generate bone chain.\nOther selected strand will be automatically skinned to generated bone chain"
    bl_options = {"REGISTER", "UNDO"}

    origin_offset: bpy.props.IntProperty(name="Bones start", description='Place first bone at some start distance from strand root location', default=60, min=0, max=90, subtype='PERCENTAGE')
    offset_tip: bpy.props.IntProperty(name="Offset to Tip", description='Bunch up generated bones more toward strand tip', default=0, min=0, max=100, subtype='PERCENTAGE')
    bone_count: bpy.props.IntProperty(name="Bones count", description='', default=2, min=1, soft_max=6)
    assign_jiggle: BoolProperty(name="Assign Jiggle", description="Assign jiggle to bones", default=True)
    generation_mode: bpy.props.EnumProperty(name='Bone generation mode', description='Descibes how new bones will be generated',
        items=[
            ('SELECTED_ISLANDS', 'All selected stripes', 'Generate bone chain for all selected strans (mesh islands)'),
            ('ACTIVE_ISLAND', 'Active stripe only', 'Generate bone chain only for active stripe (island with active face/edge/vert)')
        ], default='ACTIVE_ISLAND')


    def invoke(self, context, event):
        self.prev_bones_names = []
        return self.execute(context)

    def build_strand_islands(self, bm, active_vert):
        islands = []
        island = []  #  [[verts_row1], [verts_row2], ...]
        islands_curl_verts = []     # for handling curl vertices
        island_curl_verts = []  # list of  [curl_verts]
        def add_to_island(vert_row):
            cnt = len(vert_row)
            if cnt > 1: # avoid adding single vert rows - caused by uv curls
                island.append(vert_row)
            elif cnt == 1:
                island_curl_verts.append(vert_row[0]) # single vert anyway

        vert_row_ids = [] # island is list of rows of vert ids
        is_active = False
        active_idx = None
        prev_loop = bm.verts[0].link_loops[0]
        uv_lay = bm.loops.layers.uv['HairTool_UV']
        # go through all verts and build islands - based on UV[1]. Curl verts are added separately
        for v in bm.verts: # DONE: deal with curly uvs... - ignore len(vert_row_ids) == 1 ?
            is_active = (v == active_vert or is_active)
            loop = v.link_loops[0] # all should have same uv
            diff = abs(loop[uv_lay].uv[1] - prev_loop[uv_lay].uv[1])
            if diff < 0.00001:   # NOTE: same row
                vert_row_ids.append(v.index) # vert is invalidated after edit_bone mode, thus store index
            elif diff < 0.99:  # NOTE: moved to next row
                add_to_island(vert_row_ids)
                vert_row_ids = [v.index] # start filling new row
            else:             # NOTE: we moved to new island
                add_to_island(vert_row_ids)
                if bm.verts[vert_row_ids[-1]].select:
                    islands.append(island)
                    islands_curl_verts.append(island_curl_verts)
                    if is_active:
                        active_idx = len(islands)-1
                        is_active = False
                island = []
                island_curl_verts = []
                vert_row_ids = [v.index]
            prev_loop = v.link_loops[0]
        add_to_island(vert_row_ids)
        if bm.verts[vert_row_ids[-1]].select:
            islands.append(island) #no next island, thus conditions from loop above wont be triggered
            islands_curl_verts.append(island_curl_verts)
            if is_active: # so another check
                active_idx = len(islands)-1
                is_active = False
        # print(islands)
        # print(islands_curl_verts)
        return islands, active_idx, islands_curl_verts


    def get_set_rig(self, context, ht_props):
        active_obj = self.active_obj
        if ht_props.target_rig:
            rig = ht_props.target_rig
        else:
            rig_name = active_obj.name + '_Rig'
            rig = bpy.data.objects.get(rig_name)
            ht_props.target_rig = rig
        if rig:
            armature = rig.data
        else:
            armature = bpy.data.armatures.new(active_obj.name + "_Bones")
            rig = bpy.data.objects.new(active_obj.name + '_Rig', armature)
            rig.matrix_world = active_obj.matrix_world
            context.collection.objects.link(rig)

        # NOTE: add arma mod to active_obj if not exist
        mod_armature = active_obj.modifiers.get('Hair Armature')
        if not mod_armature:
            found_mod = False
            for mod in active_obj.modifiers:
                if mod.type == 'ARMATURE' and mod.object == rig:
                    found_mod = True
                    break
            if not found_mod:
                mod_armature = active_obj.modifiers.new('Hair Armature', type='ARMATURE')
                mod_armature.object = rig
        rig.show_in_front = True
        is_in_scene = context.scene.objects.get(rig.name)
        if not is_in_scene:
            context.scene.collection.objects.link(rig)
        return rig

    def create_edit_bones(self, context, pin_bone_name, islands_bone_pts_local):
        created_bones = []
        created_bones_names = []
        to_rig_space = self.rig.matrix_world.inverted() @ self.active_obj.matrix_world
        for bone_pts_local in islands_bone_pts_local:
            prev_pt = bone_pts_local[0]
            prev_bone = None
            for i,bone_pt in enumerate(bone_pts_local[1:]):
                bone = self.rig.data.edit_bones.new('HT_Bone')
                bone.envelope_distance = 0.0001
                bone.head_radius = 0.002
                bone.tail_radius = 0.002
                if i == 0 and pin_bone_name :
                    root_bone = self.rig.data.edit_bones.get(pin_bone_name)
                    if root_bone:
                        bone.parent = root_bone
                created_bones.append(bone)
                created_bones_names.append(bone.name)
                bone.head = to_rig_space @ prev_pt # from active obj local, to rig local
                bone.tail = to_rig_space @ bone_pt # from active obj local, to rig local
                if prev_bone:
                    bone.parent = prev_bone
                    bone.use_connect = True
                prev_pt = bone_pt
                prev_bone = bone
        self.prev_bones_names.extend(created_bones_names) # backup - we remove new bones on operator redo (cos blender cant perform it properly)
        return created_bones, created_bones_names

    def gen_bones_data(self, bm, islands, active_idx):
        bones_co_kd = None  # required for weighting verts by finding closest bone
        island_bone_pts_local = []
        for island_idx,island in enumerate(islands):
            if island_idx == active_idx:
                island_bone_pts_local.append([])
                rows_cnt = len(island)
                bones_co_kd = kdtree.KDTree(rows_cnt-1) # holds bone points

                ids = np.linspace(0, 1, self.bone_count+1)
                if self.offset_tip:
                    exponent = self.offset_tip/100*1.5+1 # remap (0,1) to (1,3)
                    ids = 1-np.power(-ids+1, exponent)
                    # offset_tip_tns = calc_pow_inverted(self.offset_tip+1, self.bone_count+1)
                    # ids = np.power(ids, self.offset_tip+1)
                ids = ids*(1-self.origin_offset/100) + self.origin_offset/100 # remap from (0,1) to (self.origin_offset/100, 1)
                ids = ids * (rows_cnt - 1)


                strip_width = len(island[0])
                first_vert = bm.verts[island[0][0]]
                last_vert = bm.verts[island[0][-1]]
                is_cylinder = strip_width != 2 and len([e for e in first_vert.link_edges if e.other_vert(first_vert) == last_vert]) > 0
                if is_cylinder: # we have circle profiel (or stripe with 1 poly width - should work either way)
                    strip_center_row_idx = round(strip_width/2)
                    is_even = strip_width % 2 == 0

                def get_row_center(vert_row_ids):
                    first_vert = bm.verts[vert_row_ids[0]]
                    last_vert = bm.verts[vert_row_ids[-1]]
                    avg_co = (first_vert.co + last_vert.co)/2
                    if is_cylinder: # cylinder profile
                        if is_even:
                            last_vert = bm.verts[vert_row_ids[strip_center_row_idx]] # opposite vert
                            avg_co = (first_vert.co + last_vert.co)/2
                        else:
                            diagonal_vert = bm.verts[vert_row_ids[strip_center_row_idx]] # opposite vert
                            avg_co = (avg_co + diagonal_vert.co)/2
                    return avg_co

                for i, idx in enumerate(ids):
                    seg, fac = divmod(idx, 1)
                    row_idx = int(seg)
                    vert_row_ids = island[row_idx]
                    avg_co = get_row_center(vert_row_ids)

                    #NOTE:  blend with next row using fac
                    next_row_ids = island[min(row_idx+1, rows_cnt-1)]
                    next_co = get_row_center(next_row_ids)
                    # next_co = (bm.verts[next_row_ids[0]].co + bm.verts[next_row_ids[-1]].co)/2
                    avg_co = avg_co.lerp(next_co, fac)
                    island_bone_pts_local[-1].append(avg_co)
                    bones_co_kd.insert(avg_co, i)

        bones_co_kd.balance()
        return island_bone_pts_local, bones_co_kd

    def generate_weights(self, bm, created_bones, pin_bone, islands, bones_co_kd, islands_curl_verts):
        active_obj = self.active_obj
        deform = bm.verts.layers.deform.active

        to_rig_space_mat = self.rig.matrix_world.inverted() @ active_obj.matrix_world
        to_active_space = to_rig_space_mat.inverted() # back from rig to active object space
        pin_group = active_obj.vertex_groups.get(pin_bone)
        if not pin_group:
            pin_group = active_obj.vertex_groups.new(name=pin_bone)

        # NOTE: if vertex group already exists, for created bones, remove it
        for bone in created_bones:
            bgroup = active_obj.vertex_groups.get(bone.name)
            if bgroup:
                for v in bm.verts:
                    for group_id in v[deform].keys():
                        if group_id == bgroup.index:
                            del v[deform][group_id]
                            v[deform][pin_group.index] = 1


        for island, island_curl_verts in zip(islands, islands_curl_verts):
            do_curl_verts = True # once per island - handle the extra curl verts
            for vert_row_ids in island:
                if do_curl_verts and island_curl_verts:
                    vert_row_ids.extend(island_curl_verts)
                do_curl_verts = False
                for v_id in vert_row_ids:
                    v = bm.verts[v_id]
                    co, bone_idx, dist = bones_co_kd.find(v.co)
                    bones_to_check = {max(0,bone_idx-1), min(bone_idx, len(created_bones)-1)}
                    for b_idx in bones_to_check:
                        bone = created_bones[b_idx]
                        pt, fac = intersect_point_line(v.co, to_active_space @ bone.head, to_active_space @ bone.tail)
                        bgroup = active_obj.vertex_groups.get(bone.name)
                        if not bgroup:
                            bgroup = active_obj.vertex_groups.new(name=bone.name)

                        # remap fac from  (0,1) - so that 0.5 is at max influcence
                        x = abs(fac-0.5)  # -0.5 cos fac is from head to tip (0, 1)
                        x_clamped = clamp(x, -1, 1)

                        # weight = 0.5*(math.cos(fac * 3.14)+1) #smooth fallof
                        weight = -abs(x_clamped)+1
                        # vert_groups = v[deform].keys() # current vert groups
                        v[deform][bgroup.index] = weight
                        if b_idx == 0 and fac <= 0.5:  # assign pin_bone vert_group to first half, of first bone
                            v[deform][pin_group.index] = 1-weight



    def set_lock_weight(self, all_new_bones_names, lock):
        for bones_chain in all_new_bones_names:
            vg = self.active_obj.vertex_groups.get(bones_chain[0])
            if vg:
                vg.lock_weight = lock # so that normalize wont affect it



    def execute(self, context):
        active_obj = context.active_object
        self.active_obj = active_obj
        ht_props = active_obj.ht_props
        if len(active_obj.data.uv_layers) < 2:
            self.report({'WARNING'}, 'No second UV channel found! Cancelling')
            return {"CANCELLED"}
        try:    # prevent poll error
            bpy.ops.object.vertex_group_remove_from(use_all_groups=True)
        except:
            pass
        mesh = active_obj.data

        bm = bmesh.from_edit_mesh(mesh)
        bm.faces.ensure_lookup_table()
        bm.verts.ensure_lookup_table()

        ht_uvs = bm.loops.layers.uv.get('HairTool_UV')
        if not ht_uvs:
            self.report({'WARNING'}, 'No \'HairTool UV\' layer found! Cancelling')
            return {"CANCELLED"}
        # NOTE: get active verts
        active_element = bm.select_history.active
        if self.generation_mode == 'ACTIVE_ISLAND':
            active_vert = active_element
            if isinstance(active_element, bmesh.types.BMFace):
                active_vert = active_element.verts[0]
            elif isinstance(active_element, bmesh.types.BMEdge):
                active_vert = active_element.verts[0]

            if not active_vert:
                self.report({'ERROR'}, 'One active mesh element (vert, edge, face) found. Switching to \'Selected Islands\' mode')
                self.generation_mode = 'SELECTED_ISLANDS'
                active_vert = None
        else:
            active_vert = None

        # NOTE: build mesh islands based on HairTool_UV uvs
        islands, active_island_idx, islands_curl_verts = self.build_strand_islands(bm, active_vert)

        if not islands:
            self.report({'ERROR'}, 'Select at least one hair strip (island) for rigging')
            return {'CANCELLED'}
        active_island_ids = [active_island_idx] if self.generation_mode == 'ACTIVE_ISLAND' else [i for i in range(len(islands))]

        # NOTE: detect existing or create new rig for hair. And setup armature modifier on active_obj
        self.rig  = self.get_set_rig(context, ht_props )

        ######## XXX:  DO STUPIND Islands loop 3 times - avoids mode switching and thus bm, ebones etc invalidation

        # NOTE: generate bone (head.co, tail.co) by traveling over island row verts.
        is_bone_pts_co = []  # list of lists of tuples (head.co, tail.co)
        is_bones_co_kd = []
        for active_island_idx in active_island_ids:
            island_bone_pts_co, island_bones_co_kd = self.gen_bones_data(bm, islands, active_island_idx)
            is_bone_pts_co.append(island_bone_pts_co)
            is_bones_co_kd.append(island_bones_co_kd)

        # NOTE: create actuall bones
        all_new_bones_names = []
        islands_new_bones = []
        context.view_layer.objects.active = self.rig
        bpy.ops.object.mode_set(mode='EDIT')

        if self.prev_bones_names: # if operator redo - remove previously created bones
            for bname in reversed(self.prev_bones_names):
                pbone = self.rig.pose.bones.get(bname)
                if pbone:
                    pbone.ht_props.jiggle_index = -1
                    pbone.bone_group = None
                ebone = self.rig.data.edit_bones.get(bname)
                if ebone:
                    self.rig.data.edit_bones.remove(ebone)
            self.prev_bones_names.clear()
        for active_island_idx, island_bone_pts_co in zip(active_island_ids, is_bone_pts_co):
            island_new_bones, created_bones_names = self.create_edit_bones(context, ht_props.pin_bone, island_bone_pts_co) # fills self.prev_bones_names; also destroys bm (by switch to edit mode)
            all_new_bones_names.append(created_bones_names)
            islands_new_bones.append(island_new_bones)
            self.prev_bones_names.extend(created_bones_names) # backup - we remove new bones on operator redo (cos blender cant perform it properly)
        # bpy.ops.object.editmode_toggle() #reqyured fir bones to show in view
        context.view_layer.objects.active = self.active_obj
        # bmesh.update_edit_mesh(mesh, True)


        # NOTE: assign weights to all strips

        mesh = active_obj.data
        bm = bmesh.new()   # create an empty BMesh
        bm = bmesh.from_edit_mesh(mesh)
        # Ensure custom data exists.
        bm.verts.layers.deform.verify()
        bm.verts.ensure_lookup_table()
        pin_group_name = ht_props.pin_bone if ht_props.pin_bone else 'ht_root'
        for active_island_idx, island_bones_co_kd, island_new_bones in zip(active_island_ids, is_bones_co_kd, islands_new_bones):
            islands_to_skin = islands if self.generation_mode == 'ACTIVE_ISLAND' else [islands[active_island_idx]]
            curly_islands_verts = islands_curl_verts if self.generation_mode == 'ACTIVE_ISLAND' else [islands_curl_verts[active_island_idx]]
            self.generate_weights(bm, island_new_bones, pin_group_name, islands_to_skin, island_bones_co_kd, curly_islands_verts)
                # bm.to_mesh(mesh) # for obj mode
        bmesh.update_edit_mesh(mesh, destructive=True) #save weights
        bm.free()  # free and prevent further access


        # NOTTE: finally smooth ver groups, and assing jiggle physics
        self.rig.select_set(True)
        bpy.ops.object.mode_set(mode='WEIGHT_PAINT')
        bpy.context.object.data.use_paint_mask_vertex = True
        bpy.ops.object.vertex_group_smooth(group_select_mode='ALL', factor=0.4, repeat=1)
        # active_obj.vertex_groups.active = active_obj.vertex_groups[created_bones_names[0].name]

        # NOTE: normalize without affecting root of bone chains
        self.set_lock_weight(all_new_bones_names, True)
        bpy.ops.object.vertex_group_normalize_all(lock_active=False)
        self.set_lock_weight(all_new_bones_names, False)

        bpy.ops.object.mode_set(mode='OBJECT')

        context.view_layer.objects.active = self.rig
        bpy.ops.object.mode_set(mode='OBJECT')
        context.view_layer.objects.active = active_obj

        active_obj.update_tag()
        self.rig.data.edit_bones.update()
        self.rig.pose.bones.update()
        context.view_layer.update()
        self.rig.pose.use_auto_ik = True
        active_obj.ht_props.target_rig = self.rig

        bpy.ops.object.mode_set(mode='EDIT')

        # NOTE: add springs
        if self.assign_jiggle:
            pbones = [self.rig.pose.bones.get(bname) for bone_chain in all_new_bones_names for bname in bone_chain]
            OBJECT_OT_Assign_Bones_Jiggle.assign_jiggle_to_bones(self.rig, pbones)
        return {"FINISHED"}


class HTOOL_OT_GenerateWeight(bpy.types.Operator):
    bl_label = "Add weights"
    bl_idname = "object.ribbon_weight"
    bl_description = "Generate vertex weight gradient from root to tip of each hair card"
    bl_options = {"REGISTER", "UNDO"}

    createNewVC: BoolProperty(name="Add new VColor", description="Adds new vertex color layer instead of overriding active one", default=False)
    gradientFalloff: FloatProperty(name="Gradient Falloff", description="Gradient Falloff", default=0,
                                    min=-1, max=1, subtype='PERCENTAGE')
    def execute(self, context):
        ribbonMesh = context.active_object
        if len(ribbonMesh.data.uv_layers)<2:
            self.report({'INFO'}, 'No second UV channel found!')
            return {"CANCELLED"}
        mesh = ribbonMesh.data
        if not ribbonMesh.vertex_groups or self.createNewVC:
            ribbonMesh.vertex_groups.new(name = 'gradient')
        if self.createNewVC:
            vg = ribbonMesh.vertex_groups[-1]
        else:
            vg = ribbonMesh.vertex_groups.active
        vertUV = {}
        cpow = calc_exponent(self.gradientFalloff)
        for face in mesh.polygons:
            for vert_idx, loop_idx in zip(face.vertices, face.loop_indices):
                uv_coords = mesh.uv_layers['HairTool_UV'].data[loop_idx].uv
                vertUV[vert_idx]= (uv_coords.x, uv_coords.y)
        selected_verts = [v for v in mesh.vertices if v.select]
        verts = selected_verts if mesh.use_paint_mask_vertex else mesh.vertices
        for vert in verts:
            x,y = vertUV[vert.index]
            weight = abs(max(min(1-y, 1), 0))  # d over box height
            w2 = math.pow(weight, cpow)
            vg.add([vert.index],w2 , "REPLACE")
        if self.createNewVC:
            ribbonMesh.vertex_groups.active = ribbonMesh.vertex_groups[-1]
        bpy.ops.object.mode_set(mode='WEIGHT_PAINT')
        return {"FINISHED"}

class HTOOL_OT_GenerateVerColorGradient(bpy.types.Operator):
    bl_label = "Generate gradient"
    bl_idname = "object.ribbon_vert_color_grad"
    bl_description = "Generate vertex color gradient from root to tip of each hair card"
    bl_options = {"REGISTER", "UNDO"}

    createNewVC: BoolProperty(name="Add new VColor", description="Adds new vertex color layer instead of overriding active one", default=False)
    gradientFalloff: FloatProperty(name="Gradient Falloff", description="Gradient Falloff", default=0,
                                  min=-1, max=1, subtype='PERCENTAGE')

    def execute(self, context):
        ribbonMesh = context.active_object
        if len(ribbonMesh.data.uv_layers)<2:
            self.report({'INFO'}, 'No second UV channel found!')
            return {"CANCELLED"}
        mesh = ribbonMesh.data
        if not mesh.vertex_colors or self.createNewVC:
            mesh.vertex_colors.new(name="Gradient")

        # color_layer = mesh.vertex_colors["Col"]
        # or you could avoid using the color_layer name
        if self.createNewVC:
            color_layer = mesh.vertex_colors[-1]
        else:
            color_layer = mesh.vertex_colors.active
        cpow = calc_exponent(self.gradientFalloff)
        selected_faces = [f for f in mesh.polygons if f.select]
        faces = selected_faces if mesh.use_paint_mask_vertex else mesh.polygons
        for face in faces:
            for loop_idx in face.loop_indices:
                x,y = mesh.uv_layers['HairTool_UV'].data[loop_idx].uv
                col = abs(max(min(y, 1), 0))
                col2 = math.pow(col, cpow)
                color_layer.data[loop_idx].color = [col2,col2,col2,1]
        if self.createNewVC:
            mesh.vertex_colors.active = mesh.vertex_colors[-1]
        bpy.ops.object.mode_set(mode='VERTEX_PAINT')
        ribbonMesh.update_tag()
        return {"FINISHED"}

class HTOOL_OT_GenerateVerColorRandom(bpy.types.Operator):
    bl_label = "Generate random vertex colors"
    bl_idname = "object.ribbon_vert_color_random"
    bl_description = "Makes each ribbon vertex color unique"
    bl_options = {"REGISTER", "UNDO"}

    Seed: IntProperty(name="Noise Seed", default=1, min=1, max=1000)
    mergeSimilar: BoolProperty(name="Merge Similar", description="Merge Simila", default=False)
    createNewVC: BoolProperty(name="Add new VColor", description="Adds new vertex color layer instead of overriding active one", default=False)


    def execute(self, context):
        np.random.seed(self.Seed)
        obj = bpy.context.active_object
        bpy.ops.object.mode_set(mode='EDIT', toggle=False)  # Go to edit mode
        bpy.ops.mesh.select_all(action="DESELECT")  # unselect everything

        bm = bmesh.from_edit_mesh(obj.data)  # load mesh
        bm.faces.ensure_lookup_table()

        if self.createNewVC or not obj.data.vertex_colors:
            obj.data.vertex_colors.new(name="Random Color")

        if self.createNewVC:
            color_layer =bm.loops.layers.color[-1]
        else:
            color_layer =bm.loops.layers.color.active

        faces_lislands = []
        faces = bm.faces

        while faces:
            faces[0].select = True  # select 1st face
            bpy.ops.mesh.select_linked()  # select all linked faces makes a full loop
            faces_lislands.append([f for f in faces if f.select])
            bpy.ops.mesh.hide(unselected=False)  # hide the detected loop
            faces = [f for f in bm.faces if not f.hide]  # update faces

        bpy.ops.mesh.reveal()  # unhide all faces
        islandColor = {} #dictt will contain faceCount : Color pairs
        for facesIsland in faces_lislands: # face islands list
            if self.mergeSimilar:
                islandFaceCount = len(facesIsland)
                if islandFaceCount in islandColor.keys():
                    random_color = islandColor[islandFaceCount]
                else:
                    random_color = np.random.random_sample(3).tolist()
                    islandColor[islandFaceCount] = random_color  #asign faceCount : Color"
            else:
                random_color = np.random.random_sample(3).tolist()
            for face in facesIsland: #island faces
                for loop in face.loops:
                        loop[color_layer] = random_color+[1]

        bm.free()  # free and prevent further access
        if self.createNewVC:
            obj.data.vertex_colors.active = obj.data.vertex_colors[-1]
        self.report({'INFO'}, 'Vertex colors have been generated')
        bpy.ops.object.mode_set(mode='VERTEX_PAINT')
        return {"FINISHED"}


def three_d_bincount_add(out, e_k, weights):
    out[:, 0] += np.bincount(e_k, weights[:, 0], out.shape[0])
    out[:, 1] += np.bincount(e_k, weights[:, 1], out.shape[0])
    out[:, 2] += np.bincount(e_k, weights[:, 2], out.shape[0])


def new_bincount(out, e_k, weights=None):
    out += np.bincount(e_k, weights, out.shape[0])


def close_bmesh(context,  bm, source):
    bm.normal_update()
    if context.object.mode == "EDIT":
        bmesh.update_edit_mesh(source, tessface=False, destructive=False)
    else:
        bm.to_mesh(source)
        bm.free()
        # source.update()


def get_bmesh(context, mesh):
    bm = bmesh.new()
    if context.active_object.mode == 'OBJECT':
        bm.from_mesh(mesh)
    elif context.active_object.mode == 'EDIT':
        bm = bmesh.from_edit_mesh(mesh)
    return bm


def smooth_mesh_data(context, bm, data, iteration_amount):
    # bm.verts.ensure_lookup_table()
    # bm.edges.ensure_lookup_table()

    # o_co = np.array([vert.co for vert in bm.verts])
    o_co = data
    vert_count = len(bm.verts)

    edge_keys = np.array([[edge.verts[0].index, edge.verts[1].index] for edge in bm.edges])
    # freeze_verts = np.array([vert.is_boundary or not vert.is_manifold for vert in bm.verts])  # manifold for pocket sewing edges

    p_co = np.copy(o_co)  # current new vertex position

    #sum edges that have vert X  and either end of edge (Va, Vb)
    v_connections = np.zeros(vert_count, dtype=np.float32)
    new_bincount(v_connections, edge_keys[:, 1])
    new_bincount(v_connections, edge_keys[:, 0])

    for x in range(iteration_amount):
        q_co = np.copy(p_co)  # prevoius iteration vert position
        p_co.fill(0)
        #calc average position weighted...
        if len(p_co.shape) == 1:
            new_bincount(p_co, edge_keys[:, 1], q_co[edge_keys[:, 0]])
            new_bincount(p_co, edge_keys[:, 0], q_co[edge_keys[:, 1]])

            p_co = p_co / v_connections  # new aver posision
        else:
            three_d_bincount_add(p_co, edge_keys[:, 1], q_co[edge_keys[:, 0]])
            three_d_bincount_add(p_co, edge_keys[:, 0], q_co[edge_keys[:, 1]])

            p_co = p_co / v_connections[:, None]  # new aver posision

        # p_co[freeze_verts] = q_co[freeze_verts]  # not selected ver - reset to original pos o_co
    # source.vertices.foreach_set('co', p_co.ravel())
    # for v in bm.verts:
    #     v.co = p_co[v.index]
    return p_co

def remap_01(arr):
    return list(np.interp(arr, (np.nanmin(arr), np.nanmax(arr)), (0, 1)))

class HTOOL_OT_AoToVcol(bpy.types.Operator):
    bl_idname = "object.ao_to_vcol"
    bl_label = "Bake AO"
    bl_description = "Bake hair cards Ambient Occlusion to vertex color.\n If you select multiple objects, then they will also influence generated AO on active object"
    bl_options = {"REGISTER","UNDO"}

    offset: bpy.props.FloatProperty(name="Surface Offset", default=0.01, min=0.0, max=1.0 )
    dist: bpy.props.FloatProperty(name="AO Distance", default=1.0, min=0.0)
    smooth_iter: bpy.props.IntProperty(name='Smooth', description='', default=1, min=0, max=12)
    bounces: bpy.props.IntProperty(name='Bounces', description='', default=1, min=0, max=5)
    contrast: bpy.props.FloatProperty(name='Contrast', description='', default=0.3, min=0, max=1)
    side: bpy.props.EnumProperty(name='Side', description='Shoot light rays from Front of faces, back or both',
        items=[
            ('FRONT', 'Front', ''),
            ('BACK', 'Back', ''),
            ('BOTH', 'Both', '')
        ], default='FRONT')

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'MESH'

    def invoke(self, context, event):
        self.depsgraph = context.evaluated_depsgraph_get()
        self.bvh = get_obj_mesh_bvht(context.active_object, self.depsgraph, applyModifiers=True, world_space=True) #fastest
        self.other_bvh = [get_obj_mesh_bvht(obj, self.depsgraph, applyModifiers=True, world_space=True) for obj in context.selected_objects if obj.type == 'MESH' and obj != context.active_object]
        return self.execute(context)

    def execute(self, context):
        obj = context.active_object
        me = obj.data
        bm = bmesh.new()   # create an empty BMesh
        bm.from_mesh(me)   # fill it in from a Mesh

        if 'AO' in bm.loops.layers.color.keys():
            color_layer = bm.loops.layers.color['AO']
        else:
            color_layer = bm.loops.layers.color.new('AO')

        per_face_ao = []
        faces_hit_ids = []
        ray_cast_count = 18 if self.side == 'BOTH' else 9
        mat = obj.matrix_world
        for f in bm.faces:
            #convert to pt by .to_4d().  Then to 3d
            ray_casts = self.simple_sample((mat@f.calc_center_median().to_4d()).xyz, (mat@Vector(f.normal[:]+(0,))).xyz)
            # total distance loc, norm, idx, dist
            base_ao = sum(dist / self.dist if loc and dist < self.dist else 1 for (loc, norm, idx, dist, is_active_obj) in ray_casts)  # ! fix 1.0 to self.dist
            faces_hit_ids.append([(idx, is_active_obj) if loc and dist < self.dist else (-1, is_active_obj) for (loc, norm, idx, dist, is_active_obj) in ray_casts])
            per_face_ao.append(base_ao/ray_cast_count)

        import math
        prev_ao = remap_01(per_face_ao)
        #* average current color + other faces that were ray_hit from current vert
        for n in range(self.bounces):
            next_bounce_ao = []
            for src_f_id, f_hits in enumerate(faces_hit_ids):  # sum per_face ao, from raycast hits
                sum_aos = 0
                miss_count = 0
                for (f_id, is_active_obj) in f_hits:
                    if is_active_obj: #use light cache
                        sum_aos += prev_ao[f_id] if f_id > -1 else 1
                    else:  # no light cache, so just 0 or 1
                        sum_aos += 0 if f_id > -1 else 1 # add zero - hited solid face...

                bounce_ao = sum_aos / ray_cast_count + prev_ao[src_f_id]/2
                # next_bounce_ao.append(bounce_ao)  # max to prevent darkening
                next_bounce_ao.append(max(bounce_ao, prev_ao[src_f_id]))  # max to prevent darkening

            # prev_ao = next_bounce_ao.copy()
            prev_ao = remap_01(next_bounce_ao)

        ao_per_vert = [0.0]*len(bm.verts)
        for i,f in enumerate(bm.faces):
            for v in f.verts:
                ao_per_vert[v.index] += prev_ao[i]

        for v_id, v in enumerate(bm.verts):
            ao_per_vert[v_id] /= len(v.link_faces)

        smoothed_ao = smooth_mesh_data(context, bm, np.array(ao_per_vert), self.smooth_iter)
        smoothed_ao -= np.nanmin(smoothed_ao)  #normalize
        smoothed_ao /= np.nanmax(smoothed_ao)  # normalize cd
        smoothed_ao = np.power(smoothed_ao, self.contrast*1.5 + 0.5)
        d3_ao = np.repeat(smoothed_ao[:, None], [3], axis=1)  # repeats 3x, row element
        for v, sm_ao in zip(bm.verts, list(smoothed_ao)):
            for loop in v.link_loops:
                loop[color_layer] = [sm_ao, sm_ao, sm_ao, 1]  # rgb + a
        bm.to_mesh(me)
        bm.free()  # free and prevent further access
        obj.data.update()
        return {"FINISHED"}

    def raycast_objs(self, ray_orig, ray_dir):
        # loc, norm, idx, dist, + (active_obj)
        rayc = self.bvh.ray_cast(ray_orig, ray_dir)
        if not rayc[0] and self.other_bvh:  # test other selected objs
            for sel_obj_bvj in self.other_bvh:
                rayc = sel_obj_bvj.ray_cast(ray_orig, ray_dir)
                if rayc[0]:
                    return rayc + (False,)
        return rayc + (True,)  # loc, norm, idx, dist, active_obj?

    def simple_sample(self, center, normal):
        component_A = normal.cross(normal.yxz).normalized() if normal.yxz != normal else normal.cross(normal.zyx).normalized()
        component_B = normal.cross(component_A).normalized()
        above_offset = center+self.offset * normal
        below_offset = center-self.offset * normal
        assert abs(normal.cross(component_A).dot(normal)) < 0.001
        casts = []
        if self.side != 'BACK': #so in case of both or front
            casts.append(self.raycast_objs(above_offset, normal))
            casts.append(self.raycast_objs(above_offset, 2*normal + component_A))
            casts.append(self.raycast_objs(above_offset, 2*normal - component_A))
            casts.append(self.raycast_objs(above_offset, 2*normal + component_B))
            casts.append(self.raycast_objs(above_offset, 2*normal - component_B))

            casts.append(self.raycast_objs(above_offset, normal + component_A + component_B))
            casts.append(self.raycast_objs(above_offset, normal + component_A - component_B))
            casts.append(self.raycast_objs(above_offset, normal - component_A + component_B))
            casts.append(self.raycast_objs(above_offset, normal - component_A - component_B))
        if self.side != 'FRONT':
            casts.append(self.raycast_objs(below_offset, -1*normal))
            casts.append(self.raycast_objs(below_offset, -2*normal + component_A))
            casts.append(self.raycast_objs(below_offset, -2*normal - component_A))
            casts.append(self.raycast_objs(below_offset, -2*normal + component_B))
            casts.append(self.raycast_objs(below_offset, -2*normal - component_B))

            casts.append(self.raycast_objs(below_offset, -1*normal + component_A + component_B))
            casts.append(self.raycast_objs(below_offset, -1*normal + component_A - component_B))
            casts.append(self.raycast_objs(below_offset, -1*normal - component_A + component_B))
            casts.append(self.raycast_objs(below_offset, -1*normal - component_A - component_B))
        return casts  # loc, norm, idx, dist, active_obj?


def get_linked_faces(f):
    link_faces = [f]
    f.tag = True
    new_faces = [f]
    while True:
        new_edges = [e for new_face in new_faces for e in new_face.edges if len(e.link_faces) == 2]
        new_faces = []
        for e in new_edges:
            for f in e.link_faces:
                if not f.tag:
                    new_faces.append(f)
                    f.tag = True
        if not new_faces:
            break #break while
        else:
            link_faces.extend(new_faces)
    return link_faces


def get_face_islands(bm):
    next_face = bm.faces[0]
    islands = []
    face_count = len(bm.faces)
    scanned_faces_count = 0
    while True:
        islands.append(get_linked_faces(next_face))
        scanned_faces_count += len(islands[-1])
        if scanned_faces_count >= face_count:
            break
        non_tag_faces = [f for f in bm.faces if not f.tag]
        if not non_tag_faces:
            break
        else:
            next_face = non_tag_faces[0]
    return islands


class HTOOL_OT_UVSampling(bpy.types.Operator):
    bl_idname = "object.uv_sample_from_target"
    bl_label = "Sample UV from target"
    bl_description = "Sample UV from target object and creates new UV channel; sampled in place of each hair card root position"
    bl_options = {"REGISTER", "UNDO"}

    method: bpy.props.EnumProperty(name='Sampling Method', description='Use hair card root Center or Profile vertices for picking UVs',
        items=[
            ('CENTER', 'Root center', 'Less detailed but works great on target mesh seams'),
            ('PROFILE', 'Root Profile', 'More detailed, but may give ugly artefeacts on seams')
        ],  default='CENTER')

    collapse_threshold: bpy.props.FloatProperty(name='Collapse threshold', description='Colapse hair card UV if picked UV size is too big. Should help fix very long UVs picked across target object seams', default = 0.1, min=0, max=1)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, 'method')
        if self.method == 'PROFILE':
            layout.prop(self, 'collapse_threshold')

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'MESH'

    @staticmethod
    def get_face_3d_to_uv(face, co, uv_lay):
        '''Get uv position corresponding to 3d loc co, on face, using uv '''
        face3d_barycentric_w = poly_3d_calc([v.co for v in face.verts], co)  # get barycentric weights
        # faceUV_barycentric_w = poly_3d_calc([loop[uv_lay].uv for loop in face.loops], co)  # get barycentric weights
        # for face in bm.faces:
        avg_uv_co = Vector((0, 0))
        for bary_weigth, loop in zip(face3d_barycentric_w, face.loops):
            uv = loop[uv_lay].uv
            avg_uv_co += uv * bary_weigth
        # for i, vert in enumerate(face.verts):
        #     avg_weight += vert[w_lay][source_id] * face3d_barycentric_w[i] if source_id in vert[w_lay].keys() else 0
        return avg_uv_co

    def execute(self, context):
        mesh_ribbons = context.active_object
        if not mesh_ribbons.ht_props.target_obj:
            self.report({'ERROR'}, f'No target object specified. Cancelling')
            return {'CANCELLED'}

        target = bpy.data.objects[mesh_ribbons.ht_props.target_obj]
        target_mwi = target.matrix_world.inverted()

        target_BVHT = get_obj_mesh_bvht(target, context.evaluated_depsgraph_get(), applyModifiers=False, world_space=True)

        ribbon_bm = bmesh.new()   # create an empty BMesh
        ribbon_bm.from_mesh(mesh_ribbons.data)   # fill it in from a Mesh
        target_bm = bmesh.new()   # create an empty BMesh
        target_bm.from_mesh(target.data)   # fill it in from a Mesh

        target_bm.faces.ensure_lookup_table()
        ribbon_bm.faces.ensure_lookup_table()

        target_uv = target_bm.loops.layers.uv[0]
        hair_square_uv = ribbon_bm.loops.layers.uv['HairTool_UV']
        picked_uv_name = target.name+ '_picked_uv'
        if picked_uv_name in ribbon_bm.loops.layers.uv.keys():
            projected_uv = ribbon_bm.loops.layers.uv[picked_uv_name]
        else:
            projected_uv = ribbon_bm.loops.layers.uv.new(picked_uv_name)

        ribbon_bm.faces.ensure_lookup_table()
        ribbon_bm.verts.ensure_lookup_table()
        faces_lislands = get_face_islands(ribbon_bm)

        if self.method == 'CENTER': #collapse uv in root center
            for facesIsland in faces_lislands:  # face islands list
                root_verts_cnt = 0
                root_co = Vector((0, 0, 0))
                for face in facesIsland:  # island faces
                    for loop in face.loops:
                        uv = loop[hair_square_uv].uv
                        if uv.y < 0.01:
                            root_co += loop.vert.co
                            root_verts_cnt += 1
                if root_verts_cnt == 0:
                    print('Can detect root position for one of hair cards')
                    continue
                root_co /= root_verts_cnt

                hit_co, normal, f_id, distance = target_BVHT.find_nearest(mesh_ribbons.matrix_world@root_co)
                # print(hit_co)
                hit_uv = self.get_face_3d_to_uv(target_bm.faces[f_id], target_mwi@hit_co, target_uv)
                # print(hit_uv)

                for face in facesIsland:  # island faces
                    for loop in face.loops:
                        loop[projected_uv].uv = hit_uv[:]
        else:
            for facesIsland in faces_lislands:  # get root verts, and avg_root_co (vert at very bottom of uv)
                root_verts = []
                avg_root_co = Vector((0, 0, 0))
                for face in facesIsland:  # island faces
                    for loop in face.loops:
                        uv = loop[hair_square_uv].uv
                        if uv.y < 0.002:
                            avg_root_co += loop.vert.co
                            root_verts.append(loop.vert)
                rv_cnt_with_dupli = len(root_verts)
                avg_root_co = avg_root_co / rv_cnt_with_dupli


                picked_uvs = [] #* store  each root picked UV
                for root_vert in root_verts:
                    hit_co, normal, f_id, distance = target_BVHT.find_nearest(mesh_ribbons.matrix_world @ root_vert.co)
                    hit_uv = self.get_face_3d_to_uv(target_bm.faces[f_id], target_mwi@hit_co, target_uv)
                    picked_uvs.append(hit_uv)

                center_hit_uv = self.get_face_3d_to_uv(target_bm.faces[f_id], target_mwi@avg_root_co, target_uv) #avg root picked uv

                #* check uv are not too big, if so use center_hit_uv
                for i, p_uv in enumerate(picked_uvs):
                    if (p_uv-center_hit_uv).length > self.collapse_threshold:
                        picked_uvs[i] = center_hit_uv # collapse partially uv = True

                #* write UV for each hair card / island
                root_vert_cnt = int(rv_cnt_with_dupli/2) + 1
                island_vert_count = root_vert_cnt * (int(len(facesIsland)/(root_vert_cnt-1)) + 1)

                for root_vert, picked_uv in zip(root_verts, picked_uvs):
                    current_vert = root_vert
                    max_idx = root_vert.index + island_vert_count - root_vert_cnt  # max availale vert id for current island
                    #* go along root loop up
                    while True: #this will work only if generated mesh ribbons topology was not changed (vert ids sort order important)
                        for loop in current_vert.link_loops:
                            loop[projected_uv].uv = picked_uv[:]
                        next_idx = current_vert.index + root_vert_cnt
                        if next_idx <= max_idx:  # vert out of island
                            current_vert = ribbon_bm.verts[next_idx]
                        else:
                            break


        ribbon_bm.to_mesh(mesh_ribbons.data)
        ribbon_bm.free()  # free and prevent further access
        self.report({'INFO'}, f'New uv channel \'projected_uv\' generated successfully')
        mesh_ribbons.ht_props.used_uv_pick = True  # just helper on convert
        return {"FINISHED"}




class HTOOL_OT_WeightSampling(bpy.types.Operator):
    bl_idname = "object.weight_sample_from_target"
    bl_label = "Sample Weights from target"
    bl_description = "Sample vertex weights from target object; sampled in place of each hair card root position"
    bl_options = {"REGISTER", "UNDO"}

    method: bpy.props.EnumProperty(name='Sampling Method', description='Use hair card root Center or Profile vertices for picking UVs',
                                   items=[
                                       ('CENTER', 'Root center', 'Pick weights using strand root center'),
                                       ('PROFILE', 'Root Profile', 'More detailed weights sampling, but may give ugly artefeacts on seams')
                                   ],  default='CENTER')

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'MESH'

    @staticmethod
    def get_avg_weight_all(face, w_lay, co):
        # this will be output groups ids
        face_barycentric_w = poly_3d_calc([v.co for v in face.verts], co)  # get barycentric weights

        face_groups_li = {g for vert in face.verts for g in vert[w_lay].keys()}
        avg_weight = {g_idx: 0 for g_idx in face_groups_li}

        for i, vert in enumerate(face.verts):
            for g_idx in face_groups_li:
                avg_weight[g_idx] += vert[w_lay][g_idx] * face_barycentric_w[i] if g_idx in vert[w_lay].keys() else 0
        return avg_weight

    @staticmethod
    def get_face_3d_to_uv(face, co, uv_lay):
        '''Get uv position corresponding to 3d loc co, on face, using uv '''
        face3d_barycentric_w = poly_3d_calc([v.co for v in face.verts], co)  # get barycentric weights
        # faceUV_barycentric_w = poly_3d_calc([loop[uv_lay].uv for loop in face.loops], co)  # get barycentric weights
        # for face in bm.faces:
        avg_uv_co = Vector((0, 0))
        for bary_weigth, loop in zip(face3d_barycentric_w, face.loops):
            uv = loop[uv_lay].uv
            avg_uv_co += uv * bary_weigth
        # for i, vert in enumerate(face.verts):
        #     avg_weight += vert[w_lay][source_id] * face3d_barycentric_w[i] if source_id in vert[w_lay].keys() else 0
        return avg_uv_co

    def execute(self, context):
        mesh_ribbons = context.active_object
        if not mesh_ribbons.ht_props.target_obj:
            self.report({'ERROR'}, f'No target object specified. Cancelling')
            return {'CANCELLED'}

        target = bpy.data.objects[mesh_ribbons.ht_props.target_obj]
        target_mwi = target.matrix_world.inverted()

        #* create vgroups first, and map target vg ids, to new vgroup ids
        target_to_new_vg_id = {}
        for t_vg in target.vertex_groups:
            mesh_rib_vg = mesh_ribbons.vertex_groups.get(t_vg.name)
            if not mesh_rib_vg:
                mesh_rib_vg = mesh_ribbons.vertex_groups.new(name=t_vg.name)  # changes active idx
            target_to_new_vg_id[t_vg.index] = mesh_rib_vg.index  # map

        mesh_ribbons.data.update()

        target_BVHT = get_obj_mesh_bvht(target, context.evaluated_depsgraph_get(), applyModifiers=False, world_space=True)

        ribbon_bm = bmesh.new()   # create an empty BMesh
        ribbon_bm.from_mesh(mesh_ribbons.data)   # fill it in from a Mesh
        ribbon_bm.faces.ensure_lookup_table()
        ribbon_bm.verts.ensure_lookup_table()

        target_bm = bmesh.new()   # create an empty BMesh
        target_bm.from_mesh(target.data)   # fill it in from a Mesh
        target_bm.faces.ensure_lookup_table()
        target_bm.verts.ensure_lookup_table()

        w_lay_trg = target_bm.verts.layers.deform.active  # vertex groups
        w_lay_ribb = ribbon_bm.verts.layers.deform.verify()  # create or retur existin one layer
        #* vert[w_lay] is dict - group.ids: g.weights

        hair_square_uv = ribbon_bm.loops.layers.uv['HairTool_UV']  #for getting hair root uvs (thye are top in UV)
        faces_lislands = get_face_islands(ribbon_bm)
        #* vert[w_lay] is dict - group.ids: g.weights

        if self.method == 'CENTER':  # collapse uv in root center
            for facesIsland in faces_lislands:  # face islands list

                #* find center of hair root from its helpepr uv
                root_verts_cnt = 0
                root_co = Vector((0, 0, 0))
                for face in facesIsland:  # island faces
                    for loop in face.loops:
                        uv = loop[hair_square_uv].uv
                        if uv.y < 0.01:
                            root_co += loop.vert.co
                            root_verts_cnt += 1
                if root_verts_cnt == 0:
                    # print('Can detect root position for one of hair cards')
                    continue
                root_co /= root_verts_cnt

                hit_co, normal, f_id, distance = target_BVHT.find_nearest(mesh_ribbons.matrix_world@root_co) #? maybe times target.mwi ?
                avg_weight_all = self.get_avg_weight_all(target_bm.faces[f_id], w_lay_trg, target_mwi@hit_co)

                for face in facesIsland:
                    for vert in face.verts:
                        vert[w_lay_ribb].clear()
                        for g_id, weight in avg_weight_all.items():
                            ribbon_vg_id = target_to_new_vg_id[g_id]
                            vert[w_lay_ribb][ribbon_vg_id] = weight

        else:
            for facesIsland in faces_lislands:  # get root verts, and avg_root_co (vert at very bottom of uv)
                root_verts = []
                avg_root_co = Vector((0, 0, 0))
                for face in facesIsland:  # island faces
                    for loop in face.loops:
                        uv = loop[hair_square_uv].uv
                        if uv.y < 0.002:
                            avg_root_co += loop.vert.co
                            root_verts.append(loop.vert)
                rv_cnt_with_dupli = len(root_verts)
                avg_root_co = avg_root_co / rv_cnt_with_dupli

                picked_weights = []  # * store  each root picked UV
                for root_vert in root_verts:
                    hit_co, normal, f_id, distance = target_BVHT.find_nearest(mesh_ribbons.matrix_world@root_vert.co)  # ? maybe times target.mwi ?
                    avg_weight_all = self.get_avg_weight_all(target_bm.faces[f_id], w_lay_trg, target_mwi@hit_co)
                    picked_weights.append(avg_weight_all)

                #* write UV for each hair card / island
                root_vert_cnt = int(rv_cnt_with_dupli/2) + 1
                island_vert_count = root_vert_cnt * (int(len(facesIsland)/(root_vert_cnt-1)) + 1)

                for root_vert, picked_weight in zip(root_verts, picked_weights):
                    current_vert = root_vert
                    max_idx = root_vert.index + island_vert_count - root_vert_cnt  # max availale vert id for current island
                    #* go along root loop up
                    while True:  # this will work only if generated mesh ribbons topology was not changed (vert ids sort order important)
                        current_vert[w_lay_ribb].clear()
                        for g_id, weight in picked_weight.items():
                            ribbon_vg_id = target_to_new_vg_id[g_id]
                            current_vert[w_lay_ribb][ribbon_vg_id] = weight

                        next_idx = current_vert.index + root_vert_cnt
                        if next_idx <= max_idx:  # vert out of island
                            current_vert = ribbon_bm.verts[next_idx]
                        else:
                            break

        ribbon_bm.to_mesh(mesh_ribbons.data)
        ribbon_bm.free()  # free and prevent further access
        target_bm.free()  # free and prevent further access
        self.report({'INFO'}, f'Vertex group picked successfully')
        mesh_ribbons.ht_props.used_weight_pick = True  # just helper on convert
        return {"FINISHED"}
