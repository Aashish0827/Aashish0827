# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
# Copyright (C) 2017 JOSECONSCO
# Created by JOSECONSCO

import bisect
import numpy as np
from mathutils import Vector, Quaternion
from math import ceil, floor
from .utils.helper_functions import resample_linear
from functools import cache
# import math
# p1 = math.floor(t)
# p2 = (p1 + 1)
# p3 = (p2 + 1) if p2 < len(points)-1 else len(points)-1
# p0 = p1 - 1 if p1 >= 1 else 0

# t = t - math.floor(t)
# tt = t * t
# ttt = tt * t

# q1 = -ttt + 2.0*tt - t
# q2 = 3.0*ttt - 5.0*tt + 2.0
# q3 = -3.0*ttt + 4.0*tt + t
# q4 = ttt - tt

# OutVec = 0.5 * (points[p0] * q1 + points[p1] * q2 + points[p2] * q3 + points[p3] * q4)
#resampled_points = [b_spline_point_orig(points, i * (len(points) - 1.00001)/(res-1)) for i in range(res)]

SPLINE_CACHE = {}

# @cache
def do_cache_coefficients(points_count, res, tn_fallof=None):
    spline_coeff = {}
    t_map_full_rage = (points_count - 1.001) / (res - 1)  # t is from 0-1, for while curve
    # .001 - cos if we reach res*t_multiplier - ten last point is on end of spline - and p[-1].co = 0,0,0
    t_ins = np.linspace(0, (res-1)*t_map_full_rage, res) if tn_fallof is None else tn_fallof*(res-1)*t_map_full_rage
    for i, t_in in enumerate(t_ins):
        spline_coeff[i] = {}
        # t_in = i * t_multiplier
        t = t_in - floor(t_in)
        tt = t * t
        ttt = tt * t
        spline_coeff[i]['q1'] = -ttt + 2.0*tt - t
        spline_coeff[i]['q2'] = 3.0*ttt - 5.0*tt + 2.0
        spline_coeff[i]['q3'] = -3.0*ttt + 4.0*tt + t
        spline_coeff[i]['q4'] = ttt - tt
    return spline_coeff


def get_cubic_spline_points(points, res,  uniform_spacing, noiseStrandSeparation, shrink_ts=1, use_cache=True, tn_fallof=None):
    """
    Args:
        :verts -2d list of multiple strands (vec1, vec2, vec... n):
        :res  number of points after resampling :
        :uniform_spacing if spacing of points is uniform or not. Is not then can use cache and is faster:
        :noiseStrandSeparation=0 - rendomize tn +/- delta:
        :same_point_count=True if false, shorter strands = less points (smaller res):
        :shortenStrandLen=0.0 - reduce eval T_max by  *=shrink_t:

    Returns:
        :Vec list - spline points resampled
    """
    # from cProfile import Profile
    # from pstats import Stats
    # prof = Profile()
    # prof.enable()

    points_len = len(points)
    resampled_points = []
    if use_cache:
        # print('Using cache')
        global SPLINE_CACHE
        t_map_full_rage = (points_len - 1.01)/(res-1)  # t is from 0-1, for while curve
        t_ins = np.linspace(0, (res-1)*t_map_full_rage, res) if tn_fallof is None else tn_fallof*(res-1)*t_map_full_rage
        for i, t in enumerate(t_ins):  # i - is time t = i * t_map_full_rage, from <0,1> mapped to <0, point_count/res * res>
            # t = i * t_map_full_rage
            p1 = floor(t)
            p2 = (p1 + 1)
            p3 = min(p2 + 1, points_len-1)
            p0 = max(p1 - 1,  0)
            out_pos = points[p0] * SPLINE_CACHE[i]['q1'] + points[p1] * SPLINE_CACHE[i]['q2'] + \
                points[p2] * SPLINE_CACHE[i]['q3'] + points[p3] * SPLINE_CACHE[i]['q4']
            resampled_points.append(0.5 * out_pos)
        return resampled_points
    else:
        # print('Not using cache')
        #for uniform point distribution t_i has to be modified by strand points legths
        # adjust time spacing based on points distances etc
        t_s_adjusted = get_adjusted_t_s(points, res, uniform_spacing, noiseStrandSeparation, shrink_ts, tn_fallof)
        for t in t_s_adjusted:  # i - is time t = i * t_map_full_rage, from <0,1> mapped to <0, point_count/res * res>
            p1 = floor(t)
            p2 = (p1 + 1)
            p3 = min(p2 + 1, points_len-1)
            p0 = max(p1 - 1,  0)
            t = t - p1
            tt = t * t
            ttt = tt * t
            q1 = -ttt + 2.0*tt - t
            q2 = 3.0*ttt - 5.0*tt + 2.0
            q3 = -3.0*ttt + 4.0*tt + t
            q4 = ttt - tt
            out_pos = points[p0] * q1 + points[p1] * q2 + points[p2] * q3 + points[p3] * q4
            resampled_points.append(0.5 * out_pos)

        # prof.disable()  # don't profile the generation of stats
        # prof.dump_stats('curve_from_grid.stats')
        # with open('get_cubic_pts_output.txt', 'wt') as output:
        #     stats = Stats('curve_from_grid.stats', stream=output)
        #     stats.sort_stats('cumulative', 'time')
        #     stats.print_stats()
        return resampled_points



def get_strand_proportions(strandsList):  # return array <0,1> - where 1 is for longest strand
    lengthPerStrand = []
    for v in strandsList:
        pts = np.array(v).T
        tmp = np.apply_along_axis(np.linalg.norm, 0, pts[:, :-1] - pts[:, 1:])  # do an - an-1 and get length
        t = tmp.sum()  # len of strand
        lengthPerStrand.append(t)  # len*numb of spliness / number of splines
    strand_len_normalized = np.array(lengthPerStrand)/max(lengthPerStrand)
    return strand_len_normalized.tolist()
    #Below wont work is splines have different points counts... but if lens are eq, then works ok
    # pts = np.array(strandsList)
    # tmp = np.apply_along_axis(np.linalg.norm, 1, pts[:, :-1] - pts[:, 1:]) #sum lens of strans
    # len_sum = tmp.sum(1) #sum x,y,z into strand len lists
    # return list(len_sum/max(len_sum))


def get_adjusted_t_s(strand, res, uniform_spacing, noiseStrandSeparation=None, shrink_ts=1, tn_fallof = None):  # return array <0,1> - where 1 is for longest strand
    '''
        Args:
            tn_fallof  - corr_t_ins * tn_fallof (usually fallof, to increase hair density at tips - should be <0, 1> )
    '''
    points_count = len(strand)
    t_in = np.linspace(0, 1, res) if tn_fallof is None else tn_fallof
    corr_t_ins = t_in
    if uniform_spacing: #adjust uniform spaced t (non xyz uniform), by segments legnths - makes points evennly distributed in Euclidean space
        domain = [i/(points_count-1) for i in range(points_count)]
        pts = np.array(strand)
        seg_lens = np.apply_along_axis(np.linalg.norm, 1, pts[:-1, :]-pts[1:, :])  # do an - an-1 and get length
        t_spat = np.insert(seg_lens, 0, 0).cumsum()  # add zero and sum
        #t will be now proportional to segments distances - bigger point spacing - more time.
        t_spat = t_spat/t_spat[-1]
        corr_t_ins = np.interp(t_in,  t_spat, domain)
    if type(noiseStrandSeparation) is np.ndarray:
        corr_t_ins = corr_t_ins+noiseStrandSeparation/res
        np.clip(corr_t_ins, 0, 1, out=corr_t_ins)  # cos t_spat in (0,1)

    return list(corr_t_ins * (points_count - 1.01) * shrink_ts)  # remap from <0,1> to <0, point_count-1>


def interpol_Catmull_Rom_splines(verts, res, uniform_spacing=False, noiseStrandSeparation=0, same_point_count=True, shortenStrandLen=0, seed=2, tn_fallof=None, len_seed = -1):
    """ Catmull_Rom - spline interpolation (cubic)
    Args:
        :verts -2d list of multiple strands (vec1, vec2, vec... n):
        :res  number of points after resampling :
        :uniform_spacing if spacing of points is uniform or not. Is not then can use cache and is faster:
        :noiseStrandSeparation=0 - rendomize tn +/- delta:
        :same_point_count=True if false, shorter strands = less points (smaller res):
        :shortenStrandLen=0.0 - reduce eval T_max by  *=shrink_t:
        :tn_fallof=0.0 - adjust spline evaluated time by using custom t_n's
    """
    # res -= 1 #res before -1 == number of segments on generated spline. pts_count = seg_count - 1
    strands_count = len(verts)
    use_cache = not(uniform_spacing or noiseStrandSeparation or not same_point_count or shortenStrandLen)  # we need to calc point spacing so can't use chache
    if use_cache:
        len_first = len(verts[0])
        if not all(len(strand) == len_first for strand in verts): #if strands are not equal lengths disable caching
            # print('Not all strands have same point count. Disabling cache')
            use_cache = False
    if use_cache:
        global SPLINE_CACHE
        SPLINE_CACHE.clear()
        SPLINE_CACHE = do_cache_coefficients(len(verts[0]), res, tn_fallof)  # assume they are eq. len
    # print('Using cache') if use_cache else print('no cache')

    #shorte stran leg by reducing evel time
    lseed = seed if len_seed < 0 else len_seed
    np.random.seed(lseed)
    shrink_ts = list(1.0 - np.random.uniform(0, shortenStrandLen/2, strands_count)) if shortenStrandLen else [1]*strands_count
    np.random.seed(seed)
    res_normalized = [res]*strands_count
    tn_fallofs = None
    if not same_point_count:
        NormalizedStrandsLength = get_strand_proportions(np.array(verts))
        res_normalized = [max(ceil((res) * strandLen), 2) for strandLen in NormalizedStrandsLength]
        if tn_fallof is not None:
            t_in = np.linspace(0, 1, len(tn_fallof))
            tn_fallofs = [] #fill tn_fallofs for each spline len()
            for res in res_normalized:
                t_out_res = np.linspace(0, 1, res)
                tn_fallofs.append(np.interp(t_out_res, t_in, tn_fallof))

    if noiseStrandSeparation:
        # deltaMargin = (verts[0][1]-verts[0][0]).length  # AN-A(N-1) use distance between first pts on two neighbors
        noiseStrandSeparation = (2*np.random.rand(res) - 1.0)*noiseStrandSeparation  # *deltaMargin
    if tn_fallofs is not None: #if we want to adjust times (eg. more toward tip/root)
        return [get_cubic_spline_points(splinex, res_n, uniform_spacing, noiseStrandSeparation, t_shrink, use_cache, tn_fall) for splinex, t_shrink, res_n, tn_fall in zip(verts, shrink_ts, res_normalized, tn_fallofs)]
    else:  # tn_fallof arg may be none or single list
        return [get_cubic_spline_points(splinex, res_n, uniform_spacing, noiseStrandSeparation, t_shrink, use_cache, tn_fallof) for splinex, t_shrink, res_n in zip(verts, shrink_ts, res_normalized)]


def get_cubic_spline_points_simple(points, res,  uniform_spacing = True, custom_fallof = None):
    """
    Args:
        :verts -1d list strand (vec1, vec2, vec... n):
        :res  number of points after resampling
        :uniform_spacing if spacing of points is uniform or not. Is not then can use cache and is faster:

    Returns:
        :Vec list - spline points resampled
    """
    # res -= 1  # res before -1 == number of segments on generated spline. pts_count = seg_count - 1
    points_len = len(points)
    resampled_points = []

    #for uniform point distribution t_i has to be modified by strand points legths
    # adjust time spacing based on points distances etc
    t_s_adjusted = get_adjusted_t_s(points, res, uniform_spacing, tn_fallof = custom_fallof)
    for t in t_s_adjusted:  # i - is time t = i * t_map_full_rage, from <0,1> mapped to <0, (point_count/res) * res>
        p1 = floor(t)
        p2 = (p1 + 1)
        p3 = min(p2 + 1, points_len-1)
        p0 = max(p1 - 1,  0)
        t = t - p1
        tt = t * t
        ttt = tt * t
        q1 = -ttt + 2.0*tt - t
        q2 = 3.0*ttt - 5.0*tt + 2.0
        q3 = -3.0*ttt + 4.0*tt + t
        q4 = ttt - tt
        out_pos = points[p0] * q1 + points[p1] * q2 + points[p2] * q3 + points[p3] * q4
        resampled_points.append(0.5 * out_pos)
    return resampled_points


def get2dinterpol_Catmull_Rom(verts, spl_count_normalized, pts_count_normalized, shortenStrandLen, Seed, uniform_strands, uniform_points, noiseStrandSeparation, tn_fallof=None, len_seed = 1):
    spl_count_neg_one = True if spl_count_normalized == -1 else False
    if spl_count_neg_one:  # do 3 splines but we will use middle one as output
        spl_count_normalized = 3
    x = interpol_Catmull_Rom_splines(verts, spl_count_normalized, uniform_strands, noiseStrandSeparation=noiseStrandSeparation, seed=Seed)
    stramds_firstRow, *strands_afterFirst = x #splits x into x[0] + x[1:]
    strands_afterFirst_Transposed = list(zip(*strands_afterFirst))  # transpose
    x2 = interpol_Catmull_Rom_splines(strands_afterFirst_Transposed, pts_count_normalized - 1, uniform_points, shortenStrandLen=shortenStrandLen, seed=Seed, tn_fallof=tn_fallof, len_seed=len_seed)
    [x2_element.insert(0, first) for x2_element, first in zip(x2,stramds_firstRow)] #add back first row

    #there will be 3 output strands if spl_count_neg_one - use middle one
    return [x2[1]] if spl_count_neg_one else x2


def rotationMatrix(theta, axis):
    """
    Return the rotation matrix associated with counterclockwise rotation about
    the given axis by theta radians.
    """
    quat_rot = Quaternion(axis, theta)
    return np.array(quat_rot.to_matrix())


def parallel_transport_TNB(points):
    '''Get (Tangents,Normals) lists from points (Vector) list (slower than build in hack for alignign :( '''
    # Number of points
    n = len(points)
    points = np.array([point.xyz for point in points], 'f')
    # Calculate all tangents
    T = np.apply_along_axis(np.gradient, axis=0, arr=points)

    # Normalize all tangents normalized
    def f(m): return m / np.linalg.norm(m)
    T = np.apply_along_axis(f, axis=1, arr=T)

    # Initialize the first parallel-transported normal vector V
    B = np.zeros(np.shape(points))
    B[0] = (T[0][1], -T[0][0], 0)
    B[0] = B[0] / np.linalg.norm(B[0])

    # Compute the values for B for each tangential vector from T
    for i in range(n - 1):
        b = np.cross(T[i], T[i + 1])
        if np.linalg.norm(b) < 0.00001:
            B[i + 1] = B[i]
        else:
            b = b / np.linalg.norm(b)
            phi = np.arccos(np.dot(T[i], T[i + 1]))
            R = rotationMatrix(phi, b)
            B[i + 1] = np.dot(R, B[i])

    # Calculate the second parallel-transported normal vector U
    N = np.array([np.cross(t, v) for (t, v) in zip(T, B)], 'f')

    # Normalize all tangents
    return (T,N,B)

