# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
# Copyright (C) 2017 JOSECONSCO
# Created by JOSECONSCO

import bpy
from bpy.props import BoolProperty, FloatProperty, IntProperty
from .utils.general_utils import unlink_from_scene

# def generate_profile(hairCurve, profile_type, strandResU=None, strandResV=None, strandWidth=None, strandPeak=None, strandUplift=None, write_profile_props=True):
def generate_profile(hairCurve, profile_type, strandResU=2, strandResV=1, strandWidth=0.5, strandPeak=0.3, strandUplift=0.0, write_profile_props=True):
    stored_props = hairCurve.ht_props.profile_props
    if 'diagonal' in hairCurve.keys():  # backup diagonal in obj props
        diagonal_local = hairCurve['diagonal']
    else:
        diagonal_local = hairCurve.dimensions.length/hairCurve.matrix_world.to_scale().length  # world space * scale.inv  -> to local sp
        diagonal_local = -1.1 if diagonal_local < 0.001 else diagonal_local
        hairCurve['diagonal'] = diagonal_local

    hairCurve.data.bevel_mode = profile_type
    hairCurve.data.resolution_u = strandResU
    if profile_type in {'ROUND', 'PROFILE'}:
        hairCurve.data.bevel_depth = strandWidth  * diagonal_local / 10
        hairCurve.data.bevel_resolution = strandResV
        if write_profile_props:
            stored_props['strandWidth'] = strandWidth
            stored_props['strandResV'] = strandResV
            stored_props['strandResU'] = strandResU

    elif profile_type == 'OBJECT':
        strand_width = strandWidth * diagonal_local / 10
        pointsCo = []
        for i in range(strandResV + 2):
            x = 2 * i / (strandResV+1) - 1  # normalise and map from -1 to 1
            pointsCo.append((x * strand_width, ((1 - x * x) * strandPeak + strandUplift) * strand_width, 0))
        if hairCurve.data.bevel_object:
            curveBevelObj = hairCurve.data.bevel_object
            curveBevelObj.data.splines.clear()
            BevelCurveData = curveBevelObj.data
        else:
            BevelCurveData = bpy.data.curves.new('hairBevelCurve', type='CURVE')  # new CurveData
            BevelCurveData.dimensions = '2D'
            curveBevelObj = bpy.data.objects.new('bevelCurve', BevelCurveData)  # new object
            hairCurve.data.bevel_object = curveBevelObj
        bevelSpline = BevelCurveData.splines.new('POLY')  # new spline
        bevelSpline.points.add(len(pointsCo) - 1)
        for i, coord in enumerate(pointsCo):
            x, y, z = coord
            bevelSpline.points[i].co = (x, y, z, 1)
        curveBevelObj.use_fake_user = True
        hairCurve.data.use_auto_texspace = True
        # hairCurve.data.show_normal_face = False
        if write_profile_props:
            stored_props['strandResU'] = strandResU
            stored_props['strandResV'] = strandResV
            stored_props['strandWidth'] = strandWidth
            stored_props['strandPeak'] = strandPeak
            stored_props['strandUplift'] = strandUplift
        hairCurve.update_from_editmode()


def update_profile(hairCurve, strandResU=None, strandResV=None, strandWidth=None, strandPeak=None, strandUplift=None, write_profile_props=True):
    stored_props = hairCurve.ht_props.profile_props
    # strandWidth = stored_props['strandWidth'] if not strandWidth else strandWidth
    if 'diagonal' in hairCurve.keys():  # backup diagonal in obj props
        diagonal_local = hairCurve['diagonal']
    else:
        diagonal_local = hairCurve.dimensions.length/hairCurve.matrix_world.to_scale().length  # world space * scale.inv  -> to local sp
        diagonal_local = 0.1 if diagonal_local < 0.001 else diagonal_local
        hairCurve['diagonal'] = diagonal_local

    if strandResU:
        hairCurve.data.resolution_u = strandResU
    else:
        strandResU = hairCurve.data.resolution_u

    if hairCurve.data.bevel_mode in {'ROUND', 'PROFILE'}:
        hairCurve.data.bevel_depth = strandWidth  * diagonal_local / 10
        if strandResV is None:
            strandResV = hairCurve.data.bevel_resolution
        else:
            hairCurve.data.bevel_resolution = strandResV
        if write_profile_props:
            stored_props['strandResU'] = strandResU
            stored_props['strandWidth'] = strandWidth
            stored_props['strandResV'] = strandResV
    else:
        strandResV = stored_props['strandResV'] if strandResV is None else strandResV
        strandPeak = stored_props['strandPeak'] if strandPeak is None else strandPeak
        strandUplift = stored_props['strandUplift'] if strandUplift is None else strandUplift

        strand_width = strandWidth * diagonal_local / 10
        pointsCo = []
        for i in range(strandResV + 2):
            x = 2 * i / (strandResV+1) - 1  # normalise and map from -1 to 1
            pointsCo.append((x * strand_width, ((1 - x * x) * strandPeak + strandUplift) * strand_width, 0))
        if hairCurve.data.bevel_object:
            curveBevelObj = hairCurve.data.bevel_object
            curveBevelObj.data.splines.clear()
            BevelCurveData = curveBevelObj.data
        else:
            BevelCurveData = bpy.data.curves.new('hairBevelCurve', type='CURVE')  # new CurveData
            BevelCurveData.dimensions = '2D'
            curveBevelObj = bpy.data.objects.new('bevelCurve', BevelCurveData)  # new object
            hairCurve.data.bevel_object = curveBevelObj
        bevelSpline = BevelCurveData.splines.new('POLY')  # new spline
        bevelSpline.points.add(len(pointsCo) - 1)
        for i, coord in enumerate(pointsCo):
            x, y, z = coord
            bevelSpline.points[i].co = (x, y, z, 1)
        curveBevelObj.use_fake_user = True
        hairCurve.data.use_auto_texspace = True


        # hairCurve.data.show_normal_face = False
        if write_profile_props:
            stored_props['strandResU'] = strandResU
            stored_props['strandResV'] = strandResV
            stored_props['strandWidth'] = strandWidth
            stored_props['strandPeak'] = strandPeak
            stored_props['strandUplift'] = strandUplift
        hairCurve.update_from_editmode()


def remove_unused_bevels():
    all_bevel_objs = [obj for obj in bpy.data.objects if obj.name.startswith('bevelCurve')]
    used_bevel_objs = [obj.data.bevel_object for obj in bpy.data.objects if obj.type == 'CURVE' and obj.data.bevel_object]
    for obj in all_bevel_objs:
        if obj not in used_bevel_objs:
            bpy.data.objects.remove(obj, do_unlink=True)

class HTOOL_OT_GenerateProfile(bpy.types.Operator):
    bl_label = "Add profile"
    bl_idname = "object.generate_profile"
    bl_options = {"REGISTER", "UNDO"}
    bl_description = "Add profile to curve"

    strandResU: IntProperty(name="Resolution along strand", default=3, min=1, max=5, description="Additional subdivisions along strand length")
    strandResV: IntProperty(name="Resolution of Profile", default=2, min=0, max=5, description="Profile Resolution")
    strandWidth: FloatProperty(name="Width", description="Strand width in relation to object size", default=0.5, min=0.0, soft_max=10)
    strandPeak: FloatProperty(name="Roundness", default=0.3, min=0.0, soft_max=1, description="Describes curvature of ribbon. 0 - gives flat ribbon")
    strandUplift: FloatProperty(name="Normal Offset", default=-0.2, min=-1, soft_max=1, description="Moves whole ribbon up or down")

    set_profile: bpy.props.EnumProperty(name='Profile', description='',
        items=[
            ('ROUND', 'Use Round', 'Curves will have cylindrical profile'),
            ('OBJECT', 'Use Flat', 'Curves will have flat (ribbon) profile'),
            ('PROFILE', 'Use Custom', 'Curves will have custom profile'),
            ('KEEP', 'Use Current', 'Do not change current curve profile')
        ], default='KEEP')

    write_profile_props: BoolProperty(name="Store profile", description="Write to profile props", default=True, options={'HIDDEN'}) # basically only for align tilt
    diagonal_local = None

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        hairCurve = context.active_object
        col.prop(self, 'set_profile')
        col.prop(self, 'strandWidth')
        col.prop(self, 'strandResV')
        col.prop(self, 'strandResU')
        if (self.set_profile == 'KEEP' and hairCurve.data.bevel_mode == 'OBJECT') or self.set_profile == 'OBJECT':
            col.prop(self, 'strandPeak')
            col.prop(self, 'strandUplift')
            # col.prop(self, 'alignToSurface')


    def invoke(self, context, event):
        remove_unused_bevels()
        bpy.ops.ed.undo_push()
        if context.active_object.type != 'CURVE':
            self.report({'INFO'}, 'Select curve object first')
            return {"CANCELLED"}
        hairCurve = context.active_object
        if not hairCurve.get('diagonal'):  # backup diagonal in obj props
            diagonal_local = hairCurve.dimensions.length/hairCurve.matrix_world.to_scale().length  # world space * scale.inv  -> to local sp
            hairCurve['diagonal'] = 0.1 if diagonal_local < 0.001 else diagonal_local

        self.strandResU = hairCurve.ht_props.profile_props.strandResU
        self.strandResV = hairCurve.ht_props.profile_props.strandResV
        self.strandWidth = hairCurve.ht_props.profile_props.strandWidth
        self.strandPeak = hairCurve.ht_props.profile_props.strandPeak
        self.strandUplift = hairCurve.ht_props.profile_props.strandUplift
        self.set_profile = 'KEEP'
        return self.execute(context)

    def execute(self, context):
        if self.set_profile == 'KEEP':
            update_profile(context.active_object, self.strandResU, self.strandResV, self.strandWidth, self.strandPeak, self.strandUplift, self.write_profile_props)
        else:
            generate_profile(context.active_object, self.set_profile, self.strandResU, self.strandResV, self.strandWidth, self.strandPeak, self.strandUplift, self.write_profile_props)

        return {"FINISHED"}


class HTOOL_OT_EditRibbonProfile(bpy.types.Operator):
    bl_label = "Manually Edit Profile"
    bl_idname = "object.ribbon_edit_profile"
    bl_description = "Edit curve Profile (link it to scene and put into edit mode)"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(self, context):  # make selection only false, if obj mode
        obj = context.active_object
        return obj and obj.type == 'CURVE' and obj.data.bevel_mode == 'OBJECT' and obj.data.bevel_object

    def invoke(self, context, event):
        remove_unused_bevels()
        return self.execute(context)

    def execute(self, context):
        Curve = context.active_object
        if not Curve.type == 'CURVE':
            self.report({'INFO'}, 'Use operator on curve type object')
            return {"CANCELLED"}
        bevelObj = bpy.context.object.data.bevel_object
        if bevelObj:
            if bevelObj.name not in context.scene.objects.keys():
                bpy.context.scene.collection.objects.link(bevelObj)
            bpy.ops.object.select_all(action='DESELECT')
            bpy.context.view_layer.objects.active = bevelObj
            bevelObj.select_set(True)
            bpy.ops.view3d.view_selected()
            bpy.ops.object.editmode_toggle()
            self.report({'INFO'}, 'Editing curve Profile was successful')
        return {"FINISHED"}


class HTOOL_OT_DuplicateRibbonProfile(bpy.types.Operator):
    bl_label = "Un-instance Profile"
    bl_idname = "object.ribbon_duplicate_profile"
    bl_description = "Un-instance curve Profile"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(self, context):  # make selection only false, if obj mode
        obj = context.active_object
        return obj and obj.type == 'CURVE' and obj.data.bevel_mode == 'OBJECT' and obj.data.bevel_object

    def invoke(self, context, event):
        remove_unused_bevels()
        return self.execute(context)

    def execute(self, context):
        Curve = context.active_object
        if not Curve.type == 'CURVE':
            self.report({'INFO'}, 'Use operator on curve type object')
            return {"CANCELLED"}
        bevelObj = bpy.context.object.data.bevel_object
        if bevelObj:
            new_obj = bevelObj.copy()
            new_obj.data = bevelObj.data.copy()
            new_obj.use_fake_user = True
            bpy.context.object.data.bevel_object = new_obj
            self.report({'INFO'}, 'Duplicating curve Profile was successful')
        return {"FINISHED"}


class HTOOL_OT_CloseRibbonProfile(bpy.types.Operator):
    bl_label = "Close curve Profile"
    bl_idname = "object.ribbon_close_profile"
    bl_description = "Hide curve Profile object (unlink it from scene)"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(self, context):  # make selection only false, if obj mode
        obj = context.active_object
        return obj and obj.type == 'CURVE' and obj.data.bevel_object is None

    def invoke(self, context, event):
        remove_unused_bevels()
        return self.execute(context)

    def execute(self, context):
        bevelObj = context.active_object
        if bevelObj.type != 'CURVE':
            self.report({'INFO'}, 'Object is not Curve!')
            return {"CANCELLED"}  # skip non bevel obj
        for obj in context.scene.objects:
            if obj.type == 'CURVE':
                if obj.data.bevel_object is not None:
                    bevelObj.use_fake_user = True
                    unlink_from_scene(bevelObj)
                    self.report({'INFO'}, 'Closing curve Profile '+bevelObj.name+' was successful')

        return {"FINISHED"}
