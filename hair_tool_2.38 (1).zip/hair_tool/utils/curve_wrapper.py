# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
# Copyright (C) 2017 JOSECONSCO
# Created by JOSECONSCO

import bpy
import numpy as np
import math
from mathutils import Vector, Matrix, Quaternion, Euler
from bpy_extras.view3d_utils import region_2d_to_location_3d
from .helper_functions import resample_linear, fallof_smoothstep, clamp, gold_random, smooth_threshold
#WONTDO: will it get sppeed from writing to always new spline? (Instead of current hack fo going edit mode to delete pts) - may break mat order
#DONE: manually remove splines, and Spline class will write to new last spline [-1]

def get_tips_pts(context, obj, world_space=True, only_sel=False, with_adj_pts = False):
    ''' returns [spl_id][points][p.co's] lists - for workspace tool mostly'''
    out_co, out_spl_ids, out_pts, adj_points = [], [], [], []
    mat = obj.matrix_world if world_space else Matrix.Identity(4)
    offset = context.scene.ht_props.select_offset
    active_end = context.scene.ht_props.active_end
    higlight_range = context.scene.ht_props.higlight_range
    for i, spl in enumerate(obj.data.splines):
        pts = spl.points if spl.type in {'NURBS', 'POLY'} else spl.bezier_points
        last_pid = len(pts)-1
        p_id = clamp(last_pid - offset, 0, last_pid) if active_end == "TIPS" else clamp(offset, 0, last_pid)

        pt_select = pts[p_id].select if spl.type in {'NURBS', 'POLY'} else pts[p_id].select_control_point
        if not only_sel or (only_sel and pt_select):
            out_pts.append(pts[p_id])
            out_co.append(mat @ pts[p_id].co.xyz if world_space else pts[p_id].co.xyz)
            out_spl_ids.append(i)
            if with_adj_pts:  # only for drawing in 3d
                points_ids = None
                if higlight_range == 1:
                    points_ids = [clamp(p_id-1, 0, last_pid), p_id, clamp(p_id+1, 0, last_pid)]
                elif higlight_range == 2:
                    points_ids = [clamp(p_id-2, 0, last_pid), clamp(p_id-1, 0, last_pid), p_id, clamp(p_id+1, 0, last_pid), clamp(p_id+2, 0, last_pid)]
                adj_points.append([mat @ pts[p_id].co.xyz for p_id in points_ids] if points_ids else None)

    if with_adj_pts:
        return out_spl_ids, out_pts, out_co, adj_points
    else:
        return out_spl_ids, out_pts, out_co

def get_len_masked(len_normalized, len_threshold, margin, seed=0):
    ''' based on normalized strands lens, pick strands above threshold val (%)'''
    np.random.seed(seed)
    gold_seed = np.random.rand()  # (0,1) range
    prob_remapped = smooth_threshold(len_normalized, len_threshold, margin/2)
    prob_01_ids = np.where((prob_remapped > 0) & (prob_remapped < 1))[0]  # id's for blend range...
    rsel_ids = []
    if prob_01_ids.shape[0] > 1:  # do we have any strands between (0,1)  len range?
        prob_01_range = prob_remapped[prob_01_ids]
        cum_prob = np.cumsum(prob_01_range)  # without normalize
        cum_sum_range = cum_prob[-1]  # scale rd_01 * this
        half_cnt = int(len(cum_prob)/2)  # pick half pts
        for i in range(half_cnt):  # pick half of elements, for blending sel to non_sel strands...
            rd = gold_random(i, gold_seed) * cum_sum_range  # low discrepancy sampling
            cp_idx = np.searchsorted(cum_prob, rd)  # bin search through cumulative probabilites
            picked_prob = cum_prob[cp_idx-1]-cum_prob[cp_idx] if cp_idx > 0 else cum_prob[cp_idx]  # we have to remove weight[idx]
            cum_prob[cp_idx:] = cum_prob[cp_idx:]-picked_prob  # from following elements
            rsel_ids.append(prob_01_ids[cp_idx])  # cos cum_prob share same ids with prob_01_ids
            #del picked element from cum_prob and prob_01_ids
            cum_prob = np.delete(cum_prob, cp_idx)
            prob_01_ids = np.delete(prob_01_ids, cp_idx)
            cum_sum_range = cum_prob[-1]
    return np.where(prob_remapped >= 1)[0].tolist()+rsel_ids

def print_quat(quat, name):
    #print quaternion as axis angle rounded to two decimal places
    axis, angle = quat.to_axis_angle()
    print(name + ": {:.2f} {:.2f} {:.2f} {:.2f}".format(axis[0], axis[1], axis[2], math.degrees(angle)))


class Segment():
    def __init__(self, root, tip):
        self.root = root
        self.tip = tip

    def follow(self, target, ik_strength):
        old_len = (self.tip - self.root).length
        # self.tip.lerp(target, strength)

        target_to_root = self.root - target  # IK way
        tip_to_root = self.root - self.tip  # non IK blend
        new_root = target + (tip_to_root.lerp(target_to_root, ik_strength)).normalized() * old_len
        self.root = new_root
        self.tip = target.copy()
        # root_ik = target - root_to_targ.normalized() * old_len  # normalize new vec. then scale back to old len
        # root_simple_offset = target + tip_to_root.normalized() * old_len #no need to normalize...
        # * pure IK
        # * self.root = target - root_targ_vec.normalized() * old_len  # normalize new vec. then scale back to old len

    def align_to_dir(self, target_dir, strength, offset):
        root_to_tip = self.tip-self.root  # non IK blend
        target_lerp_seg_dir = root_to_tip.lerp(target_dir, strength)
        rot_diff = root_to_tip.rotation_difference(target_lerp_seg_dir)
        root_to_tip.rotate(rot_diff)  # rotated
        self.root = self.root + offset
        old_tip = self.tip.copy()
        self.tip = self.root + root_to_tip
        return self.tip - old_tip  # aka offset for next segnemt


class ChainSegment():
    def __init__(self, root_obj, tip_obj):
        self.root_obj = root_obj
        self.tip_obj = tip_obj

        self.mass = 1
        self.damping = 1.0
        self.stiffness = 16

        self.track_axis = Vector((1, 0, 0))

        self.prev_root_co = self.root_obj.location.copy() # needed to handle node translation

        axis = root_obj.rotation_quaternion.to_matrix().col[0]
        self.init_dir = axis.copy()
        self.rest_dir = axis.copy()
        self.prev_dir = axis.copy()
        self.current_dir = axis.copy()
        self.velocity = Vector((0.0, 0.0, 0.0))
        # self.velocity = Quaternion((0.0, 1.0, 0.0, 0))

        self.ang_vel = Vector((0.0, 0.0, 0.0))

        self.init_mat = root_obj.matrix_world.copy()
        self.rest_mat = root_obj.matrix_world.copy()
        self.m_p_inv = Matrix.Identity(4)

    def integrate_euler_loc(self, dt ):
        if self.prev_root_co != self.root_obj.location:
            prev_root_to_tip = self.tip_obj.location - self.prev_root_co # from prev_root to tip
            root_to_tip = self.tip_obj.location - self.root_obj.location # from current_root to tip
            q_diff = prev_root_to_tip.rotation_difference(root_to_tip)
            self.current_dir.rotate(q_diff)
            # self.prev_dir.rotate(q_diff) # not needed - (maybe in verlet)
            self.prev_root_co = self.root_obj.location.copy()

        if True:
            g = 5
            grav = g*Vector((0,0, -1)) # TODO: looks bit weird, but maybe due to broken axis_angle ?
            grav_tangent = grav - grav.project(self.rest_dir) # using project(current_dir) is to vobbly )

        diff =  self.current_dir - self.rest_dir
        spring_force = - self.stiffness*diff - self.damping * self.velocity  # F = -kx - bv - g*m
        spring_force +=  grav_tangent
        acc = spring_force / self.mass
        self.velocity += acc * dt

        # NOTE: is this slower than quat?
        # self.current_dir = self.current_dir + self.velocity * dt
        # self.current_dir.normalize()

        # NOTE: does not reuire normalization... but quat slower?
        new_dir = self.current_dir + self.velocity * dt
        quat_curr_to_new = self.current_dir.rotation_difference(new_dir)
        self.current_dir.rotate(quat_curr_to_new)

        self.tip_obj.location = self.root_obj.location + self.current_dir

        # rd_prev_curr = self.prev_dir.rotation_difference(self.current_dir)
        # self.root_obj.rotation_quaternion.rotate(rd_prev_curr)

        rd_prev_curr = self.rest_dir.rotation_difference(self.current_dir)
        rmat_rotated = self.rest_mat.to_quaternion()
        rmat_rotated.rotate(rd_prev_curr)
        self.root_obj.rotation_quaternion = rmat_rotated


        # self.prev_dir = self.current_dir.copy()


    def solve_euler_axis_angle(self, dt):
        ''' This sheisse works
        stable it dt < 1/4 * T
        vel[n+1] = v[n] - h * omgea^2 * x[n]
        x[n+1] = x[n] + h * vel[n+1]
        omega^2 = k/m     #angular freq -  controls rate of oscilation
        2*dr*omega = c/m  # dr - damping ratio - dimensionless and controls amount of oscilation (0, 1) (no_damp, perfect_decay)

        w = w0 + a * dt
        q[n+1] = q[n] + 0.5 wq * q[n]
        '''
        dt = 0.04
        print("\n")

        # if self.init_dir != self.rest_dir: # NOTE: if prev chain rest_dir changed, propagete this change up the chain
        #     diff = self.init_dir.rotation_difference(self.rest_dir)
        #     new_rest =  self.init_dir.copy()
        #     new_rest.rotate(diff)
        #     total_diff = new_rest.rotation_difference(self.rest_dir)
        #     self.rest_dir = new_rest
            # self.current_dir.rotate(total_diff)

        # else:
        #     self.rest_dir = self.init_dir.copy()
        prev_root_to_tip = self.tip_obj.location - self.prev_root_co # from prev_root to tip
        if self.prev_root_co != self.root_obj.location:
            root_to_tip = self.tip_obj.location - self.root_obj.location # from current_root to tip
            q_diff = prev_root_to_tip.rotation_difference(root_to_tip)
            self.current_dir += q_diff.to_exponential_map()
            self.prev_root_co = self.root_obj.location.copy()


        diff = self.current_dir - self.rest_dir
        # diff = self.current_dir - self.rest_dir
        print_quat(Quaternion(diff), 'x')

        spring_force = - self.stiffness*diff - self.damping * self.ang_vel# + g*grav_dir.to_exponential_map() # F = -kx - bv - g*m
        print_quat(Quaternion(spring_force/self.mass), 'force')
        acc = spring_force / self.mass
        print_quat(Quaternion(acc), 'accel')


        print_quat(Quaternion(self.ang_vel), 'ang_vel')
        self.ang_vel += acc * dt
        print_quat(Quaternion(self.ang_vel), 'ang_vel')

        print_quat(Quaternion(self.current_dir), 'curr_dir')
        self.current_dir += self.ang_vel * dt

        track_curr = self.track_axis.copy()

        curr_quat = Quaternion(self.current_dir)
        track_curr.rotate(curr_quat)

        if True:
            grav = Vector((0,0, -0.1)) # TODO: looks bit weird, but maybe due to broken axis_angle ?
            grav_tan = grav - grav.project(track_curr)
            grav_dir = track_curr.rotation_difference(track_curr+grav_tan)
            print_quat(Quaternion(grav_dir), 'grav_dir') # TODO: take into account mass, stiffness, rod len?
            track_curr.rotate(grav_dir)

        # track_curr.rotate(grav_dir @ cq)
        self.tip_obj.location = self.root_obj.location + track_curr
        self.tip_obj.rotation_quaternion = grav_dir @ curr_quat

    def solve_verlet_integration_quat(self, dt):
        delta = 0.04

        spring_force = self.stiffness*(self.current_dir.rotation_difference(self.rest_dir))  # conjugated => negative dir   -> - k x
        velocity = self.current_dir.rotation_difference(self.prev_dir)  # vel =  curr - prev dir
        # velocity = 2*(self.current_dir-self.prev_dir)*(1/delta)*self.current_dir.inverted()  # vel =  curr - prev dir
        spring_force = spring_force - self.damping * velocity    # basically   stiffness_rot + damp_rot
        acceleration = spring_force * (1/self.mass)

        next_dir = 2 * self.current_dir - self.prev_dir + acceleration * delta * delta
        self.prev_dir = self.current_dir
        self.current_dir = next_dir.normalized()
        tip_cp = self.track_axis.copy()
        # tip_cp.rotate(self.rest_dir.rotation_difference(self.current_dir) )
        tip_cp.rotate(self.current_dir.rotation_difference(self.rest_dir))
        self.tip_obj.location = self.root_obj.location + tip_cp


    def semi_implicit_euler_quat(self):
        # vel += -2.0 * dt * damp_ratio * osc_ps * vel + dt * osc_ps * osc_ps * (to - pos);
        # pos += dt * vel;
        dt = 0.1
        osc_ps = 3.14 * 2 * 0.5  # oscillations per second (angular frequency)
        damp_time   = 0.5 # Time in Seconds
        damp_ratio  = - math.log(0.5) / ( osc_ps * damp_time )
        a = -2.0 * dt * damp_ratio * osc_ps
        b = dt * osc_ps * osc_ps

        self.velocity += a * self.velocity + b * ( self.rest_direction - self.current_direction)
        self.current_direction += dt * self.velocity

        self.current_direction.normalize()
        # tip_cp = self.tip_orig.copy()
        # tip_cp.rotate(self.current_dir)
        # self.tip = tip_cp
        self.tip.rotate(self.current_direction)


    def euler_cromer_integration_quat(self, dt):
        # v(n+1) = v(n) + a(n)*t
        # x(n+1) = x(n) + v(n+1)*t

        prev_root_to_tip = self.tip_obj.location - self.prev_root_co # from prev_root to tip
        if self.prev_root_co != self.root_obj.location:
            root_to_tip = self.tip_obj.location - self.root_obj.location # from current_root to tip
            q_diff = prev_root_to_tip.rotation_difference(root_to_tip)
            self.current_dir.rotate(q_diff)
            self.prev_root_co = self.root_obj.location.copy()

        # grav = Vector((0,0, -8)) # TODO: prevet vel blowup - due to gravity accumulation
        # root_to_tip_grav = (self.tip_obj.location+grav) - self.root_obj.location # from current_root to tip
        # grav_dir = prev_root_to_tip.rotation_difference(root_to_tip_grav)
        # grav_fac = grav - grav.project(prev_root_to_tip) # perp factor of gravity, to current_dir (root -> tip)
        # # grav_dir.normalize()
        # self.current_dir = grav_dir

        # if self.rest_dir.dot(self.current_dir) < 0:
        #     self.current_dir.invertd()

        x =  self.current_dir - self.rest_dir
        force = - self.stiffness * x - self.damping * self.velocity #+ grav_dir # Gravity added here, causes infinite vel_o grow - how about using normalized vel here?
        acc = force * (1/self.mass)

        self.velocity += acc * dt
        self.current_dir += self.velocity * dt
        self.velocity.normalize()
        self.current_dir.normalize()
        # print(f"{self.velocity.magnitude=}")
        track_cpy = self.track_axis.copy()
        # track_cpy.rotate(self.rest_dir.rotation_difference(self.current_dir))
        track_cpy.rotate(self.current_dir)
        self.tip_obj.location = self.root_obj.location + track_cpy # XXX: expose as return val? maybe self.out_tip_co ?


class SpringChain():
    def __init__(self, elements):
        self.links = []
        self.dt = 0.02

        parent = None
        prev = elements[0]
        prev.rotation_mode = 'QUATERNION'
        for e in elements[1:]:
            seg = ChainSegment(prev,e)
            if parent: #  head -> prev;  parent -> prev->prev
                seg.m_p_inv = parent.matrix_world.inverted() @ prev.matrix_world  # cos parent.mw @ child.mp_inv -> child.mw
            self.links.append(seg)
            e.rotation_mode = 'QUATERNION' # 'XYZ' for others
            parent = prev
            prev = e

    def step(self):
        ''' run euler motion integration for each element in chain '''
        chain_parent = self.links[0]
        chain_parent.rest_dir = chain_parent.root_obj.rotation_quaternion.to_matrix().col[0]

        parent = self.links[0].root_obj
        prev_seg = self.links[1]
        prev_seg.rest_mat = parent.matrix_world @ prev_seg.m_p_inv
        # prev_seg.rest_dir = parent.rotation_quaternion.to_matrix().col[0]
        prev_seg.rest_dir = prev_seg.rest_mat.col[0].xyz  # track with  x

        prev_seg.root_obj.location = parent.location + prev_seg.rest_dir
        prev_seg.integrate_euler_loc(self.dt)

        # for i,seg in enumerate(self.links[2:]):
        #     if prev_seg.init_dir != prev_seg.rest_dir: # NOTE: if prev chain rest_dir changed, propagete this change up the chain
        #         diff = prev_seg.init_dir.rotation_difference(prev_seg.rest_dir)
        #         idir = seg.init_dir.copy()
        #         idir.rotate(diff)
        #         seg.rest_dir = idir
        #     else:
        #         seg.rest_dir = seg.init_dir.copy()
        #     seg.integrate_euler_loc(self.dt) # was axis solve_euler_axis_angle
        #     prev_seg = seg
        for seg in self.links[2:]:
            if prev_seg.init_mat != prev_seg.rest_mat: # NOTE: if prev chain rest_dir changed, propagete this change up the chain
                seg.rest_mat = prev_seg.rest_mat @ seg.m_p_inv  # aka  parent.mw @ child.mp_inv
                seg.rest_dir = seg.rest_mat.col[0].xyz  # track with  x
            else:
                seg.rest_mat = seg.init_mat.copy()
                seg.rest_dir = seg.rest_mat.col[0].xyz  # track with  x

            seg.integrate_euler_loc(self.dt) # was axis solve_euler_axis_angle
            prev_seg = seg
        # self.links[1].init_dir = self.links[0].rest_dir.copy()


class HT_OT_SprintTest(bpy.types.Operator):
    bl_idname = "object.spring_test"
    bl_label = "object.spring_test"
    bl_description = "Spring Testing"
    bl_options = {'REGISTER','UNDO_GROUPED'}

    _timer = None

    def invoke(self, context, event):
        bpy.ops.ed.undo_push()
        obj1 = bpy.data.objects['Empty']
        obj2 = bpy.data.objects['Empty.001']
        obj3 = bpy.data.objects['Empty.002']
        obj4 = bpy.data.objects['Empty.003']
        obj5 = bpy.data.objects['Empty.004']

        self.chain = SpringChain([obj1, obj2, obj3, obj4, obj5]) # , obj3

        wm = context.window_manager
        self._timer = wm.event_timer_add(0.05, window=context.window)
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        if event.type == 'TIMER':
            self.chain.step()

        elif event.type in { "ESC"}:
            return self.cancelled(context)

        return {"PASS_THROUGH"}

    def finish(self, context):
        wm = context.window_manager
        wm.event_timer_remove(self._timer)
        return {"FINISHED"}

    def cancelled(self, context):
        wm = context.window_manager
        wm.event_timer_remove(self._timer)
        return {"CANCELLED"}


class ChainIK():
    def __init__(self, spl_pts):
        self.segs = []
        self.chain_root = spl_pts[0].co.xyz
        prev = None
        for pt in spl_pts:
            if prev:
                self.segs.append(Segment(prev.co.xyz, pt.co.xyz))
            prev = pt

    def move_ik_chain(self, target, exp, pin_end):
        # cpowTip = calc_exponent(exp)
        if not self.segs:
            return
        cpowTip = exp*10+0.1
        prev = None
        cnt = len(self.segs)
        for i, seg in enumerate(reversed(self.segs)):  # from last tip
            strength = pow(1-i/cnt, cpowTip) if pin_end else 1  # * 1.0 == full IK
            if not prev:
                seg.follow(target, strength)  # higher pow == more ik on tips only _/
            else:
                seg.follow(prev.root, strength)
            prev = seg

        if pin_end:  # hold root positionis
            hook_offset = self.segs[0].root - self.chain_root
            for seg in self.segs:
                seg.root -= hook_offset
                seg.tip -= hook_offset

    def align_ik_chain(self, target_dir, exp):
        '''Align whole chain to target_dir'''
        cnt = len(self.segs)
        offset = Vector((0, 0, 0))
        straignthen_strength_mul = 0.2
        for i, seg in enumerate(self.segs):  # from last tip
            strength = pow(1-i/cnt, 2)*straignthen_strength_mul+0.1  # * 1.0 == full IK
            offset = seg.align_to_dir(target_dir, strength, offset)  # higher pow == more ik on tips only _/

    def straighten_ik_chain(self, contrast, bias):
        '''straighten whole chain to first seg'''
        cnt = len(self.segs)
        if cnt < 2:
            return
        fallofs_smoothstep = fallof_smoothstep(contrast, bias, cnt-1)
        delta_offset = Vector((0, 0, 0))  # after aligning seg, we need fix all following segs, by offseting
        prev = self.segs[0]
        for seg, strength in zip(self.segs[1:], fallofs_smoothstep):  # strength = 1.0 => full straight
            avg_dir = seg.tip - prev.root
            delta_offset = seg.align_to_dir(avg_dir, strength**2, delta_offset)  # higher pow == more ik on tips only _/
            prev = seg

    def get_pts(self):
        return [seg.root for seg in self.segs] + [self.segs[-1].tip]

points_to_remove = {} #helper [spl_id]=[pts_to_remove_ids]

def spline_remove_points(obj, spl_id=None, points_ids=None, multi_spl=False):
    ''' remov points froom obj while mantaining selection state'''

    backup_mode = obj.mode
    #to prevent removing points from both curves in edit mode
    # for ob in bpy.context.selected_objects:
    #     ob.select_set(False)
    # bpy.context.view_layer.objects.active = obj
    # obj.select_set(True)
    # remove points from points_ids by selecting them and dissolve
    if multi_spl:
        splines_ids = points_to_remove.keys()
        pts_idss = points_to_remove.values()
    else:
        splines_ids = [spl_id]
        pts_idss = [points_ids]
    # for sp_id, pt_ids in zip(splines_ids, pts_idss):
    #     spline = obj.data.splines[spl_id]
    for spl in obj.data.splines:
        if spl.type == 'BEZIER':
            for p in spl.bezier_points:
                p.select_control_point = False
                p.select_left_handle = False
                p.select_right_handle = False
        else:
            for p in spl.points:
                p.select = False

    for sp_id, pts_ids in zip(splines_ids,pts_idss):
        spline = obj.data.splines[sp_id]
        if spline.type == 'BEZIER':
            for p_id in pts_ids:
                spline.bezier_points[p_id].select_control_point = True
        else:
            for p_id in pts_ids:
                spline.points[p_id].select = True

    if obj.mode != 'EDIT':
        bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.curve.delete(type='VERT')  # context override dosent work no matter what
    if backup_mode != 'EDIT':  # we loose spline after going in and out of edit mode
        bpy.ops.object.mode_set(mode=backup_mode)

    #? spline.bezier_points.update()

#* Bezier bezer_point.co  = Vector((x,y,z))  ; select_control_point; select_left_handle; select_left_handle
#* polyline point.co  = Vector((x,y,z, 1)); select
#* Nurb point.co  = Vector((x,y,z, 1)); select

class BezierPoint(object):  # do we even need it...
    def __init__(self, co, handle_left_type='AUTO', handle_left=Vector((0, 0, 0)), handle_right_type='AUTO', handle_right=Vector((0, 0, 0)), select = False, lh_select = False, rh_select = False, radius=1, tilt=0):
        ''' ‘FREE’, ‘VECTOR’, ‘ALIGNED’, ‘AUTO’ '''
        self.co = co.xyz.copy()
        self.handle_left = handle_left.xyz.copy()
        self.handle_left_type = handle_left_type
        self.select_left_handle = lh_select
        self.handle_right = handle_right.xyz.copy()
        self.handle_right_type = handle_right_type
        self.select_right_handle = rh_select

        self.select_control_point = select
        self.tag = False #helper
        self.radius = radius
        self.tilt = tilt

    @classmethod
    def from_bezier_point(cls, b_pt):
        return cls(b_pt.co, b_pt.handle_left_type, b_pt.handle_left, b_pt.handle_right_type, b_pt.handle_right,
             select=b_pt.select_control_point, lh_select=b_pt.select_left_handle, rh_select=b_pt.select_right_handle, radius=b_pt.radius, tilt=b_pt.tilt)

    def copy_to_target(self, b_pt):
        b_pt.co = self.co.xyz.copy()

        b_pt.handle_left_type = self.handle_left_type
        b_pt.handle_right_type = self.handle_right_type

        b_pt.handle_left = self.handle_left
        b_pt.handle_right = self.handle_right
        b_pt.select_left_handle = self.select_left_handle
        b_pt.select_right_handle = self.select_right_handle
        b_pt.select_control_point = self.select_control_point
        b_pt.radius = self.radius
        b_pt.tilt = self.tilt


class Point(object):  # do we even need it...
    def __init__(self, co, select=False, radius=1, tilt=0):
        self.co = co.xyz.copy()
        self.select = select
        self.radius = radius
        self.tilt = tilt

    @classmethod
    def from_point(cls, pt):
        sel = pt.select if hasattr(pt, 'select') else pt.select_control_point
        return cls(pt.co, sel, radius=pt.radius, tilt=pt.tilt)

    def copy_to_target(self, nurb_point):
        nurb_point.co.xyz = self.co
        nurb_point.radius = self.radius
        nurb_point.select = self.select
        nurb_point.tilt = self.tilt
        # nurb_point.co.w = 1

    def copy_to_btarget(self, nurb_point):
        nurb_point.co.xyz = self.co
        nurb_point.radius = self.radius
        nurb_point.select_control_point = self.select
        nurb_point.tilt = self.tilt
        # nurb_point.co.w = 1


exp3_1 = np.array([3, 2, 1, 0], 'f')
exp4 = np.array([[4], [3], [2], [1], [0]], 'f')
boundaries = np.array([0, 1], 'f')
#cubic bezier spl - goes through p0, p3 pts. Driven by p1,p2 handles
cubic_coeffs_bez_spl = np.array([[-1, 3, -3, 1], [3, -6, 3, 0], [-3, 3, 0, 0], [1, 0, 0, 0]], dtype=np.float32)

# catmull_rom goes through p1, p2 points, driven by p0 and p3
ten = 0.5 #tensions typically 1/2
cubic_coeffs_catmull_rom = np.array([[-ten, 2-ten, ten-2, ten], [2*ten, ten-3, 3-2*ten, -ten], [-ten, 0, ten, 0], [0, 1, 0, 0]], dtype=np.float32)

lten = 0.2 # fix for ugly seg==0 kink  - use low tension
lcubic_coeffs_catmull_rom = np.array([[-lten, 2-lten, lten-2, lten], [2*lten, lten-3, 3-2*lten, -lten], [-lten, 0, lten, 0], [0, 1, 0, 0]], dtype=np.float32)

class SplineCommon(object):
    def __init__(self, in_spl):
        self.skip_pts_remove = False
        self.orig_spl_props = {}
        if in_spl:
            self.backup_spl_props(in_spl)

    def backup_spl_props(self, spl):
        ''' copy blender spline settings like resu, res_v etc'''
        for k, v in spl.bl_rna.properties.items():
            if not v.is_readonly:  # value may be eg. <bpy_struct, EnumProperty("type")>; use: path_resolve(k) instead
                self.orig_spl_props[k] = spl.path_resolve(k)
                # setattr(new_spl, k, spl.path_resolve(k))

    def write_spl_props(self, spl):
        for k, v in self.orig_spl_props.items():
            setattr(spl, k, v)

    def write_common(self, obj, spl_id=None):
        write_spl_id = spl_id if spl_id != None else self.orig_spl_id
        if write_spl_id is None:
            print('cant write spline. No targest splined index given')
            return
        obj_spl_count = len(obj.data.splines)
        if write_spl_id == -1:
            write_spl_id = obj_spl_count-1
        if write_spl_id > obj_spl_count-1:  # create new spline
            spl_type = self.orig_spl_type if self.orig_spl_type else 'NURBS'
            polyline = obj.data.splines.new(spl_type)  # by default use Nurbs
            write_spl_id = obj_spl_count
            if spl_type == 'BEZIER':
                polyline.bezier_points.add(count=self.length-1)
                for pt in polyline.bezier_points:
                    pt.handle_left_type = 'AUTO'
                    pt.handle_right_type = 'AUTO'
            else:
                polyline.points.add(count=self.length-1)
        else:
            self.set_blender_spl_p_count(obj, write_spl_id)
        polyline = obj.data.splines[write_spl_id]
        self.write_spl_props(polyline)
        return polyline

    def parallel_transport_TNB(self):
        '''Get (Tangents,Normals) lists from points (Vector) list (slower than build in hack for alignign :( '''
        def rotationMatrix(theta, axis):
            return np.array(Quaternion(axis, theta).to_matrix())

        n = self.length
        points = self.points_co if hasattr(self, 'points_co') else np.array([p.co for p in self.points], 'f')

        T = np.apply_along_axis(np.gradient, axis=0, arr=points)  # Calculate all tangents

        # Normalize all tangents normalized
        def f(m): return m / np.linalg.norm(m)
        T = np.apply_along_axis(f, axis=1, arr=T)

        # Initialize the first parallel-transported normal vector V
        B = np.zeros(np.shape(points))
        B[0] = (T[0][1], -T[0][0], 0)
        B[0] = B[0] / np.linalg.norm(B[0])

        # Compute the values for B for each tangential vector from T
        for i in range(n - 1):
            b = np.cross(T[i], T[i + 1])
            if np.linalg.norm(b) < 0.00001:
                B[i + 1] = B[i]
            else:
                b = b / np.linalg.norm(b)
                phi = np.arccos(np.dot(T[i], T[i + 1]))
                R = rotationMatrix(phi, b)
                B[i + 1] = np.dot(R, B[i])

        # Calculate the second parallel-transported normal vector U
        N = np.array([np.cross(t, v) for (t, v) in zip(T, B)])

        # Normalize all tangents
        return (T, N, B)

    def get_uniform_tns(self, res, uniform=False, t_custom=None):  # return array <0,1> - where 1 is for longest strand
        # uniform_spacing: #adjust uniform spaced t (non xyz uniform), by segments legnths - makes points evennly distributed in Euclidean space
        t_in = np.linspace(0, 1,  num=res, endpoint=True) if t_custom is None else t_custom
        if uniform:
            points_count = self.length  # 2x knots + handles
            pts = self.points_co if hasattr(self,'points_co') else np.array([p.co for p in self.points],'f')
            seg_lens = np.apply_along_axis(np.linalg.norm, 1, pts[:-1, :]-pts[1:, :])  # do an - an-1 and get length
            t_spat = np.insert(seg_lens, 0, 0).cumsum()  # add zero and sum
            t_spat = t_spat/t_spat[-1]  # it will be now proportional to segments distances - bigger point spacing - more time.
            # np.interp(2.5, xp, fp)
            tspat_vals = np.linspace(0, 1, points_count, endpoint=True)  # len(tspat_vals) == len(t_spat)
            corr_t_ins = np.interp(t_in,  t_spat, tspat_vals)   # sample tspat_vals from spatial spacing t_spat, to t_in res,
            return corr_t_ins  # remap from <0,1> to <0, point_count-1>
        else:
            return t_in

    def create_coefficients(self, seg_id):
        '''f(t) = pts[0] * t^3 + pts[1] * t^2 + pts[2] * t^1 + pts[3]
        seg_points - bezier p[seg_id], handle_r, handle_l, p[seg_id+1]
        Four ctrl points p0, p1, p2, p3 (4, space_dim)
        [t^3 t^2 t 1] @ [cubic_coeffs (4,4)] @ [pts (4,2)] -> [4,2] (2 for 2d )
        [t^3 t^2 t 1] @ [cubic_coeffs (4,4)] @ [pts (4,2)] -> [4,2] (2 for 2d )
        coeff[:,0], coeff[:,1] - x, y
        coef[0,:], coef[1,:], coef[2,:], coef[3,:] - t^3 , t^2, t, 1
        '''
        pts = self.get_segment_points(seg_id)
        seg_points = np.array(pts, 'f')
        if seg_id == 0: #sometimes first segment gives ugly kink - when p0 ~ p1
            coef = np.einsum('ij,jk->ik', lcubic_coeffs_catmull_rom, seg_points)
        else:
            coef = np.einsum('ij,jk->ik', cubic_coeffs_catmull_rom, seg_points)
        return coef


    def __create_bspl_coefficients(self, seg_id):
        pts = self.get_segment_points(seg_id)
        seg_points = np.array(pts, 'f')
        return np.einsum('ij,jk->ik', cubic_coeffs_bez_spl, seg_points)

    def evaluate_at(self, tn):
        seg, t = divmod(tn, 1)
        seg_id = int(seg)
        pts_cnt = self.length

        #* max T = (0,1) * spl_len (aka. pts_cnt)
        above_t_max = seg_id+1 - pts_cnt  # do we exceeded max t (max spline len)
        if above_t_max >= 0: #we exceeded max spline length
            seg_id = (pts_cnt-1) - 2  # move to last_id-2 (thus p1 = last_id - 2)
            t = 0.33*(t+above_t_max) + 1 # cos cubic spl t is evaluated in <p0,p3> range (and  catmull in <p1,p2>)
            coeffs = self.__create_bspl_coefficients(seg_id)
        else:
            coeffs = self.create_coefficients(seg_id)
        t_pow = np.power(t, exp3_1)  # eg t_pow is eg (8, 4) , coeffs are (4, 2)
        return np.einsum('j,jk->k', t_pow, coeffs)

    def evaluate(self, coeffs, t):
        ''' return len(t)  2d points '''
        if type(t) != np.ndarray:
            t = np.array(t, 'f')
        tn = np.power(t[:, None], exp3_1)  # eg tn is eg (8, 4) , coeffs are (4, 2)
        return np.einsum('ij,jk->ik', tn, coeffs)  # mul j's -> output (8,2)

    @staticmethod
    def expand_cols_np(in_array, shape_diff):
        # https://stackoverflow.com/a/8505658/13588868
        rows_cnt = in_array.shape[0]
        return in_array[:, :shape_diff] if shape_diff < 0 else np.c_[in_array, np.ones((rows_cnt, shape_diff))]

    @staticmethod
    def np_mat_multiply(pts, mat):
        mat_dim_diff = mat.shape[0] - pts.shape[1]  # for matching mat_dimension to pts dim
        if mat_dim_diff:  # add col to np_seg_pts (dim_diff cols)
            pts = BezierSpline.expand_cols_np(pts, mat_dim_diff)
            if mat.shape[0] == 4:  # for point (x,y,z, 1)
                pts[:, -1] = 1
        return np.einsum('ij,aj->ai', mat, pts)

    def set_blender_spl_p_count(self, obj, spl_id):
        blender_spline = obj.data.splines[spl_id]
        pts = blender_spline.bezier_points if blender_spline.type == "BEZIER" else blender_spline.points
        pts_cnt = self.length
        new_points = pts_cnt - len(pts)
        if new_points > 0:  # orig spline has not enough
            pts.add(count=new_points)
        if new_points < 0:  # orig spline have too many points
            #* since its is very slow, add delayed opiton to remove exesive poitns once at finish
            pts_ids = [pts_cnt + i for i in range(abs(new_points))]
            if not self.skip_pts_remove:
                spline_remove_points(obj, spl_id, pts_ids)



class SplineFlat(SplineCommon):
    ''' SplineFlat with flat points_co, points_titls, points_radii. For fast resampling mostly '''

    def __init__(self, in_spl=None, orig_spl_id=None):
        ''' takes data.spline '''
        super().__init__(in_spl)
        self.orig_spl_id = orig_spl_id
        if in_spl:
            self.orig_spl_type = in_spl.type
            points = in_spl.bezier_points if in_spl.type == 'BEZIER' else in_spl.points
            self.points_co = np.array([point.co for point in points], 'f') # cost tey have w=1
            self.points_radii = np.array([p.radius for p in points], 'f')
            self.points_tilts = np.array([p.tilt for p in points], 'f')
            self.points_sel = np.array([p.select for p in points]) if in_spl.type in { 'NURBS', 'POLY'} else np.array([p.select_control_point for p in points])
        else:
            self.orig_spl_type = 'NURBS'
            self.points_co = np.array([])
            self.points_radii = np.array([])
            self.points_tilts = np.array([])
            self.points_sel = np.array([])

    @classmethod
    def from_vec_list(cls, pts):
        ''' Create spline from Vector list'''
        sps_flat_obj = cls() #new obj with defautl cls init
        sps_flat_obj.points_co = np.array(pts, 'f')  # ? .copy()
        return sps_flat_obj

    @classmethod
    def from_np_array(cls, pts):
        ''' Create spline from Vector list'''
        sps_flat_obj = cls()  # new obj with defautl cls init
        sps_flat_obj.points_co = pts
        return sps_flat_obj

    @property
    def length(self):
        return self.points_co.shape[0]

    @property
    def selected(self):
        return np.any(self.points_sel)

    @property
    def selected_by_tip(self, context):
        offset = context.scene.ht_props.select_offset
        active_end = context.scene.ht_props.active_end
        last_pid = self.length-1
        p_id = offset if active_end == 'ROOTS' else last_pid - offset
        p_id = clamp(p_id, 0, last_pid)
        return self.points_sel[p_id]

    @property
    def euclidean_len(self):
        seg_lens = np.apply_along_axis(np.linalg.norm, 1, self.points_co[:-1, :]-self.points_co[1:, :])  # (..,1) 4th axis does not affect length it seems
        return np.sum(seg_lens)

    def get_bezier_segment_points(self, seg=0):
        count = self.length
        p0 = self.points[seg].co
        p1 = self.points[seg].handle_right
        p2 = self.points[(seg+1) % count].handle_left
        p3 = self.points[(seg+1) % count].co
        return p0, p1, p2, p3

    def get_segment_points(self, seg=0): #will it work - for nurbs
        count = self.length
        p1 = seg
        p2 = p1 + 1
        p3 = min(p2 + 1, count-1)
        p0 = max(p1 - 1,  0)
        return self.points_co[[p0, p1, p2, p3]]


    def resample_pts(self, res, uniform=True, t_custom=None):
        ''' generate resampled spl pts - cheaper/simpler ver of self.eval_resampled()
        '''
        t_range = self.length - 1.01
        tns = self.get_uniform_tns(res, uniform, t_custom)*t_range  # adjust tn to get even spacing
        self.points_co = np.array([self.evaluate_at(tn) for tn in tns])  #todo: optimize by checking if points for tn lay in same segment, then skip calc_coeff 2x
        if self.points_radii.shape[0] != res:
            self.points_radii = resample_linear(self.points_radii, res)
            self.points_tilts = resample_linear(self.points_tilts, res)


    def write_to_blender_spl(self, obj, spl_id=None):
        polyline = self.write_common(obj, spl_id)
        pts = polyline.bezier_points if polyline.type == 'BEZIER' else polyline.points

        if polyline.type != 'BEZIER' and self.points_co.shape[1] != 4:
            resized = self.expand_cols_np(self.points_co, 4-self.points_co.shape[1])
            pts.foreach_set('co', resized.ravel())  # make sure for nurbs we have (x,y,z,1)
        else:
            pts.foreach_set('co', self.points_co.ravel())
        target_pt_count = self.points_co.shape[0]

        if np.any(self.points_radii):
            if self.points_radii.shape[0] != target_pt_count:
                self.points_radii = resample_linear(self.points_radii, target_pt_count)
            pts.foreach_set('radius', self.points_radii)

        if np.any(self.points_tilts):
            if self.points_tilts.shape[0] != target_pt_count:
                self.points_tilts = resample_linear(self.points_tilts, target_pt_count)
            pts.foreach_set('tilt', self.points_tilts)

        if polyline.type == "BEZIER":
            for blender_pt in pts:
                blender_pt.handle_left_type = 'AUTO'
                blender_pt.handle_right_type = 'AUTO'
        else:
            polyline.order_u = 3
            polyline.use_endpoint_u = True
            # for blender_pt, p in zip(polyline.points, self.points):
            #     blender_pt.co.w = 1

    def write_rad_to_blender_spl(self, obj, spl_id=None):
        write_spl_id = spl_id if spl_id != None else self.orig_spl_id
        polyline = obj.data.splines[write_spl_id]
        target_pts = polyline.bezier_points if polyline.type == "BEZIER" else polyline.points
        target_pt_count = len(target_pts)
        if self.points_radii.shape[0] != target_pt_count:
            self.points_radii = resample_linear(self.points_radii, target_pt_count)
        target_pts.foreach_set('radius', self.points_radii)

    def write_tilt_to_blender_spl(self, obj, spl_id=None):
        write_spl_id = spl_id if spl_id != None else self.orig_spl_id
        polyline = obj.data.splines[write_spl_id]
        target_pts = polyline.bezier_points if polyline.type == "BEZIER" else polyline.points
        target_pt_count = len(target_pts)
        if self.points_tilts.shape[0] != target_pt_count:
            self.points_tilts = resample_linear(self.points_tilts, target_pt_count)
        target_pts.foreach_set('tilt', self.points_tilts)


class SplineSimple(SplineCommon):
    ''' Spline with Points() list '''
    def __init__(self, in_spl=None, orig_spl_id=None):
        super().__init__(in_spl)
        self.points = []
        self.orig_spl_type = 'NURBS'
        self.orig_spl_id = orig_spl_id
        if in_spl:
            self.orig_spl_type = in_spl.type
            pts = in_spl.bezier_points if in_spl.type == 'BEZIER' else in_spl.points
            self.points = [Point.from_point(p) for p in pts]

    @classmethod
    def from_vec_list(cls, pts, radii=None):
        ''' Create spline from Vector list'''
        sp = cls()
        if radii:
            sp.points = [Point(co,radius=r) for co,r in zip(pts, radii)]
        else:
            sp.points = [Point(co) for co in pts]
        return sp

    @property
    def length(self):
        return len(self.points)

    def selected(self):
        return any([p.select for p in self.points])

    def selected_by_tip(self, context):
        offset = context.scene.ht_props.select_offset
        active_end = context.scene.ht_props.active_end
        last_pid = self.length-1
        p_id = offset if active_end == 'ROOTS' else last_pid - offset
        p_id = clamp(p_id, 0, last_pid)
        return self.points[p_id].select

    @property
    def euclidean_len(self):
        prev_co = self.points[0].co
        total_len = 0
        for p in self.points:
            total_len += (p.co - prev_co).length
            prev_co = p.co
        return total_len

    def append(self, point):
        self.points.append(Point.from_point(point))

    def insert(self, index, points):
        if isinstance(points, list):
            temp_points = [Point.from_point(p) for p in points]
            self.points[index:index] = temp_points
        else:
            self.points.insert(index, points)

    def __delitem__(self, idx):
        del self.points[idx]

    def __getitem__(self, idx):  # overload [] get
        return self.points[idx]

    def __setitem__(self, idx, point):
        ''' point can be blender bezier, or Point '''
        self.points[idx] = Point.from_point(point)

    def get_bezier_segment_points(self, seg=0):
        count = self.length
        p0 = self.points[seg].co
        p1 = self.points[seg].handle_right
        p2 = self.points[(seg+1) % count].handle_left
        p3 = self.points[(seg+1) % count].co
        return p0, p1, p2, p3

    def get_segment_points(self, seg=0):  # will it work - for nurbs
        count = len(self.points)
        p1 = seg
        p2 = p1 + 1
        p3 = min(p2 + 1, count-1)
        p0 = max(p1 - 1,  0)
        return self.points[p0].co, self.points[p1].co, self.points[p2].co, self. points[p3].co

    def resample_pts(self, res, uniform=True, t_custom=None):
        ''' generate resampled spl pts - cheaper/simpler ver of self.eval_resampled()
        '''
        t_range = self.length - 1.01 #-1 cos we get p2 = p1+1 (so last possible p1 is len-1)
        tns = self.get_uniform_tns(res, uniform, t_custom)*t_range

        resampled_points_co = [Vector(self.evaluate_at(tn).tolist()).to_3d() for tn in tns]  # todo: optimize by checking if points for tn lay in same segment, then skip calc_coeff 2x
        radii = [p.radius for p in self.points]
        radii_res = resample_linear(radii, res)
        tilts = [p.tilt for p in self.points]
        tilts_res = resample_linear(tilts, res)
        self.points = [Point(co, False, r, t) for co, r, t in zip(resampled_points_co, radii_res, tilts_res)]

    @staticmethod
    def __np_real_roots(coefficients, EPSILON=1e-6):
        r = np.roots(coefficients)
        return r.real[abs(r.imag) < EPSILON]

    # #computes intersection between a cubic spline and a line segment. Only possible in 2d*/
    def __computeIntersections(self, seg_id, l_a, l_b):
        # https://stackoverflow.com/a/57315396
        A = l_b.y-l_a.y  # A=y2-y1
        B = l_a.x-l_b.x  # B=x1-x2
        C = l_a.x*(l_a.y-l_b.y) + l_a.y*(l_b.x-l_a.x)  # C=x1*(y1-y2)+y1*(x2-x1)
        abc_line = np.array([A, B, C], 'f')  # line eq
        coeffs = self.create_coefficients(seg_id)  # fucking ugly, but assume points.co was moved to 2d from outer funcion.

        # have the equation Ax+By+C = 0.
        # We can however rewrite both x and y as functions of t.
        # This will then give you A*x(t) + B*y(t) + C = 0, which is now an equation in only a single unknown(t) that we can find root(s) for.
        # A Bezier curve can be converted to form x = bx[0]*t ^ 3 + bx[1]*t ^ 2 + bx[2]*t + bx[3](ignore the coefficient ordering, in hindsight they should be numbered in reverse).
        # Similar equation exists for y.
        # You can plug these into the A*x(t) + B*y(t) + C = 0 equation. You will then obtain the following eq
        # (A*bx[0]+B*by[0])*t ^ 3 + (A*bx[1]+B*by[1])*t ^ 2 + (A*bx[2]+B*by[2])*t + (A*bx[3]+B*by[3]+C) = 0, or P0*t ^ 3 + P1*t ^ 2 + P2*t + P3 = 0.

        ceff2 = np.append(coeffs, np.array([[0], [0], [0], [1]], 'f'), axis=1)  # bezier(x) + bezier(y) + bezier_C
        # A * coef2[:,0] + B * coef2[:,1] + C * coef2[:,2]
        P = np.sum(abc_line * ceff2, axis=1)  # line ABC eq with bezier line coeefs
        # verify the roots are in bounds of the linear segment
        extrema_t = self.__np_real_roots(P)
        delta = 0.0 # margin for cutting pts close to self.points.co
        extrema_t = extrema_t[(extrema_t > 0+delta) & (extrema_t < 1-delta)]  # remove out of segment extremas
        if len(extrema_t) == 0:
            return []
        spl_eval_pts = self.evaluate(coeffs, extrema_t) #2d pts list
        intersections = []
        for t, pt in zip(extrema_t.tolist(), spl_eval_pts.tolist()):
            # above is intersection point assuming infinitely long line segment,
            #  make sure we are also in bounds of the line*/
            if (l_b.x-l_a.x) != 0:  # if not vertical line*/
                s = (pt[0]-l_a.x)/(l_b.x-l_a.x)
            else:
                s = (pt[1]-l_a.y)/(l_b.y-l_a.y)

            if 0 < s and s < 1.0:# in bounds?
                intersections.append((t,Vector(pt)))
        return intersections

    def spline_line_intersection(self, line_a, line_b):
        ''' return spline line intersection points. We can do this only on 2d '''
        all_intersections = []
        for seg_id in range(self.length-1):
            inters = self.__computeIntersections(seg_id, line_a, line_b)
            all_intersections.extend([(seg_id+t,pt) for t,pt in inters])
        return all_intersections


    def write_to_blender_spl(self, obj, spl_id=None):
        polyline = self.write_common(obj, spl_id)
        if polyline.type == "BEZIER":
            for blender_pt, p in zip(polyline.bezier_points, self.points):
                p.copy_to_btarget(blender_pt)
                blender_pt.handle_left_type = 'AUTO'
                blender_pt.handle_right_type = 'AUTO'
        else:
            polyline.order_u = 3
            polyline.use_endpoint_u = True
            for blender_pt, p in zip(polyline.points, self.points):
                p.copy_to_target(blender_pt)
                blender_pt.co.w = 1 #pt tension

    def write_rad_to_blender_spl(self, obj, spl_id=None):
        write_spl_id = spl_id if spl_id != None else self.orig_spl_id
        polyline = obj.data.splines[write_spl_id]
        target_pts = polyline.bezier_points if polyline.type == "BEZIER" else polyline.points
        for p_target, p in zip(target_pts, self.points):
            p_target.radius = p.radius

    def write_tilt_to_blender_spl(self, obj, spl_id=None):
        write_spl_id = spl_id if spl_id != None else self.orig_spl_id
        polyline = obj.data.splines[write_spl_id]
        target_pts = polyline.bezier_points if polyline.type == "BEZIER" else polyline.points
        for p_target, p in zip(target_pts, self.points):
            p_target.tilt = p.tilt



class Splines(object):
    '''Seens like almost no differerence in time for splFlat vs Simple (simple seems faster tiny bit...) '''
    def __init__(self, curveObj, onlySelection, with_clear = False, spline_type = 'SIMPLE', from_tips = False):
        self.splines = []
        selectedSplines = [] #to clear if with clear....
        if onlySelection:
            if from_tips: #use higlighted workspace elements
                out_spl_ids, out_pts_ids = self.__get_tips_pts(curveObj)
                for spl_id in out_spl_ids:
                    spl = curveObj.data.splines[spl_id]
                    sp = SplineSimple(spl, spl_id) if spline_type == 'SIMPLE' else SplineFlat(spl, spl_id)
                    self.splines.append(sp)
                    selectedSplines.append(spl)
            else:
                for spl_id, spl in enumerate(curveObj.data.splines):
                    pts = spl.points if spl.type in {'NURBS', 'POLY'} else spl.bezier_points
                    any_pt_selected = any([p.select for p in pts]) if spl.type in {'NURBS', 'POLY'} else any([p.select_control_point for p in pts])
                    if any_pt_selected and len(pts)>1:
                        if with_clear: # move far back, so we wont override exisitng non selected spl
                            spl_id += 99999
                        sp = SplineSimple(spl, spl_id) if spline_type == 'SIMPLE' else SplineFlat(spl, spl_id)
                        self.splines.append(sp)
                        selectedSplines.append(spl)


        if not self.splines: # try filling from any exising spline
            all_valid_splines = [spl for spl in curveObj.data.splines if len(spl.points) > 1 or len(spl.bezier_points) > 1]
            selectedSplines.extend(all_valid_splines)
            if spline_type == 'SIMPLE':
                self.splines = [SplineSimple(spl, spl_id) for spl_id, spl in enumerate(all_valid_splines)]
            else:
                self.splines = [SplineFlat(spl, spl_id) for spl_id, spl in enumerate(all_valid_splines)]

        for spl in self.splines:
            spl.skip_pts_remove = True

        if with_clear: #remove splines after reading data from them?
            if onlySelection:
                for spline in selectedSplines:
                    curveObj.data.splines.remove(spline)
            else:
                curveObj.data.splines.clear()

    def __get_tips_pts(self, obj):
        ''' returns [spl_id][points][p.co's] lists - for workspace tool mostly'''
        out_spl_ids = []
        out_pts_ids = []
        offset = bpy.context.scene.ht_props.select_offset
        active_end = bpy.context.scene.ht_props.active_end
        for i, spl in enumerate(obj.data.splines):
            pts = spl.points if spl.type in {'NURBS', 'POLY'} else spl.bezier_points

            last_pid = len(pts)-1
            p_id = offset if active_end == 'ROOTS' else last_pid - offset
            p_id = clamp(p_id, 0, last_pid)

            pt_sel_state = pts[p_id].select if spl.type in {'NURBS', 'POLY'} else pts[p_id].select_control_point
            if pt_sel_state:
                out_pts_ids.append(p_id)
                out_spl_ids.append(i)

        return out_spl_ids, out_pts_ids

    @property
    def length(self):
        return len(self.splines)

    def euclidean_seg_distances(self, context, mw):
        offset = context.scene.ht_props.select_offset
        active_end = context.scene.ht_props.active_end

        for spl in self.splines:
            seg_lens = []
            prev_co = mw @ spl.points[0].co
            sel_pt_id = None
            for i, p in enumerate(spl.points):
                current_pt = mw @ p.co
                seg_lens.append((current_pt - prev_co).length)
                prev_co = current_pt

            last_pid = spl.length-1
            p_id = offset if active_end == "ROOTS" else last_pid - offset
            p_id = clamp(p_id, 0, last_pid)

            # if spl.points[p_id].select:  # ? what if no pt selected for whole obj. Then treat all p_id as selected?
            prev_dist = 0.0
            for p, seg_l in zip(spl.points[p_id:], seg_lens[p_id:]):  # cumulative sum lens from sel pt
                p.dist_w = prev_dist  # distance to selected vert
                prev_dist = prev_dist + seg_l

            prev_dist = 0.0
            for p, seg_l in zip(reversed(spl.points[:p_id+1]), reversed(seg_lens[:p_id+1])):
                p.dist_w = prev_dist
                prev_dist = prev_dist + seg_l
            spl.seg_lens = seg_lens

    def splines_line_intersect(self, context, curve_obj, line_a, line_b):
        ''' return newly created intersection points. Only for SplineSimple..'''
        region = context.region
        rv3d = context.region_data

        #* find the intersections t, but first move spl points.co to 2d space
        pts_with_ids = []
        region_size = Vector((context.region.width, context.region.height))
        per_world_mat = rv3d.perspective_matrix @ curve_obj.matrix_world
        for spl_id, spl in enumerate(self.splines):
            #first move 3d spline points.co to screen space
            back_pts_co = [p.co.copy() for p in spl.points]
            for p in spl.points:
                ''' return 2d screen point from 3d local co (moved to world space first...). Aka view3d_utils.location_3d_to_region_2d but save mat.m_w @ '''
                #rv3d.view_matrix - cam mat world
                #rv3d.window_matrix - only fov?
                #rv3d.perspective_matrix  -> #perspective_matrix = window_matrix * view_matrix
                co_cam_3d = per_world_mat @ p.co.to_4d()  # should be (x,y,z,1) - point
                cam_co_2d_normalized = Vector((co_cam_3d.x/co_cam_3d.w, co_cam_3d.y/co_cam_3d.w))  # in <-1,1> range
                p.co = region_size * (cam_co_2d_normalized + Vector((1, 1)))/2  # remap to (0, win_width)
            #* find the intersections t.
            intersections = spl.spline_line_intersection(line_a, line_b)  # return (t, pt) list. Done in 2d space
            # pts_with_ids.extend([(t, pt, spl_id) for t, pt in inters])  # intersection pts with spl_id
            if intersections:
                t, pt = intersections[0] # only use first intersection for give pls. #TODO: sort by lowest t?
                pts_with_ids.append((t, spl_id))
            for p, b_co in zip(spl.points, back_pts_co):
                p.co = b_co

        #* perform actuall cut using split_seg_t (adds pt at time t)
        for i, (t_n, spl_id) in enumerate(pts_with_ids):
            #todo can we split cubic spl, so that cut pt gives no deformation to spl?
            # new_pt_id = self.splines[spl_id].split_seg_t(t_n)
            new_points_co = Vector(self.splines[spl_id].evaluate_at(t_n).tolist()).to_3d()  # in 3d....
            seg_id, t = divmod(t_n, 1)
            seg_id = int(seg_id)
            new_pt_id = seg_id if t < 0.3 else seg_id + 1 #if we are close to prev point, then move it, rather than next one to target co
            self.splines[spl_id].points[new_pt_id].co = new_points_co
            #global helper for quick pts removall
            points_to_remove[self.splines[spl_id].orig_spl_id] = [i for i in range(new_pt_id+1, self.splines[spl_id].length)]
            self.splines[spl_id].points = self.splines[spl_id].points[:new_pt_id+1]  # remove points after cut..
            self.splines[spl_id].points[-1].select= True
            # self.splines[spl_id].points[new_pt_id]

        if points_to_remove:  # * pts removal is slow, so do it only once for all removed pts
            spline_remove_points(curve_obj, multi_spl=True)
            points_to_remove.clear()

        [sp.write_to_blender_spl(curve_obj) for sp in self.splines]


    def resample_splines(self, res, uniform_spacing=True, same_point_count=True, tn_fallof=None):
        res_norm = [res]*self.length
        tn_fallofs = [tn_fallof]*self.length if type(tn_fallof) == np.ndarray else [None]*self.length

        if not same_point_count:
            len_per_strand = [sp.euclidean_len for sp in self.splines]
            len_normalized = np.array(len_per_strand)/max(len_per_strand)
            # res_norm = [max(ceil(res * l_norm), 2) for l_norm in len_normalized]
            res_norm = np.maximum(np.ceil(res*len_normalized), 2).astype(int).tolist()
            if tn_fallof is not None:
                t_in = np.linspace(0, 1, len(tn_fallof))
                tn_fallofs = []  # fill tn_fallofs for each spline len()
                for res in res_norm:
                    t_out_res = np.linspace(0, 1, res)
                    tn_fallofs.append(np.interp(t_out_res, t_in, tn_fallof))

        for sp, res_n, tn_fallof in zip(self.splines, res_norm, tn_fallofs):
            sp.resample_pts(res_n, uniform=uniform_spacing, t_custom=tn_fallof)

    def write_splines_to_blender(self, obj):
        for spl in self.splines: #*check if we write less pts, to obj.spline. If so remove pts from curve
            write_spl_id = spl.orig_spl_id
            if write_spl_id is None:
                continue
            obj_spl_count = len(obj.data.splines)
            if write_spl_id == -1:
                write_spl_id = obj_spl_count-1
            if write_spl_id < obj_spl_count:
                pts_cnt = spl.length
                blender_spl = obj.data.splines[write_spl_id]
                pts = blender_spl.bezier_points if blender_spl.type == 'BEZIER' else blender_spl.points
                new_points = pts_cnt - len(pts)
                if new_points < 0:  # orig spline have too many points
                    pts_ids = [pts_cnt + i for i in range(abs(new_points))]
                    points_to_remove[write_spl_id] = pts_ids
        if points_to_remove: #* pts removal is slow, so do it only once for all removed pts
            spline_remove_points(obj, multi_spl=True)
            points_to_remove.clear()


        [sp.write_to_blender_spl(obj) for sp in self.splines]


# class OBJECT_OT_DebugCurve(bpy.types.Operator):
#     bl_idname = "object.debug_curve_res"
#     bl_label = "Debug Curve resample"
#     bl_description = "DebugCurve"
#     bl_options = {"REGISTER","UNDO"}

#     res_points: bpy.props.IntProperty(name='Res Points', description='', default=6, min=0, max=22)
#     uniform: bpy.props.BoolProperty(name='uniform', description='', default=True)

#     def invoke(self, context, event):
#         obj = context.active_object
#         self.spline = SplineSimple(obj.data.splines[0], 0)
#         return self.execute(context)

#     def execute(self, context):
#         obj = context.active_object
#         spline = deepcopy(self.spline)
#         import time
#         start_time = time.time()

#         spline.resample_pts(self.res_points, self.uniform)
#         spline.write_to_blender_spl(obj)
#         print(f'SplineSimple took --- {time.time() - start_time} seconds ---')
#         return {"FINISHED"}

