class HTool_ClassCommon():
    def save_settings(self, settings_storage, ignored_props = {}):
        ignore = {'rna_type'} | set(ignored_props)
        for d in self.properties.bl_rna.properties.keys():
            if d in ignore:
                continue
            setattr(settings_storage, d, getattr(self.properties, d))

    def load_settings(self, settings_storage, ignored_props = {}):  # from curly_hair_settings
        ignore = {'name', 'rna_type'} | set(ignored_props)
        for d in settings_storage.bl_rna.properties.keys():
            if d in ignore:
                continue
            setattr(self.properties, d, getattr(settings_storage, d))

