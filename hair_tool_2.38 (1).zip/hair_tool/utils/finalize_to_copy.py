'''
Copyright (C) 2017 JOSECONSCO
Created by JOSECONSCO

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
import bpy
from ..short_hair import short_hair_mod_name

HT_MATS_LI = []

def get_ht_mesh_mats(context):
    items = []
    for obj in context.selected_objects:
        if obj.ht_props and obj.ht_props.hair_settings.hair_mesh_parent:
            items += [(mat.name, mat.name, "") for mat in obj.data.materials]
    global HT_MATS_LI
    HT_MATS_LI = list(set(items))  # rem duplis

def my_settings_callback(self, context):
    return HT_MATS_LI

class OBJECT_OT_FinalizeHair(bpy.types.Operator):
    bl_idname = "object.finalize_hair"
    bl_label = "Finalize Hair"
    bl_description = "Finalize selected hair objects (converts them to mesh if required, and joins into new object)"
    bl_options = {"REGISTER","UNDO"}

    mat: bpy.props.EnumProperty(name='Hair Material to use', description='Material to use on merged mesh haircards object',
                                items=my_settings_callback)

    @classmethod
    def poll(cls, context):
        return context.active_object

    def draw(self, context):
        layout = self.layout
        row = layout.row(align=True)
        row.prop(self, 'mat')

    @staticmethod
    def del_objs(objs):
        for _ in range(len(objs)):
            bpy.data.objects.remove(objs.pop())

    def invoke(self, context, event):
        self.first_run = True
        return self.execute(context)

    def execute(self, context):
        # handle short hair - by making sure guide obje is selected (thus duplicated, deleted - and it wont affect original base mash guide)
        for obj in context.selected_objects:
            if obj.type == 'MESH' and obj.ht_props.short_hair_props.is_short_hair:
                short_hair_mod = obj.modifiers.get(short_hair_mod_name)
                if short_hair_mod:
                    guide_obj = short_hair_mod['Input_6'] # Deformer
                    print(guide_obj.name)
                    guide_obj.hide_set(False)
                    guide_obj.select_set(True)

        if self.first_run:
            bpy.ops.object.duplicate()
            if bpy.app.version < (3, 0, 0):
                bpy.ops.object.duplicates_make_real() # XXX: in 3.0 this create duplicate of curves hair
            else:
                # in blender 3.0 exclude duplicated curves from make real- or it will be duplicated second time
                obj_to_make_real = [obj for obj in context.selected_objects if obj.type != 'CURVE']
                if obj_to_make_real:
                    override = {'active_object': obj_to_make_real[0], 'selected_objects': obj_to_make_real, 'selected_editable_objects': obj_to_make_real, 'visible_objects': obj_to_make_real, 'editable_objects': obj_to_make_real}
                    bpy.ops.object.duplicates_make_real(override) # XXX: in 3.0 this create duplicate of curves hair

            bpy.ops.object.make_single_user(object=True, obdata=True)
            bpy.ops.object.curve_to_mesh_ribbon()
            bpy.ops.object.parent_clear(type='CLEAR_KEEP_TRANSFORM')

            bpy.ops.hair.convert_short_hair_to_mesh()

            non_mesh_non_curve_objs = {obj for obj in context.selected_objects if obj.type not in {'MESH', 'CURVE'}}
            self.del_objs(non_mesh_non_curve_objs)

            # NOTE: another cleanup pass
            del_objs = {mod.object for obj in context.selected_objects for mod in obj.modifiers if mod.type == 'CURVE' and mod.object}  # braid_deform_curves
            del_objs.update([obj for obj in context.selected_objects if obj.display_type in {'WIRE', 'BOUNDS'}]) #wire dawn objs (usually grid surfaces)
            act_obj = context.active_object
            if act_obj is None or act_obj.type not in {'MESH', 'CURVE'} or act_obj in del_objs:
                for obj in context.selected_objects:
                    if obj.type in {'MESH', 'CURVE'} and obj not in del_objs:
                        context.view_layer.objects.active = obj
                        act_obj = obj
                        break
            self.del_objs(del_objs)

            output_coll = act_obj.users_collection[0] if act_obj.users_collection else context.scene.collection
            bpy.ops.object.convert(target='MESH')

            self.first_run = False
            get_ht_mesh_mats(context)  # sets HT_MATS_LI
            if HT_MATS_LI:
                ht_mat = bpy.data.materials.get(HT_MATS_LI[0][0]) #use first as temp - replaced in second step
                if ht_mat:
                    for obj in context.selected_objects:
                        if obj.ht_props and obj.ht_props.hair_settings.hair_mesh_parent:  # was generated from curve hair so assume it HT obj (or use UV?)
                            obj.data.materials.clear()
                            obj.data.materials.append(ht_mat)
            try:
                context.view_layer.objects.active = act_obj
            except:
                context.view_layer.objects.active = context.selected_objects[0] if context.selected_objects else None
            new_active_obj = context.active_object
            new_active_obj.data.use_auto_smooth = True
            new_active_obj.data.auto_smooth_angle = 3.14159

            bpy.ops.object.join()
            for col in new_active_obj.users_collection:
                col.objects.unlink(new_active_obj)
            if new_active_obj.name not in output_coll.objects.keys():
                output_coll.objects.link(new_active_obj)
                context.view_layer.objects.active = act_obj #cos col unlink - removes active_obj
            if len(HT_MATS_LI) > 1:
                return context.window_manager.invoke_props_dialog(self)
            else:
                return {"FINISHED"}

        else:
            if HT_MATS_LI and self.mat:
                temp_ht_mat = bpy.data.materials.get(HT_MATS_LI[0][0])  # use first as temp - replaced in second step
                replacing_mat = bpy.data.materials.get(self.mat)  # use first as temp - replaced in second step
                obj = context.active_object
                if temp_ht_mat and replacing_mat and (temp_ht_mat != replacing_mat):
                    for i,mat in enumerate(obj.data.materials):
                        if mat == temp_ht_mat:
                            obj.data.materials[i] = replacing_mat

        return {"FINISHED"}
