# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
# Copyright (C) 2017 JOSECONSCO
# Created by JOSECONSCO

import bpy
import bmesh
import math
from bpy_extras import view3d_utils
from math import sqrt, pow
from copy import deepcopy
from random import uniform, seed
import numpy as np
from .material_operators import HTOOL_OT_CurvesUVRefresh
from mathutils import noise, Vector, kdtree, Matrix
from mathutils.bvhtree import BVHTree
from mathutils.geometry import barycentric_transform
from bpy.props import EnumProperty, FloatProperty, BoolProperty, IntProperty, StringProperty
from .hair_curve_helpers import HTOOL_OT_CurvesTiltAlign
from .hair_curve_helpers import get_obj_mesh_bvht
from .profile_operations import generate_profile, update_profile
from .resample2d import interpol_Catmull_Rom_splines
from .utils.helper_functions import calc_exponent, get_curve_points
from .utils.curve_wrapper import SplineSimple

 #DONE: Addo noise..
 #NOPE: Support uniform and non even len interpol? Or just leave it to resample oper?

class HTOOL_OT_RibbonsFromParticleHairChild(bpy.types.Operator):
    bl_label = "Ribbons from particle hair with children"
    bl_idname = "object.ribbons_from_ph_child"
    bl_description = "Generate Ribbons from particle hair with custom made child strands generator. \n" \
                     "It gives more uniform child distribution compared to build in child particles."
    bl_options = {"REGISTER", "UNDO", "PRESET"}

    # extend: BoolProperty(name="Append", description="Appends new curves to already existing Particle hair strands", default=True)
    # override_segments: BoolProperty(name="Resample strands", description="Force using strands segments parameter", default=False)
    points_count: IntProperty(name="Points per strand",  description="How many points generate for each curve", default=5, min=2, max=20)
    childCount: IntProperty(name="Child count", default=100, min=10, max=2000)
    hairType: bpy.props.EnumProperty(name="Hair Type", default="NURBS",
                                      items=(("BEZIER", "Bezier", ""),
                                             ("NURBS", "Nurbs", ""),
                                             ("POLY", "Poly", "")))
    Seed: IntProperty(name="Noise Seed", default=1, min=1, max=1000)
    placement_jittering: IntProperty(name="Placement Jittering/Face", description="Placement Jittering/Face \n"
                                                                                    "Helps even out particle distribution \n"
                                                                                    "0 = automatic", default=0, min=0, max=1000)

    embed: FloatProperty(name="Embed roots", description="Radius for bezier curve", default=0, min=0, max=10)
    # embedTips: FloatProperty(name="Embed tips", description="Radius for bezier curve", default=0, min=0, max=10)

    noiseFalloff: FloatProperty(name="Noise falloff", description="Noise influence over strand lenght", default=0, min=-1, max=1, subtype='PERCENTAGE')
    freq: FloatProperty(name="Noise freq", default=0.5, min=0.0, max=5.0)
    noiseAmplitude: FloatProperty(name="Noise Amplitude", default=0.5, min=0.0, max=10.0)

    lenSeed: IntProperty(name="Length Seed", default=1, min=1, max=1000)
    RandomizeLengthPlus: FloatProperty(name="Increase length randomly", description="Increase length randomly", default=0, min=0, max=1, subtype='PERCENTAGE')
    RandomizeLengthMinus: FloatProperty(name="Decrease length randomly", description="Decrease length randomly", default=0, min=0, max=1, subtype='PERCENTAGE')

    generateRibbons: BoolProperty(name="Generate Ribbons", description="Generate Ribbons on curve", default=True)
    strandWidth: FloatProperty(name="Strand Width", default=0.5, min=0.0, max=10)
    strandUplift: FloatProperty(name="Strand uplift", default=0.0, min=-1, max=1, description="Moves whole ribbon up or down")
    alignToSurface: BoolProperty(name="Align tilt", description="Align tilt to Surface", default=False)

    RadiusFalloff: FloatProperty(name="Radius falloff", description="Radius falloff over strand lenght", default=0,  min=-1, max=1, subtype='PERCENTAGE')
    TipRadius: FloatProperty(name="Tip Radius", description="Tip Radius", default=0, min=0,  max=1, subtype='PERCENTAGE')

    Clumping: FloatProperty(name="Clumping", description="Clumping", default=0, min=0,  max=1, subtype='PERCENTAGE')
    ClumpingFalloff: FloatProperty(name="Clumping Falloff", description="Clumping Falloff", default=0,  min=-1, max=1, subtype='PERCENTAGE')
    Radius: FloatProperty(name="Radius", description="Radius for bezier curve", default=1, min=0, max=100)




    def check(self, context):  # DONE: can prop panel be fixed/refreshed when using f6 prop popup
        return True

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.label(text="Curves from Particle Hair Settings:")
        box.prop(self, 'embed')
        # box.prop(self, 'embedTips')
        box.prop(self, 'hairType')
        box.prop(self, 'points_count')
        box.prop(self, 'childCount')
        box.prop(self, 'placement_jittering')

        box.label(text="Noise:")
        col = box.column(align=True)
        col.prop(self, 'Seed')
        col.prop(self, 'noiseFalloff')
        col.prop(self, 'noiseAmplitude')
        col.prop(self, 'freq')
        col = box.column(align=True)
        col.prop(self, 'lenSeed')
        col.prop(self, 'RandomizeLengthPlus')
        col.prop(self, 'RandomizeLengthMinus')

        box.prop(self, 'generateRibbons')
        if self.generateRibbons:
            col = box.column(align=True)
            col.prop(self, 'strandWidth')
            col.prop(self, 'alignToSurface')
        else:
            col.prop(self, 'Radius')
            col.prop(self, 'RadiusFalloff')
            col.prop(self, 'TipRadius')
            col.prop(self, 'Clumping')
            col.prop(self, 'ClumpingFalloff')


    @staticmethod
    def createUniformParticleSystem(context, childCount, placement_jittering, Seed=1, world_space = False, use_custom_density = False, density = '', idensity=None):
        particleObj = context.active_object
        index = particleObj.particle_systems.active_index
        partsysMod = particleObj.particle_systems[index]
        tempParticleMod = particleObj.modifiers.new("HairTemp", 'PARTICLE_SYSTEM')
        partsysUniform = tempParticleMod.particle_system.settings
        partsysUniform.name = 'HairFromCurves'
        partsysUniform.count = childCount
        partsysUniform.use_emit_random = False
        partsysUniform.use_even_distribution = True
        partsysUniform.emit_from = 'FACE'
        partsysUniform.physics_type = 'NO'
        partsysUniform.frame_start = 0
        partsysUniform.frame_end = 0
        partsysUniform.lifetime = 500
        partsysUniform.distribution = "JIT"
        partsysUniform.jitter_factor = 1
        partsysUniform.userjit = placement_jittering #from 0 to 1000; 0 -automatic
        tempParticleMod.particle_system.seed = Seed
        tempParticleMod.particle_system.vertex_group_density = density if use_custom_density else partsysMod.vertex_group_density
        tempParticleMod.particle_system.invert_vertex_group_density = idensity if idensity else partsysMod.invert_vertex_group_density
        tempParticleMod.particle_system.vertex_group_length = partsysMod.vertex_group_length
        tempParticleMod.particle_system.invert_vertex_group_length = partsysMod.invert_vertex_group_length

        partsysUniform.use_modifier_stack = True

        depsgraph = context.evaluated_depsgraph_get() #to see spawned particles...
        particleObj_eval = particleObj.evaluated_get(depsgraph)
        tempParticleMod_eval = particleObj_eval.modifiers["HairTemp"]

        if world_space:
            childParticles = [particle.location.copy() for particle in tempParticleMod_eval.particle_system.particles]
        else:
            particleObjMatWorldInv = particleObj.matrix_world.inverted()
            childParticles = [particleObjMatWorldInv @ particle.location for particle in tempParticleMod_eval.particle_system.particles]
        particleObj.modifiers.remove(tempParticleMod)
        particleObj.particle_systems.active_index = index
        return childParticles

    @staticmethod
    def createUniformParticleSystem2(context, point_count, seed, world_space = False):
        '''Nice distribution but 10 slower that above... Maye option as HQ setting..
        based on http://extremelearning.com.au/evenly-distributing-points-in-a-triangle/ '''
        particleObj = context.active_object
        point_count *= 2
        # depsgraph = bpy.context.evaluated_depsgraph_get()
        # object_eval = particleObj.evaluated_get(depsgraph)
        # me = object_eval.to_mesh()
        me = particleObj.data
        me.calc_loop_triangles()
        points = [particleObj.matrix_world @ p.co for p in me.vertices] if world_space else [p.co for p in me.vertices]

        g = 1.32471795724474602596090885447809


        dim=2 #2d distribution
        alpha = np.array([pow(1/g,1) % 1 , pow(1/g,2) % 1 , pow(1/g,3) % 1 ])
        # This number can be any real number.
        # Common default setting is typically seed=0
        # But seed = 0.5 is generally better.  Nope - seed 0 is better
        # seed = 0.5
        # seed = 0
        np.random.seed(int(seed*100))
        if seed == 0:
            rand_offset = np.zeros(3)
        else:
            rand_offset = np.random.rand(3)
        # rand_offset = np.zeros(3) #! for now
        surface_points = []
        tri_count = len(me.loop_triangles)
        # z = np.zeros((point_count, dim))
        #generate point_count random points, from range of <0, tri_count>
        remaining_points = point_count
        # pts_per_tri = len(me.loop_triangles)
        random_triangle_pick = [1]
        while (remaining_points >= tri_count): #TODO: add bigger probability for bigger faces.
            random_triangle_pick = np.append(random_triangle_pick, np.arange(tri_count))  # without repetition - pick random tris  point_count times
            remaining_points -= tri_count
        random_triangle_pick = np.append(random_triangle_pick, np.random.choice(tri_count, remaining_points, replace=False))  # without repetition - pick random tris  point_count times
        pts_per_tris = np.bincount(random_triangle_pick)

        for tria, pts_per_tri in zip(me.loop_triangles, pts_per_tris):
            tri_pts_co = [points[tria.vertices[0]], points[tria.vertices[1]], points[tria.vertices[2]]]
            AB = tri_pts_co[1]-tri_pts_co[0]
            AC = tri_pts_co[2]-tri_pts_co[0]
            for i in range(pts_per_tri):  # 2 since we reject points outside triangle, in Parallelogram method
                z = (rand_offset + alpha*(i+1)) % 1  # z[x,y] is random float in <0,1>.
                # tria = me.loop_triangles[tri_id]  # z <0,1>. * tri_count  => id of random triangle
                r1 = z[0] # <0,1> along AB multiplier
                r2 = z[1]  # <0,1> along AC multiplier
                if r1 + r2 < 1: #in triagle
                    p = r1 * AB + r2 * AC
                else:#out of triangle - flip if inside tri
                    continue #doubled point count, and remove half of points (that are autside of triangel in parallelogram)
                    p = (1-r1) * AB + (1-r2) * AC
                p = Vector(p) +  tri_pts_co[0]
                surface_points.append(p)
        # object_eval.to_mesh_clear()
        return surface_points


    def invoke(self, context, event):
        self.active_obj = context.active_object
        self.depsgraph = context.evaluated_depsgraph_get()
        self.obj_eval = context.active_object.evaluated_get(self.depsgraph)
        self.source_surf_bvh_w = get_obj_mesh_bvht(self.obj_eval, self.depsgraph, applyModifiers=True, world_space=True)  # for tilt aliging and other
        return self.execute(context)

    def execute(self, context):
        depsgraph = bpy.context.evaluated_depsgraph_get()
        ob = bpy.context.active_object
        obj_eval = ob.evaluated_get(depsgraph)

        # particleObj = context.active_object
        particleObj = obj_eval
        if bpy.context.active_object.particle_systems is None:  # create new one
            self.report({'INFO'}, 'No active Particle Hair System found!')
            return {"CANCELLED"}
        index = particleObj.particle_systems.active_index
        psys_active = particleObj.particle_systems[index]
        if psys_active.settings.type != 'HAIR':  # create new one
            self.report({'INFO'}, 'Active Particle System is not Hair type! Cancelling')
            return {"CANCELLED"}
        pointsList_hair = []
        # context.scene.update() #! disabled with depsgraph api change
        if len(psys_active.particles) == 0:  # require more that three strands
            self.report({'INFO'}, 'Active Particle System has zero strands! Cancelling')
            return {"CANCELLED"}
        diagonal = particleObj.dimensions.length   # to normalize some values - is world space. #? normalize to local by /particleObj.matrix_world.to_scale().length  ?
        for particle in psys_active.particles:  # for strand point
            pointsList_hair.append([hair_key.co for hair_key in particle.hair_keys])  # DONE: exclude duplicates if first strand[0] in list already
        if len(psys_active.particles) == 1: #create two fake strands so that barycentric works
            pointsList_hair.append([x.xyz+Vector((0.01*diagonal, 0, 0)) for x in pointsList_hair[0]])
            pointsList_hair.append([x.xyz+Vector((0 ,0.01*diagonal, 0)) for x in pointsList_hair[0]])
        elif len(psys_active.particles) == 2: #create one fake strands so that barycentric works
            pointsList_hair.append([x.xyz+Vector((0.01*diagonal, 0, 0)) for x in pointsList_hair[0]])
        pointsList_uniq = []
        [pointsList_uniq.append(x) for x in pointsList_hair if x not in pointsList_uniq]  #removing doubles (can cause zero size tris)

        #same_point_count cos barycentric transform requires it
        pointsList = interpol_Catmull_Rom_splines(pointsList_uniq, self.points_count, uniform_spacing=True, same_point_count=True)  # just gives smoother result on borders

        searchDistance = 100 * diagonal
        parentRoots = [strand[0] for strand in pointsList]  # first point of roots
    #create nnew Part Sytem with uniform points
        pointsChildRoots = self.createUniformParticleSystem(context, self.childCount, self.placement_jittering, self.Seed)  # return child part roots positions

        kd = kdtree.KDTree(len(parentRoots))
        for i, root in enumerate(parentRoots):
            kd.insert(root, i)
        kd.balance()
        sourceSurface_BVHT = BVHTree.FromObject(particleObj, depsgraph) #with mod , local space
        childStrandsPoints = []  #will contain strands with child points
        childStrandRootNormals = []
        length_ver_group_index = -1
        vertex_group_length_name = psys_active.vertex_group_length
        if vertex_group_length_name:  # calc weight based on root point
            length_ver_group_index = particleObj.vertex_groups[vertex_group_length_name].index

        particleObj_eval = particleObj.evaluated_get(depsgraph)
        particleObjMesh = particleObj_eval.to_mesh() #evaluated so with modifiers
        seed(a=self.lenSeed, version=2)
        embed = self.embed * 0.04 * diagonal
        cpow = calc_exponent(self.noiseFalloff)
        cpowClump = calc_exponent(self.ClumpingFalloff)
        noiseFalloff = [pow(i / self.points_count, cpow) for i in range(self.points_count)]
        ClumpFalloff = [pow((i+1) / self.points_count, cpowClump) for i in range(self.points_count)]

        for i,childRoot in enumerate(pointsChildRoots):  #for each child find it three parents and genereate strands by barycentric transform
            snappedPoint, normalChildRoot, rootHitIndex, distance = sourceSurface_BVHT.find_nearest(childRoot, searchDistance)
            childStrandRootNormals.append(normalChildRoot)
            threeClosestParentRoots = kd.find_n(childRoot, 3) #find three closes parent roots
            rootTri_co, ParentRootIndices, distances = zip(*threeClosestParentRoots)  #split it into 3 arrays
            sourceTri_BVHT = BVHTree.FromPolygons(rootTri_co,[(0,1,2)],all_triangles=True)  # [0,1,2] - polygon == vert indices list
            childRootSnapped, normalChildProjected, index, distance = sourceTri_BVHT.find_nearest(childRoot, searchDistance) #snap generated child to parent triangle ares \normals are sometimes flipped
            childRootSnapped2, normalChildProjected2, index2, distance2 = sourceSurface_BVHT.find_nearest(childRootSnapped, searchDistance) #this gives ok normals always

            lenWeight = 1
            if length_ver_group_index != -1:  # if vg exist
                averageWeight = 0
                for vertIndex in particleObjMesh.polygons[rootHitIndex].vertices: #DONE: check if work on mesh with modifiers
                    for group in particleObjMesh.vertices[vertIndex].groups:
                        if group.group == length_ver_group_index:
                            averageWeight += group.weight
                            break
                lenWeight = averageWeight / len(particleObjMesh.polygons[rootHitIndex].vertices)
            ranLen=uniform(-self.RandomizeLengthMinus, self.RandomizeLengthPlus)
            lenWeight*=(1+ranLen)
            # diff = childRoot - childRootSnapped
            # mat_loc = Matrix.Translation(childRootSnapped)
            # matTriangleSpaceInv = mat_loc #* rotMatrix
            # matTriangleSpaceInv.invert()
            rotQuat = normalChildProjected2.rotation_difference(normalChildRoot)
            translationMatrix = Matrix.Translation(childRoot)
            rotMatrixRot = rotQuat.to_matrix().to_4x4()
            mat_sca = Matrix.Scale(lenWeight, 4)
            transformMatrix = translationMatrix @ rotMatrixRot
            strandPoints = []
            #for childRootSnapped points transform them from parent root triangles to parent next segment triangle t1,t2,t3
            # and compensate child snapping to root triangle from before
            for j,(t1,t2,t3) in enumerate(zip(pointsList[ParentRootIndices[0]],pointsList[ParentRootIndices[1]],pointsList[ParentRootIndices[2]])):
                pointTransformed = barycentric_transform(childRootSnapped,rootTri_co[0],rootTri_co[1],rootTri_co[2], Vector(t1), Vector(t2), Vector(t3))
                childInterpolatedPoint = transformMatrix@mat_sca@(pointTransformed-childRootSnapped) #rotate child strand to original pos (from before snapt)
                #do noise
                noise.seed_set(self.Seed + i)  # add seed per strand/ring ?
                noiseVectorPerStrand = noise.noise_vector(childInterpolatedPoint * self.freq / diagonal,
                                                          noise_basis ='PERLIN_ORIGINAL') * noiseFalloff[j] * self.noiseAmplitude * diagonal / 10
                # childInterpolatedPoint += noiseVectorPerStrand

                #do clumping
                diff = Vector(t1) - childInterpolatedPoint  # calculate distance to parent strand (first strand from trio)
                # point += noiseVectorPerStrand * noiseFalloff[j] * self.noiseAmplitude * diagonal / 10
                # childClumped = childInterpolatedPoint + ClumpFalloff[j] * self.Clumping * diff + noiseVectorPerStrand * (1-ClumpFalloff[j])
                childClumped = childInterpolatedPoint + ClumpFalloff[j] * self.Clumping * diff + noiseVectorPerStrand * (1-ClumpFalloff[j]* self.Clumping)
                # childClumped = childInterpolatedPoint + noiseVectorPerStrand

                strandPoints.append(childClumped)
            # embeding roots
            diff = strandPoints[0] - strandPoints[1]
            diff.normalize()
            normalWeight = abs(diff.dot(normalChildRoot))
            strandPoints[0] += (diff*normalWeight - normalChildRoot*(1-normalWeight)) * embed  # do childStrandRootNormal to move it more into mesh surface
            childStrandsPoints.append(strandPoints)

        particleObj.to_mesh_clear()
        # create the Curve Datablock
        curveData = bpy.data.curves.new(particleObj.name+'_curve', type='CURVE')

        splinePointsNp = np.array(childStrandsPoints, dtype=np.float32)
        if self.hairType != 'BEZIER':
            splinePointsNpOnes = np.ones((len(childStrandsPoints), self.points_count, 4), dtype=np.float32)  # 4 coord x,y,z ,1
            splinePointsNpOnes[:, :, :-1] = splinePointsNp
            splinePointsNp = splinePointsNpOnes
        for strandPoints in splinePointsNp:  # for strand point
            curveLength = len(strandPoints)
            polyline = curveData.splines.new(self.hairType)
            if self.hairType == 'BEZIER':
                polyline.bezier_points.add(curveLength - 1)
            elif self.hairType == 'POLY' or self.hairType == 'NURBS':
                polyline.points.add(curveLength - 1)
            if self.hairType == 'NURBS':
                polyline.order_u = 3  # like bezier thing
                polyline.use_endpoint_u = True

            if self.hairType == 'BEZIER':
                # polyline.bezier_points.co = (x, y, z)
                polyline.bezier_points.foreach_set("co", strandPoints.ravel())
                polyline.bezier_points.foreach_set('handle_left_type','AUTO')
                polyline.bezier_points.foreach_set('handle_right_type','AUTO')
            else:
                polyline.points.foreach_set("co", strandPoints.ravel())
                # polyline.points[i].co = (x, y, z, 1)
        curveData.resolution_u = self.strandResU
        curveData.dimensions = '3D'
        # create Object
        curveOB = bpy.data.objects.new(particleObj.name+'_curve', curveData)
        curveOB.matrix_world = particleObj.matrix_world
        scn = context.scene
        scn.collection.objects.link(curveOB)
        curveOB.ht_props.target_obj = particleObj.name  # store source surface for snapping oper
        context.view_layer.objects.active = curveOB
        curveOB.select_set(True)
        # curveOB.data.show_normal_face = False
        if self.generateRibbons:
            generate_profile(curveOB, 'OBJECT', strandWidth=self.strandWidth)
            if self.alignToSurface:
                HTOOL_OT_CurvesTiltAlign.align_curve_tilt(
                    context, self.depsgraph, curveOB, self.source_surf_bvh_w, resetTilt=True, onlySelection=False)
            HTOOL_OT_CurvesUVRefresh.uvCurveRefresh(curveOB)
            context.view_layer.objects.active = particleObj
        else:
            curveData.fill_mode = 'FULL'
            curveData.bevel_depth = 0.004 * diagonal
            curveData.bevel_resolution = 2
            bpy.ops.object.curve_taper(TipRadiusFalloff=self.RadiusFalloff, TipRadius=self.TipRadius, MainRadius=self.Radius)
        return {"FINISHED"}



class HTOOL_OT_ParticleHairToCurves(bpy.types.Operator):
    bl_label = "Particle Hair to Curves"
    bl_idname = "object.hair_to_curves"
    bl_description = "Convert active Hair particle system to curves. "
    bl_options = {"REGISTER", "UNDO"} #fixes operator on redo

    hairType: bpy.props.EnumProperty(name="Hair Type", default="NURBS",
                                      items=(("BEZIER", "Bezier", ""),
                                             ("NURBS", "Nurbs", ""),
                                             ("POLY", "Poly", "")))
    particleHairRes: IntProperty(name="Hair Res", description="How many points output curve will build off", default=2, min=0, soft_max=6)
    generateRibbons: BoolProperty(name="Generate Ribbons", description="Generate Ribbons on curve", default=False)
    strandWidth: FloatProperty(name="Strand Width", default=0.5, min=0.0, soft_max=10)
    alignToSurface: BoolProperty(name="Align tilt", description="Align tilt to Surface", default=False)

    def check(self, context):  # DONE: can prop panel be fixed/refreshed when using f6 prop popup
        return True

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.label(text="Curve from Particle Hair Settings:")
        box.prop(self, 'particleHairRes')
        box.prop(self, 'hairType')
        col = box.column(align=True)
        col.prop(self, 'generateRibbons')
        if self.generateRibbons:
            col.prop(self, 'strandWidth')
            col.prop(self, 'alignToSurface')

    def invoke(self, context, event):
        self.active_obj = context.active_object
        self.depsgraph = context.evaluated_depsgraph_get()
        self.obj_eval = context.active_object.evaluated_get(self.depsgraph)
        self.source_surf_bvh_w = get_obj_mesh_bvht(self.obj_eval, self.depsgraph, applyModifiers=True, world_space=True)  # for tilt aliging and other
        return self.execute(context)


    def execute(self, context):
        particleObj = context.active_object
        partsysMod = None
        for mod in particleObj.modifiers:
            if mod.type == 'PARTICLE_SYSTEM':  #  and mod.show_viewport use first visible
                if particleObj.particle_systems.active.name == mod.particle_system.name:
                    if mod.particle_system.settings.type == "HAIR":
                        partsysMod = mod  # use first
                        break
        if partsysMod is None:
            self.report({'INFO'}, 'No active Particle Hair System found')
            return {"CANCELLED"}
        partsysMod.particle_system.settings.display_step = self.particleHairRes
        # partsysMod.particle_system.settings.draw_step = self.particleHairRes

        context.scene.render.hair_subdiv = 1
        bpy.ops.object.modifier_convert(modifier=partsysMod.name)
        generated_hair = context.active_object
        me = generated_hair.data
        bm = bmesh.new()  # create an empty BMesh
        bm.from_mesh(me)
        bm.to_mesh(me)
        bm.free()
        generated_hair.data.transform(particleObj.matrix_world.inverted())  # cos modifier_convert above, applays loc,rot, scale so revert it
        generated_hair.matrix_world = particleObj.matrix_world
        bpy.ops.object.convert(target='CURVE')
        bpy.ops.object.editmode_toggle()
        bpy.ops.curve.select_all(action='SELECT')
        bpy.ops.curve.spline_type_set(type=self.hairType)

        if self.hairType == 'NURBS':
            for polyline in context.active_object.data.splines:
                polyline.order_u = 3  # like bezier thing
                polyline.use_endpoint_u = True
        bpy.ops.object.editmode_toggle()

        generated_hair.data.dimensions = '3D'
        generated_hair.data.fill_mode = 'FULL'
        generated_hair.data.bevel_resolution = 2
        generated_hair.data.resolution_u = 3
        if self.generateRibbons:
            generated_hair.ht_props.target_obj = particleObj.name  # for snapping purpouse
            generate_profile(generated_hair, 'OBJECT', strandWidth=self.strandWidth)
            if self.alignToSurface:
                HTOOL_OT_CurvesTiltAlign.align_curve_tilt(
                    context, self.depsgraph, generated_hair, self.source_surf_bvh_w, resetTilt=True, onlySelection=False)

            HTOOL_OT_CurvesUVRefresh.uvCurveRefresh(generated_hair)

        # partsysMod.show_viewport = False

        return {"FINISHED"}


def getObjectMassCenter(context, obj):
    local_bbox_center = 0.125 * sum((Vector(b) for b in obj.bound_box), Vector())
    global_bbox_center = obj.matrix_world @ local_bbox_center
    region = context.region
    rv3d = context.space_data.region_3d
    return view3d_utils.location_3d_to_region_2d(region, rv3d, global_bbox_center)  # 3d coords to 2d reg


def particle_hair_override(depsgraph, particleObj, pointsList, idx = -1): #todo maybe add resampling some day. cant update from UI. bad poll - edit.particle_hair
    ''' Redraw last strand. What if different pt count. '''
    # depsgraph = bpy.context.evaluated_depsgraph_get()
    depsgraph.update()
    object_eval = particleObj.evaluated_get(depsgraph)
    particle_sys_eval = object_eval.particle_systems.active
    if len(particle_sys_eval.particles[0].hair_keys) == len(pointsList):
        for i, parp in enumerate(pointsList):
            particle_sys_eval.particles[idx].hair_keys[i].co = parp  # wtf why
        bpy.ops.particle.particle_edit_toggle()
        bpy.ops.particle.particle_edit_toggle()


def particleHairFromPoints(context, particleObj, pointsList, extend=False, stick = True):
    ''' Particle system only works on equal len strands. No api for hair_keys with ++ point, or --'''
    particle_sys = None
    context.view_layer.objects.active = particleObj
    for mod in particleObj.modifiers:
        if mod.type == 'PARTICLE_SYSTEM':  # use first visible
            if mod.particle_system.name == particleObj.particle_systems.active.name:
                mod.show_viewport = True
                particle_sys = mod.particle_system
                if particle_sys.is_global_hair and extend:  # prevent jump in there were exising hairs, if they are not connected
                    bpy.ops.particle.connect_hair(all=False)
                depsgraph = bpy.context.evaluated_depsgraph_get()
                particleObj_eval = particleObj.evaluated_get(depsgraph)
                particle_sys_eval = particleObj_eval.particle_systems.active  # use last
                extendList = []
                if extend and mod.particle_system.settings.type == "HAIR":
                    for strand in particle_sys_eval.particles:  # for strand point
                        extendList.append([hair_key.co for hair_key in strand.hair_keys])
                    if len(extendList) > 0:
                        pointsList = interpol_Catmull_Rom_splines(extendList, len(pointsList[0]), uniform_spacing=False, same_point_count=True) + pointsList
                bpy.ops.particle.edited_clear()  #? toogle editability - without cant set particle count
                break
    if particle_sys is None:  # create new one
        print('No active Particle Hair System found! Adding new one')
        particleObj.modifiers.new("Hair_From_Curves", 'PARTICLE_SYSTEM')
        depsgraph = bpy.context.evaluated_depsgraph_get()
        particle_sys = particleObj.particle_systems[-1]
        particle_sys.name = 'Hair_HTool'

    # Create new settings
    particle_sys.settings.type = 'HAIR'
    particle_sys.settings.emit_from = 'FACE'
    particle_sys.settings.use_strand_primitive = True

    hair_len = len(pointsList[0])-1
    particle_sys.settings.hair_step = hair_len  # == HAIR_KEY NUMB
    particle_sys.settings.count = len(pointsList)
    particle_sys.settings.display_step = max(math.floor(math.log(len(pointsList[0]), 2)), 2) + 1
    # partsysMod.name = 'HairFromCurves'

    if not particle_sys.is_edited:
        bpy.ops.particle.particle_edit_toggle()
        bpy.ops.particle.select_all(action='SELECT')
        x, y = getObjectMassCenter(context, particleObj)
        # bpy.context.scene.tool_settings.particle_edit.tool = 'COMB' #! does not work in Modeling layout?
        bpy.ops.wm.tool_set_by_id(name="builtin_brush.Comb")
        if bpy.app.version > (2, 90):
            bpy.ops.particle.brush_edit(  # do 'empty' stroke to generate comb cache
                stroke=[{"name": "", "location": (0, 0, 0), "mouse": (x, y), "pressure": 0, "size": 0, "pen_flip": False, "time": 0, "is_start": False, "mouse_event": (0, 0), "x_tilt": 0, "y_tilt": 0},
                        {"name": "", "location": (0, 0, 0), "mouse": (x + 1, y + 1), "pressure": 0, "size": 0, "pen_flip": False, "time": 0, "is_start": False, "mouse_event": (0, 0), "x_tilt": 0, "y_tilt": 0}])
        else:
            bpy.ops.particle.brush_edit(  # do 'empty' stroke to generate comb cache
                stroke=[{"name": "", "location": (0, 0, 0), "mouse": (x, y), "pressure": 0, "size": 0, "pen_flip": False, "time": 0, "is_start": False},
                        {"name": "", "location": (0, 0, 0), "mouse": (x + 1, y + 1), "pressure": 0, "size": 0, "pen_flip": False, "time": 0, "is_start": False}])
        weights = [i / hair_len for i in range(hair_len, -1, -1)]
        for particle in particle_sys.particles:
            particle.hair_keys.foreach_set('weight', weights)
        bpy.ops.particle.rekey(keys_number=len(pointsList[0]))  # fixes jumping bug and removes doubles
        bpy.ops.particle.select_all(action='DESELECT')
        #sticks the attached curves to head surface
        bpy.ops.particle.particle_edit_toggle()

    #write hair_keys.co
    depsgraph = bpy.context.evaluated_depsgraph_get()
    particleObj_eval = particleObj.evaluated_get(depsgraph)
    particle_sys_eval = particleObj_eval.particle_systems.active
    for i, points in enumerate(pointsList):  # for strand point
        particle_sys_eval.particles[i].location = points[0]
        for j, point in enumerate(points):  # for strand point
            particle_sys_eval.particles[i].hair_keys[j].co = Vector(point)
    #to update hair co's
    bpy.ops.particle.particle_edit_toggle()
    bpy.ops.particle.particle_edit_toggle()
    if stick:
        if not particleObj_eval.particle_systems.active.is_global_hair:
            bpy.ops.particle.disconnect_hair(all=False)
            bpy.ops.particle.connect_hair(all=False)


class HTOOL_OP_ShortenParticles(bpy.types.Operator):
    bl_idname = "particles.scale_particles"
    bl_label = "Scale Hair"
    bl_description = "Shorten/lengthen particle hair length in uniform way"
    bl_options = {"REGISTER","UNDO"}

    method: bpy.props.EnumProperty(name='Method', description='Method',
        items=[
            ('SCALE', 'Scale', 'Scale'),
            ('GROW', 'Grow', 'Grow')], default='SCALE')

    shorten_fac: bpy.props.IntProperty(name='Scale Hair', description='Change particle hair length (and generated curve ribbons length as an result too)',
                                       default=100, min=10, soft_max=200, subtype='PERCENTAGE')

    @classmethod
    def poll(cls, context):
        return context.active_object

    def invoke(self, context, event):
        particleObj = context.active_object
        self.is_interactive_combing = bpy.context.object.ht_props.modal_hair.runModalHair
        self.old_mode = context.mode

        if context.mode == 'PARTICLE': #exit particle edit mode
            bpy.ops.particle.particle_edit_toggle()

        depsgraph = context.evaluated_depsgraph_get()
        obj_eval = particleObj.evaluated_get(depsgraph)
        if bpy.context.active_object.particle_systems is None:  # create new one
            self.report({'INFO'}, 'No active Particle Hair System found!')
            return {"CANCELLED"}

        psys_active = obj_eval.particle_systems.active
        if psys_active.settings.type != 'HAIR':  # create new one
            self.report({'INFO'}, 'Active Particle System is not Hair type! Cancelling')
            return {"CANCELLED"}

        if len(psys_active.particles) == 0:  # require more that three strands
            self.report({'INFO'}, 'Active Particle System has zero strands! Cancelling')
            return {"CANCELLED"}

        factor = self.shorten_fac/100
        self.hair_splines = [SplineSimple.from_vec_list([hair_key.co for hair_key in particle.hair_keys]) for particle in psys_active.particles]

        self.shorten_fac = 100
        bpy.ops.ed.undo_push()  # to prevent restoring curve from step above on execute()
        # return self.execute(context)
        return context.window_manager.invoke_props_dialog(self)

    # def draw(self, context):
    #     layout = self.layout
    #     layout.prop(self, 'method')
    #     layout.prop(self, 'shorten_fac')

    def execute(self, context):
        particleObj = context.active_object
        factor = self.shorten_fac/100
        splines = deepcopy(self.hair_splines) # fix redo

        if self.method == 'SCALE':
            for strand in splines:
                first_co = strand.points[0].co
                for p in strand.points:
                    p.co = first_co+(p.co-first_co)*factor
        else:
            for strand in splines:
                pt_cnt = strand.length
                custom_tns = np.linspace(0, factor, pt_cnt)
                strand.resample_pts(res=pt_cnt, uniform=False, t_custom=custom_tns)

        #write hair_keys.co
        depsgraph = context.evaluated_depsgraph_get()
        particleObj_eval = particleObj.evaluated_get(depsgraph)
        particle_sys_eval = particleObj_eval.particle_systems.active
        for i, strand in enumerate(splines):  # for strand point
            # particle_sys_eval.particles[i].location = points[0]
            for j, point in enumerate(strand.points):  # for strand point
                particle_sys_eval.particles[i].hair_keys[j].co = point.co
        #to update hair co's
        bpy.ops.particle.particle_edit_toggle()
        if self.old_mode != 'PARTICLE': #to object mode,  if we were not in 'Comb mode'
            bpy.ops.particle.particle_edit_toggle()

        if self.is_interactive_combing:
            bpy.context.object.ht_props.modal_hair.runModalHair = True
        # if stick:
        # if not particleObj_eval.particle_systems.active.is_global_hair:
        #     bpy.ops.particle.disconnect_hair(all=False)
        #     bpy.ops.particle.connect_hair(all=False)

        return {"FINISHED"}

class HTOOL_OT_ParticleHairFromCurves(bpy.types.Operator):
    bl_label = "Particle Hair from Curves"
    bl_idname = "object.hair_from_curves"
    bl_description = "Creates particle hair strands from Curves object. \n" \
                     "Two objects need to be selected: one mesh and one curve type"
    bl_options = {"REGISTER", "UNDO"}

    # extend: BoolProperty(name="Append", description="Appends new curves to already existing Particle hair strands", default=True)
    mode: bpy.props.EnumProperty(name='Mode', description='Choose if curves should be added to active particle system or new particles',
                                items=[
                                    ('REPLACE', 'Replace', 'Replace hair strands from particle system'),
                                    ('EXTEND', 'Extend', 'Add hair strands to particle system'),
                                    # ('NEW', 'Create new Particle system', 'Create new particle system add hair to it')
                                ], default='REPLACE')
    affected_psys: bpy.props.EnumProperty(name='Affected Hair System', description='Affect only active particle system or matching target by name',
                                 items=[
                                     ('BY_NAME', 'Match by name', 'Match selected object name with Particle Hair name. I no match - create new hair system with object name'),
                                     ('ACTIVE', 'Use active particle system', 'Affect only active particle hair system')
                                 ], default='ACTIVE')
    stick_to_target: BoolProperty(name="Stick to target", description="Force floating hairs roots to stick to mesh surface", default=True)
    p_hair_res_mode: bpy.props.EnumProperty(name='Resolution', description='Define points count on output strands of Particle Hair System',
        items=[
            ('AUTO', 'Auto', 'Addon will decide if use Max of Fixed output resolution depending on input curve strands resolution'),
            ('MAX', 'Max', 'If input curve strands have different resolutions, use curve with maximum points count for particle hair resolution'),
            ('MIN', 'Min', 'If input curve strands have different resolutions, use curve with minimum points count for particle hair resolution'),
            ('AVERAGE', 'Average', 'If input curve strands have different resolutions, use average points count for particle hair resolution'),
            ('FIXED', 'Fixed', 'Choose yourself how much points assign to output particle hair system')
        ], default='AUTO')
    points_count: bpy.props.IntProperty(name='Points Count', description='How much points assing to particle hair system', default=5, min=3, soft_max=20)

    def draw(self, context):
        layout = self.layout

        split = layout.split(factor=0.3, align=True)
        split.label(text='Affected Hair System:')
        split.prop(self, 'affected_psys', expand=True)

        col = layout.column()
        col.label(text='Mode:')
        row = col.row()
        row.prop(self, 'mode', expand=True)

        col = layout.column()
        col.label(text='Resolution:')
        row = col.row()
        row.prop(self, 'p_hair_res_mode', expand=True)

        # layout.prop(self, 'stick_to_target')
        if self.p_hair_res_mode == 'FIXED':
            layout.prop(self, 'points_count')

    def invoke(self, context, event):
        particleObj = context.active_object
        if particleObj.type != 'MESH':
            self.report({'INFO'}, 'Select mesh object first')
            return {"CANCELLED"}
        return self.execute(context)


    def execute(self, context):
        back_deflect = context.scene.tool_settings.particle_edit.use_emitter_deflect #prevent hair stranigten on scaled objs....
        context.scene.tool_settings.particle_edit.use_emitter_deflect = False
        meshObj = [obj for obj in context.selected_objects if obj.type == 'MESH']
        curveObjs = [obj for obj in context.selected_objects if obj.type == 'CURVE']
        if len(meshObj) == 0 or len(curveObjs) == 0:
            self.report({'INFO'}, 'Select one curve and then mesh that will receive particle hair! Cancelling')
            return {"CANCELLED"}

        particleObj = context.active_object
        merged_strands_lens = []  # 'name', 'points', 'len_list' #for affected_psys 'Active
        merged_strands_points = []

        def recalc_pts(pts, strand_lens):
            if self.p_hair_res_mode == 'AUTO':
                if not np.all(strand_lens == strand_lens[0]):
                    max_len = np.amax(strand_lens)
                    # averLen = int((len(pointsList[0]) + len(pointsList[1])) / 2)  # assume at least two splines?
                    pointsList = interpol_Catmull_Rom_splines(pts, max_len, uniform_spacing=False)
            elif self.p_hair_res_mode == 'MAX':
                pointsList = interpol_Catmull_Rom_splines(pts, np.amax(strand_lens), uniform_spacing=False)
            elif self.p_hair_res_mode == 'MIN':
                pointsList = interpol_Catmull_Rom_splines(pts, np.amin(strand_lens), uniform_spacing=False)
            elif self.p_hair_res_mode == 'AVERAGE':
                pointsList = interpol_Catmull_Rom_splines(pts, int(np.average(strand_lens)), uniform_spacing=False)
            else:
                pointsList = interpol_Catmull_Rom_splines(pts, self.points_count, uniform_spacing=False)
            return pointsList

        for curveObj in curveObjs:
            #wtf undo won't work without this .... extend - if disablend, and then enabled breaks appending old hair (old hair co are all null)
            # bpy.context.scene.update()
            curveData = curveObj.data
            curveData.transform(particleObj.matrix_world.inverted()@curveObj.matrix_world) #to make it go into particle obj space
            pointsList = []
            for polyline in curveData.splines:  # for strand point
                pts = get_curve_points(polyline)
                if len(pts) > 1:
                    pointsList.append(pts)
            curveData.transform(curveObj.matrix_world.inverted() @ particleObj.matrix_world)
            all_strand_len = [len(strand) for strand in pointsList]
            if self.affected_psys == 'ACTIVE': #skip next lines
                merged_strands_lens.extend(all_strand_len)
                merged_strands_points.extend(pointsList)
                continue

            #* since we are matching psystem to obj by name:
            matchFound = False
            for i,particleSystem in enumerate(particleObj.particle_systems):
                if particleSystem.name == curveObj.name:
                    particleObj.particle_systems.active_index = i
                    matchFound = True
                    break

            if not matchFound or len(particleObj.particle_systems)==0:  # No matched Particle Hair System found! Adding new one
                particleObj.modifiers.new(curveObj.name, 'PARTICLE_SYSTEM')
                particleObj.particle_systems[-1].name = curveObj.name
                particleObj.particle_systems.active_index = len(particleObj.particle_systems)-1
                particleObj.data.update()
                depsgraph = bpy.context.evaluated_depsgraph_get()
                depsgraph.update()
                # particleObj.particle_systems.update()

            pointsList = recalc_pts(pointsList, all_strand_len)
            particleHairFromPoints(context, particleObj, pointsList, extend=self.mode == 'EXTEND', stick=self.stick_to_target)

        if self.affected_psys == 'ACTIVE':
            pointsList = recalc_pts(merged_strands_points, merged_strands_lens)
            if len(particleObj.particle_systems) == 0:  # No matched Particle Hair System found! Adding new one
                particleObj.modifiers.new('ParticleFromCurves', 'PARTICLE_SYSTEM')
                particleObj.particle_systems[-1].name = 'ParticleFromCurves'
                particleObj.particle_systems.active_index = len(particleObj.particle_systems)-1
                particleObj.data.update()
                depsgraph = bpy.context.evaluated_depsgraph_get()
                depsgraph.update()
                # particleObj.particle_systems.update()
            particleHairFromPoints(context, particleObj, pointsList, extend=self.mode == 'EXTEND', stick=self.stick_to_target)

        context.scene.tool_settings.particle_edit.use_emitter_deflect = back_deflect
        return {"FINISHED"}
