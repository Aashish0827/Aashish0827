# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
# Copyright (C) 2017 JOSECONSCO
# Created by JOSECONSCO

import math
import traceback
import random

import bgl
import bpy
import gpu
from copy import copy, deepcopy
from bpy.props import (BoolProperty, EnumProperty, FloatProperty, IntProperty, StringProperty)
from bpy_extras import view3d_utils
from gpu_extras.batch import batch_for_shader
from mathutils import Vector
from mathutils.geometry import barycentric_transform
from .utils.curve_wrapper import SplineFlat, get_tips_pts
from .curve_simplify import simplify_RDP

from .hair_curve_helpers import HTOOL_OT_CurvesTiltAlign, HTOOL_OT_EmbedRoots
from .utils.helper_functions import calc_exponent, get_obj_mesh_bvht, calc_pow_inverted, calc_pow, gold_random
from .utils.general_utils import create_new_curve_obj, get_addon_preferences
import numpy as np
from .particle_hair import particleHairFromPoints, particle_hair_override
from .resample2d import  interpol_Catmull_Rom_splines
from .material_operators import HTOOL_OT_AssignRegionsFromObjProps, HTOOL_OT_CurvesUVRefresh
from .profile_operations import generate_profile, update_profile


addon_keymaps = []

def change_draw_keymap(enable_draw_hair):
    global addon_keymaps
    wm = bpy.context.window_manager
    gpencil_keymap = wm.keyconfigs.user.keymaps.get('Grease Pencil')  # Get hotkeys from the currently used keyconfig
    if gpencil_keymap is None:
        # print("HTool - cant override 'Grease Pencil' keymap. Cancelling")
        return
    obj_mode_keymap = wm.keyconfigs.user.keymaps.get('Object Mode')

    if enable_draw_hair:
        target_key = gpencil_keymap.keymap_items.get('gpencil.annotate')  # Specify the operation of which to retrieve the hotkey
        if target_key:  # override defalt gp draw hotkey (first get it from keymap)
            target_key.active = False
        # else:  # industry standard does not have keymaps.get('Grease Pencil')
        km = wm.keyconfigs.user.keymaps['3D View']
        kmi = km.keymap_items.get('object.draw_hair_surf')
        if kmi:
            kmi.active = True
        # addon_keymaps.append((km, kmi))

        #industry standard fix
        if obj_mode_keymap:
            for keymap_item in obj_mode_keymap.keymap_items:
                if keymap_item.idname == 'wm.tool_set_by_id' and keymap_item.properties['name'] == 'builtin.annotate':
                    keymap_item.active = False
        if bpy.context.workspace.tools.from_space_view3d_mode(mode=bpy.context.mode).idname in ["builtin.cursor", "builtin.annotate"]:
            bpy.ops.wm.tool_set_by_id(name='builtin.select_box')
    else:
        km = wm.keyconfigs.user.keymaps['3D View']
        kmi = km.keymap_items.get('object.draw_hair_surf')
        if kmi:
            kmi.active = False

        target_key = gpencil_keymap.keymap_items.get('gpencil.annotate')  # Specify the operation of which to retrieve the hotkey
        if target_key:
            target_key.active = True

        if obj_mode_keymap:
            for keymap_item in obj_mode_keymap.keymap_items:
                if keymap_item.idname == 'wm.tool_set_by_id' and keymap_item.properties['name'] == 'builtin.annotate':
                    keymap_item.active = True

class HT_OT_ClearCache(bpy.types.Operator):
    bl_idname = "object.clear_cache"
    bl_label = "Clear snapping cache"
    bl_description = "Clears BVHT data required for stroke snapping.\nUse when drawing target object is modified, and you get bad result when drawing. After that addon will generate new cache as soon as you draw new stroke."
    bl_options = {"REGISTER","UNDO"}

    def execute(self, context):
        global GLOBAL_BVHT
        GLOBAL_BVHT.clear()
        return {"FINISHED"}


MAT_UVS = []
class ModalDrawingSettings(bpy.types.PropertyGroup):
    def modalHairCheck(self, context):
        change_draw_keymap(self['runModalHair'])
        if not self['runModalHair']:
            global GLOBAL_BVHT
            GLOBAL_BVHT.clear()
            context.scene.last_stroke.clear()
        else:
            bpy.ops.wm.tool_set_by_id(name="hair_tool.hair_transform")

    def reset_cache(self, context):
        global GLOBAL_BVHT
        GLOBAL_BVHT.clear()
        self['reset_bvh_cache'] = False
        print('Snapping cache cleared')

    def get_width(self):
        return bpy.context.active_object.ht_props.profile_props.strandWidth

    def set_width(self, value):
        bpy.context.active_object.ht_props.profile_props.strandWidth = value

    def update_width(self, context):
        obj = context.active_object
        if obj.type !='CURVE':
            return
        if self.target_type == 'CURVE_RIBBON':
            update_profile(obj, strandWidth=self.profile_width)
        else:
            obj.data.bevel_depth = self.profile_width

    def update_last(self, context):
        if not self.extend:
            bpy.ops.object.draw_hair_surf('INVOKE_DEFAULT', update_strand=True)

    def update_uv(self, context):
        if context.active_object and context.active_object.type == 'CURVE':
            context.active_object.ht_props['use_auto_uv'] = self.use_auto_uv
            if self.use_auto_uv:
                HTOOL_OT_AssignRegionsFromObjProps.update_assigned_uv_regions(context.active_object)

    def set_no_change(self, value):
        self["warning"] = False

    def extend_toggle(self, context):
        if self['extend']:
            bpy.ops.wm.tool_set_by_id(name="hair_tool.hair_transform")
            self.runModalHair = True

    def uv_items(self, context):
        global MAT_UVS
        obj = context.active_object
        # mat_uv = [('AUTO', 'Auto', 'Assign uv automatically')]
        mat_uv = []
        RandomFlipX = get_addon_preferences().flipUVRandom
        if obj and obj.material_slots and obj.material_slots[0].material:
            uvHairPoints = obj.material_slots[0].material.ht_props.hair_uv_points
            pts_cnt = len(uvHairPoints)
            for i in range(pts_cnt):
                idx = i*2 if RandomFlipX else i
                mat_uv.append((f"{idx}", f"{i} box", f"Use uv box: {i}"))
                if RandomFlipX:
                    mat_uv.append((f"{idx+1}", f"{i} box (mirrored)", f"Use uv box: {i} mirrored"))
        if MAT_UVS != mat_uv:
            MAT_UVS = mat_uv
        return MAT_UVS

    def switch_profile(self, context):
        if self.set_profile != 'KEEP':
            active_obj = context.active_object
            if active_obj.type == 'CURVE':
                generate_profile(active_obj, self.set_profile, strandWidth=self.profile_width)

    runModalHair: BoolProperty(name="Draw hair",
                               description="Draw hair on mesh surface, while holding D - key", default=False, update=modalHairCheck)
    extend: bpy.props.BoolProperty(name='Extend Strand', description='Extend selected strands when drawing', default=False, update=extend_toggle)
    spline_type: bpy.props.EnumProperty(name="Curve", default="NURBS",
                                     items=(("BEZIER", "Bezier", ""),
                                            ("NURBS", "Nurbs", ""),
                                            ("POLY", "Poly", "")))

    target_type: bpy.props.EnumProperty(name="Target", default="CURVE_RIBBON",
                                        items=(("CURVE", "Curves", "Generate curve ribbons"),
                                          ("CURVE_RIBBON", "Curve Ribbons", "Generate curve"),
                                          ("PARTICLE", "Particle Hair", "Generate Particle hair")))
    surface_snap: bpy.props.BoolProperty(name="Surface Snapping", default=True, description="Project strands on target surface")
    trace_mode: bpy.props.EnumProperty(name="Trace Mode", default="SIMPLE", description="Defines how extended strands will follow drawn stroke",
                                        items=(("SIMPLE", "Simple", "Each extended strand will follow drawn stroke in same linear way"),
                                          ("GUIDE", "Guided", "Drawn stroke will behave as guide for extended strands")))
    use_auto_uv: bpy.props.BoolProperty(name="Auto UV", default=True, description="Assign uv automatically to drawn strand.\nDetailed setup can be done under UV Image Editor->Right Sidebar->Hair Tool UV Tab", update=update_uv)
    uv_regions: bpy.props.EnumProperty(name='Pick UV box', description='Pick UVs that will be assigned to drawn strand',
                                    items=uv_items, update=update_last, options={'ENUM_FLAG'})

    offset_tip: FloatProperty(name="Offset to tip", description="Move spline points more toward tip", default=0, min=0, max=1, subtype='PERCENTAGE', update=update_last)
    offset_root: FloatProperty(name="Offset to root", description="Move spline points more toward root", default=0.3, min=0, max=1, subtype='PERCENTAGE', update=update_last)

    points_sampling: bpy.props.EnumProperty(name="Resolution", default="FIXED",
                                            items=(("FIXED", "Fixed Resolution", "Number of points per strand"),
                                                   ("ADAPTIVE", "Adaptive Resolution", "Number of points depends on strand length")),
                                                   update=update_last)
    points_count: IntProperty(name="Points", description="How many points generate for each spline", default=6, min=3, soft_max=20, update=update_last)
    points_count_extend: IntProperty(name="Points", description="How many points generate for each spline", default=6, min=3, soft_max=20, update=update_last)
    adaptive_error: IntProperty(name="Reduction", description="Bigger values give simpler strands (less output points)", default=10, max=100, min=5, subtype='PERCENTAGE', update=update_last)
    target_spline_len: FloatProperty(name="Max length", description="Maximum hair length (0 - disabled)\nStrand length will be clipped to this value.", default=0.0,
                                     min=0, soft_max=0.5, update=update_last)
    elevation_fallof: FloatProperty(name="Elevation falloff", description="Elevation strength over strand length", default=0.0,
                                    min=-1, max=1, update=update_last)
    elevate_above: FloatProperty(name="Elevation distance", description="Elevation strands above surface by this distance", default=0.2,
                                 min=0.01, soft_max=1.0, update=update_last)
    embedValue: FloatProperty(name="Embed Roots Depth", description="Move strands first point into mesh surface", default=0, min=0, soft_max=10, update=update_last)
    use_pressure: BoolProperty(name="Use Pressure", description="Use pen pressure to change strand width", default=True, update=update_last)
    alignToSurface: BoolProperty(name="Align tilt", description="Align tilt to Surface", default=True, update=update_last)
    profile_width: FloatProperty(name="Profile width", description="Profile width - affects all strands profle width", default=0.5, min=0.0, soft_max=10, set=set_width, get=get_width, update=update_width)
    strand_radius: FloatProperty(name="Strand Radius", description="Per strand radius (default 1)", default=1.0, min=0.0, soft_max=10, update=update_last)
    set_profile: bpy.props.EnumProperty(name='Profile', description='',
                                        items=[
                                            ('ROUND', 'Round', 'Curves will have cylindrical profile'),
                                            ('OBJECT', 'Flat', 'Curves will have flat (ribbon) profile'),
                                            ('KEEP', 'Use Current', 'Do not change current curve profile')
                                        ], default='OBJECT', update=switch_profile)

    reset_bvh_cache: BoolProperty(name="Reset cache", description="Reset snapping cache (usefull when drawn strands are not showing in proper places)", default=False, update=reset_cache)
    # update_strand: BoolProperty(name="Update last stroke", description="Update last stroke", default=False, update=redraw_up)
    # warning: BoolProperty(name="No last stroke data", description="No last stroke data", default=False, set=set_no_change)


class HTOOL_PT_DrawingCurvesPanel(bpy.types.Panel):
    bl_label = "Draw Hair"
    bl_idname = "HTOOL_PT_DrawingCurvesPanel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_options = {'DEFAULT_CLOSED'}
    bl_category = 'Hair Tool'
    bl_context = 'objectmode'

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type in {'CURVE', 'MESH'}

    def draw(self, context):
        draw_props = context.scene.ht_props.hair_drawing
        layout = self.layout

        col = layout.column(align=True)
        row = col.row(align=True)
        row.prop(draw_props, 'runModalHair', icon='HAIR')
        row.operator('object.clear_cache', text='', icon="FILE_REFRESH")

        if context.active_object.type == 'CURVE':
            col.prop(draw_props, 'extend', icon='DECORATE_LINKED')
        if draw_props.runModalHair:
            col = layout.column(align=True)
            extend_is_possible = draw_props.extend and context.active_object.type == 'CURVE'
            if not extend_is_possible:
                col.prop(draw_props, 'target_type')
            else:
                split = col.split(factor=0.5, align=True)
                split.label(text="Trace Mode")
                split.prop(draw_props, 'trace_mode', text='')

            if draw_props.target_type in {'CURVE', 'CURVE_RIBBON'}:
                if not extend_is_possible:
                    if draw_props.target_type == 'CURVE_RIBBON':
                        row = layout.row(align=True)
                        row.prop(draw_props, 'use_auto_uv', emboss=True, icon='UV_ISLANDSEL')
                        if not draw_props.use_auto_uv:
                            row.prop_menu_enum(draw_props, 'uv_regions')
                    col.prop(draw_props, 'spline_type')
                if draw_props.target_type == 'CURVE_RIBBON':
                    col.prop(draw_props, 'set_profile')

            col.prop(draw_props, 'surface_snap', icon="SNAP_ON")
            if draw_props.target_type in {'CURVE_RIBBON', 'CURVE'}:
                col.prop(draw_props, 'profile_width')
                col.prop(draw_props, 'strand_radius')

            col = layout.column(align=True)
            if draw_props.target_type != 'PARTICLE':
                col.prop(draw_props, 'points_sampling', text="")
            if draw_props.points_sampling == 'FIXED' or draw_props.target_type == 'PARTICLE':
                if draw_props.extend:
                    col.prop(draw_props, 'points_count_extend')
                else:
                    col.prop(draw_props, 'points_count')
            else:
                col.prop(draw_props, 'adaptive_error')

            if draw_props.target_type == 'PARTICLE' or not extend_is_possible:
                # col = layout.column(align=True)
                # col.prop(draw_props, 'offset_tip')
                # col.prop(draw_props, 'offset_root')
                if draw_props.target_type in {'CURVE', 'CURVE_RIBBON'}:
                    col = layout.column(align=True)
                    col.prop(draw_props, 'embedValue')
                if draw_props.surface_snap:
                    col = layout.column(align=True)
                    col.prop(draw_props, 'elevate_above')
                    col.prop(draw_props, 'elevation_fallof')
                col = layout.column(align=True)
                col.prop(draw_props, 'target_spline_len')

            if draw_props.target_type in {'CURVE', 'CURVE_RIBBON'}:
                col = layout.column(align=True)
                col.prop(draw_props, 'use_pressure', icon='STYLUS_PRESSURE')
                if draw_props.target_type == 'CURVE_RIBBON':
                    col.prop(draw_props, 'alignToSurface', icon="SNAP_NORMAL")

shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
shader_2d = gpu.shader.from_builtin('2D_UNIFORM_COLOR')


def draw_lines_callback_po(self, context):
    bgl.glLineWidth(3.0)
    if self.stored_points:
        batch = batch_for_shader(shader_2d, 'LINE_STRIP', {"pos": self.stored_points})
        shader_2d.bind()
        shader_2d.uniform_float("color", (1, 0.5, 0, 1))
        batch.draw(shader_2d)
    bgl.glLineWidth(1)


GLOBAL_BVHT = {}

class HTOOL_OT_ModalDrawHair(bpy.types.Operator):
    """Draw a line with the mouse"""
    bl_idname = "object.draw_hair_surf"
    bl_label = "Draw Hair on mesh"
    bl_description = "Draw Hair on mesh surface. \\n" \
                     "If you have curve object selected, new strokes will be appended to this curve \\n" \
                     "otherwise if mesh is selected new curve hair will be created."
    bl_options = {"REGISTER", "UNDO"}

    update_strand: bpy.props.BoolProperty(name='update_strand', default=False)

    @staticmethod
    def trim_spline_to_len(points, target_len):
        '''Return points spacing len '''
        strand_len = 0
        previous_point = points[0]
        for i,point in enumerate(points):
            point_diff_vec = Vector(point) - Vector(previous_point)
            previous_point = point
            strand_len += point_diff_vec.length
            if strand_len > target_len:
                return points[:max(4,(i+1))]
        return points

    def snap_points(self, context):
        """Run this function on left mouse, execute the ray cast"""
        region = context.region
        rv3d = context.region_data
        # ray_target = ray_origin + view_vector
        draw_props = context.scene.ht_props.hair_drawing
        ret_points_3d = []

        def obj_ray_cast(view_vector, ray_origin, point, pt_id):
            location, normal, face_index, depth = self.snap_surface_BVHT.ray_cast(ray_origin, view_vector)
            # success, location, normal, face_index = obj.ray_cast(ray_origin_obj, ray_direction_obj) #works in local space
            if location and (draw_props.surface_snap or pt_id == 0):  # first pt_id always is glued to surface
                return location, normal, face_index
            else:
                depth_location = ret_points_3d[-1] if pt_id > 0 else Vector((0, 0, 0))
                location_from_2d = view3d_utils.region_2d_to_location_3d(region, rv3d, point, depth_location)
                return location_from_2d, None, None

        for i, point in enumerate(self.stored_points):
            view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, point)
            ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, point)

            hit_loc_world, _, _ = obj_ray_cast(view_vector, ray_origin, point, i)  # hit_loc_world, normal, face_index
            ret_points_3d.append(hit_loc_world)  # save as vec
        return ret_points_3d

    def extend_snap_points(self, context, tip_pt_co, TNs):
        """for given spl tip, extend it using 2d self.stored_points
        May use TN (tangent, normal) frame for stroke tip calc along drawn path
        """
        region = context.region
        rv3d = context.region_data
        draw_props = context.scene.ht_props.hair_drawing
        stroke_root = self.stored_points[0]

        tip_pt_co_2d = view3d_utils.location_3d_to_region_2d(region, rv3d, tip_pt_co, default=None)
        diff_screen_space = tip_pt_co_2d - stroke_root  # vec from drawn line begining to last drawn stroke tip

        first_tn = TNs[0]  # for  'GUIDE' mode
        tip_in_tris_frame = (tip_pt_co_2d - stroke_root).to_3d()
        zero_pt = Vector((0,0,0))

        depth = tip_pt_co
        extended_pts = []
        for stroke_pt, tn in zip(self.stored_points, TNs):
            if draw_props.trace_mode == 'GUIDE':
                #* transform from first seg frame, to current seg frame using barycentric_transform
                framed_point = barycentric_transform(tip_in_tris_frame, zero_pt, first_tn[0], first_tn[1],
                                                                                zero_pt, tn[0],     tn[1])
                point_from_tip = framed_point.xy + stroke_pt  # now drawn stroke is rooted from tip_pt_co
            else: #* 'SIMPLE'  follow mode
                point_from_tip = stroke_pt + diff_screen_space  # now drawn stroke is rooted from tip_pt_co

            location3d_from_2d = view3d_utils.region_2d_to_location_3d(region, rv3d, point_from_tip, depth)
            if draw_props.surface_snap:
                hit_loc_world, normal, face_index, dist = self.snap_surface_BVHT.find_nearest(location3d_from_2d)
            else:
                hit_loc_world = location3d_from_2d
            extended_pts.append(hit_loc_world) # save as vec
        return extended_pts

    def calculate_2d_frame(self, curve_2d):
        '''return tangetns and normal for 2d curve'''
        prev = curve_2d[0]
        Ts = []
        Ns = []
        for pt in curve_2d[1:]: #to_3d for barycentric transform
            Ts.append((pt-prev).normalized().to_3d())
            Ns.append(Vector((Ts[-1].y, -Ts[-1].x, 0)))
            prev = pt
        Ts.append(Ts[-1]) #for last point just copy prev
        Ns.append(Ns[-1])
        return list(zip(Ts, Ns))


    def extend_strand_write(self, context):
        draw_props = context.scene.ht_props.hair_drawing
        spl_ids, points, out_co = get_tips_pts(context, self.curve_hair, world_space=True, only_sel=True)
        matInvCurve = self.curve_hair.matrix_world.inverted() if draw_props.target_type in {'CURVE', 'CURVE_RIBBON'} else self.snap_surface.matrix_world.inverted()
        #get tangent, and bitangents only for 'GUIDED' follow mode
        TNs = self.calculate_2d_frame(self.stored_points) if draw_props.trace_mode == 'GUIDE' else [1]*len(self.stored_points)
        err = draw_props.adaptive_error/10
        for spl_id, tip_pt, tip_pt_co in zip(spl_ids, points, out_co):
            extend_snap_points = self.extend_snap_points(context, tip_pt_co, TNs)
            # if draw_props.target_spline_len > 0:
            #     extend_snap_points = self.trim_spline_to_len(extend_snap_points, draw_props.target_spline_len)
            if draw_props.points_sampling == 'FIXED' or draw_props.target_type == "PARTICLE":
                pts_cnt = draw_props.points_count_extend if draw_props.extend else draw_props.points_count
                points_resampled = interpol_Catmull_Rom_splines([extend_snap_points], pts_cnt, uniform_spacing=True)[0]
            else:
                simp_pids = simplify_RDP(extend_snap_points, error=err)
                points_resampled = [extend_snap_points[i] for i in simp_pids]

            # pt_proj, nrm, _, elevation_dist = self.snap_surface_BVHT.find_nearest(tip_pt_co, 100)
            to_tip_offset_3d = tip_pt_co - points_resampled[0]
            for i, new_point in enumerate(points_resampled):
                if self.snap_surface_BVHT and draw_props.surface_snap:
                    elevate_above = new_point +  to_tip_offset_3d  #elevation_dist
                    points_resampled[i] = matInvCurve @ elevate_above
                else:
                    points_resampled[i] = matInvCurve @ new_point

            #* write to curve or particle hair
            old_spl = SplineFlat(self.curve_hair.data.splines[spl_id], orig_spl_id=spl_id)
            old_spl.points_co = np.append(old_spl.points_co[:, :3], np.array(points_resampled[1:], 'f'), axis=0)
            old_spl.write_to_blender_spl(self.curve_hair)

        self.select_pts(spl_ids=spl_ids)
        if draw_props.alignToSurface and self.snap_surface is not None:
            HTOOL_OT_CurvesTiltAlign.align_curve_tilt(context, self.depsgraph, self.curve_hair, self.snap_surface_BVHT, resetTilt=True, onlySelection=True)
         #? no p_hair support - they ony work with same pts count


    def new_strand_write(self, context):
        #self.snap_surfac - in case of particle hair - this is target_type obj
        draw_props = context.scene.ht_props.hair_drawing
        points_count = draw_props.points_count
        #* write to cache, or read from cache on redo
        if self.update_strand:
            if draw_props.target_type in {'CURVE', 'CURVE_RIBBON'}:
                read_id = len(self.curve_hair.data.splines)-1
            else:
                read_id = len(self.snap_surface.particle_systems.active.particles)-1 if self.snap_surface.particle_systems.active else -1
            if read_id in context.scene.last_stroke:
                snapped_points_3d = deepcopy(context.scene.last_stroke[read_id]['points'])
                self.stored_pressure = context.scene.last_stroke[read_id]['pressure']
            else:
                print(f'No cache for strand id: {read_id}')
                return
        else:
            if draw_props.target_type in {'CURVE', 'CURVE_RIBBON'}:
                write_id = len(self.curve_hair.data.splines)-1
            else:
                write_id = len(self.snap_surface.particle_systems.active.particles) if self.snap_surface.particle_systems.active else 0
            snapped_points_3d = self.snap_points(context)  # snap 2d self.stored_points and make them  3d
            context.scene.last_stroke[write_id] = {}
            context.scene.last_stroke[write_id]['points'] = [p.copy() for p in snapped_points_3d]
            context.scene.last_stroke[write_id]['pressure'] = copy(self.stored_pressure)
            context.scene.last_stroke['obj_name'] = self.curve_hair.name if draw_props.target_type in {'CURVE', 'CURVE_RIBBON'} else self.snap_surface.name

        if draw_props.target_spline_len > 0:
            snapped_points_3d = self.trim_spline_to_len(snapped_points_3d, draw_props.target_spline_len)

        #* then rasample for uniform spacing
        offset_tip = calc_pow_inverted(max(-1*draw_props.elevation_fallof, 0)+1, len(snapped_points_3d))  # offset tip if neg fallof
        offset_root_tip = np.power(offset_tip, max(draw_props.elevation_fallof, 0)+1)   # offset root if pos fallof
        cnt = len(snapped_points_3d)
        reduced_pts_cnt = math.ceil(math.sqrt(cnt)+0.5*cnt)
        points_uniform = interpol_Catmull_Rom_splines([snapped_points_3d], reduced_pts_cnt, uniform_spacing=True, tn_fallof=offset_root_tip)[0]

        #* then project on target
        cpow = calc_exponent(-1*draw_props.elevation_fallof/2)
        matInvCurve = self.curve_hair.matrix_world.inverted() if draw_props.target_type in {'CURVE', 'CURVE_RIBBON'} else self.snap_surface.matrix_world.inverted()
        elevation_fallof = calc_pow(cpow, len(points_uniform))  # 0.1 to give 1% of influence on root
        snapped_points_3d = []
        for i, point in enumerate(points_uniform):
            if self.snap_surface_BVHT and draw_props.surface_snap:
                # elevation_fallof = math.pow(i / points_count, cpow)  # 0.1 to give 1% of influence on root
                snappedPoint, normalSourceSurf, index, distance = self.snap_surface_BVHT.find_nearest(point, 100)
                elevate_above = point + draw_props.elevate_above * normalSourceSurf * elevation_fallof[i]
                snapped_points_3d.append(matInvCurve @ elevate_above)
            else:
                snapped_points_3d.append(matInvCurve @ point)

        #* finally resamplte to target pt coutn, or auto res
        # offset_root_tip_tns = None
        # if draw_props.offset_tip or draw_props.offset_root: #* done automaticly now from elevation_fallof
        #     offset_tip_tns = calc_pow_inverted(draw_props.offset_tip+1, draw_props.points_count)
        #     offset_root_tip_tns = np.power(offset_tip_tns, 2*draw_props.offset_root+1)
        offset_root_tip_tns = None
        err = draw_props.adaptive_error/10
        if draw_props.points_sampling == 'FIXED' or draw_props.target_type == "PARTICLE":
            points_resampled = interpol_Catmull_Rom_splines([snapped_points_3d], points_count, uniform_spacing=False, tn_fallof=offset_root_tip_tns)[0]
        else:
            simp_pids = simplify_RDP(snapped_points_3d, error=err)
            points_resampled = [snapped_points_3d[i] for i in simp_pids]
            #? make spl nice with uniform resample
            # offset_tip_tns = calc_pow_inverted(draw_props.offset_tip+1, draw_props.points_count)
            # offset_root_tip_tns = np.power(offset_tip_tns, 2*draw_props.offset_root+1)
            # points_resampled = interpol_Catmull_Rom_splines([points_resampled], len(points_resampled), uniform_spacing=True)[0]

        #* write to curve or particle hair
        if draw_props.target_type in {'CURVE', 'CURVE_RIBBON'}:
            write_spl_w = SplineFlat().from_vec_list(points_resampled)
            write_spl_w.orig_spl_type = draw_props.spline_type
            np_rad = np.array(self.stored_pressure[:])
            if draw_props.use_pressure:
                if np.all(np_rad==1): #if pressure enabled, but no pressure on stroke, then fade <1; 0>
                    np_rad = np.array([1, 1, 0])  # fade from 1, to 0
                else:
                    np_rad[-1] = 0
            write_spl_w.points_radii = np_rad * draw_props.strand_radius

            write_spl_w.write_to_blender_spl(self.curve_hair, spl_id=-1)
            last_id = len(self.curve_hair.data.splines)-1
            self.select_pts(spl_ids=[last_id])

            if draw_props.embedValue > 0:  # no embed if extending
                HTOOL_OT_EmbedRoots.embed_strands_roots(context, self.curve_hair, self.snap_surface_BVHT,  embed=draw_props.embedValue, onlySelection=True)
            if draw_props.target_type == 'CURVE_RIBBON':
                if self.init_profile:
                    bevel_type = 'OBJECT' if draw_props.set_profile == 'KEEP' else draw_props.set_profile # use flat profile as backup
                    if 'diagonal' not in self.curve_hair.keys():  # or else it may happen - profille * digonal == 0
                        self.curve_hair['diagonal'] = float(write_spl_w.euclidean_len)
                    generate_profile(self.curve_hair, bevel_type, strandWidth=draw_props.profile_width)
                    self.init_profile = False
                self.ub_box_assingn_update(draw_props)
                if draw_props.alignToSurface and self.snap_surface is not None:
                    self.depsgraph.update()  # for alignign to work properly
                    HTOOL_OT_CurvesTiltAlign.align_curve_tilt(context, self.depsgraph, self.curve_hair, self.snap_surface_BVHT, resetTilt=True, onlySelection=True)

        else:
            if self.update_strand:
                particle_hair_override(self.depsgraph, self.snap_surface, points_resampled)
                self.snap_surface.particle_systems.active.settings.display_step = max(math.floor(math.log(points_count, 2)), 2) + 1
            else:
                particleHairFromPoints(context, self.snap_surface, [points_resampled], extend=True)

    def select_pts(self, spl_ids):
        for i in range(len(self.curve_hair.data.splines)):
            spl = self.curve_hair.data.splines[i]
            select = i in spl_ids
            if spl.type == 'BEZIER':
                for p in spl.bezier_points:
                    p.select_control_point = select
            else:
                for p in spl.points:
                    p.select = select

    def ub_box_assingn_update(self, draw_props):
        edited_spl_id = len(self.curve_hair.data.splines)-1
        mat_count = len(self.curve_hair.data.materials)
        # np.random.seed(data_o.ht_props.uv_seed)
        if mat_count > 1:
            if draw_props.use_auto_uv:
                self.curve_hair.ht_props['use_auto_uv'] = True
                HTOOL_OT_AssignRegionsFromObjProps.update_assigned_uv_regions(self.curve_hair)
                # uv_box_id = divmod(edited_spl_id+np.random.randint(mat_count), mat_count)[1]  # pick randomm material

            else:
                boxes = [int(box) for box in draw_props.uv_regions]
                if not boxes:
                    boxes = [i for i in range(mat_count)]
                idx = int(gold_random(edited_spl_id, seed=1)*len(boxes))
                self.curve_hair.data.splines[-1].material_index = boxes[idx]
        elif mat_count == 0:
            HTOOL_OT_CurvesUVRefresh.uvCurveRefresh(self.curve_hair)

    @staticmethod
    def smooth_vecs(pts):
        #we to np, and back to vec
        np_pts = np.array(pts, 'f')
        for i in range(2):
            avg = (np_pts[2:, :] + np_pts[:-2, :] + 4*np_pts[1:-1, :]) / 6
            np_pts[1:-1, :] = avg
        return [Vector(p) for p in np_pts.tolist()]

    def modal(self, context, event):
        draw_props = context.scene.ht_props.hair_drawing
        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'}:
            return {'PASS_THROUGH'}

        if event.type == 'MOUSEMOVE':
            if self.lmb:
                pt_candidate = Vector((event.mouse_region_x, event.mouse_region_y))
                if not self.stored_points or (self.stored_points[-1]-pt_candidate).length > 12:
                    self.stored_points.append(Vector((event.mouse_region_x, event.mouse_region_y)))  # save as vec
                    self.stored_pressure.append(event.pressure if draw_props.use_pressure else 1)  # save as vec
                # if draw_props.target_type in {'CURVE', 'CURVE_RIBBON'} and len(self.stored_points) > 3: #? too slow on heavy meshes
                #     if draw_props.extend:
                #         self.extend_strand_write(context)
                #     else:
                #         self.new_strand_write(context)
                context.area.tag_redraw()

        elif event.type == 'LEFTMOUSE':
            if event.value == 'RELEASE':
                if len(self.stored_points) > 3:
                    try:
                        context.scene.last_stroke['extend'] = draw_props.extend
                        self.stored_points = self.smooth_vecs(self.stored_points)
                        if draw_props.extend:
                            self.extend_strand_write(context)
                        else:
                            self.new_strand_write(context)
                    except Exception as e:
                        self.report({'ERROR'}, f'Execution error: {e}')
                        traceback.print_exc()
                        bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
                        return {'CANCELLED'}
                self.stored_points.clear()
                self.stored_pressure.clear()
                bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
                context.area.tag_redraw()
                return {'FINISHED'}

        elif event.ctrl and event.type == 'Z' and event.value == 'PRESS':
            self.curve_hair.data.splines.remove(self.curve_hair.data.splines[-1])
            self.curve_hair.update_tag()
            context.area.tag_redraw()

        elif event.type in {'RET'}:
            bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
            context.area.tag_redraw()
            return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}


    def invoke(self, context, event):
        active_obj = context.active_object if context.active_object else None
        if not active_obj:
            self.report({'INFO'}, 'Select curve or mesh object first!')
            return {"CANCELLED"}

        self.stored_points = []
        self.stored_pressure = []
        self.lmb = True

        draw_props = context.scene.ht_props.hair_drawing
        if active_obj.type != 'CURVE':
            draw_props.extend = False
        self.init_profile = False # should we generate a profile
        if draw_props.target_type in {'CURVE', 'CURVE_RIBBON'}:
            bpy.ops.wm.tool_set_by_id(name="hair_tool.hair_transform")
            if draw_props.extend:
                if active_obj.type != 'CURVE':
                    self.report({'ERROR'}, f'Extend drawing only works on curves. Cancelling')
                    return {'CANCELLED'}

            if active_obj.type == 'MESH':  # snap to this mesh, create curve hair
                draw_props.extend = False
                self.init_profile = True
                curve = create_new_curve_obj(active_obj.name+'_hair', active_obj) #selects is
                curve.data.bevel_depth = 0.004
                curve.matrix_world = active_obj.matrix_world
                # bpy.context.scene.update()
                curve.ht_props.target_obj = active_obj.name

            if active_obj.type == 'CURVE':  # curve is selected so use it
                curve = context.active_object
                if not curve.ht_props.target_obj:
                    self.report({'INFO'}, 'Select curve has not target to snap to!  Cancelling!')
                    return {"CANCELLED"}

            snapSurface = None
            if not (self.update_strand or draw_props.extend): #new spline only if drawin new stroke
                curve.data.splines.new(draw_props.spline_type)

            if curve.ht_props.target_obj and curve.ht_props.target_obj in bpy.data.objects.keys():
                snapSurface = bpy.data.objects[curve.ht_props.target_obj]
            else:
                if active_obj and active_obj.type == 'MESH':
                    snapSurface = active_obj
                    curve.ht_props.target_obj = active_obj.name
            if snapSurface is None:
                self.report({'INFO'}, 'There is no target to draw hair on! Cancelling!')
                print('There is no target to draw hair on! Select mesh obj, or hair curve ribbons with target object set')
                return {"CANCELLED"}

            self.curve_hair = curve
            self.snap_surface = snapSurface
            self.depsgraph = context.evaluated_depsgraph_get()
            global GLOBAL_BVHT
            if snapSurface.name not in GLOBAL_BVHT.keys():
                GLOBAL_BVHT[snapSurface.name] = get_obj_mesh_bvht(snapSurface, self.depsgraph, applyModifiers=True, world_space=True)
            self.snap_surface_BVHT = GLOBAL_BVHT[snapSurface.name]
        elif draw_props.target_type == 'PARTICLE':
            draw_props.extend = False
            if active_obj.type == 'MESH':
                self.snap_surface = active_obj
                self.depsgraph = context.evaluated_depsgraph_get()
                self.snap_surface_BVHT = get_obj_mesh_bvht(active_obj, self.depsgraph, applyModifiers=True, world_space=True)
            else:
                self.report({'ERROR'}, 'Only Mesh objects are supported for PARTICLE Hair drawing. Cancelling')
                return {'CANCELLED'}

        if self.update_strand:
            ls = context.scene.last_stroke
            if ls and not ls['extend'] and context.active_object and ls['obj_name'] == context.active_object.name and context.active_object.select_get():
                self.new_strand_write(context)
            return {'FINISHED'}

        args = (self, context)
        self._handle = bpy.types.SpaceView3D.draw_handler_add(draw_lines_callback_po, args, 'WINDOW', 'POST_PIXEL')

        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}
