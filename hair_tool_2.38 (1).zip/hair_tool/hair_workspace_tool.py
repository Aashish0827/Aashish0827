# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with self program.  If not, see <http://www.gnu.org/licenses/>.
# Copyright (C) 2020 JOSECONSCO
# Created by JOSECONSCO

from copy import deepcopy
from math import cos, degrees, ceil, floor

import bgl
import bpy
import gpu
import numpy as np
from bpy_extras import view3d_utils
from gpu_extras.batch import batch_for_shader
from gpu_extras.presets import draw_circle_2d
from mathutils import Euler, Matrix, Quaternion, Vector

from .hair_curve_helpers import HTOOL_OT_CurvesTiltAlign
from .utils.curve_wrapper import ChainIK, Splines, get_tips_pts
from .utils.helper_functions import clamp, get_fallof_fun, get_obj_mesh_bvht

shader_3d_uniform = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
shader_2d_flat = gpu.shader.from_builtin('2D_UNIFORM_COLOR')  # 2D_FLAT_COLOR
shader_3d_smooth = gpu.shader.from_builtin('3D_SMOOTH_COLOR')

sel_col = (0.3, 1., 0.1)
adj_verts_colors_sel1 = [sel_col+(0.0,), sel_col+(0.8,), sel_col+(0.0,)]
adj_verts_colors_sel2 = [sel_col+(0.0,), sel_col+(0.5,), sel_col+(0.8,), sel_col+(0.5,), sel_col+(0.0,)]

not_sel_col = (0.9, 0.7, 0.2)
adj_verts_colors_not_sel1 = [not_sel_col+(0.0,), not_sel_col+(0.8,),  not_sel_col+(0.0,)]
adj_verts_colors_not_sel2 = [not_sel_col+(0.0,), not_sel_col+(0.5,), not_sel_col+(0.8,),  not_sel_col+(0.5,), not_sel_col+(0.0,)]

def draw_tips_pts(self, context):
    obj = context.active_object
    higlight_bias = context.scene.ht_props.higlight_bias
    higlight_range = context.scene.ht_props.higlight_range
    if context.space_data.overlay.show_overlays and obj and obj.type == 'CURVE' and obj.mode == 'OBJECT' and obj.visible_get():
        theme = bpy.context.preferences.themes['Default']
        g_vertex_size = theme.view_3d.vertex_size + 1
        spl_ids, pts, pts_co, adj_points = get_tips_pts(context, obj, world_space=True, only_sel=False, with_adj_pts=True)
        if not pts:
            return
        center = Vector((0, 0, 0))
        for p_co in pts_co:
            center += p_co
        center /= len(pts_co)

        #* bias toward camera offset
        g_rv3d = context.region_data
        camera_pos = g_rv3d.view_matrix.inverted().translation
        camDistance = camera_pos - center
        bias = (higlight_bias / camDistance.length_squared) / 20

        # g_vertex_color = theme.view_3d.vertex
        bgl.glEnable(bgl.GL_BLEND)
        bgl.glEnable(bgl.GL_DEPTH_TEST)
        bgl.glLineWidth(2)
        for p, p_co, connected_pts in zip(pts, pts_co, adj_points):
            sel = getattr(p, 'select', False) or getattr(p, 'select_control_point', False)
            bgl.glDepthRange(0, 1 - bias if sel else 1 - 0.99*bias)
            bgl.glPointSize(g_vertex_size + 1 if sel else g_vertex_size)
            batch_pts = batch_for_shader(shader_3d_uniform, 'POINTS', {"pos": [p_co]})
            shader_3d_uniform.bind()
            shader_3d_uniform.uniform_float("color", sel_col+(1,) if sel else not_sel_col+(1,))
            batch_pts.draw(shader_3d_uniform)

            if higlight_range:
                if higlight_range == 1:
                    adj_col = adj_verts_colors_sel1 if sel else adj_verts_colors_not_sel1
                else:
                    adj_col = adj_verts_colors_sel2 if sel else adj_verts_colors_not_sel2
                batch_edges = batch_for_shader(shader_3d_smooth, 'LINE_STRIP', {"pos": connected_pts, "color": adj_col})
                shader_3d_smooth.bind()
                batch_edges.draw(shader_3d_smooth)

        bgl.glDepthRange(0, 1)
        bgl.glDisable(bgl.GL_DEPTH_TEST)
        bgl.glDisable(bgl.GL_BLEND)
        bgl.glPointSize(1)
        bgl.glLineWidth(1)


def draw_2d_circle(self, context):
    color = (0.9, 0.9, 0.9, 0.9)
    draw_circle_2d(self.center_2d, color, self.rad_draw_2d, segments=32)
    pass


handle_SpaceView3D = None


class HT_TransformGiGroup(bpy.types.GizmoGroup):
    bl_idname = "HT_TransformGiGroup"  # this shit has to be same as cls name!
    bl_label = "Test Light Widget"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_options = {'3D'}  # , 'PERSISTENT'

    def __init__(self):  # enabled once on worktool ON
        global handle_SpaceView3D
        is_ht_on = bpy.context.workspace.tools.from_space_view3d_mode(mode=bpy.context.mode).idname == HTOOL_OT_ToolModelHair.bl_idname
        if handle_SpaceView3D is None and is_ht_on:
            # print('Addind draw')
            #! not greatest sollutions it seems.
            args = (None, bpy.context)  # u can pass arbitrary class as first param  Instead of (self, context)
            handle_SpaceView3D = bpy.types.SpaceView3D.draw_handler_add(draw_tips_pts, args, 'WINDOW', 'POST_VIEW')
            bpy.context.area.tag_redraw()

    def __del__(self):  # enabled once on worktool OFF
        global handle_SpaceView3D
        if handle_SpaceView3D is not None:
            # print('rem draw')
            #! not greatest sollutions it seems. Unbinds on operator each operator redoo.....
            bpy.types.SpaceView3D.draw_handler_remove(handle_SpaceView3D, 'WINDOW')
            handle_SpaceView3D = None

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'CURVE'
        # if bpy.context.workspace.tools.from_space_view3d_mode(mode=context.mode).idname == MyTool.bl_idname:
        #     return True
        # else:
        #     context.window_manager.gizmo_group_type_unlink_delayed(cls.bl_idname)
        #     return False

    def invoke_prepare(self, context, gizmo):
        pass

    def setup(self, context):
        pass

    def refresh(self, context):
        # print('GizmoGroup refresh')
        pass
        # TODO: put cache update here?


class HT_PT_ToolHotkeys(bpy.types.Panel):
    bl_idname = "HT_PT_ToolHotkeys"
    bl_label = "Hotkeys"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Tool"
    is_popover = True

    # bl_context = ".ht_hotkeys"  # dot on purpose (access from topbar)
    # bl_ui_units_x = 8
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return context.workspace.tools.from_space_view3d_mode(mode=context.mode).idname == "hair_tool.hair_transform"

    def draw(self, context):
        layout = self.layout
        # Active Tool
        # -----------
        # from bl_ui.space_toolsystem_common import ToolSelectPanelHelper
        # tool = ToolSelectPanelHelper.tool_active_from_context(context)
        # props = tool.operator_properties("curve.hair_transform")
        # preferences = bpy.context.preferences.addons[__package__].preferences
        col = layout.column()
        row = col.row()
        row.label(text="Ctrl+MWheel")
        row.label(text="Offset selection")
        row = col.row()
        row.label(text="Ctrl+RMB")
        row.label(text="Select object")
        row = col.row()
        row.label(text="(Shift)+RMB")
        row.label(text="Select Points")
        row = col.row()
        row.label(text="(Alt)+A")
        row.label(text="(de)Select All")
        row = col.row()
        row.label(text="Ctrl+I")
        row.label(text="Invert Selection")
        row = col.row()
        row.label(text="(Alt)+B+LMB")
        row.label(text="Box (de)Select")
        row = col.row()
        row.label(text="G, R, S")
        row.label(text="Transform spline")
        row = col.row()
        row.label(text="C+LMB(MMB)")
        row.label(text="Circle (de)Select")
        row = col.row()
        row.label(text="Ctr+(Shift)+LMB")
        row.label(text="Lasso (de)Select")
        row = col.row()
        row.label(text="X, Del")
        row.label(text="Delete Selected")
        row = col.row()
        row.label(text="Ctrl+D")
        row.label(text="Linear Deformer")
        row = col.row()
        row.label(text="K")
        row.label(text="Cut Tool")
        row = col.row()
        row.label(text="Shift+D")
        row.label(text="Duplicate Strand")
        row = col.row()
        row.label(text="Alt+S")
        row.label(text="Adjust Radius")
        row = col.row()
        row.label(text="Alt+R")
        row.label(text="Reset Radius")
        row = col.row()
        row.label(text="Ctrl+T")
        row.label(text="Adjust Tilt")
        row = col.row()
        row.label(text="Alt+T")
        row.label(text="Reset Tilt")
        row = col.row()
        row.label(text="E")
        row.label(text="Extend Curve")

class HT_PT_DrawSettings(bpy.types.Panel):
    bl_idname = "HT_PT_DrawSettings"
    bl_label = "Draw Settings"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Tool"
    is_popover = True

    # bl_context = ".ht_hotkeys"  # dot on purpose (access from topbar)
    # bl_ui_units_x = 8
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return context.workspace.tools.from_space_view3d_mode(mode=context.mode).idname == "hair_tool.hair_transform"

    def draw(self, context):
        layout = self.layout
        ht_scn_props = context.scene.ht_props
        layout.prop(ht_scn_props, "higlight_bias")
        layout.prop(ht_scn_props, "higlight_range")


class HTOOL_OT_ToolModelHair(bpy.types.WorkSpaceTool):
    bl_space_type = 'VIEW_3D'
    bl_context_mode = 'OBJECT'
    # The prefix of the idname should be your add-on name.
    bl_idname = "hair_tool.hair_transform"
    bl_label = "Hair Modeling"
    bl_description = "Select, transfrom, delete curve ribbons using Hair Tool"
    bl_icon = "brush.particle.smooth"
    bl_widget = "HT_TransformGiGroup"
    bl_keymap = (
                ("curve.deform_curve", {"type": 'D', "value": 'ANY', 'ctrl': True}, None),
                ("hair.knife_cut_modal", {"type": 'K', "value": 'ANY'}, None),
                ("curve.curve_lenghten", {"type": 'E', "value": 'PRESS'}, None),
                ("curve.hair_straighten", {"type": 'I', "value": 'PRESS'}, None),
                ("wm.call_menu", {"type": 'DEL', "value": 'PRESS'}, {"properties": [('name', 'HTOOL_MT_DeleteMenu')]}),
                ("wm.call_menu", {"type": 'X', "value": 'PRESS'}, {"properties": [('name', 'HTOOL_MT_DeleteMenu')]}),
                # ("curve.hair_delete", {"type": 'DEL', "value": 'PRESS'}, None),
                # ("curve.hair_delete", {"type": 'X', "value": 'PRESS'}, None),
                ("curve.hair_duplicate", {"type": 'D', "value": 'ANY', 'shift': True}, None),
                ("curve.hair_radilt_fallof", {"type": 'S', "value": 'ANY', 'alt': True},  {"properties": [('mode', 'RADIUS')]}),
                ("curve.hair_radilt_reset", {"type": 'R', "value": 'ANY', 'alt': True}, {"properties": [('mode', 'RADIUS')]}),
                ("curve.hair_radilt_fallof", {"type": 'T', "value": 'ANY', 'ctrl': True},  {"properties": [('mode', 'TILT')]}),
                ("curve.hair_radilt_reset", {"type": 'T', "value": 'ANY', 'alt': True}, {"properties": [('mode', 'TILT')]}),
                ("hair.offset_selection", {"type": 'WHEELUPMOUSE', "value": 'ANY', 'ctrl': True}, {"properties": [("increase", True)]}),
                ("hair.offset_selection", {"type": 'WHEELDOWNMOUSE', "value": 'ANY', 'ctrl': True}, {"properties": [("increase", False)]}),
                ("curve.hair_transform", {"type": 'G', "value": 'PRESS'}, {"properties": [("transform_mode", 'TRANSLATE')]}),
                ("curve.hair_transform", {"type": 'R', "value": 'PRESS'}, {"properties": [("transform_mode", 'ROTATE')]}),
                ("curve.hair_transform", {"type": 'S', "value": 'PRESS'}, {"properties": [("transform_mode", 'SCALE')]}),
                ("view3d.select", {"type": 'RIGHTMOUSE', "value": 'PRESS', "ctrl": True}, None),
                ("view3d.select", {"type": 'RIGHTMOUSE', "value": 'PRESS', "ctrl": True, "shift": True}, {"properties": [("toggle", True)]}),
                ("curve.hair_select", {"type": 'RIGHTMOUSE', "value": 'PRESS'}, {"properties": [("extend", False)]}),
                ("curve.hair_select", {"type": 'RIGHTMOUSE', "value": 'PRESS', 'shift': True}, {"properties": [("extend", True)]}),
                ("curve.hair_select_set", {"type": 'A', "value": 'PRESS'}, {"properties": [("mode", "SELECT")]}),
                ("curve.hair_select_set", {"type": 'A', "value": 'PRESS', "alt": True}, {"properties": [("mode", "DESELECT")]}),
                ("curve.hair_select_set", {"type": 'A', "value": 'DOUBLE_CLICK'}, {"properties": [("mode", "DESELECT")]}),
                ("curve.hair_select_set", {"type": 'I', "value": 'PRESS', "ctrl": True}, {"properties": [("mode", "INVERT")]}),
                ("hair.select_region_modal", {"type": 'B', "value": 'PRESS'}, {"properties": [("sel_type", 'BOX'), ('mode', 'ADD')]}),
                ("hair.select_region_modal", {"type": 'B', "value": 'PRESS', "alt": True}, {"properties": [("sel_type", 'BOX'), ('mode', 'SUB')]}),
                ("hair.select_region_modal", {"type": 'C', "value": 'PRESS'}, {"properties": [("sel_type", 'CIRCLE'), ('mode', 'ADD')]}),
                ("hair.select_region_modal", {"type": 'C', "value": 'PRESS', "alt": True}, {"properties": [("sel_type", 'CIRCLE'), ('mode', 'SUB')]}),
                ("hair.select_region_modal", {"type": 'EVT_TWEAK_L', "value": 'ANY', "ctrl": True}, {"properties": [("sel_type", 'LASSO'), ('mode', 'ADD')]}),
                ("hair.select_region_modal", {"type": 'EVT_TWEAK_L', "value": 'ANY', "ctrl": True, "shift": True}, {"properties": [("sel_type", 'LASSO'), ('mode', 'SUB')]}),
    )
    # ,"key_modifier": 'Ctrl' ; EVT_TWEAK_L

    def draw_settings(context, layout, tool):
        transform_op = tool.operator_properties("curve.hair_transform")
        ht_scn_props = context.scene.ht_props
        row = layout.row(align=True)
        row.prop(ht_scn_props, "active_end", expand=True)
        ic = 'PINNED' if transform_op.pin_end else 'UNPINNED'
        row.prop(transform_op, "pin_end", text='', icon=ic)
        # layout.prop(ht_scn_props, "select_offset")
        # layout.label(text=f'Offset {ht_scn_props.select_offset}')
        split = layout.split(factor=0.3, align=True)
        split.label(text='Mode')
        split.prop(ht_scn_props, "move_mode", text='')
        if ht_scn_props.move_mode == 'IK':
            layout.prop(ht_scn_props, "clump_falloff")
        layout.popover(panel="HT_PT_DrawSettings")

        # layout.prop(props, "mode")
        layout.prop(ht_scn_props, "align_tilt", icon="SNAP_NORMAL")
        reg = context.region.type
        if reg == 'TOOL_HEADER':
            # popover_kw = {"space_type": 'VIEW_3D', "region_type": 'UI', "category": "Tool"}
            # layout.popover_group(context=".ht_hotkeys", **popover_kw)
            layout.popover(panel="HT_PT_ToolHotkeys")
        # if context.area.type == 'PROPERTIES':



class HTOOL_OT_HairTransform(bpy.types.Operator):  # ! revrite to this operator
    bl_idname = "curve.hair_transform"
    bl_label = "Hair Transform"
    bl_description = "Curve Hair Transform (more, rotate, scale tips) with IK"
    bl_options = {'REGISTER', 'UNDO'}

    pin_end: bpy.props.BoolProperty(name="Pinned", description="Keep other spline ending in place", default=True)
    transform_mode: bpy.props.EnumProperty(name='Transform mode',
                                           items=(
                                               ('TRANSLATE', 'Translate', ''),
                                               ('ROTATE', 'Rotate', ''),
                                               ('SCALE', 'Scale', '')), default='TRANSLATE')

    @staticmethod
    def draw_debug_2d(self, context):
        bgl.glEnable(bgl.GL_BLEND)
        bgl.glLineWidth(1)
        bgl.glEnable(bgl.GL_DEPTH_TEST)

        center_w = self.center_3dw
        if self.x:
            line_pts = [Vector((-100, 0, 0))+center_w, Vector((100, 0, 0))+center_w]
            batch_pts = batch_for_shader(shader_3d_uniform, 'LINES', {"pos": line_pts})
            shader_3d_uniform.bind()
            shader_3d_uniform.uniform_float("color", (1, .1, .1, 0.8))
            batch_pts.draw(shader_3d_uniform)
        elif self.y:
            line_pts = [Vector((0, -100, 0))+center_w, Vector((0, 100, 0))+center_w]
            batch_pts = batch_for_shader(shader_3d_uniform, 'LINES', {"pos": line_pts})
            shader_3d_uniform.bind()
            shader_3d_uniform.uniform_float("color", (0, 1, 0, 0.8))
            batch_pts.draw(shader_3d_uniform)
        elif self.z:
            line_pts = [Vector((0, 0, -100))+center_w, Vector((0, 0, 100))+center_w]
            batch_pts = batch_for_shader(shader_3d_uniform, 'LINES', {"pos": line_pts})
            shader_3d_uniform.bind()
            shader_3d_uniform.uniform_float("color", (0.2, 0.2, 1, 0.8))
            batch_pts.draw(shader_3d_uniform)

        bgl.glDisable(bgl.GL_DEPTH_TEST)
        bgl.glDisable(bgl.GL_BLEND)

    def update_draw_header(self, context):
        scn_s = context.scene.ht_props
        context.area.header_text_set(f"Proportional Size: {scn_s.influence_rad: .2f}  Fallof: {context.scene.tool_settings.proportional_edit_falloff}")

    def calc_rad_2d(self, context):
        '''For drawing circle'''
        region = context.region
        rv3d = context.region_data
        scn_s = context.scene.ht_props
        center_2d_plus_rad_3d = view3d_utils.location_3d_to_region_2d(region, rv3d, self.center_3dw + Vector((scn_s.influence_rad, 0, 0)), default=Vector((0, 0)))
        self.rad_draw_2d = (center_2d_plus_rad_3d - self.center_2d).length

    def move_tip(self, context, event):  #
        ''' returns (hit, hit_co_world, hit_obj)
        If nothing hit, get output location based on region_2d_to_location_3d
        '''
        def write_pts(pts, moved_pts):
            for p, m_p in zip(pts, moved_pts):
                p.co.xyz = m_p

        active_roots = context.scene.ht_props.active_end == "ROOTS"
        clump_falloff = context.scene.ht_props.clump_falloff
        move_mode_ik = context.scene.ht_props.move_mode == 'IK'
        splines = self.curve_obj.data.splines
        scn_s = context.scene.ht_props

        if not move_mode_ik:
            self.calc_rad_2d(context)  # for drawing
            self.update_draw_header(context)

        def move_the_chains(spl, target_co):
            pts = spl.points[:] if spl.type in {'NURBS', 'POLY'} else spl.bezier_points[:]
            pid_offset = context.scene.ht_props.select_offset
            last_pid = len(pts)-1
            if last_pid < 1:
                return
            p_id = pid_offset if active_roots else last_pid - pid_offset
            p_id = clamp(p_id, 0, last_pid)
            other_end_r = p_id == 0 and not active_roots  # we scrolled to other end - root
            other_end_t = p_id == last_pid and active_roots  # we scrolled to other end - tip
            if p_id == 0 or p_id == last_pid:
                flip = active_roots
                if other_end_r or other_end_t:
                    flip = not flip
                ik_chain = ChainIK(pts[::-1]) if flip else ChainIK(pts)
                ik_chain.move_ik_chain(target_co, clump_falloff, self.pin_end)
                moved_pts = ik_chain.get_pts()[::-1] if flip else ik_chain.get_pts()
                write_pts(pts, moved_pts)
            else:
                if active_roots:  # when pull by roots, use pts order
                    sub_chain_a = pts[p_id:]
                    sub_chain_b = pts[:p_id+1]  # !check if in (0, len) range
                    ik_chain = ChainIK(sub_chain_a[::-1])  # rev
                    ik_chain.move_ik_chain(target_co, clump_falloff, self.pin_end)
                    moved_pts_a = ik_chain.get_pts()[::-1]  # rev

                    ik_chain_b = ChainIK(sub_chain_b)
                    ik_chain_b.move_ik_chain(moved_pts_a[0], clump_falloff, pin_end=False)
                    moved_pts_b = ik_chain_b.get_pts()
                else:  # when pull by tips, flip pts order
                    sub_chain_a = pts[:p_id+1]
                    sub_chain_b = pts[p_id:]  # ! cos we use seame point p[p_id] in both chains...
                    if len(sub_chain_a) > 1:
                        ik_chain = ChainIK(sub_chain_a)
                        ik_chain.move_ik_chain(target_co, clump_falloff, self.pin_end)
                        moved_pts_a = ik_chain.get_pts()
                    else:
                        moved_pts_a = [target_co]

                    ik_chain_b = ChainIK(sub_chain_b[::-1])
                    ik_chain_b.move_ik_chain(moved_pts_a[-1], clump_falloff, pin_end=False)
                    moved_pts_b = ik_chain_b.get_pts()[::-1]
                write_pts(sub_chain_a, moved_pts_a)
                write_pts(sub_chain_b, moved_pts_b)

        def move_fk_proportional(spl, offset):  # spl - SplineSimple
            bspl = splines[spl.orig_spl_id]
            out_pts = bspl.bezier_points if bspl.type == 'BEZIER' else bspl.points
            fallof_fun = get_fallof_fun(context.scene.tool_settings.proportional_edit_falloff)
            for out_p, p in zip(out_pts, spl.points):
                dist_fallof = max(1-p.dist_w/scn_s.influence_rad, 0)  # map dist - (0, inf), to (1, 0)
                dist_fallof = fallof_fun(dist_fallof)
                out_p.co.xyz = p.co.lerp((p.co + offset), dist_fallof)  # lerp old pos, to new  target_co

        region = context.region
        rv3d = context.region_data
        mouse_co_2d = Vector((event.mouse_region_x, event.mouse_region_y))
        mw_inv = self.curve_obj.matrix_world.inverted()

        #* TRANSLATE
        if self.transform_mode == 'TRANSLATE':
            first_click_3d = view3d_utils.region_2d_to_location_3d(region, rv3d, self.first_click, depth_location=self.center_3dw)
            mouse_co_3d = view3d_utils.region_2d_to_location_3d(region, rv3d, mouse_co_2d, depth_location=self.center_3dw)
            offset = mouse_co_3d - first_click_3d
            offset = mw_inv @ Vector((offset.xyz[:] + (0,)))  # to obj space - as vector  (it is diff.co after all)
            offset = offset.to_3d()
            if self.x:
                offset = offset.project(Vector((1, 0, 0)))
            elif self.y:
                offset = offset.project(Vector((0, 1, 0)))
            elif self.z:
                offset = offset.project(Vector((0, 0, 1)))

            if move_mode_ik:
                for sp_id, orig_tip_co in zip(self.sel_spl_ids, self.original_spl_tips_co):
                    move_the_chains(splines[sp_id], target_co=orig_tip_co+offset)
            else:
                # spl_copy = deepcopy(self.sel_splines)
                for orig_spl in self.sel_splines.splines:  # with original init positions
                    move_fk_proportional(orig_spl, offset)
                # spl_copy.write_splines_to_blender(self.curve_obj)

        #* ROTATE
        if self.transform_mode == 'ROTATE':
            center_2d = view3d_utils.location_3d_to_region_2d(region, rv3d, self.center_3dw, default=None)
            cen2d_to_fclick = self.first_click - center_2d
            cen_sec_click = mouse_co_2d - center_2d
            rot_diff_ang = cen2d_to_fclick.angle_signed(cen_sec_click, 0)  # for first click to current mouse pos
            if self.x:
                rot_dir = Vector((1, 0, 0))
            elif self.y:
                rot_dir = Vector((0, 1, 0))
            elif self.z:
                rot_dir = Vector((0, 0, 1))
            else:
                view_dir = view3d_utils.region_2d_to_vector_3d(region, rv3d, center_2d)  # ? or: view_dir = rv3d.view_rotation * Vector((0.0, 0.0, -1.0))
                rot_dir = view_dir
            # * rot in local space:
            # rot_mat_loc = mw_inv @ Quaternion(rot_dir, rot_diff_ang).to_matrix().to_4x4()  # get 3d rot, form screen rot
            rot_quat_l = Quaternion(rot_dir, rot_diff_ang)
            rot_quat_l.rotate(mw_inv)

            if move_mode_ik:
                for sp_id, orig_tip_co in zip(self.sel_spl_ids, self.original_spl_tips_co):
                    center_to_pt_rot = orig_tip_co - self.center_l
                    center_to_pt_rot.rotate(rot_quat_l)  # rotate orig vec...
                    move_the_chains(splines[sp_id], target_co=self.center_l+center_to_pt_rot)
            else:
                no_rot = Quaternion((0.0, 1.0, 0.0), 0)
                for orig_spl in self.sel_splines.splines:  # with original init positions
                    # move_fk_proportional(orig_spl, offset)
                    bspl = splines[orig_spl.orig_spl_id]
                    out_pts = bspl.bezier_points if bspl.type == 'BEZIER' else bspl.points
                    fallof_fun = get_fallof_fun(context.scene.tool_settings.proportional_edit_falloff)
                    for out_p, p in zip(out_pts, orig_spl.points):
                        center_to_p_rot = p.co - self.center_l
                        dist_fallof = max(1-p.dist_w/scn_s.influence_rad, 0)  # map dist - (0, inf), to (1, 0)
                        dist_fallof = fallof_fun(dist_fallof)

                        center_to_p_rot.rotate(no_rot.slerp(rot_quat_l, dist_fallof))  # rotate orig vec...
                        out_p.co.xyz = self.center_l + center_to_p_rot  # lerp old pos, to new  target_co

        #* SCALE
        if self.transform_mode == 'SCALE':
            x = Vector((1, 0, 0))
            y = Vector((0, 1, 0))
            z = Vector((0, 0, 1))

            center_2d = view3d_utils.location_3d_to_region_2d(region, rv3d, self.center_3dw, default=None)
            base_scale = max((self.first_click - center_2d).length, 0.01)
            new_dist = (mouse_co_2d - center_2d).length if not self.force_zero else 0.0
            scale_fac = new_dist / base_scale

            if move_mode_ik:
                for sp_id, orig_tip_co in zip(self.sel_spl_ids, self.original_spl_tips_co):
                    center_to_pt = orig_tip_co - self.center_l
                    if self.x:
                        scale_move = orig_tip_co + (scale_fac-1)*center_to_pt.project(x)
                    elif self.y:
                        scale_move = orig_tip_co + (scale_fac-1)*center_to_pt.project(y)
                    elif self.z:
                        scale_move = orig_tip_co + (scale_fac-1)*center_to_pt.project(z)
                    else:
                        scale_move = self.center_l + scale_fac*center_to_pt
                    move_the_chains(splines[sp_id], target_co=scale_move)
            else:
                for orig_spl in self.sel_splines.splines:  # with original init positions

                    # move_fk_proportional(orig_spl, offset)
                    bspl = splines[orig_spl.orig_spl_id]
                    out_pts = bspl.bezier_points if bspl.type == 'BEZIER' else bspl.points
                    fallof_fun = get_fallof_fun(context.scene.tool_settings.proportional_edit_falloff)
                    for out_p, p in zip(out_pts, orig_spl.points):
                        center_to_pt = p.co - self.center_l
                        if self.x:
                            scale_move = p.co + (scale_fac-1)*center_to_pt.project(x)
                        elif self.y:
                            scale_move = p.co + (scale_fac-1)*center_to_pt.project(y)
                        elif self.z:
                            scale_move = p.co + (scale_fac-1)*center_to_pt.project(z)
                        else:
                            scale_move = self.center_l + scale_fac*center_to_pt

                        dist_fallof = max(1-p.dist_w/scn_s.influence_rad, 0)  # map dist - (0, inf), to (1, 0)
                        dist_fallof = fallof_fun(dist_fallof)
                        out_p.co.xyz = p.co.lerp(scale_move, dist_fallof)  # lerp old pos, to new  target_co

        if self.snap_surface:
            HTOOL_OT_CurvesTiltAlign.align_curve_tilt(context, self.depsgraph, self.curve_obj, self.snap_surface_BVHT, resetTilt=True, onlySelection=True)

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'CURVE' and context.space_data.type == 'VIEW_3D'

    def invoke(self, context, event):
        self.sel_spl_ids = []
        self.curve_obj = curve_obj = context.active_object
        self.x, self.y, self.z = False, False, False
        self.first_click = Vector((event.mouse_region_x, event.mouse_region_y))
        bpy.ops.ed.undo_push()

        #* for tilt align
        scn_s = context.scene.ht_props
        self.snap_surface = bpy.data.objects.get(curve_obj.ht_props.target_obj) if curve_obj.ht_props.target_obj and scn_s.align_tilt else None
        if self.snap_surface:
            #* fix strand jump on tilt aligning, if obj.rot != 0
            if curve_obj.rotation_euler != Euler((0.0, 0.0, 0.0), 'XYZ') or min(curve_obj.scale[:]) < 0:  # fix rot if curve rot is non 0,0,0, or scele x,y,z <0
                override = {'selected_editable_objects': [curve_obj]}
                if curve_obj.data.users > 1:
                    curve_obj.data = curve_obj.data.copy()
                bpy.ops.object.transform_apply(override, location=False, rotation=True, scale=False)  # ! apply  scale breaks /changes pts radius
                # context.view_layer.update()

            #* create snap_surface_BVHT for tilt align
            self.depsgraph = context.evaluated_depsgraph_get()
            self.snap_surface_BVHT = get_obj_mesh_bvht(self.snap_surface, self.depsgraph, applyModifiers=True, world_space=True)

        self.move_fk = context.scene.ht_props.move_mode == 'FK'
        if self.move_fk:
            self.sel_splines = Splines(curve_obj, onlySelection=True, spline_type='SIMPLE', from_tips=True)
            self.sel_splines.euclidean_seg_distances(context, curve_obj.matrix_world)  # ads p.dist_w - from sel point to each strand

        self.sel_spl_ids, pts, pts_co = get_tips_pts(context, curve_obj, world_space=False, only_sel=True)
        if not self.sel_spl_ids:
            self.sel_spl_ids, pts, pts_co = get_tips_pts(context, curve_obj, world_space=False, only_sel=False)

        #* operation origing / center
        if context.scene.tool_settings.transform_pivot_point == 'CURSOR':
            self.center_l = curve_obj.matrix_world.inverted() @ context.scene.cursor.location
        else:
            sel_center = Vector((0, 0, 0))
            for p_co in pts_co:
                sel_center += p_co
            self.center_l = sel_center / len(pts_co)
        self.center_3dw = curve_obj.matrix_world @ self.center_l
        self.original_spl_tips_co = pts_co

        #* cor circle drawing
        region = context.region
        rv3d = context.region_data
        self.center_2d = view3d_utils.location_3d_to_region_2d(region, rv3d, self.center_3dw, default=None)

        self.force_zero = False
        self.calc_rad_2d(context)
        args = (self, context)
        self._handle = bpy.types.SpaceView3D.draw_handler_add(self.draw_debug_2d, args, "WINDOW", "POST_VIEW")
        self._handle_2d = bpy.types.SpaceView3D.draw_handler_add(draw_2d_circle, args, "WINDOW", "POST_PIXEL") if self.move_fk else None
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def finish(self, context):
        bpy.types.SpaceView3D.draw_handler_remove(self._handle, "WINDOW")
        if self._handle_2d:
            bpy.types.SpaceView3D.draw_handler_remove(self._handle_2d, "WINDOW")
        context.area.header_text_set(None)
        context.area.tag_redraw()

    def modal(self, context, event):
        scn_s = context.scene.ht_props
        if event.type in {"LEFTMOUSE", 'RET'}:
            self.finish(context)
            return {"FINISHED"}

        elif event.type in {"RIGHTMOUSE", "ESC"}:
            self.finish(context)
            bpy.ops.ed.undo()
            context.active_object.data.update_tag()
            context.area.tag_redraw()
            return {'CANCELLED'}

        elif event.type == 'X' and event.value == 'PRESS':
            self.x, self.y, self.z = not self.x, False, False

        elif event.type == 'Y' and event.value == 'PRESS':
            self.x, self.y, self.z = False, not self.y, False

        elif event.type == 'Z' and event.value == 'PRESS':
            self.x, self.y, self.z = False, False, not self.z

        elif event.type == 'MOUSEMOVE':
            self.move_tip(context, event)
            context.area.tag_redraw()
            # return {'PASS_THROUGH'}
        elif event.type == "ZERO" and event.value == 'RELEASE':
            self.force_zero = not self.force_zero
            self.move_tip(context, event)
            context.area.tag_redraw()
        else:
            if self.move_fk:
                if event.type == "WHEELUPMOUSE":
                    scn_s.influence_rad *= 1.1
                    self.move_tip(context, event)

                elif event.type == "WHEELDOWNMOUSE":
                    scn_s.influence_rad = max(0.001, scn_s.influence_rad * 0.9)
                    self.move_tip(context, event)

            else:
                if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'}:
                    return {'PASS_THROUGH'}

        return {"RUNNING_MODAL"}


class OBJECT_OT_SelectOffset(bpy.types.Operator):
    bl_idname = "hair.offset_selection"
    bl_label = "Select Offset"
    bl_description = "Select Offset"
    bl_options = {"REGISTER", "UNDO_GROUPED"}

    increase: bpy.props.BoolProperty(name='Increase', description='', default=True)

    def execute(self, context):
        offset_prev = context.scene.ht_props.select_offset
        ht_props = context.scene.ht_props
        obj = context.active_object
        next_offset = ht_props.select_offset + 1 if self.increase else ht_props.select_offset - 1
        longest_pid = 0
        if obj.type == 'CURVE':
            for i, spl in enumerate(obj.data.splines):
                pts = spl.points if spl.type in {'NURBS', 'POLY'} else spl.bezier_points
                spl_len = len(pts)
                last_pid = spl_len-1
                longest_pid = max(longest_pid, last_pid)

                if ht_props.active_end == "TIPS":
                    p_id_current = clamp(last_pid - ht_props.select_offset, 0, last_pid)
                    p_id_next = clamp(last_pid - next_offset, 0, last_pid)
                else:
                    p_id_current = clamp(ht_props.select_offset, 0, last_pid)
                    p_id_next = clamp(next_offset, 0, last_pid)
                sel_mask = [False]*spl_len
                if p_id_current != p_id_next:  # deselect old, select new one
                    if spl.type in {'NURBS', 'POLY'}:
                        sel_mask[p_id_next] = pts[p_id_current].select
                        pts.foreach_set('select', sel_mask)
                    else:
                        sel_mask[p_id_next] = pts[p_id_current].select_control_point
                        pts.foreach_set('select_control_point', sel_mask)
                else:
                    pass
                    # if spl.type in {'NURBS', 'POLY'}:
                    #     sel_mask[p_id_next] = True
                    #     pts.foreach_set('select', sel_mask)
                    # else:
                    #     sel_mask[p_id_next] = True
                    #     pts.foreach_set('select_control_point', sel_mask)
            obj.data.update_tag()
        ht_props.select_offset = clamp(next_offset, 0, longest_pid)
        # bpy.ops.ed.undo_push()
        bpy.context.area.tag_redraw()
        return {"FINISHED"}


class HTOOL_OT_HairSelectAll(bpy.types.Operator):
    bl_idname = "curve.hair_select_set"
    bl_label = "(de)Select hair alll"
    bl_description = "(de)Select hair alll"
    bl_options = {'REGISTER', "UNDO"}

    # select: bpy.props.BoolProperty(name='Select', description='Select All', default=True)
    mode: bpy.props.EnumProperty(name='Mode',
        items=[
            ('SELECT', 'Select', 'Select'),
            ('DESELECT', 'Deselect', 'Deselect'),
            ('INVERT', 'Invert', 'Invert selection')
        ], default='SELECT')


    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'CURVE'

    def execute(self, context):
        curve_obj = context.active_object
        # _, tip_pts, _ = get_tips_pts(context, curve_obj, world_space=True, only_sel=False)

        sel_tip_pts = []
        not_sel_tip_pts = []
        offset = context.scene.ht_props.select_offset
        active_end = context.scene.ht_props.active_end
        for spl in curve_obj.data.splines:
            pts = spl.points if spl.type in {'NURBS', 'POLY'} else spl.bezier_points
            last_pid = len(pts)-1
            p_id = clamp(last_pid - offset, 0, last_pid) if active_end == "TIPS" else clamp(offset, 0, last_pid)
            pt_sel_state = pts[p_id].select if spl.type in {'NURBS', 'POLY'} else pts[p_id].select_control_point
            if pt_sel_state:
                sel_tip_pts.append(pts[p_id])
            else:
                not_sel_tip_pts.append(pts[p_id])

        for spl in curve_obj.data.splines:
            pts = spl.points if spl.type in {'NURBS', 'POLY'} else spl.bezier_points
            sel_mask = [False]*len(pts)
            if spl.type in {'NURBS', 'POLY'}:
                pts.foreach_set('select', sel_mask)
            else:
                pts.foreach_set('select_control_point', sel_mask)

        if self.mode != "DESELECT": #we already deselected
            pts_to_set = sel_tip_pts+not_sel_tip_pts if self.mode == "SELECT" else not_sel_tip_pts
            for pt in pts_to_set:
                try:
                    pt.select = True
                except Exception:
                    pt.select_control_point = True
        context.area.tag_redraw()

        return {'FINISHED'}


class HTOOL_OT_LmbHairSelect(bpy.types.Operator):
    bl_idname = "curve.hair_select"
    bl_label = "Select hair tip"
    bl_description = "Select Hair tips (MTool modeling)"
    bl_options = {'REGISTER', "UNDO"}

    extend: bpy.props.BoolProperty(name='Extend', description='', default=False)

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'CURVE'

    def mouse_click_select(self, event):
        return (event.type == 'LEFTMOUSE' and self.left_click_select) or (event.type == 'RIGHTMOUSE' and not self.left_click_select)

    def invoke(self, context, event):
        wm = bpy.context.window_manager
        km = wm.keyconfigs.user.keymaps.get('3D View Tool: Object, Hair Modeling')
        self.left_click_select = True
        if km:
            kmi = km.keymap_items['curve.hair_select']
            self.left_click_select = True if kmi.type == 'LEFTMOUSE' else False

        curve_obj = context.active_object
        if self.mouse_click_select(event) and event.value == 'PRESS':
            sel_spl_ids, sel_pts, sel_pts_co = get_tips_pts(context, curve_obj, world_space=True, only_sel=True)

            if not self.extend:  # deselect all pts first
                for curve in curve_obj.data.splines:
                    if curve.type in {'NURBS', 'POLY'}:
                        [setattr(p, 'select', False) for p in curve.points]
                    else:
                        [setattr(p, 'select_control_point', False) for p in curve.bezier_points]

            mouse_co = Vector((event.mouse_region_x, event.mouse_region_y))
            region = context.region
            rv3d = context.region_data
            best_dist_2d = 20
            overlapping_pts = [] #deal with selecting overlapping pts
            best_pt = None
            spl_ids, pts, pts_co = get_tips_pts(context, curve_obj, world_space=True, only_sel=False)
            for spl_id, pt, p_co in zip(spl_ids, pts, pts_co):
                tip_2d = view3d_utils.location_3d_to_region_2d(region, rv3d, p_co, default=None)
                if not tip_2d:
                    continue
                current_dist = (tip_2d-mouse_co).length
                if current_dist <= best_dist_2d:
                    if current_dist == best_dist_2d:
                        if best_pt not in overlapping_pts:
                            overlapping_pts.append(best_pt)
                        overlapping_pts.append(pt)
                    best_pt = pt
                    best_dist_2d = current_dist

            if overlapping_pts: #deal tips that are in same coordinates...
                cnt = len(overlapping_pts)
                sel_overlapping_pts = [op for op in overlapping_pts if op in sel_pts]
                if cnt == 1 or len(sel_overlapping_pts) == 0:
                    best_pt = overlapping_pts[0]
                else:
                    prev_pt = overlapping_pts[-1]
                    i = 0
                    while True:
                        candidate = overlapping_pts[i % cnt]
                        #not sel point, but with prev_pt selected
                        if candidate not in sel_overlapping_pts and prev_pt in sel_overlapping_pts:
                            best_pt = candidate
                            break
                        else:
                            prev_pt = candidate
                        i += 1
                        if i >= cnt:
                            break

            if best_pt:
                try:
                    best_pt.select = True if not self.extend else not best_pt.select
                except Exception as e:
                    best_pt.select_control_point = True if not self.extend else not best_pt.select_control_point
        return {'FINISHED'}


class HTOOL_MT_DeleteMenu(bpy.types.Menu):
    bl_idname = "HTOOL_MT_DeleteMenu"
    bl_label = "Hair Tool Menu Delete"
    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT'

    def draw(self, context):
        layout = self.layout
        layout.operator_enum("curve.hair_delete", "mode")



class HTOOL_OT_HairDelete(bpy.types.Operator):
    bl_idname = "curve.hair_delete"
    bl_label = "Hair Delete"
    bl_description = "Delete Hair curve"
    bl_options = {'REGISTER'}

    mode: bpy.props.EnumProperty(name='Mode', description='Delete mode',
                                 items=[
                                     ('OBJECT', 'Object', 'Delete selected object'),
                                     ('SPLINE', 'Spline', 'Delete whole strand (spline)'),
                                     ('SLICE', 'Cut', 'Cut spline at selection point')
                                 ], default='SPLINE')

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'CURVE'

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "mode", expand=True)

    def invoke(self, context, event):
        # bpy.ops.ed.undo_push()  # to prevent restoring curve from step above on execute()
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        curve_obj = context.active_object
        if self.mode == 'OBJECT':
            bpy.ops.object.delete(use_global=False)
            return {'FINISHED'}

        sel_spl_ids, sel_pts, _ = get_tips_pts(context, curve_obj, world_space=False, only_sel=True)
        if not sel_spl_ids:
            self.report({'WARNING'}, 'No curve endings selected! Cancelling')
            return {'CANCELLED'}
        splines = curve_obj.data.splines
        if self.mode == 'SPLINE':
            for sp_id in reversed(sel_spl_ids):
                splines.remove(splines[sp_id])
        else:
            sel_splines = Splines(context.active_object, onlySelection=True, spline_type='SIMPLE')
            for spl in sel_splines.splines:
                for i, p in enumerate(spl.points):
                    if p.select:
                        del spl.points[i+1:]
                        spl.points[i].select = True
                        break
            context.scene.ht_props.select_offset = 0
            sel_splines.write_splines_to_blender(curve_obj)  # override old spl
        bpy.ops.ed.undo_push()
        return {'FINISHED'}


class HTOOL_OT_ResetRadiusTilt(bpy.types.Operator):
    bl_idname = "curve.hair_radilt_reset"
    bl_label = "Hair Radius/Tilt Reset"
    bl_description = "Hair Radius/Tilt Reset"
    bl_options = {'REGISTER', "UNDO"}

    mode: bpy.props.EnumProperty(name='Mode', description='Mode', items=[('RADIUS', 'Radius', 'Radius'), ('TILT', 'Tilt', 'Tilt')], default='RADIUS')

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'CURVE'

    def invoke(self, context, event):
        curve_obj = context.active_object
        spl_ids, pts, pts_co = get_tips_pts(context, curve_obj, only_sel=True)
        rad_mode = self.mode == 'RADIUS'
        for spl_id in spl_ids:
            spl = curve_obj.data.splines[spl_id]
            pts = spl.points if spl.type in {'NURBS', 'POLY'} else spl.bezier_points
            if rad_mode:
                for p in pts:
                    p.radius = 1
            else:
                for p in pts:
                    p.tilt = 0
        return {'FINISHED'}


class HTOOL_OT_AdjustRadius(bpy.types.Operator):
    bl_idname = "curve.hair_radilt_fallof"
    bl_label = "Radius/Tilt Adjustment"
    bl_description = "Proportianl Radius/Tilt Adjustment"
    bl_options = {'REGISTER', 'GRAB_CURSOR', 'BLOCKING', 'UNDO'}

    mode: bpy.props.EnumProperty(name='Mode', description='Smooth Axis', items=[('RADIUS', 'Radius', 'Radius'), ('TILT', 'Tilt', 'Tilt')], default='RADIUS')

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'CURVE'

    def calc_rad_2d(self, context):
        '''For drawing circle'''
        region = context.region
        rv3d = context.region_data
        scn_s = context.scene.ht_props
        center_2d_plus_rad_3d = view3d_utils.location_3d_to_region_2d(region, rv3d, self.center_3dw + Vector((scn_s.influence_rad, 0, 0)), default=Vector((0, 0)))
        self.rad_draw_2d = (center_2d_plus_rad_3d - self.center_2d).length

    def invoke(self, context, event):
        curve_obj = context.active_object
        self.sel_splines = Splines(curve_obj, onlySelection=True, spline_type='SIMPLE', from_tips=True)
        self.sel_splines.euclidean_seg_distances(context, curve_obj.matrix_world)
        self.first_click = Vector((event.mouse_region_x, event.mouse_region_y))
        self.scale_fac = 1  # radius scale factor

        self.sel_spl_ids, pts, pts_co = get_tips_pts(context, curve_obj, world_space=False, only_sel=True)
        if not self.sel_spl_ids:
            self.sel_spl_ids, pts, pts_co = get_tips_pts(context, curve_obj, world_space=False, only_sel=False)

        if context.scene.tool_settings.transform_pivot_point == 'CURSOR':
            op_center = curve_obj.matrix_world.inverted() @ context.scene.cursor.location
        else:
            sel_center = Vector((0, 0, 0))
            for p_co in pts_co:
                sel_center += p_co
            op_center = sel_center / len(pts_co)
        self.center_3dw = curve_obj.matrix_world @ op_center

        region = context.region
        rv3d = context.region_data
        self.center_2d = view3d_utils.location_3d_to_region_2d(region, rv3d, self.center_3dw, default=None)

        self.force_zero = False
        self.calc_rad_2d(context)  # for drawing
        args = (self, context)
        self._handle = bpy.types.SpaceView3D.draw_handler_add(draw_2d_circle, args, "WINDOW", "POST_PIXEL")
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def update_draw_header(self, context):
        scn_s = context.scene.ht_props
        txt = 'Radius' if self.mode == 'RADIUS' else 'Tilt'
        context.area.header_text_set(f"{txt}: {self.scale_fac:.2f}   Proportional Size: {scn_s.influence_rad:.2f}")

    def modal(self, context, event):
        scn_s = context.scene.ht_props
        if event.type == "MOUSEMOVE":
            self.adjust_radilt(context, event)

        if event.type == "LEFTMOUSE":
            return self.finish(context)

        if event.type == "ZERO" and event.value == 'RELEASE':
            self.force_zero = not self.force_zero
            self.adjust_radilt(context, event)

        if event.type == "WHEELUPMOUSE":
            scn_s.influence_rad *= 1.1
            self.adjust_radilt(context, event)

        if event.type == "WHEELDOWNMOUSE":
            scn_s.influence_rad = max(0.001, scn_s.influence_rad * 0.9)
            self.adjust_radilt(context, event)

        if event.type in {"RIGHTMOUSE", "ESC"}:
            return self.cancelled(context)

        return {"RUNNING_MODAL"}

    def finish(self, context):
        bpy.types.SpaceView3D.draw_handler_remove(self._handle, "WINDOW")
        context.area.tag_redraw()
        context.area.header_text_set(None)
        return {"FINISHED"}

    def cancelled(self, context):
        bpy.types.SpaceView3D.draw_handler_remove(self._handle, "WINDOW")
        context.area.tag_redraw()
        self.sel_splines.write_splines_to_blender(context.active_object)
        context.area.header_text_set(None)
        return {"CANCELLED"}

    def adjust_radilt(self, context, event):
        self.calc_rad_2d(context)  # for drawing
        self.update_draw_header(context)
        mode_rad = self.mode == 'RADIUS'
        coord = Vector((event.mouse_region_x, event.mouse_region_y))
        base_scale = max((self.first_click - self.center_2d).length, 0.01)
        if self.force_zero:
            new_dist = 0
        else:
            new_dist = (coord - self.center_2d).length

        scale_fac = new_dist / base_scale  # ==1 for default radius 1. For thilt compenstae later to 0
        self.scale_fac = scale_fac
        if not mode_rad:
            if coord[0] - self.center_2d[0] < 0:
                scale_fac = -scale_fac
        self.update_draw_header(context)
        spl_copy = deepcopy(self.sel_splines)
        fallof_fun = get_fallof_fun(context.scene.tool_settings.proportional_edit_falloff)
        scn_s = context.scene.ht_props
        for spl in spl_copy.splines:
            for p in spl.points:
                dist_fallof = max(1-p.dist_w/scn_s.influence_rad, 0)  # map dist - (0, inf), to (1, 0)
                dist_fallof = fallof_fun(dist_fallof)

                if mode_rad:
                    p.radius = p.radius * scale_fac * dist_fallof + p.radius * (1 - dist_fallof)  # basically lerp old rad, to new rad aka. scale_fac
                else:  # (scale_fac-1) - cos reseted titl is 0, not 1
                    p.tilt = (p.tilt + scale_fac-1) * dist_fallof + p.tilt * (1 - dist_fallof)  # basically lerp old rad, to new rad aka. scale_fac

        spl_copy.write_splines_to_blender(context.active_object)  # override old spl
        return {'FINISHED'}


class HTOOL_OT_HairDuplicate(bpy.types.Operator):
    bl_idname = "curve.hair_duplicate"
    bl_label = "Hair Duplicate"
    bl_description = "Duplicate Hair curve(s)"
    bl_options = {'REGISTER', "UNDO"}

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'CURVE'

    def execute(self, context):
        curve_obj = context.active_object
        sel_spl_ids, _, _ = get_tips_pts(context, curve_obj, world_space=True, only_sel=True)
        if not sel_spl_ids:
            self.report({'WARNING'}, 'No curve endings selected! Cancelling')
            return {'CANCELLED'}

        splines = curve_obj.data.splines
        for sp_id in sel_spl_ids:
            spl = splines[sp_id]
            new_spl = splines.new(spl.type)
            new_spl.points.add(len(spl.points)-1)
            for k, v in spl.bl_rna.properties.items():
                if not v.is_readonly:  # value may be eg. <bpy_struct, EnumProperty("type")>; use: path_resolve(k) instead
                    setattr(new_spl, k, spl.path_resolve(k))

            for p, p_old in zip(new_spl.points, spl.points):
                p.co = p_old.co
                p.select = True
                p.radius = p_old.radius
                p.tilt = p_old.tilt
                p.weight = p_old.weight
                p_old.select = False
        bpy.ops.curve.hair_transform('INVOKE_DEFAULT', transform_mode='TRANSLATE')
        return {'FINISHED'}


class HTOOL_OT_HairRegionSelect(bpy.types.Operator):
    bl_idname = "hair.select_region_modal"
    bl_label = "Select Hair Region"
    bl_options = {"REGISTER", "UNDO"}

    sel_type: bpy.props.EnumProperty(name='selection type',
                                     items=(
                                         ('BOX', 'Box', ''),
                                         ('LASSO', 'Lasso', ''),
                                         ('CIRCLE', 'Circle', '')), default='BOX')
    mode: bpy.props.EnumProperty(name='mode',
                                 items=(
                                     ('ADD', 'Add', ''),
                                     ('SUB', 'Substract', ''),
                                     ('SET', 'Set', '')), default='ADD')

    clicked = False

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'CURVE'

    @staticmethod
    def draw_line_loop_2d(self, context):
        if self.mouse_pts:
            bgl.glEnable(bgl.GL_BLEND)
            batch_edges = batch_for_shader(shader_2d_flat, 'LINE_LOOP', {"pos": self.mouse_pts})
            shader_2d_flat.bind()
            shader_2d_flat.uniform_float("color", (1, 1, 1, 1))
            batch_edges.draw(shader_2d_flat)
            bgl.glDisable(bgl.GL_BLEND)


    def select_circle(self, context, curve_obj, center2d):
        region = context.region
        rv3d = context.region_data
        spl_ids, pts, pts_co = get_tips_pts(context, curve_obj, world_space=True, only_sel=False)
        for p, p_co in zip(pts, pts_co):
            tip_2d = view3d_utils.location_3d_to_region_2d(region, rv3d, p_co, default=None)
            if (tip_2d-center2d).length < context.scene.ht_props.circle_sel_rad2d:
                p.select = True if self.mode == 'ADD' else False

    def select_box(self, context, curve_obj):
        region = context.region
        rv3d = context.region_data
        min_x, max_x = min(self.mouse_pts[0].x, self.mouse_pts[2].x), max(self.mouse_pts[0].x, self.mouse_pts[2].x)
        min_y, max_y = min(self.mouse_pts[0].y, self.mouse_pts[2].y), max(self.mouse_pts[0].y, self.mouse_pts[2].y)
        for curve in curve_obj.data.splines:
            tip_world = curve_obj.matrix_world @ curve.points[-1].co.xyz
            tip_2d = view3d_utils.location_3d_to_region_2d(region, rv3d, tip_world, default=None)
            if min_x < tip_2d.x < max_x and min_y < tip_2d.y < max_y:
                curve.points[-1].select = True if self.mode == 'ADD' else False

    def is_point_inside_winding(self, context, curve_obj):
        mouse_pts = self.mouse_pts
        region = context.region
        rv3d = context.region_data
        spl_ids, pts, pts_co = get_tips_pts(context, curve_obj, world_space=True, only_sel=False)
        for p, p_co in zip(pts, pts_co):
            rad = 0
            tip_2d = view3d_utils.location_3d_to_region_2d(region, rv3d, p_co, default=None)
            prev_V = mouse_pts[-1]
            for i in range(len(mouse_pts)):
                next_V = mouse_pts[i]
                rad += (prev_V-tip_2d).angle_signed((next_V-tip_2d))
                prev_V = mouse_pts[i]
            if abs(abs(rad) - 6.283) < 0.1:  # is it close to 2pi= 6.283 ?
                p.select = True if self.mode == 'ADD' else False

    def mouse_click_select(self, event):
        return (event.type == 'LEFTMOUSE' and self.left_click_select) or (event.type == 'RIGHTMOUSE' and not self.left_click_select)

    def modal(self, context, event):
        if self.sel_type == 'CIRCLE':
            scn_s = context.scene.ht_props
            if event.type == "WHEELUPMOUSE":
                scn_s.circle_sel_rad2d = ceil(scn_s.circle_sel_rad2d * 1.1)
                self.rad_draw_2d = scn_s.circle_sel_rad2d

            elif event.type == "WHEELDOWNMOUSE":
                scn_s.circle_sel_rad2d = floor(max(0.001, scn_s.circle_sel_rad2d * 0.9))
                self.rad_draw_2d = scn_s.circle_sel_rad2d

            elif self.mouse_click_select(event) and event.value == 'PRESS':
                self.clicked = True
                self.mode = 'ADD'

            elif event.type == "MIDDLEMOUSE" and event.value == 'PRESS':
                self.clicked = True
                self.mode = 'SUB'

            elif event.type == "MOUSEMOVE":
                self.center_2d = Vector((event.mouse_region_x, event.mouse_region_y))
                if self.clicked:
                    self.select_circle(context, self.curve_obj, center2d=self.center_2d)
                context.area.tag_redraw()

            elif self.mouse_click_select(event) and event.value == 'RELEASE':
                self.clicked = False

            elif event.type in {"RIGHTMOUSE", "ESC", "RET"}:
                bpy.types.SpaceView3D.draw_handler_remove(self._handle, "WINDOW")
                context.area.tag_redraw()
                return {"FINISHED"}


        elif self.sel_type == 'BOX':
            if self.mouse_click_select(event) and event.value == 'PRESS':
                self.first_co = Vector((event.mouse_region_x, event.mouse_region_y))
                self.clicked = True

            elif event.type == "MOUSEMOVE":
                if self.clicked:
                    a = self.first_co
                    b = Vector((event.mouse_region_x, self.first_co.y))
                    c = Vector((event.mouse_region_x, event.mouse_region_y))
                    d = Vector((self.first_co.x, event.mouse_region_y))
                    self.mouse_pts = [a, b, c, d]
                context.area.tag_redraw()

            elif self.mouse_click_select(event) and event.value == 'RELEASE':
                self.is_point_inside_winding(context, self.curve_obj)
                bpy.types.SpaceView3D.draw_handler_remove(self._handle, "WINDOW")
                context.area.tag_redraw()
                return {"FINISHED"}

        elif self.sel_type == 'LASSO':
            if event.type == "MOUSEMOVE":
                self.mouse_pts.append(Vector((event.mouse_region_x, event.mouse_region_y)))
                context.area.tag_redraw()

            elif self.mouse_click_select(event) and event.value == 'RELEASE':
                self.is_point_inside_winding(context, self.curve_obj)
                bpy.types.SpaceView3D.draw_handler_remove(self._handle, "WINDOW")
                context.area.tag_redraw()
                return {"FINISHED"}

        elif event.type in {"RIGHTMOUSE", "ESC"}:
            bpy.types.SpaceView3D.draw_handler_remove(self._handle, "WINDOW")
            context.area.tag_redraw()
            return {"CANCELLED"}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        self.curve_obj = context.active_object
        self.mouse_pts = []

        self.center_2d = event.mouse_region_x, event.mouse_region_y #for 'CIRCLE'
        self.rad_draw_2d = context.scene.ht_props.circle_sel_rad2d  # for 'CIRCLE'

        #get left click select, or right click
        if event.type in {"RIGHTMOUSE", "EVT_TWEAK_R"}:
            self.left_click_select = False
            self.first_co = Vector((event.mouse_region_x, event.mouse_region_y))
            self.clicked = True
        elif event.type in {"LEFTMOUSE", "EVT_TWEAK_L"}:
            self.left_click_select = True
            self.first_co = Vector((event.mouse_region_x, event.mouse_region_y))
            self.clicked = True
        else:
            self.left_click_select = True
            # wm = bpy.context.window_manager
            # km = wm.keyconfigs.user.keymaps.get('3D View Tool: Object, Hair Modeling')
            # if km:
            #     if self.sel_type == 'LASSO':
            #         for kmi in km.keymap_items:
            #             if kmi.idname == 'hair.select_region_modal' and kmi.properties.sel_type == 'LASSO' and kmi.properties.mode == self.mode: # kmi.type == 'EVT_TWEAK_L'
            #                 self.left_click_select = True if kmi.type == 'EVT_TWEAK_L' else False
            #                 break
            #     else:
            #         kmi = km.keymap_items['curve.hair_select']
            #         self.left_click_select = True if kmi.type == 'LEFTMOUSE' else False

        args = (self, context)
        if self.sel_type in {'LASSO','BOX'}:
            self._handle = bpy.types.SpaceView3D.draw_handler_add(self.draw_line_loop_2d, args, "WINDOW", "POST_PIXEL")
        else: #* circle sel
            self._handle = bpy.types.SpaceView3D.draw_handler_add(draw_2d_circle, args, "WINDOW", "POST_PIXEL")
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}


class HTOOL_OT_CurvesAdjustLen(bpy.types.Operator):
    bl_label = "Hair lenghten"
    bl_idname = "curve.curve_lenghten"
    bl_description = "Extend or shorten selected strands"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'CURVE'

    def invoke(self, context, event):
        self.scale_strand = 100
        self.sel_splines = Splines(context.active_object, onlySelection=True, spline_type='FLAT')  # Flat will auto resample tilt, radius
        self.pt_cnt = [s.length for s in self.sel_splines.splines]
        self.euclid_len = [s.euclidean_len for s in self.sel_splines.splines]  # reduce growth on long strands, or else they blow too fast
        self.t_spat = []
        for spl in self.sel_splines.splines:
            seg_lens = np.apply_along_axis(np.linalg.norm, 1, spl.points_co[:-1, :]-spl.points_co[1:, :])  # do an - an-1 and get length
            t_spat = np.insert(seg_lens, 0, 0).cumsum()  # add zero and sum
            self.t_spat.append(t_spat/t_spat[-1])  # it will be now proportional to segments distances - bigger point spacing - more time.

        self.init_cox_2d = event.mouse_region_x

        bpy.ops.ed.undo_push()  # to prevent restoring curve from step above on execute()
        context.window_manager.modal_handler_add(self)
        # return self.execute(context)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type == "MOUSEMOVE":
            scale = clamp(1 + (event.mouse_region_x - self.init_cox_2d)/600, 0.2, 3)
            context.area.header_text_set(f"Factor: {scale:.2f}")
            self.extend_shorten_spl(context, scale)
            context.area.tag_redraw()

        elif event.type in {"LEFTMOUSE", "RET"}:
            context.area.header_text_set(None)
            context.area.tag_redraw()
            return {"FINISHED"}

        elif event.type in {"RIGHTMOUSE", "ESC"}:
            context.area.header_text_set(None)
            bpy.ops.ed.undo()
            context.area.tag_redraw()
            return {"CANCELLED"}

        return {'RUNNING_MODAL'}


    def extend_shorten_spl(self, context, scale):
        splines = deepcopy(self.sel_splines)
        max_e_len = max(self.euclid_len)
        for e_len, t_spat, pts_cnt, spl in zip(self.euclid_len, self.t_spat, self.pt_cnt, splines.splines):
            t_range = pts_cnt - 1.01
            tn_new = scale*t_range  # adjust tn to get even spacing
            if scale > 100: # make long hair glow slower
                extra_t = tn_new - t_range
                grow_mul = max_e_len/e_len
                tn_new = t_range + extra_t * grow_mul
                cut_t = grow_mul*(scale-1)+1
                new_tns = np.linspace(0, cut_t, pts_cnt, endpoint=True)

            elif scale < 100:
                t_cut = scale
                new_tns = np.linspace(0, t_cut, pts_cnt, endpoint=True)
            spl.resample_pts(pts_cnt, uniform=False, t_custom=new_tns)

        splines.write_splines_to_blender(context.active_object)
        return {"FINISHED"}


# from .volume_preserve_smoothing import (CommonSmoothMethods, close_bmesh, get_mirrored_verts)
class SmoothDrawingSettings(bpy.types.PropertyGroup):
    radius: bpy.props.FloatProperty(name="Radius", description="radius", default=0.5, min=0.01, soft_max=1)
    strength: bpy.props.FloatProperty(name="Strength", description="strength", default=50, min=0, max=100, subtype='PERCENTAGE')
    only_selected: bpy.props.BoolProperty(name='Only selected', description='', default=False)
    method: bpy.props.EnumProperty(
        items=(('LC', 'Laplacian', ''),
               ('INFlATE', 'Inflate', ''),
               ('VOL', 'Volume', '')),
        name="Method",
        default='LC',)


shader_3d_uniform = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
shader_2d = gpu.shader.from_builtin('2D_UNIFORM_COLOR')


class HTOOL_OT_CircleSelect(bpy.types.Operator):
    bl_idname = "hair.circle_select"
    bl_label = "Hair Circle Select"
    bl_description = "Hair Circle Select"
    bl_options = {"REGISTER", "UNDO"}


    draw: bpy.props.BoolProperty(name='draw', description='', default=False)
    resize: bpy.props.BoolProperty(name='resize', description='', default=False)

    @staticmethod
    def draw_circle_px(self, context):
        vps_settings = context.scene.vps_draw
        g_rv3d = context.region_data
        viewDir = g_rv3d.view_rotation @ Vector((0.0, 0.0, -1.0))
        quat_rot = Vector((0, 0, 1)).rotation_difference(viewDir)
        rot_mat = quat_rot.to_matrix().to_4x4()

        bgl.glLineWidth(1)
        bgl.glEnable(bgl.GL_BLEND)
        bgl.glDisable(bgl.GL_DEPTH_TEST)

        circle = np.array([(0.0, 1.0, 0.0, 1.), (-0.3826834559440613, 0.9238795042037964, 0.0, 1.), (-0.7071067690849304, 0.7071067690849304, 0.0, 1.), (-0.9238795042037964, 0.3826834261417389, 0.0, 1.), (-1.0, -4.371138828673793e-08, 0.0, 1.), (-0.9238795042037964, -0.38268351554870605, 0.0, 1.), (-0.7071067690849304, -0.7071067690849304, 0.0, 1.), (-0.38268348574638367, -0.9238795042037964, 0.0, 1.),
                           (-1.5099580252808664e-07, -1.0, 0.0, 1.), (0.3826832175254822, -0.9238796234130859, 0.0, 1.), (0.7071065902709961, -0.7071070075035095, 0.0, 1.), (0.9238795042037964, -0.38268357515335083, 0.0, 1.), (1.0, 1.1924880638503055e-08, 0.0, 1.), (0.9238794445991516, 0.3826836049556732, 0.0, 1.), (0.7071065306663513, 0.7071070075035095, 0.0, 1.), (0.3826829791069031, 0.9238797426223755, 0.0, 1.)], 'f')
        circle[:, :-1] = circle[:, :-1] * vps_settings.radius
        if self.draw_cursor_co:
            mat = Matrix.Translation(self.draw_cursor_co).to_4x4() @ rot_mat
            mat_np = np.array(mat, 'f')
            vertices = np.einsum('ij,aj->ai', mat_np, circle)[:, :-1]

            batch = batch_for_shader(shader_3d_uniform, 'LINE_LOOP', {"pos": vertices})
            shader_3d_uniform.bind()
            shader_3d_uniform.uniform_float("color", (1,1,1,1))
            batch.draw(shader_3d_uniform)

            bgl.glDisable(bgl.GL_DEPTH_TEST)
            bgl.glDisable(bgl.GL_BLEND)


    def adjust_size(self, context, event):
        vps_settings = context.scene.vps_draw
        region = context.region
        rv3d = context.region_data
        curr_loc3d_from_2d = view3d_utils.region_2d_to_location_3d(region, rv3d, (event.mouse_region_x, 0), self.draw_cursor_co)
        start_loc3d_from_2d = view3d_utils.region_2d_to_location_3d(region, rv3d, (self.start_xloc, 0), self.draw_cursor_co)
        diff = (curr_loc3d_from_2d - start_loc3d_from_2d).length
        if self.start_xloc > event.mouse_region_x:
            diff *= -1
        vps_settings.radius = max(0.01, self.start_rad+diff)

        args = (self, context)
        self._handle = bpy.types.SpaceView3D.draw_handler_add(self.draw_circle_px, args, 'WINDOW', 'POST_VIEW')


class HTOOL_OT_HairModalKnife(bpy.types.Operator):
    bl_idname = "hair.knife_cut_modal"
    bl_label = "Hair Knife Cut"
    bl_options = {"REGISTER", "UNDO"}

    @staticmethod
    def draw_line_loop_2d(self, context):
        bgl.glPointSize(4)
        draw_pts = [self.mouse_hover_co]
        if self.mouse_pts:
            draw_pts.extend(self.mouse_pts)
        batch_pts = batch_for_shader(shader_2d_flat, 'POINTS', {"pos": draw_pts})
        shader_2d_flat.bind()
        shader_2d_flat.uniform_float("color", (0.6, 1, 0.4, 1))
        batch_pts.draw(shader_2d_flat)
        bgl.glPointSize(1)

        if self.mouse_pts:
            batch_edges = batch_for_shader(shader_2d_flat, 'LINE_STRIP', {"pos": self.mouse_pts+[self.mouse_hover_co]})
            shader_2d_flat.bind()
            shader_2d_flat.uniform_float("color", (0.6, 1, 0.4, 1))
            batch_edges.draw(shader_2d_flat)


    def modal(self, context, event):
        if event.type == "LEFTMOUSE" and event.value == 'RELEASE':
            self.mouse_pts.append(Vector((event.mouse_region_x, event.mouse_region_y)))
            if len(self.mouse_pts) >= 2:
                self.b_splines.splines_line_intersect(context, self.curve_obj, self.mouse_pts[-2], self.mouse_pts[-1]) #cut in screen space..
            context.area.tag_redraw()

        elif event.type == 'MOUSEMOVE':
            self.mouse_hover_co = Vector((event.mouse_region_x, event.mouse_region_y))
            context.area.tag_redraw()

        elif event.type in {"RET", "SPACE"}:
            bpy.types.SpaceView3D.draw_handler_remove(self._handle, "WINDOW")
            context.area.tag_redraw()
            return {"FINISHED"}

        elif event.type in {"RIGHTMOUSE", "ESC"}:
            bpy.types.SpaceView3D.draw_handler_remove(self._handle, "WINDOW")
            bpy.ops.ed.undo()
            context.active_object.data.update_tag()
            context.area.tag_redraw()
            return {"CANCELLED"}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        bpy.ops.ed.undo_push()
        self.curve_obj = context.active_object
        self.mouse_hover_co = Vector((event.mouse_region_x, event.mouse_region_y))
        self.mouse_pts = []
        self.b_splines = Splines(self.curve_obj, onlySelection=True, spline_type='SIMPLE', from_tips=True)

        args = (self, context)
        self._handle = bpy.types.SpaceView3D.draw_handler_add(self.draw_line_loop_2d, args, "WINDOW", "POST_PIXEL")
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}
