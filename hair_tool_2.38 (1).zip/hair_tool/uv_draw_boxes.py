# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
# Copyright (C) 2017 JOSECONSCO
# Created by JOSECONSCO

import bpy
from .material_operators import HTOOL_OT_CurvesUVRefresh, HTOOL_OT_AssignRegionsFromObjProps
import time
import numpy as np
import gpu
from gpu_extras.batch import batch_for_shader
from .utils.gpu_helpers import draw_text_line, draw_gradient_box, draw_background_box
import bgl
import blf
from .short_hair import update_all_edges_uvs

shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')

def offset_adjust_true(point_count, offset_tip, offset_root):  # must be same as in OffsetNode
    x = np.linspace(1, 0, point_count)
    p1 = 1 - np.power(1-x, 5*offset_tip+1)
    p2 = np.power(x, 5*offset_root+1)
    return (p1 + p2)/2


def power_offset_points(point_count, offset_tip, offset_root):  # must be same as in OffsetNode
    x = np.linspace(1, 0, point_count)
    p1 = 1 - np.power(1-x, offset_tip+1)
    p2 = np.power(p1, offset_root+1)
    return p2

def draw_callback_px(self, context):
    region = context.region

    draw_text_lines = []
    # draw_text_lines.append([f"state {self.state}", 'H1'])
    draw_text_lines.append(["Draw rectangular shape with LMB", 'H1'])
    draw_text_lines.append(["Drag corner points to adjust box size", 'H1'])
    draw_text_lines.append(["Shift+DEL - reset uv", 'p'])
    draw_text_lines.append(["", 'p'])
    draw_text_lines.append(["", 'p'])
    draw_text_lines.append(["", 'p'])
    draw_text_lines.append(["ENTER - Finish; ESC / RMB - Cancel", 'p'])


    bgl.glPointSize(6)
    if len(self.uv_data_cache) > 0:
        coords = []
        coords_points = []
        region = context.region
        pointsToDraw = self.uv_data_cache[:]
        delta = 4
        for i,uv_point in enumerate(pointsToDraw): #draw non edited boxes
            if self.state == 'edit_box' and i == self.edit_point_index:  # draw not edited uv boxes
                # del pointsToDraw[self.edit_point_index]
                continue
            x1, y1 = region.view2d.view_to_region(uv_point['start_point'][0], uv_point['start_point'][1],clip = False) # vies space to UV (0,1 space)
            x2, y2 = region.view2d.view_to_region(uv_point['end_point'][0], uv_point['end_point'][1],clip = False) # vies space to UV (0,1 space)

            # mouse_x, mouse_y = region.view2d.view_to_region(self.mouse_pos[0], self.mouse_pos[1], clip=False)

            coords = [(x1, y1), (x1, y2), (x2, y2), (x2, y1)]
            batch_box_outline = batch_for_shader(shader, 'LINE_LOOP', {"pos": coords})
            shader.bind()
            if x1 < self.mouse_pos[0] < x2 and y2 < self.mouse_pos[1] < y1:
                # print(f'mouse over box: {i}')
                shader.uniform_float("color", (0.4, 1.0, 0.2, 1))
                draw_text_lines[3] = ["DEL - delete higlighted box", 'p']
                draw_text_lines[4] = [f"Shift +Scroll - offset root/tip  {uv_point['offset_root']:.1f} : {uv_point['offset_tip']:.1f}", 'p']
                draw_text_lines[5] = [f"F - Flip box Y direction: {uv_point['flip_y']}", 'p']
            else:
                shader.uniform_float("color", (0.8, 0.8, 0.8, 0.7))
            batch_box_outline.draw(shader)

            # -- Drawing horizontal lines
            pts_count = 10
            y_pts = power_offset_points(pts_count, uv_point['offset_tip'], uv_point['offset_root'])  # generate 10 pts
            pts_corrected = np.zeros((2*pts_count, 2), 'f')

            # generate lines by generating point paris:
            #line_x: (x1, y_x), (x2, y_x)  +
            #line_x+1:  (x1, y_x+1), (x2, y_x+1)  + [x+2] etc.

            pts_corrected[::2, 0] = x1
            pts_corrected[1::2, 0] = x2
            pts_corrected[:, 1] = np.repeat((y2 - y1)*y_pts + y1, 2)

            batch_h_lines = batch_for_shader(shader, 'LINES', {"pos": pts_corrected})
            batch_h_lines.draw(shader)


            y_center = (y1+y2)/2
            if x1 < self.mouse_pos[0] < x2 and y2 < self.mouse_pos[1] < y_center:
                col_tip = (0.4, 1.0, 0.2)
            else:
                col_tip = (0.8, 0.8, 0.8)

            if x1 < self.mouse_pos[0] < x2 and y_center < self.mouse_pos[1] < y1:
                col_root = (0.4, 1.0, 0.2)
            else:
                col_root = (0.8, 0.8, 0.8)

            #root grad
            draw_gradient_box(x0=x1, y0=y1, x1=x2, y1=y_center, color_top=col_root + (uv_point['offset_root']/2,), color_bottom=col_root + (0.0,))
            #tip grad
            draw_gradient_box(x0=x1, y0=y_center, x1=x2, y1=y2, color_top=col_tip + (0.0,), color_bottom=col_tip + (uv_point['offset_tip']/2,) )

            #drawing points corner handles


            coords_points = [(x1, y1), (x2, y2)]
            batch = batch_for_shader(shader, 'POINTS', {"pos": coords_points})
            shader.bind()
            if x1-delta < self.mouse_pos[0] < x2+delta and y2-delta < self.mouse_pos[1] < y1+delta:
                shader.uniform_float("color", (0.4, 1.0, 0.2, 1))
            else:
                shader.uniform_float("color", (0.8, 0.8, 0.8, 0.7))
            batch.draw(shader)

            draw_background_box(width=50, height=20, left_margin=x1, bottom_margin=y1-25, alpha=0.8)
            font_id = 0
            blf.color(font_id, 1.0, 1.0, 1.0, 1.0)
            blf.size(font_id, 17, 60)
            blf.position(font_id, x1+5, y1-20, 0)
            blf.draw(font_id, 'ID: '+str(i))

    if self.state in ['new_box', 'edit_box']:  # draw currently edited box
        box = self.uv_data_cache[self.edit_point_index]

        x1, y1 = region.view2d.view_to_region(box['start_point'][0], box['start_point'][1], clip = False) # vies space to UV (0,1 space)
        start_point = [x1,y1]

        x2, y2 = region.view2d.view_to_region(box['end_point'][0], box['end_point'][1], clip = False)
        end_point = [x2, y2]

        coords = [(start_point[0], start_point[1]), (start_point[0], end_point[1]),
                (end_point[0], end_point[1]), (end_point[0], start_point[1])]
        batch = batch_for_shader(shader, 'LINE_LOOP', {"pos": coords})
        shader.bind()
        shader.uniform_float("color", (0.4, 1.0, 0.2, 1))
        batch.draw(shader)

        coords_points = [(start_point[0], start_point[1]),  (end_point[0], end_point[1])]
        batch = batch_for_shader(shader, 'POINTS', {"pos": coords_points})
        shader.bind()
        batch.draw(shader)
    draw_text_line(draw_text_lines, width_override=340)
    bgl.glPointSize(1)



class HTOOL_OT_ModalUvRangeSelect(bpy.types.Operator):
    """Draw a line with the mouse"""
    bl_idname = "hair.uv_area_select"
    bl_label = "Draw UVs for Hair"
    bl_description = "Draw box in UV editor to define hair ribbons UVs"
    bl_options = {"REGISTER", "UNDO"}

    _handle = None
    UVBackup = {} # when operator is cancelled, restore UVs

    states = ['main', 'new_box', 'edit_box', 'adjust_offset']
    state = 'main'
    current_state = None

    edit_end_point = False #true when updating existing uv box
    edit_start_point = False #true when updating existing uv box

    mouse_pos = []  #we need it to pass as self.mouse_pos to draw handler

    def manualUndo(self,active_obj): #cos bpy.ops.ed.undo() if fuk up
        active_obj.material_slots[0].material.ht_props.hair_uv_points.clear()
        for points in self.UVBackup['uv_data']:
            active_obj.material_slots[0].material.ht_props.hair_uv_points.add()
            for p in points.keys():  # copy start and end point
                active_obj.material_slots[0].material["ht_props"]["hair_uv_points"][-1][p] = points[p]
        if active_obj.type == 'CURVE':
            HTOOL_OT_CurvesUVRefresh.uvCurveRefresh(active_obj, refresh_everything=True)
        for cdata_name, mat_spl_ids in self.UVBackup['cdata_mat_order'].items():
            cdata = bpy.data.curves.get(cdata_name)
            for s, orig_m_idx in zip(cdata.splines, mat_spl_ids):
                s.material_index = orig_m_idx

    def save_xy_to_uv_box(self,hair_uv_point,box, region):
        hair_uv_point.start_point = box['start_point']
        hair_uv_point.end_point = box['end_point']

    def init_uv_data_cache_with_defaults(self, uv_data):
        uv_data['start_point'] = [0, 1]
        uv_data['end_point'] = [1, 0]
        uv_data['offset_tip'] = 0
        uv_data['offset_root'] = 0
        uv_data['flip_y'] = False

    def uv_box_reset(self, hair_uv_points):
        hair_uv_points.clear()
        hair_uv_points.add()
        hair_uv_points[-1].start_point = [0, 1]
        hair_uv_points[-1].end_point = [1, 0]

        self.uv_data_cache.clear()
        self.uv_data_cache.append({})
        self.init_uv_data_cache_with_defaults(self.uv_data_cache[-1])

    @staticmethod
    def offset_node_set(active_obj):
        first_mat = active_obj.material_slots[0].material
        hair_uv_points = first_mat.ht_props.hair_uv_points
        RandomFlipX = bpy.context.preferences.addons['hair_tool'].preferences.flipUVRandom
        for fmat_idx, mat in enumerate(active_obj.data.materials):  # now we can set mapping nodes for each mat slot
            uvRectIndex = fmat_idx // 2 if RandomFlipX else fmat_idx
            OffsetNode = mat.node_tree.nodes['OffsetNode']  # created in update_mapping_nodes
            OffsetNode.inputs['Offset Tip'].default_value = hair_uv_points[uvRectIndex].offset_tip
            OffsetNode.inputs['Offset Root'].default_value = hair_uv_points[uvRectIndex].offset_root

    def initialize_uv_points_cache(self,  hair_uv_points):
        ''' points for drawing UI in uv editor. Cos uvrefresh() may remove material.ht_props.uv- data '''
        self.uv_data_cache.clear()
        for uv_point in hair_uv_points:  # draw non edited boxes
            self.uv_data_cache.append({})
            self.uv_data_cache[-1]['start_point'] = [uv_point.start_point[0], uv_point.start_point[1]]  # vies space to UV (0,1 space)
            self.uv_data_cache[-1]['end_point'] = [uv_point.end_point[0], uv_point.end_point[1]]
            self.uv_data_cache[-1]['offset_tip'] = uv_point.offset_tip
            self.uv_data_cache[-1]['offset_root'] = uv_point.offset_root
            self.uv_data_cache[-1]['flip_y'] = uv_point.flip_y

    def do_material_update(self, obj):
        if obj.type == 'CURVE':
            HTOOL_OT_CurvesUVRefresh.uvCurveRefresh(obj, refresh_everything=True)
        elif obj.type == 'MESH' and obj.ht_props.short_hair_props.is_short_hair:
            update_all_edges_uvs(obj)

    def finish(self, context):
        if self._handle:
            bpy.types.SpaceImageEditor.draw_handler_remove(self._handle, 'WINDOW')
        obj = context.active_object
        if obj.type == 'CURVE':
            HTOOL_OT_CurvesUVRefresh.uvCurveRefresh(obj, refresh_everything=True)
        elif obj.type == 'MESH' and obj.ht_props.short_hair_props.is_short_hair:
            update_all_edges_uvs(obj)

        self.report({'INFO'}, 'Finished')
        return {'FINISHED'}

    def modal(self, context, event):
        context.area.tag_redraw()
        region = context.region
        active_obj = context.active_object
        hair_uv_points = active_obj.material_slots[0].material.ht_props.hair_uv_points
        if event.type == 'MOUSEMOVE':
            self.mouse_pos = [event.mouse_region_x, event.mouse_region_y]
            x, y = region.view2d.region_to_view(self.mouse_pos[0], self.mouse_pos[1])  # view space to UV (0,1 space)
            if self.state == 'edit_box' or self.state == 'new_box':
                box = self.uv_data_cache[self.edit_point_index]
                if self.edit_start_point:
                    box['start_point'] = [x, y]
                    if x > box['end_point'][0]:
                        box['end_point'][0] = x
                    if y < box['end_point'][1]:
                        box['end_point'][1] = y

                if self.edit_end_point or self.state == 'new_box':
                    box['end_point'] = [x, y]
                    if x < box['start_point'][0]:
                        box['start_point'][0] = x
                    if y > box['start_point'][1]:
                        box['start_point'][1] = y

            return {'RUNNING_MODAL'}

        if self.state == 'main':
            x, y = region.view2d.region_to_view(self.mouse_pos[0], self.mouse_pos[1])  # view space to UV (0,1 space)
            if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
                if not(0 < self.mouse_pos[0] < region.width) or not (0 < self.mouse_pos[1] < region.height):
                    return self.finish(context)

                delta = 0.03
                self.edit_point_index = -1
                for point_index,points in enumerate(hair_uv_points):
                    if x-delta < points.start_point[0] < x + delta and  y-delta < points.start_point[1] < y + delta:
                        self.edit_start_point = True
                        self.edit_point_index = point_index
                        self.state = 'edit_box'
                        return {'RUNNING_MODAL'}
                    if x-delta < points.end_point[0] < x + delta and  y-delta < points.end_point[1] < y + delta:
                        self.edit_end_point = True
                        self.edit_point_index = point_index
                        self.state = 'edit_box'
                        return {'RUNNING_MODAL'}

                if self.edit_point_index == -1: #if not edtiting points then start new uv box
                    hair_uv_points.add()
                    hair_uv_points[-1].start_point = [x, y]
                    self.uv_data_cache.append({})
                    self.init_uv_data_cache_with_defaults(self.uv_data_cache[-1])
                    self.uv_data_cache[-1]['start_point'] = [x, y]
                    self.uv_data_cache[-1]['end_point'] = [x, y]
                    self.state = 'new_box'
                    return {'RUNNING_MODAL'}

            elif event.ctrl and event.type == 'Z' and event.value == 'PRESS':
                if len(hair_uv_points) > 1:
                    last_idx = len(hair_uv_points)-1
                    hair_uv_points.remove(last_idx)
                    del self.uv_data_cache[last_idx]
                    self.do_material_update(active_obj)

            elif event.type == 'WHEELUPMOUSE' and event.shift:
                for i, hair_uv_point in enumerate(hair_uv_points):
                    startX, startY = hair_uv_point.start_point
                    endX, endY = hair_uv_point.end_point
                    y_center = (endY + startY) / 2
                    if startX < x < endX and y_center < y < startY:
                        hair_uv_points[i].offset_root += 0.1
                        self.uv_data_cache[i]['offset_root'] = hair_uv_points[i].offset_root
                        self.offset_node_set(active_obj)
                        break
                    if startX < x < endX and endY < y < y_center:
                        hair_uv_points[i].offset_tip += 0.1
                        self.uv_data_cache[i]['offset_tip'] = hair_uv_points[i].offset_tip
                        self.offset_node_set(active_obj)
                        break

            elif event.type == 'WHEELDOWNMOUSE' and event.shift:
                for i, hair_uv_point in enumerate(hair_uv_points):
                    startX, startY = hair_uv_point.start_point
                    endX, endY = hair_uv_point.end_point
                    y_center = (endY + startY) / 2
                    if startX < x < endX and y_center < y < startY:
                        hair_uv_points[i].offset_root -= 0.1
                        self.uv_data_cache[i]['offset_root'] = hair_uv_points[i].offset_root
                        self.offset_node_set(active_obj)
                        break
                    if startX < x < endX and endY < y < y_center:
                        hair_uv_points[i].offset_tip -= 0.1
                        self.uv_data_cache[i]['offset_tip'] = hair_uv_points[i].offset_tip
                        self.offset_node_set(active_obj)
                        break

            elif event.type == 'DEL' and event.shift == False:  # delete box/boxes
                if len(hair_uv_points) > 0:
                    for i, hair_uv_point in enumerate(hair_uv_points):
                        startX, startY = hair_uv_point.start_point
                        endX, endY = hair_uv_point.end_point
                        if startX < x < endX and endY < y < startY:
                            hair_uv_points.remove(i)
                            self.uv_data_cache.pop(i)
                            if len(hair_uv_points) == 0:
                                self.uv_box_reset(hair_uv_points)
                            self.do_material_update(active_obj)
                            break

            elif event.type == 'F' and event.value == 'PRESS':  # delete box/boxes
                if len(hair_uv_points) > 0:
                    for i, hair_uv_point in enumerate(hair_uv_points):
                        startX, startY = hair_uv_point.start_point
                        endX, endY = hair_uv_point.end_point
                        if startX < x < endX and endY < y < startY:
                            hair_uv_points[i].flip_y = not hair_uv_points[i].flip_y
                            self.uv_data_cache[i]['flip_y'] = hair_uv_points[i].flip_y
                            self.do_material_update(active_obj)
                            break

            elif event.type == 'DEL' and event.shift:
                if len(hair_uv_points) > 0:
                    self.uv_box_reset(hair_uv_points)
                    self.do_material_update(active_obj)

            elif event.type in {'RIGHTMOUSE', 'ESC'}:
                if self._handle:
                    bpy.types.SpaceImageEditor.draw_handler_remove(self._handle, 'WINDOW')
                self.manualUndo(active_obj)  # ? why not just bpy.ops.ed.undo? cos its fuk up..
                self.report({'INFO'}, 'CANCELLED')
                return {'CANCELLED'}

            elif event.type in {'NUMPAD_ENTER', 'RET'} and time.time()-self.startTime > 1:
                return self.finish(context)

        elif self.state == 'new_box':
            if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':  # finish drawing box, and calculate uv Transformation
                box = self.uv_data_cache[self.edit_point_index]
                hair_uv_point = hair_uv_points[self.edit_point_index]
                self.save_xy_to_uv_box(hair_uv_point, box, region)
                self.do_material_update(active_obj)
                self.state = 'main'

        elif self.state == 'edit_box':
            if event.type == 'LEFTMOUSE'  and event.value == 'RELEASE':
                box = self.uv_data_cache[self.edit_point_index]
                hair_uv_point = hair_uv_points[self.edit_point_index]
                self.save_xy_to_uv_box(hair_uv_point, box, region)
                self.edit_end_point = False
                self.edit_start_point = False
                self.do_material_update(active_obj)
                self.state = 'main'

        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'}:
            # allow navigation
            return {'PASS_THROUGH'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        self.startTime = time.time() #to prevetn enter finishing action, when using spacebar search
        active_obj = context.active_object
        if active_obj.type != 'CURVE' and (active_obj.type == 'MESH' and not active_obj.ht_props.short_hair_props.is_short_hair):
            self.report({'WARNING'}, "Operator works only on curve ribbons! Cancelling")
            return {'CANCELLED'}

        if context.area.type == 'IMAGE_EDITOR':
            if active_obj.type == 'MESH' and active_obj.ht_props.short_hair_props.is_short_hair:
                bpy.ops.object.mode_set(mode='OBJECT')
            self.edit_point_index = -1
            if not active_obj.data.materials:
                HTOOL_OT_CurvesUVRefresh.uvCurveRefresh(active_obj, refresh_everything=True)
            first_mat = active_obj.data.materials[0]
            self.UVBackup.clear() # manual undo begin backup
            self.UVBackup['uv_data'] = []
            for point in first_mat.ht_props.hair_uv_points:
                out_dict = {k: v[:] if str(type(v)) == "<class 'IDPropertyArray'>" else v for k, v in point.items()}
                self.UVBackup['uv_data'].append(out_dict)
            data_inst_using_first_mat = [data for data in bpy.data.curves if data.materials and data.materials[0] == first_mat]  # get data blocks that are usin first_mat
            objs_mat_per_spl_backup = {}
            for c_data in data_inst_using_first_mat:
                objs_mat_per_spl_backup[c_data.name] = [s.material_index for s in c_data.splines]
            self.UVBackup['cdata_mat_order'] = objs_mat_per_spl_backup
            # active_obj.material_slots[0].material.ht_props.hair_uv_points.clear()
            self.uv_data_cache = [] # stores each uv box data
            self.initialize_uv_points_cache(active_obj.material_slots[0].material.ht_props.hair_uv_points)
            args = (self, context)
            self._handle = bpy.types.SpaceImageEditor.draw_handler_add(draw_callback_px, args, 'WINDOW', 'POST_PIXEL')
            self.mouse_pos = [event.mouse_region_x, event.mouse_region_y]
            self.report({'INFO'}, 'Draw box shape in UV editor')
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "You must run this operator in UV editor! Cancelling")
            return {'CANCELLED'}


class OBJECT_OT_AddRegionLenMask(bpy.types.Operator):
    bl_idname = "object.add_region_len_mask"
    bl_label = "Add length mask"
    bl_description = "It will let you assing UV regions based on strand length"
    bl_options = {"REGISTER","UNDO"}

    def execute(self, context):
        context.active_object.ht_props.threshold_mask.add()
        HTOOL_OT_AssignRegionsFromObjProps.update_assigned_uv_regions(context.active_object)
        return {"FINISHED"}

class OBJECT_OT_RemoveRegionLenMask(bpy.types.Operator):
    bl_idname = "object.remove_region_len_mask"
    bl_label = "Remove Mask"
    bl_description = "Remove Length Mask"
    bl_options = {"REGISTER", "UNDO"}

    index: bpy.props.IntProperty(name='Index', description='', default= 0, min=0)
    def execute(self, context):
        context.active_object.ht_props.threshold_mask.remove(self.index)
        HTOOL_OT_AssignRegionsFromObjProps.update_assigned_uv_regions(context.active_object)
        return {"FINISHED"}

class HT_UVPanel:
    bl_space_type = 'IMAGE_EDITOR'
    bl_region_type = 'UI'
    bl_category = "Hair Tool UV"


class IMAGE_PT_HTool(HT_UVPanel, bpy.types.Panel):
    bl_idname = 'IMAGE_PT_HTool'
    bl_label = "Hair UVs"

    def draw(self, context):
        layout = self.layout
        layout.operator("hair.uv_area_select", text='Define UV Regions', icon='UV_ISLANDSEL')  # Select by UV


class IMAGE_PT_AutoUV(HT_UVPanel, bpy.types.Panel):
    bl_parent_id = "IMAGE_PT_HTool"
    bl_idname = 'IMAGE_PT_AutoUV'
    bl_label = "Enable Auto UV"

    @classmethod
    def poll(cls, context):
        show = True if context.active_object and context.active_object.type == 'CURVE' and (context.active_object.data.bevel_object or context.active_object.data.bevel_depth) else False
        return show

    def draw_header(self, context):
        obj_uv_props = context.active_object.ht_props
        self.layout.prop(obj_uv_props, 'use_auto_uv', text='')

    def draw(self, context):
        layout = self.layout
        obj_uv_props = context.active_object.ht_props
        layout.operator("hair.update_assigned_uv_regions", icon='FILE_REFRESH')
        layout.active = obj_uv_props.use_auto_uv
        col = layout.column(align=True)
        col.prop(obj_uv_props, 'default_uv_region', text='')
        if obj_uv_props.default_uv_region == 'MANUAL':
            row = col.row(align=True)
            row.prop(obj_uv_props, "uv_regions")
        row = col.row(align=True)
        row.prop(obj_uv_props, "uv_seed")


class IMAGE_PT_LenUvMask(HT_UVPanel, bpy.types.Panel):
    bl_parent_id = "IMAGE_PT_AutoUV"
    bl_idname = 'IMAGE_PT_LenUvMask'
    bl_label = "Length masked UVs"

    def draw_header(self, context):
        obj_uv_props = context.active_object.ht_props
        self.layout.prop(obj_uv_props, 'use_length_mask_uv', text='')

    def draw(self, context):
        layout = self.layout
        # col.separator(factor=2)
        # col.label(text='')
        obj_uv_props = context.active_object.ht_props
        layout.active = obj_uv_props.use_auto_uv and obj_uv_props.use_length_mask_uv
        for i, mask_props in enumerate(obj_uv_props.threshold_mask):
            col = layout.column(align=True)
            inv_ic = 'REC' if mask_props.invert else 'CLIPUV_DEHLT'
            row = col.row(align=True)
            row.alignment = 'RIGHT'
            row.prop(mask_props, 'invert', icon=inv_ic, icon_only=True)
            row.operator("object.remove_region_len_mask", text='', icon='REMOVE').index = i

            split = col.split(factor=0.67, align=True)
            threshold_type = 'rel_threshold' if mask_props.treshold_mode == 'RELATIVE' else 'len_threshold'
            split.prop(mask_props, threshold_type)
            split.prop(mask_props, 'treshold_mode', text='')

            split = col.split(factor=0.7, align=True)
            split.prop(mask_props, 'margin')
            split.prop(mask_props, 'seed')
            row = col.row(align=True)
            row.prop(mask_props, 'uv_regions')

        col = layout.column(align=True)
        col.operator("object.add_region_len_mask", icon='ADD')


def uvGridShow_button(self, context):
    layout = self.layout
    if context.active_object:
        obj = context.active_object
        if obj.type == 'CURVE' and (obj.data.bevel_object or obj.data.bevel_depth):
            layout.operator("hair.uv_area_select", text='Hair UV', icon='UV_ISLANDSEL')  # Select by UV
        if obj.ht_props.short_hair_props.is_short_hair:
            layout.operator("hair.uv_area_select", text='Hair UV', icon='UV_ISLANDSEL')  # Select by UV


def append_IMAGE_HT_header():
    bpy.types.IMAGE_HT_header.append(uvGridShow_button)  # inject button into image editor header

def remove_IMAGE_HT_header():
    bpy.types.IMAGE_HT_header.remove(uvGridShow_button)
