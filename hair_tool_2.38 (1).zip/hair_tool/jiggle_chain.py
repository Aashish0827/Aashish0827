# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
# Copyright (C) 2017 JOSECONSCO
# Created by JOSECONSCO

import bpy
from math import degrees, sin, copysign, sqrt
from mathutils import Vector, Matrix, Quaternion, Euler
from mathutils.geometry import intersect_point_line
from bpy.app.handlers import persistent
# define signed distance field for rounded cone
# https://iquilezles.org/www/articles/distfunctions/distfunctions.htm
# def sdRoundCone(pbone, point):
#     # sampling independent computations (only depend on shape)
#     r1 = pbone.bone.head_radius
#     r2 = pbone.bone.tail_radius
#     head_tail_vec = pbone.tail - pbone.head
#     l2 = head_tail_vec.dot(head_tail_vec)
#     rad_diff = r1 - r2
#     a2 = l2 - rad_diff*rad_diff
#
#     # sampling dependant computations
#     head_p_vec = point - pbone.head
#     y = head_p_vec.dot(head_tail_vec)
#     z = y - l2
#     help = head_p_vec*l2 - head_tail_vec*y
#     x2 =  help.dot(help)
#     y2 = y*y*l2
#     z2 = z*z*l2
#
#     k =  copysign(rad_diff*rad_diff*x2, rad_diff) # copysign(a,b) =  a * sign(b)
#     if copysign(a2*z2, z) > k:
#         return  sqrt(x2 + z2) /l2 - r2
#     if copysign(a2*y2, y) < k:
#         return  sqrt(x2 + y2) /l2 - r1
#     return (sqrt(x2*a2/l2)+y*rad_diff)/l2 - r1

def bone_hit_simple(pbone, point):
    ''' Simple bbox check - sphere vs point'''
    center = (pbone.head+pbone.tail)/2
    rad = (pbone.head-pbone.tail).length
    rad += max(pbone.bone.head_radius , pbone.bone.tail_radius ) + 2*pbone.bone.envelope_distance
    rad *= 0.5
    return False if (point-center).length > rad else True


def bone_hit_detect_aprox(pbone, point):
    ''' aproximated with cone. Less accurate version
    (we hit straight perpendicular to |head tail| - rather than at angle caused by r1-r2) but should be good enough
    return outside - bool, normal, hit_co '''
    line_hit, a_fac = intersect_point_line(point, pbone.head, pbone.tail) # intersect_point_line(p, a, b)

    #NOTE: we have to clamp line to segment hit
    if a_fac < 0:
        line_hit = pbone.head
        rad = pbone.bone.head_radius
    elif a_fac > 1:
        line_hit = pbone.tail
        rad = pbone.bone.tail_radius
    else:
        rad = pbone.bone.head_radius*(1-a_fac) + pbone.bone.tail_radius*a_fac # lerp from ra to rb

    colision_offset = pbone.bone.envelope_distance
    if (line_hit - point).length > rad+1.1*colision_offset: # fast check if we are outside
        return False, None, None

    normal = (point - line_hit).normalized()
    surf_hit = line_hit +  (rad+colision_offset)*normal

    surf_hit_to_p = point - surf_hit # vec from inside line to capsule surface hit
    is_inside = surf_hit_to_p.dot(normal) < 0
    #dist = (surf_hit-point).length
    return is_inside, normal, surf_hit


def bone_hit_detect_exact(pbone, point):
    ''' cone hit detection - more accuartate but not 100% exact
    (we hit at angle defined by r1-r2 difference
    offset_fac = 1.02 => move 2% outside of surface
    return outside - bool, normal, hit_co '''
    r_head = pbone.bone.head_radius
    r_tail = pbone.bone.tail_radius
    colision_offset = pbone.bone.envelope_distance
    a_p = point - pbone.head
    a_b = pbone.tail - pbone.head
    ab_len = a_b.length

    ap_projected_ab = a_p.project(a_b)
    ap_perp = a_p - ap_projected_ab
    cone_slope = (r_head-r_tail)/ ab_len
    ap_fix = cone_slope * ap_perp.length # dist from P_projected' to  P2' - point projected on a_b based on dr/ab_len slope

    line_hit = pbone.head + ap_projected_ab - ap_fix * (a_b/ab_len)

    a_to_hit = line_hit-pbone.head

    # NOTE: we hit cone line a_b -> now clamp and  move line_hit outside to surface of cone
    sign = -1 if a_to_hit.dot(a_b) < 0 else 1
    a_fac = sign * a_to_hit.length/ab_len # a_fac - distance from the first point of a_b line as a percentage of the length of the line

    # NOTE: clamp line to segment hit
    if a_fac < 0:
        line_hit = pbone.head
        rad = r_head
    elif a_fac > 1:
        line_hit = pbone.tail
        rad = r_tail
    else:
        rad = r_head*(1-a_fac) + r_tail*a_fac # lerp from ra to rb

    line_hit_to_p = point - line_hit

    normal = line_hit_to_p.normalized()
    surf_hit = line_hit +  (rad+colision_offset)*normal

    surf_hit_to_p_vec = point - surf_hit # vec from inside line to capsule surface hit
    is_inside = surf_hit_to_p_vec.dot(normal) < 0
    return is_inside, normal, surf_hit

class OBJECT_OT_Select_Jiggle_Group(bpy.types.Operator):
    bl_idname = "object.select_jiggle_group"
    bl_label = "Select bones in group"
    bl_description = "Select jiggle bones assigned to active group"
    bl_options = {"REGISTER","UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'ARMATURE' and obj.mode == 'POSE' and len(obj.ht_props.jiggle_props.physics_props) > 0

    def execute(self, context):
        obj = context.active_object
        jiggle_props = obj.ht_props.jiggle_props

        # NOTE: setup jiggle bones color - using bone_groups
        physics_props_cnt = len(jiggle_props.physics_props)
        if jiggle_props.active_index > physics_props_cnt-1:
            self.report({'WARNING'}, f'Active jiggle group index is out of range.')
            return {'CANCELLED'}

        for pbone in obj.pose.bones:
            pbone.bone.select = False # deselect first all
            if pbone.ht_props.jiggle_index == jiggle_props.active_index:
                pbone.bone.select = True

        return {"FINISHED"}

class OBJECT_OT_Assign_Bones_Jiggle(bpy.types.Operator):
    bl_idname = "object.assign_jiggle"
    bl_label = "Assign Jiggle to bones"
    bl_description = "Assign jiggle physics to selected pose bones"
    bl_options = {"REGISTER","UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return context.selected_pose_bones and obj.ht_props.jiggle_props.active_index < len(obj.ht_props.jiggle_props.physics_props)

    @staticmethod
    def assign_jiggle_to_bones(obj, pbones):
        jiggle_props = obj.ht_props.jiggle_props

        # NOTE: setup jiggle bones color - using bone_groups
        physics_props_cnt = len(jiggle_props.physics_props)
        if physics_props_cnt == 0:
            OBJECT_OT_Add_Jiggle_Settings.add_jiggle_settings(obj)
            jiggle_props.active_index = 0
        if jiggle_props.active_index < physics_props_cnt:
            jiggle_props.active_index = len(jiggle_props.physics_props)-1

        jiggle_bone_group = obj.pose.bone_groups[jiggle_props.active_index]
        for pbone in pbones:
            pbone.bone_group = jiggle_bone_group
            pbone.ht_props.jiggle_index = jiggle_props.active_index

    def execute(self, context):
        obj = context.active_object
        self.assign_jiggle_to_bones(obj, context.selected_pose_bones)

        return {"FINISHED"}


class OBJECT_OT_Remove_Bones_Jiggle(bpy.types.Operator):
    bl_idname = "object.remove_bones_jiggle"
    bl_label = "Remove Jiggle from bones"
    bl_description = "Remove jiggle physics from selected pose bones"
    bl_options = {"REGISTER","UNDO"}

    @classmethod
    def poll(cls, context):
        return context.selected_pose_bones

    def execute(self, context):
        for pbone in context.selected_pose_bones:
            pbone.bone_group = None
            pbone.ht_props.jiggle_index = -1
        return {"FINISHED"}

class OBJECT_OT_Add_Jiggle_Settings(bpy.types.Operator):
    bl_idname = "object.add_jiggle_settings"
    bl_label = "New Jiggle Settings"
    bl_description = "Create new jiggle physics settings"
    bl_options = {"REGISTER","UNDO"}

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'ARMATURE'

    @staticmethod
    def add_jiggle_settings(obj):
        jiggle_props = obj.ht_props.jiggle_props
        new_props = jiggle_props.physics_props.add()
        physics_props_cnt = len(jiggle_props.physics_props)
        new_props.name = f'Jiggle_{physics_props_cnt}'

        # NOTE: setup jiggle bones color - using bone_groups
        # jiggle_bone_group = obj.pose.bone_groups.get(f'Jiggle_{idx_str}')
        bone_groups_cnt = len(obj.pose.bone_groups)
        if bone_groups_cnt < physics_props_cnt:
            jiggle_bone_group = obj.pose.bone_groups.new(name=f'Jiggle')
            idx_str = f'{bone_groups_cnt+1:02d}' # with leading zeros
            jiggle_bone_group.color_set = f'THEME{idx_str}'

        jiggle_props.active_index = physics_props_cnt-1

    def execute(self, context):
        obj = context.active_object
        self.add_jiggle_settings(obj)
        if context.selected_pose_bones:
            bpy.ops.object.assign_jiggle()
        return {"FINISHED"}


class OBJECT_OT_Remove_Jiggle_Settings(bpy.types.Operator):
    bl_idname = "object.remove_jiggle_settings"
    bl_label = "Remove chain"
    bl_description = "Remove jiggle chain"
    bl_options = {"REGISTER","UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'ARMATURE'

    def execute(self, context):
        obj = context.active_object
        jiggle_props = obj.ht_props.jiggle_props

        physics_props_cnt = len(jiggle_props.physics_props)
        if jiggle_props.active_index > physics_props_cnt - 1:
            jiggle_props.active_index = physics_props_cnt - 1

        jiggle_props.physics_props.remove(jiggle_props.active_index)

        bone_groups_cnt = len(obj.pose.bone_groups)
        if jiggle_props.active_index < bone_groups_cnt:
            sel_bone_group = obj.pose.bone_groups[jiggle_props.active_index]
            obj.pose.bone_groups.remove(sel_bone_group)

        for i in range(jiggle_props.active_index, physics_props_cnt):
            if i == jiggle_props.active_index:
                for bone in obj.pose.bones:
                    if bone.ht_props.jiggle_index == jiggle_props.active_index:
                        bone.ht_props.jiggle_index = -1
                        bone.bone_group = None
            else:
                for bone in obj.pose.bones:
                    if bone.ht_props.jiggle_index == i:
                        bone.ht_props.jiggle_index = i - 1
                        bone.bone_group = obj.pose.bone_groups[i-1]


        last_idx = len(jiggle_props.physics_props)-1
        if jiggle_props.active_index > last_idx:
            jiggle_props.active_index = last_idx

        return {"FINISHED"}

#Select coliision bones operator
class OBJECT_OT_Select_Collision_Bones(bpy.types.Operator):
    bl_idname = "object.select_collision_bones"
    bl_label = "Select Collision Bones"
    bl_description = "Select collision bones"
    bl_options = {"REGISTER","UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'ARMATURE'

    def execute(self, context):
        obj = context.active_object
        obj.data.display_type = 'ENVELOPE'
        for pbone in obj.pose.bones:
            if pbone.ht_props.jiggle_collision:
                pbone.bone.hide = False
                pbone.bone.select = True
        return {"FINISHED"}



class JBONES_UL_props(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        obj = data.id_data
        active_physics_prop = item
        # jiggle_props = data
        # item_idx = int(item.path_from_id('mass')[-7])  # wont work if  jiggle_propx idx is 2 digits
        item_idx = [i for i, ph in enumerate(obj.ht_props.jiggle_props.physics_props) if ph == active_physics_prop][0]
        if active_physics_prop:
            layout.prop(active_physics_prop, 'name', text='', emboss=False)
            if item_idx < len(obj.pose.bone_groups):
                group = obj.pose.bone_groups[item_idx]
                row = layout.row(align=True)
                row.enabled = group.is_custom_color_set  # only custom colors are editable
                row.prop(group.colors, "normal", text="")
        else:
            layout.label(text="", translate=False, icon_value=icon)

class  HTOOL_PT_VIEW3D_PT_JIGGLE(bpy.types.Panel):
    bl_label = "Jiggle Physics"
    bl_idname = "HTOOL_PT_VIEW3D_PT_JIGGLE"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Hair Tool'
    # bl_context = 'objectmode'
    # bl_options = {'HIDE_HEADER'}

    drawAsMenu = False

    @classmethod
    def poll(cls, context):
        return context.active_object

    def draw(self, context):
        layout = self.layout
        obj = context.active_object
        scn_jiggle_props = context.scene.ht_props.jiggle_props
        text = 'Run Spring Physics' if not scn_jiggle_props.sim_is_running else 'Simulation enabled'
        if scn_jiggle_props.sim_is_running:      # disable with bool prop
            layout.prop(scn_jiggle_props, 'sim_is_running', text=text, icon="GP_MULTIFRAME_EDITING")
        else: # if disabled then give option to enable
            layout.operator("object.enable_spring_physics", icon="GP_MULTIFRAME_EDITING", text=text, depress=scn_jiggle_props.sim_is_running )
            layout.prop(scn_jiggle_props, 'sim_mode')
        if  obj and obj.type == 'ARMATURE' and obj.mode == 'POSE':
            obj_jiggle_props = obj.ht_props.jiggle_props
            if context.active_pose_bone:
                col = layout.column(align=True)
                row = col.row(align=True)
                txt = 'Add Collision' if not context.active_pose_bone.ht_props.jiggle_collision else 'Remove Collision'
                row.prop(context.active_pose_bone.ht_props, 'jiggle_collision', icon='MOD_PHYSICS', text=txt)
                row.operator("object.select_collision_bones", icon="BONE_DATA", text='')
                if context.active_pose_bone.ht_props.jiggle_collision:
                    col.prop(context.active_pose_bone.ht_props, 'friction')

            if scn_jiggle_props.sim_mode == 'CUSTOM':
                col.prop(obj_jiggle_props, 'time_step')
            if obj:
                layout.label(text='Assign Jiggle to selection:')
                row = layout.row()
                row.template_list("JBONES_UL_props", "", obj_jiggle_props, "physics_props", obj_jiggle_props, "active_index", rows=3)
                col = row.column(align=True)
                col.operator("object.add_jiggle_settings", icon="ADD", text='')
                col.operator("object.remove_jiggle_settings", icon="REMOVE", text='')
                col.menu("HT_MT_Jiggle_BonesMenu", text='', icon='DOWNARROW_HLT')

                chain_idx = obj_jiggle_props.active_index
                physics_props_cnt = len(obj_jiggle_props.physics_props)
                if physics_props_cnt and chain_idx < physics_props_cnt:
                    chain_props = obj_jiggle_props.physics_props[chain_idx]
                    col = layout.column(align=True)
                    col.prop(chain_props, 'mass')
                    col.prop(chain_props, 'stiffness')
                    col.prop(chain_props, 'damping')
                    col.prop(chain_props, 'gravity')


class HT_MT_Jiggle_BonesMenu(bpy.types.Menu):
    bl_idname = "HT_MT_Jiggle_BonesMenu"
    bl_label = "Jiggle Bones"

    def draw(self, context):
        layout = self.layout
        layout.operator("object.assign_jiggle")
        layout.operator("object.remove_bones_jiggle")
        layout.operator("object.select_jiggle_group")

class ChainSegment():
    def __init__(self, root_data, tip_data):
        '''
            root_data: loc, exp_map
        '''
        self.mass = 1.0
        self.damping = 2.0
        self.stiffness = 10.
        self.gravity = Vector((0, 0, -9.81))

        root_co = root_data['loc']
        self.prev_root_co = root_co.copy() # needed to handle node translation
        self.root_co = root_co.copy() # needed to handle node translation
        self.tip_co = tip_data['loc'].copy()

        self.mag = (self.tip_co - self.root_co).length
        # self.track_axis = Vector((0, 1, 0))*self.mag

        self.init_dir = root_data['rest_rot'].copy() # stores initial chain rot
        self.rest_dir = root_data['rest_rot'].copy() # target for jiggle
        self.prev_dir = root_data['curr_rot'].copy()
        self.current_dir = root_data['curr_rot'].copy()
        self.velocity = Vector((0.0, 0.0, 0.0))

        self.ang_vel = Vector((0, 0, 0))

        self.init_mat = root_data['rest_mat'].copy()
        self.rest_mat = root_data['rest_mat'].copy()
        self.current_quat = root_data['rest_mat'].to_quaternion()
        self.m_p_inv = root_data['m_p_inv']
        self.next = None

        self.pbone = None
        self.phys_prop = None

    def update_physics_props(self):
        self.mass = self.phys_props.mass
        self.damping = self.phys_props.damping
        self.stiffness = self.phys_props.stiffness
        self.gravity = Vector((0, 0, -self.phys_props.gravity))

    def get_current_rotation(self):
        return self.root_co, self.current_quat # quat(dir*axis)

class SubChain():
    def __init__(self, chain_data):
        '''
            chain_data is a list of tuples (co, rotation - axis*angle)
        '''
        self.dt = 0.04
        self.reached_rest_state = False # TODO: add per each subchain
        self.segments = []
        self.pbones = []
        self.empties = []
        self.collision_bones = []

        # NOTE: create chain [(d1,d2), (d2,d3), (d3, ..)]
        prev_seg_data = chain_data[0]
        prev_seg = None
        segments = []
        for seg_data in chain_data[1:]:  # 4 objs give 3 segs
            new_seg = ChainSegment(prev_seg_data,seg_data )
            if prev_seg:
                prev_seg.next = new_seg
            segments.append(new_seg)
            prev_seg_data = seg_data
            prev_seg = new_seg
        self.segments = segments

    def set_target_bones(self, child_bones):
        ''' they will receive the sim output '''
        parent_bone = child_bones[0].parent
        self.pbones = child_bones
        # NOTE: root local matrix required to to properly propagate movement from root.parent bone
        # NOTE: get root.pbone.matrix_local by diffing  prev_bone.mw-root.mw
        if parent_bone:
            self.root_pbone_mat_local = parent_bone.matrix.inverted() @ child_bones[0].matrix @ child_bones[0].matrix_basis.inverted()
        else:
            self.root_pbone_mat_local = child_bones[0].matrix @ child_bones[0].matrix_basis.inverted()


    def solve_semi_euler_euler(self, seg):
        '''  stable it dt < 1/4 * T
        vel[n+2] = v[n] - h * omgea^2 * x[n]
        x[n+1] = x[n] + h * vel[n+2]
        omega^2 = k/m     #angular freq -  controls rate of oscilation
        2*dr*omega = c/m  # dr - damping ratio - dimensionless and controls amount of oscilation (0, 1) (no_damp, perfect_decay)


        w = w0 + a * dt
        q[n+1] = q[n] + 0.5 wq * q[n]
        '''
        pass

    def integrate_euler_loc(self, seg):
        dt = self.dt
        # seg.set_physics(phys_props.mass, phys_props.damping, phys_props.stiffness, phys_props.gravity)

        if seg.next:
            if seg.init_mat != seg.rest_mat: # NOTE: if prev chain rest_dir changed, propagete this change up the chain
                seg.next.rest_mat = seg.rest_mat @ seg.next.m_p_inv  # aka  parent.mw @ child.mp_inv
                seg.next.rest_dir = seg.next.rest_mat.col[1].xyz  # track with  y
            else:
                seg.next.rest_mat = seg.next.init_mat.copy()
                seg.next.rest_dir = seg.next.rest_mat.col[1].xyz  # track with  y

        if seg.prev_root_co != seg.root_co: # NOTE: handles root_tranlation
            prev_root_to_tip = seg.tip_co - seg.prev_root_co # from prev_root to next_seg.root
            root_to_tip = seg.tip_co - seg.root_co # from current_root to next_seg.root
            q_diff = prev_root_to_tip.rotation_difference(root_to_tip)
            seg.current_dir.rotate(q_diff)
            seg.prev_root_co = seg.root_co.copy()


        # T =R x F  ;  a = T/I  = T/ (m R^2) = F R sin() / m R^2  = g * sin() / R
        g_const = Vector((0,0, -seg.phys_props.gravity)) # longer lever arm, bigger gravity acc
        grav_tangent = g_const - g_const.project(seg.rest_dir) # tangetn to rest_dir (current_dir wobbles)
        grav_tangent *= seg.mag

        x =  seg.current_dir - seg.rest_dir
        spring_force = - seg.phys_props.stiffness*x - seg.phys_props.damping * seg.velocity  # F = -kx - bv - g*m
        acc = spring_force / seg.phys_props.mass + grav_tangent  # in theory  /= m R^2 => I
        seg.velocity += acc * dt

        for collision_bone in self.collision_bones:
            if collision_bone.name == seg.pbone.name: # DONE: avoid self collision
                continue

            is_inside, normal, surf_hit = bone_hit_detect_aprox(collision_bone, seg.tip_co)
            if is_inside:
                root_to_tip = seg.current_dir # why using current_dir gives jitter?
                root_to_hit = surf_hit - seg.root_co # from current_root to next_seg.root
                q_diff = root_to_tip.rotation_difference(root_to_hit)
                seg.current_dir.rotate(q_diff)
                seg.velocity -= collision_bone.ht_props.friction * seg.velocity * dt  #  Frict = f * m * a,   vf = f * v * dt

        # NOTE: is this slower than quat?
        seg.current_dir = seg.current_dir + seg.velocity * dt
        seg.current_dir.normalize()


        # NOTE: does not reuire normalization... quat is slower?
        # new_dir = seg.current_dir + seg.velocity * dt
        # quat_curr_to_new = seg.current_dir.rotation_difference(new_dir)
        # seg.current_dir.rotate(quat_curr_to_new)
        seg.tip_co = seg.root_co + seg.mag * seg.current_dir


        rd_prev_curr = seg.rest_dir.rotation_difference(seg.current_dir)
        seg.current_quat = seg.rest_mat.to_quaternion()
        seg.current_quat.rotate(rd_prev_curr)

        if seg.next:  # NOTE: seg.tip.co  -> seg[n+1].root.co
            seg.next.root_co = seg.tip_co.copy()
        else:  # extra check if sim reached rest state
            vel_mag = seg.ang_vel.length
            if vel_mag + acc.length < 0.1:
                self.reached_rest_state = True


        # seg.prev_dir = seg.current_dir.copy()

    def solve_euler_axis_angle(self, seg):
        ''' This sheisse works
        stable it dt < 1/4 * T
        vel[n+1] = v[n] - h * omgea^2 * x[n]
        x[n+1] = x[n] + h * vel[n+1]
        omega^2 = k/m     #angular freq -  controls rate of oscilation
        2*dr*omega = c/m  # dr - damping ratio - dimensionless and controls amount of oscilation (0, 1) (no_damp, perfect_decay)

        w = w0 + a * dt
        q[n+1] = q[n] + 0.5 wq * q[n]
        '''
        dt = self.dt

        if seg.next:
            if seg.init_dir != seg.rest_dir: # NOTE: if prev chain rest_dir changed, propagete this change up the chain
                diff = seg.init_dir - seg.rest_dir
                seg.next.rest_dir = seg.next.init_dir - diff
            else:  # FIXed: eg. reseting root bone rot wont  reset rest of chaing
                seg.next.rest_dir = seg.next.init_dir

        if seg.prev_root_co != seg.root_co: # NOTE: handles root_tranlation
            prev_root_to_tip = seg.tip_co - seg.prev_root_co # from prev_root to next_seg.root
            root_to_tip = seg.tip_co - seg.root_co # from current_root to next_seg.root
            q_diff = prev_root_to_tip.rotation_difference(root_to_tip)
            seg.current_dir += q_diff.to_exponential_map()
            seg.prev_root_co = seg.root_co.copy()


        diff = seg.current_dir - seg.rest_dir
        spring_force = - seg.stiffness*diff - seg.damping * seg.ang_vel # F = -kx - bv - g*m
        acc = spring_force / seg.mass #+ g*grav_dir.to_exponential_map()
        seg.ang_vel += acc * dt
        seg.current_dir += seg.ang_vel * dt

        track_curr = seg.track_axis.copy()
        curr_quat = Quaternion(seg.current_dir)
        track_curr.rotate(curr_quat)

        if True:
            grav = Vector((0, 0, -0.5))*seg.mag
            grav_tan = grav - grav.project(track_curr)
            grav_dir = track_curr.rotation_difference(track_curr+grav_tan)
            track_curr.rotate(grav_dir)
            seg.curr_with_grav_dir = (grav_dir @ curr_quat).to_exponential_map()

        seg.tip_co = seg.root_co + track_curr

        if seg.next:  # NOTE: seg.tip.co  -> seg[n+1].root.co
            seg.next.root_co = seg.tip_co.copy()
        else:  # extra check if sim reached rest state
            vel_mag = seg.ang_vel.length
            if vel_mag + acc.length < 0.1:
                self.reached_rest_state = True

    def solve_verlet_integration_euler(self, seg):
        ''' does not behave well with double current_dir. Problems with maintaining dir
         args:  seg - processed segment
        '''
        dt = self.dt
        if seg.next:
            if seg.init_euler != seg.rest_euler: # NOTE: if prev chain rest_euler changed, propagete this change up the chain
                diff = seg.init_euler - seg.rest_euler
                new_rest =  seg.next.init_euler - diff
                total_diff = new_rest - seg.next.rest_euler
                seg.next.rest_euler = new_rest
                stiff_01 = seg.stiffness/60 # (40  max stiffnes) -  remap from (0, 40) - (1, 0.5) => (max_wiggle, 50% wiggle)
                seg.current_euler += total_diff * stiff_01 # NOTE: update both current and prev euler - so that we wont build velocity in diff dir
                seg.prev_euler += total_diff * stiff_01
            else:  # FIX: eg. reseting root bone rot wont  reset rest of chaing
                seg.next.rest_euler = seg.next.init_euler

        if seg.prev_root_co != seg.root_co: # NOTE: handles root_tranlation
            prev_root_to_tip = seg.tip_co - seg.prev_root_co # from prev_root to next_seg.root
            root_to_tip = seg.tip_co - seg.root_co # from current_root to next_seg.root
            q_diff = prev_root_to_tip.rotation_difference(root_to_tip)
            q_diff_evec = Vector(q_diff.to_euler()[:])
            stiff_01 = 1 - seg.stiffness/60 # (40  max stiffnes) -  remap from (0, 40) - (1, 0.5) => (max_wiggle, 50% wiggle)
            seg.current_euler += q_diff_evec * stiff_01 # NOTE: update both current and prev euler - so that we wont build velocity in diff dir
            seg.prev_euler += q_diff_evec * stiff_01
            seg.prev_root_co = seg.root_co

        if True: # gravity causes jiggle on gimball?
            current_dir = seg.track_axis.copy()
            current_dir.rotate(Euler(seg.current_euler).to_quaternion())
            gravity = Vector((0,0,-0.1))
            g_diff = gravity.rotation_difference(current_dir)

            angle = g_diff.angle
            g_dirr = Vector(g_diff.to_euler()[:])*sin(angle)


        velocity = (seg.current_euler - seg.prev_euler)/dt    # vel =  curr - prev dir
        x = seg.current_euler - seg.rest_euler
        spring_force = - seg.stiffness*x -  seg.damping * velocity - 10*g_dirr*seg.mass # F = -kx - bv - g*m
        acceleration = spring_force / seg.mass

        next_dir = 2 * seg.current_euler - seg.prev_euler + acceleration * dt * dt #  v = 2v(n) - v(n-1) + at^2
        seg.prev_euler = seg.current_euler
        seg.current_euler = next_dir

        track_cpy = seg.track_axis.copy()
        track_cpy.rotate(Euler(seg.current_euler)) # XXX: do we need convert to quat?
        seg.tip_co = seg.root_co + track_cpy

        if seg.next:  # NOTE: seg.tip.co  -> seg[n+1].root.co
            seg.next.root_co = seg.tip_co.copy()
        else:  # extra check if sim reached rest state
            vel_mag = velocity.length
            accel_mag = acceleration.length
            if vel_mag + accel_mag < 0.1:
                self.reached_rest_state = True

    def step(self):
        ''' run euler motion integration for each element in chain '''
        for seg in self.segments:
            # self.solve_verlet_integration_euler(seg) # number 1)
            self.integrate_euler_loc(seg) # number 1)


class SpringChains():
    def __init__(self, armature, write_loc = True, write_rot = False, can_rest=True):
        ''' chain_data[n]['loc'] - segment root loc, curr_rot, etc, '''
        self.sub_chains = []
        self.write_loc = write_loc #write translation to chain root_objs
        self.write_rot = write_rot #write rotation to chain root_objs
        self.armature = armature
        self.can_rest = can_rest # can chain rest if movement is small?

    def add_sub_chain(self, chain_data):
        sc = SubChain(chain_data)
        self.sub_chains.append(sc)
        return sc

    def solve_chains(self):
        ''' run euler motion integration for each element in chain '''
        for chain in self.sub_chains:
            pbones = chain.pbones
            if not (self.can_rest and chain.reached_rest_state):
                # NOTE: write transformation from chain.parent, to first root.seg (chaing[0])
                chain_root_pb = pbones[0]
                root_mat = chain.root_pbone_mat_local
                if chain_root_pb.parent:
                    root_mat = chain_root_pb.parent.matrix @ root_mat

                if chain_root_pb.bone.use_inherit_rotation:
                    chain.segments[0].rest_dir = root_mat.col[1].xyz # track with y
                    chain.segments[0].rest_mat = root_mat
                chain.segments[0].root_co = root_mat.col[3].xyz # propagate change from pbone to root empty
                chain.step()

                # NOTE: write chain.seg coordinates
                for i, (pbone, sim_seg) in enumerate(zip(pbones, chain.segments)):
                    loc, current_quat = sim_seg.get_current_rotation()
                    rot_constraint = pbone.constraints.get('Set Rotation')
                    if not rot_constraint:
                        rot_constraint = pbone.constraints.new('LIMIT_ROTATION')
                        rot_constraint.use_limit_x = rot_constraint.use_limit_y = rot_constraint.use_limit_z = True
                        rot_constraint.owner_space = 'WORLD'
                        rot_constraint.influence = 1.0
                        rot_constraint.name = 'Set Rotation'


                    rot_eu = current_quat.to_euler()
                    rot_constraint.min_x = rot_constraint.max_x = rot_eu.x
                    rot_constraint.min_y = rot_constraint.max_y = rot_eu.y
                    rot_constraint.min_z = rot_constraint.max_z = rot_eu.z

                    if chain.empties:
                        empty = chain.empties[i]
                        empty.location = loc
                        empty.rotation_quaternion = current_quat

    def finish_chains(self):
        for sub_chain in self.sub_chains: # force chains movement on scene change
            for pbone in reversed(sub_chain.pbones):
                copy_rot = pbone.constraints.get('Set Rotation')
                if copy_rot:
                    world_rot_from_constr = Euler((copy_rot.min_x, copy_rot.min_y, copy_rot.min_z)).to_matrix().to_4x4()
                    rot_from_constr = self.armature.convert_space(pose_bone=pbone, matrix=world_rot_from_constr, from_space='WORLD', to_space='LOCAL')
                    pbone.rotation_quaternion = rot_from_constr.to_quaternion()
                    pbone.constraints.remove(copy_rot)


def matrix_world(armature_ob, pbone):
    ''' Gives pbone.matrix -> but calculated manually'''
    local = pbone.bone.matrix_local
    basis = pbone.matrix_basis
    if pbone.parent:
        parent_local = pbone.parent.bone.matrix_local
        return matrix_world(armature_ob, pbone.parent) @ (parent_local.inverted() @ local) @ basis
    else:
        return  local @ basis


def get_child_chains(pbone, out_chain):
    ''' get armature childs bones as flat child list of branches '''
    for i,child in enumerate(pbone.children):
        if child.ht_props.jiggle_index > -1:
            if i > 0 or not child.bone.use_connect or child.parent.ht_props.jiggle_index == -1:  # more than 1 child or not connected, or parent was not jiggle
                out_chain.append([]) # generate new subchain
            out_chain[-1].append(child)
        get_child_chains(child, out_chain)

def get_root_bones(arma):
    ''' get all root bones for rig. In theory only one'''
    root_bones = []
    for pbone in arma.pose.bones:
        if not pbone.parent:
            root_bones.append(pbone)
    return root_bones

def setup_empty(context,name, mat):
    empty = bpy.data.objects.get(name)
    if not empty:
        empty = bpy.data.objects.new(name, None)
        empty.rotation_mode = 'QUATERNION'
        empty.empty_display_type = 'ARROWS'
        empty.empty_display_size = 0.02
        context.scene.collection.objects.link(empty)
    empty.matrix_world = mat
    return empty

def init_arma_spring_chains(context):
    armature_springs = []
    arma_objs = [obj for obj in context.visible_objects if obj.type == 'ARMATURE']
    dt = 1/context.scene.render.fps
    scn_jiggle_props = context.scene.ht_props.jiggle_props
    can_rest = scn_jiggle_props.sim_mode == 'REALTIME' # NOTE: enable 'chain freeze' only for 'REALTIME' mode
    for arma_obj in arma_objs:
        obj_springs = SpringChains(arma_obj, write_loc = True, write_rot = True, can_rest = can_rest)

        obj_jiggle_props = arma_obj.ht_props.jiggle_props
        root_bones = get_root_bones(arma_obj)
        root_bones = [rb for rb in root_bones if rb]

        #get collision pbones
        collision_bones = []
        for pbone in arma_obj.pose.bones:
            if pbone.ht_props.jiggle_collision:
                collision_bones.append(pbone)

        for root_bone in root_bones:
            in_pbone_chains = [[root_bone]] if root_bone.ht_props.jiggle_index > -1 else [[]]
            get_child_chains(root_bone, in_pbone_chains)  # scan child branches for chains if jiggle bones
            # import pprint
            # pprint.pprint(in_pbone_chains)
            in_pbone_chains = [chain for chain in in_pbone_chains if chain]
            for pbone_chain in in_pbone_chains:
                chain_init_data = []
                empties = []

                parent = pbone_chain[0].parent
                parent_mat = Matrix.Identity(4)
                if parent:  # get parent_mat - without local transfroms of all pbone_chain[0] parents
                    parent_mat = arma_obj.convert_space(pose_bone=parent, matrix=parent_mat, from_space='LOCAL_WITH_PARENT', to_space='WORLD')

                for pbone in pbone_chain:
                    # pbone.bone.use_inherit_rotation = True
                    pbone.rotation_mode = 'QUATERNION'
                    world_matrix = pbone.matrix
                    rest_mat_world = arma_obj.convert_space(pose_bone=pbone, matrix=Matrix.Identity(4), from_space='LOCAL_WITH_PARENT', to_space='WORLD')
                    # rest_mat_world = world_matrix @ pbone.matrix_basis.inverted() # without matrix_basis - but icludes all parent local transf mat_basis...
                    link_data = {}
                    link_data['loc'] = world_matrix.col[3].xyz
                    link_data['curr_rot'] = world_matrix.col[1].xyz
                    link_data['rest_rot'] = rest_mat_world.col[1].xyz
                    link_data['rest_mat'] = rest_mat_world
                    link_data['m_p_inv']  = parent_mat.inverted() @ rest_mat_world
                    chain_init_data.append(link_data)
                    # empties.append(setup_empty(context,pbone.name, world_matrix)) # NOTE: for debugging
                    parent_mat = rest_mat_world

                # NOTE: helper - tail point - required for tip_co - root_co - in sim step
                link_data = {}
                link_data['loc'] = pbone_chain[-1].tail
                link_data['curr_rot'] = world_matrix.col[1].xyz
                link_data['rest_rot'] = rest_mat_world.col[1].xyz
                link_data['rest_mat'] = rest_mat_world
                link_data['m_p_inv']  = parent_mat.inverted() @ rest_mat_world
                chain_init_data.append(link_data)

                spring_sub_chain = obj_springs.add_sub_chain(chain_init_data)
                for pbone, seg in zip(pbone_chain, spring_sub_chain.segments):
                    seg.pbone = pbone
                    seg.phys_props = obj_jiggle_props.physics_props[pbone.ht_props.jiggle_index] # idx should be > -1
                    # seg.set_physics(phys_props.mass, phys_props.damping, phys_props.stiffness, phys_props.gravity)

                if empties:
                    spring_sub_chain.empties = empties
                spring_sub_chain.collision_bones = collision_bones
                spring_sub_chain.dt = dt
                spring_sub_chain.set_target_bones(pbone_chain)
        if obj_springs.sub_chains: # does armature has any jiggle bone chains
            armature_springs.append(obj_springs)
    return armature_springs

SPRING_OBJS = []
@persistent
def spring_bone_frame_change(scn):
    # print('Frame change')
    # bpy.context.scene.ht_props.jiggle_props.jiggle_frame_step = True
    # NOTE: for this SpringChains.can_rest = False - sim is always running
    for obj_springs in SPRING_OBJS:
        obj_springs.solve_chains() # jiggle them always - even in no scene update (wait for chain.reached_rest_state)


class HT_OT_SpringBones(bpy.types.Operator):
    bl_idname = "object.enable_spring_physics"
    bl_label = "Enable Spring Sim"
    bl_description = "Enable Spring Simulation on bones. Assign jiggle physics to bones first (in pose mode).\nSimulation timesteps is based on scene animation fps\n[ESC] - to finish the sim"
    bl_options = {'REGISTER','UNDO_GROUPED'}

    _timer = None

    def invoke(self, context, event):
        scn_jiggle_props = context.scene.ht_props.jiggle_props
        scn_jiggle_props.sim_is_running = True
        spring_chains = init_arma_spring_chains(context)
        if len(spring_chains) == 0:
            self.report({'ERROR'}, f'No spring bones set on visible armatures. Cancelling!')
            return {'CANCELLED'}
        self.spring_objs = spring_chains
        self.dep = context.evaluated_depsgraph_get()
        if scn_jiggle_props.sim_mode == 'FRAME_CHANGE': # modal only takes care of finishing the sim
            global SPRING_OBJS
            SPRING_OBJS = spring_chains
            bpy.app.handlers.frame_change_post.append(spring_bone_frame_change)
        else: # 'REALTIME'
            dt = 1/context.scene.render.fps
            self._timer = context.window_manager.event_timer_add(dt, window=context.window)
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}


    def modal(self, context, event):
        scn_jiggle_props = context.scene.ht_props.jiggle_props
        if event.type == 'TIMER':
            # print('Timer')
            # NOTE: force chains movement on scene change
            if len(self.dep.updates) > 0 or context.screen.is_animation_playing: # XXX: disabled or else sim is paused on slow animation
                # for update in self.dep.updates:
                #     if update.id.original == context.active_object
                for obj_springs in self.spring_objs:
                    for sub_chain in obj_springs.sub_chains:
                        sub_chain.reached_rest_state = False #it is possible we need update arma

            # for sub_chain in self.spring_objs.sub_chains: # bones was deleted => finish sim
            #     if not sub_chain.pbones[0].bone:
            #         return self.finish(context)
            for obj_springs in self.spring_objs:
                obj_springs.solve_chains() # jiggle them always - even in no scene update (wait for chain.reached_rest_state)

        # on undo event finish spring sim
        elif event.type == 'Z' and event.value == 'PRESS' and event.ctrl:
            return self.finish(context)

        elif event.type in {"ESC"} and event.value == 'PRESS':
            return self.finish(context)
        elif not scn_jiggle_props.sim_is_running:
            return self.finish(context)

        return {"PASS_THROUGH"}
        # return {"RUNNING_MODAL"}

    def finish(self, context):
        #apply pose bones constraints
        context.scene.ht_props.jiggle_props.sim_is_running = False
        for obj_springs in self.spring_objs:
            obj_springs.finish_chains()

        if context.scene.ht_props.jiggle_props.sim_mode == 'FRAME_CHANGE':
            bpy.app.handlers.frame_change_post.remove(spring_bone_frame_change)
        else:
            wm = context.window_manager
            wm.event_timer_remove(self._timer)
            self._timer = None
        return {"FINISHED"}


