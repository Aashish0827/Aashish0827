# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
# Copyright (C) 2017 JOSECONSCO
# Created by JOSECONSCO

import bpy
import math
from math import sin, cos
import numpy as np
from copy import deepcopy
from mathutils import Vector, Matrix, kdtree, Euler
from bpy.props import EnumProperty, FloatProperty, BoolProperty, IntProperty, StringProperty
from .utils.curve_wrapper import Splines, SplineFlat
from .utils.helper_functions import calc_exponent, angle_signed, get_obj_mesh_bvht, bvh_from_mesh, calc_tanh, calc_pow_inverted
from .utils.general_utils import create_new_curve_obj
from .hair_curve_helpers import HTOOL_OT_CurvesTiltAlign, generate_profile

#DONE: flat ribbons give crap tilt... Use code from tilt alight to rotate to center?
#DONE: use TBS from init, then linera interpolate to resampled pts? 90% faster

def align_curve_tilt(context, depsgraph, Curve, align_target):
    ''' alternate version - with no target bvht object - since we align to center of curve '''
    unit_scale = context.scene.unit_settings.scale_length
    HTOOL_OT_CurvesTiltAlign.resetTiltFunction(context, Curve.data, False)

    depsgraph.update()
    curveBevelObj = Curve.data.bevel_object  # backup
    context.active_object.data.bevel_object = None  # zero out to prevent changing default one
    curveResU = Curve.data.resolution_u  # backup
    curv_size = Curve.dimensions.length * unit_scale  # to normalize some values

    generate_profile(Curve, 'OBJECT', strandResV=1, strandResU=curveResU, strandWidth=0.01 * curv_size, strandPeak=0, write_profile_props=False)  # for temp curve for tangent and normals
    depsgraph.update()

    Curve_eval = Curve.evaluated_get(depsgraph)
    meFromCurve = Curve_eval.to_mesh()  # mesh from curve with modifiers

    # bpy.data.meshes.new_from_object(Curve_eval) #debug mesh
    meshVertCount = len(meFromCurve.vertices)
    kdMeshFromCurve = kdtree.KDTree(meshVertCount)
    for i, v in enumerate(meFromCurve.vertices):
        kdMeshFromCurve.insert(v.co, i)
    kdMeshFromCurve.balance()

    unitsScale = context.scene.unit_settings.scale_length
    searchDistance = 200 / unitsScale
    angleFlipFix = [-3 * math.pi, -2 * math.pi, -math.pi, math.pi, 2 * math.pi]
    for i, polyline in enumerate(Curve.data.splines):  # for strand point
        points = polyline.bezier_points if polyline.type == 'BEZIER' else polyline.points
        strand_len = len(points)
        prevAngle = 0
        corrective_angles = np.zeros(strand_len, dtype=np.float16)
        current_tilt = np.zeros(strand_len, dtype=np.float16)
        points.foreach_get('tilt', current_tilt)

        for j, curvePoint in enumerate(points):  # for strand point
            pointOnMeshLoc = align_target.data.splines[i].points[j].co.xyz
            # get vertex closest to spline point (for normal) from temp spline representation
            co, index, dist = kdMeshFromCurve.find(curvePoint.co.xyz)
            curveNormal = meFromCurve.vertices[index].normal
            vecSurfaceHit = curvePoint.co.xyz - pointOnMeshLoc  # * this is not ok, hair is outside target surface. Then tilt align resutl is harsh

            if index+3 < meshVertCount:  # for last spline just use prvevangle
                tangent = HTOOL_OT_CurvesTiltAlign.get_tangents(meFromCurve, index, j == strand_len - 1)  # for bezier we can gets handles for tanget
                biTangentCurve = tangent.cross(curveNormal)
                vectSurfHitProjected90 = tangent.cross(vecSurfaceHit)
                vectSurfHitProjectedToTangent = vectSurfHitProjected90.cross(tangent)

                angle = angle_signed(biTangentCurve, vectSurfHitProjectedToTangent, tangent) - math.pi / 2  # a,b, vN  - signed -180 to 180
                if j > 1 and abs(prevAngle - angle) > math.pi / 2:  # try fixing random flips in ribbons surface
                    fix = [fix_angle for fix_angle in angleFlipFix if abs(prevAngle - (angle+fix_angle)) < math.pi / 2]
                    if fix:
                        angle += fix[0]
                corrective_angles[j] = angle
                prevAngle = angle
            else:
                corrective_angles[j] = prevAngle
        # current_tilt = current_tilt + corrective_angles
        if strand_len >= 4:
            corrective_angles[1] = (corrective_angles[2] + corrective_angles[3]) / 2
            corrective_angles[0] = (corrective_angles[1] + corrective_angles[2]) / 2
        elif strand_len == 3:
            corrective_angles[0] = (corrective_angles[1] + corrective_angles[2]) / 2

        current_tilt += corrective_angles
        points.foreach_set('tilt', current_tilt.ravel())  # in radians
        # manually smooth first two points cos they are usually broken

    Curve_eval.to_mesh_clear()
    Curve.data.bevel_object = curveBevelObj  # restore old bevel obj

    if Curve.rotation_euler != Euler((0.0, 0.0, 0.0), 'XYZ') or min(Curve.scale[:]) < 0:  # fix rot if curve rot is non 0,0,0, or scele x,y,z <0
        override = {'selected_editable_objects': [Curve]}
        if Curve.data.users > 1:
            Curve.data = Curve.data.copy()
        bpy.ops.object.transform_apply(override, location=False, rotation=True, scale=False)  # ! apply  scale breaks /changes pts radius



class HTOOL_OT_CurvesCurl(bpy.types.Operator):
    bl_label = "Generate Curls"
    bl_idname = "object.curve_curl"
    bl_description = "Change amount of points on curve"
    bl_options = {"REGISTER", "UNDO", "PRESET"}

    hairType: bpy.props.EnumProperty(name="Output Curve Type", default="NURBS",
                                     items=(("BEZIER", "Bezier", ""),
                                            ("NURBS", "Nurbs", ""),
                                            ("POLY", "Poly", "")))
    points_per_cycle: IntProperty(name="Points per cycle", description="Amount of points per curl cycle. Bigger values gives smoother curls", default=4, min=2, soft_max=10)
    curl_freq: FloatProperty(name="Curl frequency", description='Will generate more curls but also higher point count', default=5, min=0.4, soft_max=15)

    contrast: FloatProperty(name="Transition Contrast", description="Curls transition contrast along strand length", default=0.5, min=0, soft_max=1)
    offset: FloatProperty(name="Offset", description="Offset curls more toward the root or tip", default=0, min=-1, max=1)

    radius: FloatProperty(name="Radius", description="Curls Radius", default=1, min=0, soft_max=10)

    direction: bpy.props.EnumProperty(name='Direction', description='Curls Direction',
                                      items=[
                                          ('CW', 'Clockwise', ''),
                                          ('CCW', 'Counterclockwise', '')
                                      ], default='CW')

    random_direction: BoolProperty(name="Random direction", description="Flip curls direction randomly from clockwise to counter-clockwise", default=False)

    gravity_tension: FloatProperty(name="Gravity ", description="Gravity weight pulls the curls down along the hair strand. O - disabled, 0.5 - natural gravity pull", default=0, min=0, max=1, subtype='PERCENTAGE')
    align_method: bpy.props.EnumProperty(name='Tilt align method', description='Tilt align method',
        items=[ ('ZUP', 'Z-up', 'Good of you have hair going down'),
            ('MINIMUM', 'Minimum', 'Not great but better than nothing')], default='MINIMUM')

    align_tilt: BoolProperty(name="Align Tilt", description="Make curve profile face outwards direction.\nIt is slow - usually it is best to enable it at last step", default=False)
    radomize_freq: FloatProperty(name="Randomize frequency", description="Randomize frequency", default=0, min=0, max=1, subtype='PERCENTAGE')
    # fix_angle: FloatProperty(name="fix_angle", description="Randomize frequency", default=0, min=-3.2, max=3.2)
    Seed: IntProperty(name="Noise Seed", default=1, min=1, max=500)

    uniformPointSpacing: BoolProperty(name="Uniform spacing", description="Distribute stand points uniformly along strand length", default=True)
    # onlySelection: BoolProperty(name="Only Selected", description="Affect only selected splines", default=False)



    def save_settings(self, target_obj):  # Tto object curly_hair_settings
        for d in self.properties.bl_rna.properties.keys():
            if d == 'rna_type':
                continue
            setattr(target_obj.ht_props.curly_hair_settings, d, getattr(self.properties, d))

    def load_settings(self, source_obj):  # from curly_hair_settings
        # what exception could occur here??
        for d in source_obj.ht_props.curly_hair_settings.bl_rna.properties.keys():
            if d in {'name', 'rna_type', 'was_created_from_curls'}:
                continue
            setattr(self.properties, d, getattr(source_obj.ht_props.curly_hair_settings, d))


    def draw(self, context):
        layout = self.layout
        # row = layout.row(align=True)
        col = layout.column(align=True)
        # col.prop(self, 'onlySelection')
        col.prop(self, 'curl_freq')
        col.prop(self, 'points_per_cycle')
        col.prop(self, 'radius')
        col.prop(self, 'direction')

        col.prop(self, 'uniformPointSpacing')
        col.prop(self, 'align_tilt')
        if self.align_tilt:
            col.prop(self, 'align_method')

        col = layout.column(align=True)
        col.label(text = 'Curls influence along the hair length')
        col.prop(self, 'contrast')
        col.prop(self, 'offset')
        col.prop(self, 'gravity_tension')

        col = layout.column(align=True)
        col.label(text = 'Randomization')
        col.prop(self, 'random_direction')
        col.prop(self, 'radomize_freq')
        col.prop(self, 'Seed')
        # curl_curve_node = bpy.data.node_groups['TestCurveData'].nodes['curls_mapping']
        # layout.template_curveprofile(context.tool_settings, "custom_bevel_profile_preset")

    def invoke(self, context, event):
        curveObj = context.active_object
        if not curveObj.type == 'CURVE':
            self.report({'INFO'}, 'Use operator on curve type object')
            return {"CANCELLED"}

        if curveObj.ht_props.curly_hair_settings.was_created_from_curls:  # if operator wa executed on curve use its settigns
            self.load_settings(curveObj)  # else from target mesh

        #was this grid_surf obj  and It is deformed by previous curls operator?
        if curveObj.ht_props.grid_hair_settings.was_created_from_grid and curveObj.ht_props.curly_hair_settings.was_created_from_curls:
            bpy.ops.object.curves_from_grid('INVOKE_DEFAULT')

        self.input_spline_type = curveObj.data.splines[0].type
        self.hairType = self.input_spline_type  # hair type  - output spline
        if self.input_spline_type == 'NURBS':
            self.nurbs_order = curveObj.data.splines[0].order_u
        self.bezierRes = curveObj.data.resolution_u
        called_from_ht_wspace = context.workspace.tools.from_space_view3d_mode(mode=context.mode).idname == "hair_tool.hair_transform"
        self.onlySelection = True if curveObj.mode == 'EDIT' else called_from_ht_wspace
        self.sel_splines = Splines(curveObj, self.onlySelection, with_clear=True, spline_type='SIMPLE')
        bpy.ops.ed.undo_push()# to prevent restoring curve from step above on execute()
        self.TNB = [sel_sp.parallel_transport_TNB() for sel_sp in self.sel_splines.splines]  # slowing everything down = (T, N, B)
        # self.TNB.append([T, N, B])  # N = T x B   B = N x T
        return self.execute(context)


    def execute(self, context):
        curveObj = context.active_object
        sel_splines = deepcopy(self.sel_splines)
        splines_count = sel_splines.length

        np.random.seed(self.Seed)
        rand_curl_freq = np.random.rand(splines_count)/2+0.3
        init_dir = np.ones(splines_count, dtype=np.int8)
        if self.direction == 'CCW':
            init_dir *= -1
        randDir = np.random.choice([1, -1], splines_count) if self.random_direction else init_dir
        contrast = 10*self.contrast

        if self.align_tilt and self.align_method == 'MINIMUM':
            align_spline_helper = create_new_curve_obj('curls_align_helper', set_active = False)
            angle_mul = []

        for k, sel_spline in enumerate(sel_splines.splines):  # for strand point
            in_point_count = sel_spline.length

            current_freq_mul = (1-self.radomize_freq) + self.radomize_freq * rand_curl_freq[k]
            output_point_count = int(self.points_per_cycle * self.curl_freq * current_freq_mul)  # DONE: change based on random freq?

            # cpow = calc_exponent(-self.gravity_tension)
            # fallofs_pow = calc_pow(cpow, output_point_count)
            fallofs_tanh = calc_tanh(contrast*(1-self.gravity_tension/3), self.offset, output_point_count)  # linking to gravity makes in feel more natural
            fallofs_gravity = calc_pow_inverted(self.gravity_tension+1, output_point_count)  # gravity tension at 2
            sel_spline.resample_pts(output_point_count, uniform=self.uniformPointSpacing, t_custom=fallofs_gravity)

            if self.align_tilt and self.align_method == 'MINIMUM':
                sel_spline.write_to_blender_spl(align_spline_helper, k)

            t_out_y = np.linspace(0, 1, output_point_count)  # output x dim
            t_in = np.linspace(0, 1, in_point_count)  # in dimm
            # interpol_TNB = (np.interp(t_out_y, t_in, self.TNB[k]))  # first arg len() = out len
            interpol_TNB = np.zeros((3, output_point_count, 3), 'f')
            # interpol_TNB[0,:,0] = (np.interp(t_out_y, t_in, self.TNB[k][0][:,0]))  # T.x
            # interpol_TNB[0,:,1] = (np.interp(t_out_y, t_in, self.TNB[k][0][:,1]))  # T.y
            # interpol_TNB[0,:,2] = (np.interp(t_out_y, t_in, self.TNB[k][0][:,2]))  # T.z
            interpol_TNB[1,:,0] = (np.interp(t_out_y, t_in, self.TNB[k][1][:,0]))  # N.x
            interpol_TNB[1,:,1] = (np.interp(t_out_y, t_in, self.TNB[k][1][:,1]))  # N.y
            interpol_TNB[1,:,2] = (np.interp(t_out_y, t_in, self.TNB[k][1][:,2]))  # N.z
            interpol_TNB[2,:,0] = (np.interp(t_out_y, t_in, self.TNB[k][2][:,0]))  # B.x
            interpol_TNB[2,:,1] = (np.interp(t_out_y, t_in, self.TNB[k][2][:,1]))  # B.y
            interpol_TNB[2,:,2] = (np.interp(t_out_y, t_in, self.TNB[k][2][:,2]))  # B.z
            # (T, N, B) = parallel_transport_TNB(res_spl_pts_vec) #! probably slowing everything down 90%
            strand_Ts = [Vector((i)) for i in interpol_TNB[0]]
            strand_Ns = [Vector((i)) for i in interpol_TNB[1]]  # N = T x B
            strand_Bs = [Vector((i)) for i in interpol_TNB[2]]  # B = N x T

            angle = 2 * np.pi / self.points_per_cycle
            angle = randDir[k]*angle #flip direction then negate angle
            angle = angle*current_freq_mul  # randomize angle from (0, 2 * angle)

            for i, (fallof_tanh, s_pt) in enumerate(zip(fallofs_tanh.tolist(), sel_spline.points)):
                # fallof = tanh(self.contrast*(i / output_point_count + self.offset - 0.5))+1
                s_pt.co = (strand_Ns[i] * sin(i*angle) + strand_Bs[i] * cos(i*angle)) * self.radius * fallof_tanh/2 + s_pt.co

            #aligning
            corrective_angles = np.zeros(output_point_count, 'f')
            if self.align_tilt and self.align_method == 'ZUP':
                fallofs_tanh_curl = calc_tanh(1.3*contrast*(1-self.gravity_tension/3), self.offset-0.15, output_point_count)
                corrective_angles.fill(-3.14/2)# * fallofs_tanh_curl
                curveObj.data.twist_mode = 'Z_UP'
                for pt, tilt in zip(sel_spline.points, corrective_angles.tolist()):
                    pt.tilt = tilt

            sel_spline.write_to_blender_spl(curveObj, len(curveObj.data.splines))  # always write to new spline
            sel_spline.orig_spl_id = len(curveObj.data.splines)-1

        curveObj.data.resolution_u = self.bezierRes
        if self.align_tilt and self.align_method == 'MINIMUM':
            align_spline_helper.data.bevel_depth = 0.1
            align_spline_helper.data.resolution_u = 3
            depsgraph = context.evaluated_depsgraph_get()
            curveObj.data.twist_mode = 'MINIMUM'
            align_curve_tilt(context, depsgraph, curveObj, align_spline_helper)  # onlySelection=True
            bpy.data.objects.remove(align_spline_helper)

            #blend tilt to 0 on roots
            for k, sel_spline in enumerate(sel_splines.splines):  # for strand point
                curl_obj_spl = curveObj.data.splines[sel_spline.orig_spl_id]
                curl_spl = SplineFlat(curl_obj_spl, sel_spline.orig_spl_id)
                output_point_count = curl_spl.length
                fallofs_tanh = calc_tanh(2*contrast*(1-self.gravity_tension/3), self.offset, output_point_count)
                curl_spl.points_tilts = curl_spl.points_tilts * fallofs_tanh
                curl_spl.write_tilt_to_blender_spl(curveObj) #, s_pt=k)
            curveObj.update_tag()


        self.save_settings(curveObj)
        curveObj.ht_props.curly_hair_settings.was_created_from_curls = True
        return {"FINISHED"}
