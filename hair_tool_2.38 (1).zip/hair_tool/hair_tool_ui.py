# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
# Copyright (C) 2017 JOSECONSCO
# Created by JOSECONSCO

import bpy
from .utils.general_utils import addon_name_lowercase
import rna_keymap_ui
from .update_addon import get_addon_preferences
from .drawing_curves import HTOOL_PT_DrawingCurvesPanel
from .interactive_hair_combing import HTOOL_PT_ModalParticleHair, HTOOL_PT_ModalVertGroups, HTOOL_PT_ModalChildSettings, HTOOL_PT_ModalCurveHair
from .hair_baking.hair_bake_ui import HTOOL_PT_Hair_Panel_Bake
# from .hair_baking.hair_geometry_nodes import HTOOL_PT_HairSystemPanel
from pathlib import Path
import os


def curve_ops(context, obj, box):
    box.label(text="CURVE OPERATIONS")
    col = box.column(align=True)
    if obj.mode != 'EDIT':
        col.operator("object.curves_align_tilt", icon="SNAP_NORMAL")
    col.operator("object.embed_roots", icon="MOD_SCREW")
    col.prop_search(obj.ht_props, "target_obj", context.scene, "objects",icon="SNAP_NORMAL")
    col = box.column(align=True)
    col.operator("object.curve_taper", icon="SHARPCURVE")
    col.operator("curve.hair_straighten", icon="HAIR")
    col.operator("object.curves_smooth", icon="MOD_NOISE")
    col.operator("object.curves_smooth_tilt", icon="MOD_NOISE")
    col.operator("object.curves_smooth_radius", icon="MOD_NOISE")
    col.operator("curve.radius_by_length", icon="META_CAPSULE")
    col.operator("curve.radius_by_uv_width", icon="META_CAPSULE")
    col.operator("object.curves_randomize_tilt", icon="FORCE_MAGNETIC")
    col.operator("object.curve_length", icon="HAIR")
    col.operator("object.curve_resample", icon="PARTICLE_POINT")
    col.operator("object.curve_simplify", icon="PARTICLE_POINT")
    col.operator("curve.slice_with_mesh", icon="RESTRICT_INSTANCED_ON")


def profile_ops(box):
    col = box.column(align=True)
    col.operator("object.generate_profile", icon="OUTLINER_OB_SURFACE", text='Update Profile')
    col.operator("object.ribbon_duplicate_profile", icon="COPY_ID")
    row = col.row(align=True)
    row.operator("object.ribbon_edit_profile", icon="LINKED")
    row.operator("object.ribbon_close_profile", icon="UNLINKED")


def convert_generate_ops(context, obj, box):
    box.label(text='Convert / Generate hair')
    col = box.column(align=True)
    if obj.type == 'CURVE':
        col.operator("object.curve_to_mesh_ribbon", icon="FILE_REFRESH")
        braid_txt = 'Update Braid' if obj.ht_props.braid_settings.is_braid else 'Generate Braid'
        col.operator("object.braid_make", icon="LINKED", text=braid_txt)

        curls_txt = 'Update Curls'  if obj.ht_props.grid_hair_settings.was_created_from_grid and obj.ht_props.curly_hair_settings.was_created_from_curls else 'Generate Curls'
        col.operator("object.curve_curl", icon="LINKED", text=curls_txt)
        if obj.ht_props.target_obj:
            col.operator("object.curves_from_grid", icon="MESH_GRID")
    elif obj.type == 'MESH':  # for non ribbon kind of  mesh
        if context.mode == 'EDIT_MESH':
            if obj.ht_props.short_hair_props.is_short_hair:
                col.operator("hair.set_short_hair_uv_region", icon="MATERIAL")
            col.operator("object.ribbon_to_bones", icon="BONE_DATA")
            col.prop(obj.ht_props, 'target_rig')
            if obj.ht_props.target_rig and obj.ht_props.target_rig.type == 'ARMATURE':
                col.prop_search(obj.ht_props, 'pin_bone', obj.ht_props.target_rig.data, 'bones')
        else:
            if obj.ht_props.hair_settings.hair_mesh_parent:  # for ribbon mesh
                col.operator("object.ribbon_convert", icon="FILE_REFRESH")

            if obj.ht_props.short_hair_props.hair_base_mesh:
                col.operator("object.restore_short_hair_base_mesh", icon="FILE_REFRESH")
            if obj.ht_props.short_hair_props.is_short_hair:
                col.operator("hair.convert_short_hair_to_mesh", icon="FILE_REFRESH")
            else:
                col.operator("object.curves_from_grid", icon="MESH_GRID")
            if not obj.ht_props.hair_settings.hair_mesh_parent:
                for mod in context.object.modifiers:
                    if mod.type == 'PARTICLE_SYSTEM' and mod.show_viewport and mod.particle_system.settings.type == "HAIR":  # use first visible
                        col.operator("object.hair_to_curves", icon="HAIR")
                        col.operator("particles.scale_particles", icon="HAIR")
                        # col.prop_search(obj, "target_obj", context.scene, "objects",icon="STRANDS",text='Target Curve')
                        # col.operator("object.ribbons_from_ph_child", icon="HAIR")
                        break

    if context.mode == 'OBJECT':
        if len(context.selected_objects) > 1:
            col.operator("object.hair_from_curves", icon="FORCE_CURVE")
        col.operator("object.finalize_hair", icon="SOLO_ON")
        row = col.row(align=True)
        row.operator("object.setup_short_hair", icon="HAIR")
        row.operator("hair.update_short_hair_node_group", icon="FILE_REFRESH", text='')


def material_uv_ops(obj, box):
    box.label(text='Hair Material / UV')
    col = box.column(align=True)
    col.operator('hair.load_hair_mat', icon='IMPORT')
    row = col.row(align=True)
    row.operator("curve.hair_curls_uv", icon='RNA')
    row.operator("curve.reset_hair_curls_uv", icon='FILE_REFRESH', text='')
    row = col.row(align=True)
    row.operator("object.curve_uv_refresh", icon="MATERIAL")
    row.prop(obj.ht_props, 'use_auto_uv', icon='MOD_UVPROJECT', text='')
    # layout.prop(obj.ht_props.hair_settings, 'hairUvMethod', icon="MOD_UVPROJECT")
    col = box.column(align=True)
    col.operator("hair.set_uv_region", icon="MATERIAL")


def mesh_ops(context, obj, box):
    box.label(text='Mesh operations')
    col = box.column(align=True)
    if context.mode == 'EDIT_MESH':
        col.separator()
    else:
        col.operator("object.ribbon_weight", icon="WPAINT_HLT")
        col.operator("object.ao_to_vcol", icon="VPAINT_HLT")
        col.operator("object.ribbon_vert_color_grad", icon="VPAINT_HLT")
        col.operator("object.ribbon_vert_color_random", icon="VPAINT_HLT")
        col.operator("object.uv_sample_from_target", icon="VPAINT_HLT")
        col.operator("object.weight_sample_from_target", icon="MOD_VERTEX_WEIGHT")
        col.prop_search(obj.ht_props, "target_obj", context.scene, "objects", icon="SNAP_NORMAL")


class  HTOOL_PT_VIEW3D_PT_Hair_Panel(bpy.types.Panel):
    bl_label = "Hair Operators"
    bl_idname = "HTOOL_PT_VIEW3D_PT_Hair_Panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Hair Tool'
    bl_context = 'objectmode'
    # bl_options = {'HIDE_HEADER'}

    drawAsMenu = False

    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type in {'MESH', 'CURVE'}

    def draw(self, context):
        layout = self.layout
        if self.drawAsMenu:
            layout = self.layout.box()
            layout.label(text='Hair Tool')
        obj = context.active_object
        if obj:
            box = layout.box()
            convert_generate_ops(context, obj, box)

            if obj.type == 'CURVE':
                box = layout.box()
                box.label(text='Profile')
                profile_ops(box)

                box = layout.box()
                material_uv_ops(obj, box)

                box = layout.box()
                curve_ops(context, obj, box)


            if obj.type == 'MESH' and context.mode == 'OBJECT' and\
                (obj.ht_props.hair_settings.hair_mesh_parent or obj.ht_props.short_hair_props.is_short_hair_output): #for ribbon mesh
                box = layout.box()
                mesh_ops(context, obj, box)

            # layout.operator("object.cleanup_hair", icon="CANCEL")

# FOR CURVE EDIT MODE
class  HTOOL_PT_VIEW3D_EDIT_Hair_Panel(bpy.types.Panel):
    bl_label = "Hair Tool"
    bl_idname = "HTOOL_PT_VIEW3D_EDIT_Hair_Panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Hair Tool'
    bl_context = "curve_edit"

    def draw(self, context):
        self.drawAsMenu = False
        HTOOL_PT_VIEW3D_PT_Hair_Panel.draw(self, context)


# FOR HOTKEY
class HTOOL_MT_HairToolMenu(bpy.types.Menu):
    bl_idname = "HTOOL_MT_HairToolMenu"
    bl_label = "Hair Tool Menu Panel"

    @classmethod
    def poll(cls, context):
        return context.mode in {'EDIT_MESH', 'OBJECT', 'EDIT', 'EDIT_CURVE', 'PAINT_VERTEX', 'PAINT_WEIGHT'}

    def draw(self, context):
        self.drawAsMenu = True
        layout = self.layout
        obj = context.active_object
        if context.mode == 'EDIT_CURVE':
            pie = layout.menu_pie()

            # 1 - LEFT
            box = pie.box()
            col = box.column(align=True)
            col.operator("hair.set_uv_region")

            # 2 - RIGHT
            box = pie.box()

            # 3 - Bottom
            box = pie.box()
            curve_ops(context, obj, box)

        else: # OBJECT MODE
            pie = layout.menu_pie()

            # 1 - LEFT
            if obj is not None:
                if obj.type == 'CURVE':
                    box = pie.box()
                    material_uv_ops(obj, box)
                else:
                    pie.separator()

                # 2 - RIGHT
                box = pie.box()
                convert_generate_ops(context, obj, box)

                # 3 - BOTTOM
                if obj.type == 'MESH' and context.mode == 'OBJECT' \
                    and (obj.ht_props.hair_settings.hair_mesh_parent or obj.ht_props.short_hair_props.is_short_hair_output): #for ribbon mesh
                    box = pie.box()
                    mesh_ops(context, obj, box)
                elif obj.type == 'CURVE':
                    box = pie.box()
                    curve_ops(context, obj, box)
                else:
                    pie.separator()

                # 4 - TOP
                if obj.type == 'CURVE':
                    box = pie.box()
                    box.label(text='Profile')
                    profile_ops(box)
                else:
                    pie.separator()

                # 5 - TOP - LEFT
                pie.separator()

                # 6 - TOP - RIGHT
                pie.separator()

                # 7 - BOTTOM - LEFT
                pie.separator()

                # 8 - BOTTOM - RIGHT
                pie.separator()


    def check(self, context):
        return True


##########################         Addon Prefernedces                ###############################################
panels = (
    HTOOL_PT_DrawingCurvesPanel,
    HTOOL_PT_Hair_Panel_Bake,
    # HTOOL_PT_HairSystemPanel,
    HTOOL_PT_VIEW3D_PT_Hair_Panel,
    HTOOL_PT_VIEW3D_EDIT_Hair_Panel,
    HTOOL_PT_ModalParticleHair, HTOOL_PT_ModalCurveHair, HTOOL_PT_ModalChildSettings,  HTOOL_PT_ModalVertGroups
)

def update_panel(self, context):
    message = "Hair Tool: Updating Panel locations has failed"
    try:
        for panel in panels:
            if "bl_rna" in panel.__dict__:
                bpy.utils.unregister_class(panel)

        for panel in panels:
            panel.bl_category = get_addon_preferences().category
            bpy.utils.register_class(panel)

    except Exception as e:
        print("\n[{}]\n{}\n\nError:\n{}".format(__name__, message, e))
        pass

class hairToolPreferences(bpy.types.AddonPreferences):
    bl_idname = 'hair_tool'

    def set_abs_path(self, context):
        print(f'lib path is being updated. Current:{self.lib_path}')
        abs_p = os.path.abspath(self.lib_path)
        if os.path.exists(abs_p):
            self['lib_path'] = os.path.abspath(self.lib_path)
        else:
            self['lib_path'] = str(Path.home())
        print(f"lib path updated to: {self['lib_path']}")

    # expandCurveOper: bpy.props.BoolProperty( name="", description="",  default=False)
    # expandGenerators: bpy.props.BoolProperty( name="", description="",  default=False)
    flipUVRandom: bpy.props.BoolProperty( name="Random UV flip", description="Alter the ribbon look by randomly mirroring UVs on splines (this create additional materials!)",  default=True)
    draw_grid_as_wire: bpy.props.BoolProperty(name='Draw grid as wire', description='When generating hair from grid surface, switch mesh display mode to "WIRE"', default=True)
    tabs: bpy.props.EnumProperty(name="Tabs", items=[("UPDATE", "Update", ""),
                                                     ("OPTIONS", "Options", ""),
                                                     ("BAKING", "Baking", ""),
                                                     ("HOTKEYS", "Hotkeys", ""),
                                                     ("LIBRARY", "Library", "")], default="UPDATE")
    update_exist: bpy.props.BoolProperty(name="Update Exist", description="There is new GroupPro update",  default=False)
    update_text: bpy.props.StringProperty(name="Update text",  default='')

    category: bpy.props.StringProperty(name="Tab Category", description="Choose a name for the category of the panel", default="Hair Tool", update=update_panel)
    view_render_object_sync: bpy.props.BoolProperty(name="Synchronize outliner  'Eye' and 'Camera' icon",
                                                    description="Synchronize 'Hide View' and 'Hide Render' outliner options for all objects and collections", default=True)
    view_render_phair_sync: bpy.props.BoolProperty(name='Synchronize particle hair view and render properties',
                                                   description='Particle hair has some of parameters split in view vs render setting.\nEnabling this option, will make both of these parameters same, giving similar render result to view render result', default=True)

    #* library tab
    lib_path: bpy.props.StringProperty(name="Library Path", default=str(Path.home()), description="Library Path", subtype="DIR_PATH", update=set_abs_path)
    rerender: bpy.props.BoolProperty(default=False)

    #* baking
    ao_suffix: bpy.props.StringProperty(name='AO', description="Ambient Occlusion", default='_ao')
    diffuse_suffix: bpy.props.StringProperty(name='Diffuse', description="Diffuse", default='_diff')
    opacity_suffix: bpy.props.StringProperty(name='Opacity', description="Opacity", default='_opacity')
    normal_suffix: bpy.props.StringProperty(name='Normal', description="Normal map", default='_normal')
    root_suffix: bpy.props.StringProperty(name='Root', description="Root map", default='_root')
    id_suffix: bpy.props.StringProperty(name='Id', description="Random ID mask", default='_id')
    flow_suffix: bpy.props.StringProperty(name='Flow', description="Flow map", default='_flow')
    directional_suffix: bpy.props.StringProperty(name='Directional', description="Directional map", default='_dir')
    depth_suffix: bpy.props.StringProperty(name='Depth', description="Depth map", default='_depth')

    # container_prefix_suffix: bpy.props.EnumProperty(name='', items=[('PREFIX', 'Prefix', ''), ('SUFFIX', 'Suffix', '')], default='PREFIX')


    def draw(self, context):
        layout = self.layout
        row = layout.row(align=True)
        # if not CUDA_ACTIVE:
        #     layout.operator('wm.install_pip_lib')
        # else:
        #     layout.operator('wm.uninstall_pip_lib')

        row.prop(self, "tabs", expand=True)
        box = layout.box()
        if self.tabs == "UPDATE":
            col = box.column()
            sub_row = col.row(align=True)
            sub_row.operator(addon_name_lowercase()+".check_for_update")
            split_lines_text = self.update_text.splitlines()
            for line in split_lines_text:
                sub_row = col.row(align=True)
                sub_row.label(text=line)
            sub_row.separator()
            sub_row = col.row(align=True)
            if self.update_exist:
                sub_row.operator(addon_name_lowercase()+".update_addon", text='Install latest version').reinstall = False
            else:
                sub_row.operator(addon_name_lowercase()+".update_addon", text='Reinstall current version').reinstall = True
            sub_row.operator(addon_name_lowercase()+".rollback_addon")

        elif self.tabs == "OPTIONS":
            col = box.column()
            col.prop(self, 'flipUVRandom')
            col.prop(self, 'draw_grid_as_wire')
            # col.label(text="Tab Category:")
            # col.prop(self, "category", text="")

        elif self.tabs == "BAKING":
            col = box.column()
            sub_col = col.column()
            sub_col.label(text="View vs Render synchronization")
            sub_col.prop(self, 'view_render_object_sync', icon='HIDE_OFF')
            sub_col.prop(self, 'view_render_phair_sync', icon='GP_MULTIFRAME_EDITING')
            sub_col = col.column()
            sub_col.label(text='Define default suffixes added to baked texture names:')
            sub_col.prop(self, 'ao_suffix')
            sub_col.prop(self, 'diffuse_suffix')
            sub_col.prop(self, 'opacity_suffix')
            sub_col.prop(self, 'normal_suffix')
            sub_col.prop(self, 'root_suffix')
            sub_col.prop(self, 'id_suffix')
            sub_col.prop(self, 'flow_suffix')
            sub_col.prop(self, 'directional_suffix')
            sub_col.prop(self, 'depth_suffix')

        elif self.tabs == "LIBRARY":
            col = box.column()
            sub_col = col.column()
            sub_col.prop(self, "lib_path", text='Library path')
            # col.prop(self, "incl_cursor_rot")
            sub_row = col.row(align=True)
            sub_row.operator("hair_lib.render_previews", text="Render missing previews")
            sub_row.prop(self, 'rerender', text='Re-render ALL previews')


        elif self.tabs == "HOTKEYS":
            col = box.column()
            wm = bpy.context.window_manager
            kc = wm.keyconfigs.user
            km = kc.keymaps['3D View']
            kmi = get_hotkey_entry_item(km, 'wm.call_menu_pie', "HTOOL_MT_HairToolMenu")
            if kmi:
                col.context_pointer_set("keymap", km)
                rna_keymap_ui.draw_kmi([], kc, km, kmi, col, 0)
            else:
                col.label(text="No hotkey entry found for hair pie Menu (Ctrl + Shift + H)!")

            km = kc.keymaps['3D View']
            kmi = get_hotkey_entry_item(km, 'object.draw_hair_surf')
            if kmi:
                col.context_pointer_set("keymap", km)
                rna_keymap_ui.draw_kmi([], kc, km, kmi, col, 0)
            else:
                col.label(text="No hotkey entry found for hair Drawing!")

            col.operator(HTOOL_OT_HairTool_Clear_Hotkeys.bl_idname, text="Clear hotkeys", icon='REMOVE')
            col.operator(HTOOL_OT_HairTool_Add_Hotkey.bl_idname, text="Restore Hotkeys", icon='ADD')
#### end  MOve TO pref file ####################################

addon_keymaps = []

def get_hotkey_entry_item(km, kmi_name, kmi_value=None):
    '''
    returns hotkey of specific type, with specific properties.name (keymap is not a dict, so referencing by keys is not enough
    if there are multiple hotkeys!)
    '''
    for i, km_item in enumerate(km.keymap_items):
        if km.keymap_items.keys()[i] == kmi_name:
            if kmi_value:  # usually for wm.call_menu_pie
                if km.keymap_items[i].properties.name == kmi_value:
                    return km_item  #TODO: maybe this should return multiple keymaps...
            else: #for operators
                return km_item

    return None

def register_keymap():
    global addon_keymaps
    kc = bpy.context.window_manager.keyconfigs.addon

    km = kc.keymaps.get('3D View')
    if not km:
        km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'H', 'PRESS', ctrl=True, shift = True)
    kmi.properties.name = "HTOOL_MT_HairToolMenu"
    kmi.active = True
    addon_keymaps.append((km, kmi))

    # gpencil_keymap = bpy.context.window_manager.keyconfigs.user.keymaps.get('Grease Pencil')
    # km5 = kc.keymaps.new(name='3D View', space_type='VIEW_3D')  # ! use existing '3D View' ! or wont work
    kmi5 = km.keymap_items.new('object.draw_hair_surf', 'LEFTMOUSE', 'PRESS', key_modifier='D')
    kmi5.active = False  # activate from init - post_load scene...
    addon_keymaps.append((km, kmi5))

    km2 = kc.keymaps.new(name='Curve', space_type = 'VIEW_3D')
    kmi2 = km2.keymap_items.new('wm.call_menu_pie', 'H', 'PRESS', ctrl=True, shift=True)
    kmi2.properties.name = "HTOOL_MT_HairToolMenu"
    kmi2.active = True
    addon_keymaps.append((km2, kmi2))


    km2 = kc.keymaps.new(name='Mesh', space_type = 'VIEW_3D')
    kmi2 = km2.keymap_items.new('wm.call_menu_pie', 'H', 'PRESS', ctrl=True, shift=True)
    kmi2.properties.name = "HTOOL_MT_HairToolMenu"
    kmi2.active = True
    addon_keymaps.append((km2, kmi2))

    km3 = kc.keymaps.new(name='Vertex Paint', space_type='VIEW_3D')
    kmi3 = km3.keymap_items.new('wm.call_menu_pie', 'H', 'PRESS', ctrl=True, shift=True)
    kmi3.properties.name = "HTOOL_MT_HairToolMenu"
    kmi3.active = True
    addon_keymaps.append((km3, kmi3))

    km4 = kc.keymaps.new(name='Weight Paint', space_type='VIEW_3D')
    kmi4 = km4.keymap_items.new('wm.call_menu_pie', 'H', 'PRESS', ctrl=True, shift=True)
    kmi4.properties.name = "HTOOL_MT_HairToolMenu"
    kmi4.active = True
    addon_keymaps.append((km4, kmi4))


class HTOOL_OT_HairTool_Add_Hotkey(bpy.types.Operator):
    ''' Add hotkey entry '''
    bl_idname = "hairtool.add_hotkey"
    bl_label = "Add HairTool Hotkey"
    bl_options = {'REGISTER', 'INTERNAL'}

    def execute(self, context):
        unregister_keymap()
        register_keymap()
        self.report({'INFO'}, "Hotkey added in User Preferences -> Input -> 3D view")
        return {'FINISHED'}

class HTOOL_OT_HairTool_Clear_Hotkeys(bpy.types.Operator):
    ''' Add hotkey entry '''
    bl_idname = "hairtool.clear_hotkey"
    bl_label = "Addon Preferences Example"
    bl_options = {'REGISTER', 'INTERNAL'}

    def execute(self, context):
        unregister_keymap()
        self.report({'INFO'}, "Hotkey removed in User Preferences -> Input ")
        return {'FINISHED'}

def unregister_keymap():  #this only unregisters obj mode hotkey (what about curve mode hotkey)
    global addon_keymaps
    wm = bpy.context.window_manager
    for km,kmi in addon_keymaps:
        if len(km.keymap_items) > 0:
            km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    # kc = bpy.context.window_manager.keyconfigs.addon
    # km_obj = kc.keymaps.get('3D View')
    # if km_obj:
    #     for kmi in reversed(km_obj.keymap_items):
    #         if kmi.idname == 'object.draw_hair_surf':
    #             km_obj.keymap_items.remove(kmi)
    # if km_obj:
    #     for kmi in reversed(km_obj.keymap_items):
    #         if kmi.idname == 'wm.call_menu_pie' and kmi.properties.name == 'HTOOL_MT_HairToolMenu':
    #             km_obj.keymap_items.remove(kmi)
