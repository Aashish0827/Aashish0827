"""<Shape Key Collections + Split Keys>
    Copyright © <2023>  <Inlet – https://inletzone.com>

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>."""

import bpy
from ast import literal_eval
from bpy.props import StringProperty, IntProperty, FloatProperty, BoolProperty, CollectionProperty, PointerProperty, EnumProperty
from bpy.types import PropertyGroup, UIList, Operator, Panel, Action, Object, Scene, Key, Menu
from bpy.utils import register_class, unregister_class
bl_info = {
    "name": "Shape Keys Collections",
    "category": "Mesh",
    "description": "Gives the Shape Keys a folder structure such as in the Outliner",
    "blender": (4, 0, 0),
    "version": (3, 6, 0),
    "doc_url": "https://inletzone.com/shape-key-collections",
    "author": "Inlet <inletcontacts@gmail.com>",
    "location": "Properties > Data > Shape Keys",}
debug = False
def xabfba33f07914a65b(x16d9257c0a0d412cc):
    x16d9257c0a0d412cc.w16d9257c0a0d412ce.clear()
    y16d9257c0a0d412ca = None
    for xabfba33f07914a65d, x16d9257c0a0d412ce in enumerate(x16d9257c0a0d412cc.w16d9257c0a0d412cc):
        ca1a2abcfa89317efb1 = x16d9257c0a0d412cc.data.shape_keys.key_blocks
        if not x16d9257c0a0d412ce.aa1a2abcfa89317efb:
            def check_2_split():
                split_name = ''
                if x16d9257c0a0d412ce.name.endswith('_Left'):
                    split_name = x16d9257c0a0d412ce.name[:-5]
                elif x16d9257c0a0d412ce.name.endswith('_Right'):
                    split_name = x16d9257c0a0d412ce.name[:-6]
                main_found = split_name + '_Main' in x16d9257c0a0d412cc.w16d9257c0a0d412cc
                l_found = split_name + '_Left' in x16d9257c0a0d412cc.w16d9257c0a0d412cc
                r_found = split_name + '_Right' in x16d9257c0a0d412cc.w16d9257c0a0d412cc
                if main_found and l_found and r_found:
                    return True
                else:
                    return False
            if not check_2_split():
                xabfba33f07914a65f = x16d9257c0a0d412cc.w16d9257c0a0d412ce.add()
                xabfba33f07914a65f.name = x16d9257c0a0d412ce.name
                xabfba33f07914a65f.a304a4f0f8c90403ce = x16d9257c0a0d412ce.name
        if x16d9257c0a0d412cc.wabfba33f07914a65d >= len(x16d9257c0a0d412cc.w16d9257c0a0d412cc):
            x16d9257c0a0d412cc.wabfba33f07914a65d = len(x16d9257c0a0d412cc.w16d9257c0a0d412cc) -1
        if x16d9257c0a0d412ce.name == x16d9257c0a0d412cc.w16d9257c0a0d412cc[x16d9257c0a0d412cc.wabfba33f07914a65d].name:
            x16d9257c0a0d412cc.wabfba33f07914a65f = xabfba33f07914a65d
            y16d9257c0a0d412ca = x16d9257c0a0d412ce.name
        real_blocks = ca1a2abcfa89317efb1
        if x16d9257c0a0d412ce.name in real_blocks:
            y16d9257c0a0d412ce = real_blocks[x16d9257c0a0d412ce.name]
            xabfba33f07914a65d = real_blocks[:].index(y16d9257c0a0d412ce)
            x16d9257c0a0d412cc.active_shape_key_index = xabfba33f07914a65d
            try:
                bpy.ops.object.shape_key_move(type='BOTTOM')
            except RuntimeError:
                pass
    if y16d9257c0a0d412ca != None:
        if y16d9257c0a0d412ca in ca1a2abcfa89317efb1:
            yabfba33f07914a65b = ca1a2abcfa89317efb1[y16d9257c0a0d412ca]
            y16d9257c0a0d412cc = ca1a2abcfa89317efb1[:].index(yabfba33f07914a65b)
            x16d9257c0a0d412cc.active_shape_key_index = y16d9257c0a0d412cc
def ca1a2abcfa89317efb9(self, context):
    if len(self.w16d9257c0a0d412ce) == 0:
        return
    try:
        ca1a2abcfa89317efb23 = self.w16d9257c0a0d412ce[self.wabfba33f07914a65f].name
    except:
        self.wabfba33f07914a65f = (len(self.w16d9257c0a0d412ce)-1)
        ca1a2abcfa89317efb23 = self.w16d9257c0a0d412ce[self.wabfba33f07914a65f].name
    if ca1a2abcfa89317efb23 == '':
        return
    yabfba33f07914a65d = self.data.shape_keys.key_blocks
    y16d9257c0a0d412ce = self.w16d9257c0a0d412cc[ca1a2abcfa89317efb23]
    xabfba33f07914a65d = self.w16d9257c0a0d412cc[:].index(y16d9257c0a0d412ce)
    self.wabfba33f07914a65d = xabfba33f07914a65d
    if y16d9257c0a0d412ce.zabfba33f07914a65f:
        self.active_shape_key_index = len(yabfba33f07914a65d)
    else:
        y16d9257c0a0d412ce = yabfba33f07914a65d[ca1a2abcfa89317efb23]
        xabfba33f07914a65d = yabfba33f07914a65d[:].index(y16d9257c0a0d412ce)
        self.active_shape_key_index = xabfba33f07914a65d
class tabfba33f07914a65d(Menu):
    bl_label = 'Shape Key Specials'
    def draw(self, _context):
        c304a4f0f8c90403ca = len(bpy.context.active_object.tracked_keys) > 0
        layout = self.layout.column(align=True)
        if c304a4f0f8c90403ca:
            layout.operator("object.skc_toggle_track_keys", text="Track 'Applied Keys'", icon='CHECKBOX_HLT')
        else:
            layout.operator("object.skc_from_mix", icon='ADD', text="Duplicate")
            layout.separator()
            layout.operator("object.shape_key_mirror", icon='ARROW_LEFTRIGHT').use_topology = False
            layout.operator("object.shape_key_mirror", text="Mirror Shape Key (Topology)").use_topology = True
            layout.separator()
            layout.operator("object.skc_join", text='Join as Shapes')
            layout.operator("object.skc_transfer", text='Transfer Shape Key')
            layout.separator()
            layout.operator("object.skc_remove_all", icon='X', text="Delete All Shape Keys")
            layout.operator("object.skc_apply_all", text="Apply All Shape Keys")
            layout.separator()
            layout.operator("object.skc_toggle_track_keys", text="Track 'Applied Keys'", icon='CHECKBOX_DEHLT')
            icon = 'CHECKBOX_DEHLT' if bpy.context.active_object.show_2split else 'CHECKBOX_HLT'
            layout.prop(bpy.context.active_object, "show_2split", text="Show Base Value", icon=icon)
            layout.separator()
            layout.operator("object.skc_folder_open", icon='TRIA_DOWN', text="Open All Folders")
            layout.operator("object.skc_folder_close", icon='TRIA_RIGHT', text="Close All Folders")
            layout.prop(bpy.context.scene, "skc_add_to_top", text="Add to Top")
            if "animation_add_corrective_shape_key" in bpy.context.preferences.addons.keys():
                layout.separator()
                layout.operator("object.object_duplicate_flatten_modifiers", text="Create Duplicate for Editing")
                if bpy.context.active_object.active_shape_key_index < 1:
                    layout.label(text='Please select a valid shape key target')
                else:
                    layout.operator("object.add_corrective_pose_shape", icon='COPY_ID', text="Add as Corrective Pose-Shape (slow, all modifiers)")
                    layout.operator("object.add_corrective_pose_shape_delta", icon='COPY_ID', text="Add as Corrective Pose-Shape Delta (slow, all modifiers + other shape key values)")
class t16d9257c0a0d412ce(Operator):
    bl_idname = "object.skc_from_mix"
    bl_label = "New Shape from Mix"
    def invoke(self, context, event):
        x16d9257c0a0d412cc = context.active_object
        parent = x16d9257c0a0d412cc.w16d9257c0a0d412cc[x16d9257c0a0d412cc.wabfba33f07914a65d]
        if parent.zabfba33f07914a65f:
            odata = bpy.data.objects[x16d9257c0a0d412cc.name]
            shape_key_solo_start = odata.show_only_shape_key
            odata.show_only_shape_key = True
            to_dupe = []
            for child in x16d9257c0a0d412cc.w16d9257c0a0d412cc[x16d9257c0a0d412cc.wabfba33f07914a65d+1:]:
                if child.z16d9257c0a0d412ce <= parent.z16d9257c0a0d412ce:
                    break
                to_dupe.append(child)
            def make_parent():
                folder_name = parent.name + '_copy'
                x16d9257c0a0d412ce = x16d9257c0a0d412cc.w16d9257c0a0d412cc.add()
                x16d9257c0a0d412cc.wabfba33f07914a65d = (len(x16d9257c0a0d412cc.w16d9257c0a0d412cc)-1)
                x16d9257c0a0d412ce.zabfba33f07914a65f = True
                x16d9257c0a0d412ce.name = folder_name
                x16d9257c0a0d412ce.z16d9257c0a0d412cc = parent.z16d9257c0a0d412cc
                x16d9257c0a0d412ce = x16d9257c0a0d412cc.w16d9257c0a0d412ce.add()
                x16d9257c0a0d412cc.wabfba33f07914a65f = (len(x16d9257c0a0d412cc.w16d9257c0a0d412ce)-1)
                x16d9257c0a0d412ce.a304a4f0f8c90403ce = folder_name
                x16d9257c0a0d412ce.name = folder_name
                x16d9257c0a0d412ce = x16d9257c0a0d412cc.x16d9257c0a0d412ca.add()
                x16d9257c0a0d412ce.name = folder_name
            def make_childs():
                yabfba33f07914a65d = x16d9257c0a0d412cc.data.shape_keys.key_blocks
                for xabfba33f07914a65f in to_dupe:
                    if xabfba33f07914a65f.zabfba33f07914a65f:
                        folder_name = xabfba33f07914a65f.name + '_copy'
                        x16d9257c0a0d412ce = x16d9257c0a0d412cc.w16d9257c0a0d412cc.add()
                        x16d9257c0a0d412cc.wabfba33f07914a65d = (len(x16d9257c0a0d412cc.w16d9257c0a0d412cc)-1)
                        x16d9257c0a0d412ce.zabfba33f07914a65f = True
                        x16d9257c0a0d412ce.name = folder_name
                        x16d9257c0a0d412ce.z16d9257c0a0d412cc = xabfba33f07914a65f.z16d9257c0a0d412cc + '_copy'
                        x16d9257c0a0d412ce = x16d9257c0a0d412cc.w16d9257c0a0d412ce.add()
                        x16d9257c0a0d412cc.wabfba33f07914a65f = (len(x16d9257c0a0d412cc.w16d9257c0a0d412ce)-1)
                        x16d9257c0a0d412ce.a304a4f0f8c90403ce = folder_name
                        x16d9257c0a0d412ce.name = folder_name
                        x16d9257c0a0d412ce = x16d9257c0a0d412cc.x16d9257c0a0d412ca.add()
                        x16d9257c0a0d412ce.name = folder_name
                    else:
                        y16d9257c0a0d412ce = yabfba33f07914a65d[xabfba33f07914a65f.name]
                        xabfba33f07914a65d = yabfba33f07914a65d[:].index(y16d9257c0a0d412ce)
                        x16d9257c0a0d412cc.active_shape_key_index = xabfba33f07914a65d
                        x16d9257c0a0d412cc.shape_key_add(name=xabfba33f07914a65f.name + '_copy', from_mix=True)
                        x16d9257c0a0d412cc.active_shape_key_index = (len(x16d9257c0a0d412cc.data.shape_keys.key_blocks)-1)
                        a304a4f0f8c904o3ce = x16d9257c0a0d412cc.active_shape_key.name
                        x16d9257c0a0d412ce = x16d9257c0a0d412cc.w16d9257c0a0d412ce.add()
                        x16d9257c0a0d412cc.wabfba33f07914a65f = (len(x16d9257c0a0d412cc.w16d9257c0a0d412ce)-1)
                        x16d9257c0a0d412ce.a304a4f0f8c90403ce = a304a4f0f8c904o3ce
                        x16d9257c0a0d412ce.name = a304a4f0f8c904o3ce
                        x16d9257c0a0d412ce = x16d9257c0a0d412cc.w16d9257c0a0d412cc.add()
                        x16d9257c0a0d412cc.wabfba33f07914a65d = (len(x16d9257c0a0d412cc.w16d9257c0a0d412cc)-1)
                        x16d9257c0a0d412ce.name = a304a4f0f8c904o3ce
                        x16d9257c0a0d412ce.z16d9257c0a0d412cc = xabfba33f07914a65f.z16d9257c0a0d412cc + '_copy'
            make_parent()
            make_childs()
            odata.show_only_shape_key = shape_key_solo_start
            return {"FINISHED"}
        bpy.ops.object.shape_key_add(from_mix=True)
        a304a4f0f8c904o3ce = x16d9257c0a0d412cc.data.shape_keys.key_blocks[-1].name
        x16d9257c0a0d412ce = x16d9257c0a0d412cc.w16d9257c0a0d412cc.add()
        x16d9257c0a0d412cc.wabfba33f07914a65d = (len(x16d9257c0a0d412cc.w16d9257c0a0d412cc)-1)
        x16d9257c0a0d412ce.name = a304a4f0f8c904o3ce
        x16d9257c0a0d412ce = x16d9257c0a0d412cc.w16d9257c0a0d412ce.add()
        x16d9257c0a0d412cc.wabfba33f07914a65f = (len(x16d9257c0a0d412cc.w16d9257c0a0d412ce)-1)
        x16d9257c0a0d412ce.a304a4f0f8c90403ce = a304a4f0f8c904o3ce
        x16d9257c0a0d412ce.name = a304a4f0f8c904o3ce
        return {"FINISHED"}
class tabfba33f07914a65f(Operator):
    bl_idname = "object.skc_join"
    bl_label = "Join as Shapes"
    def invoke(self, context, event):
        x16d9257c0a0d412cc = context.active_object
        bpy.ops.object.join_shapes()
        a304a4f0f8c904o3ce = x16d9257c0a0d412cc.data.shape_keys.key_blocks[-1].name
        x16d9257c0a0d412ce = x16d9257c0a0d412cc.w16d9257c0a0d412cc.add()
        x16d9257c0a0d412cc.wabfba33f07914a65d = (len(x16d9257c0a0d412cc.w16d9257c0a0d412cc)-1)
        x16d9257c0a0d412ce.name = a304a4f0f8c904o3ce
        x16d9257c0a0d412ce = x16d9257c0a0d412cc.w16d9257c0a0d412ce.add()
        x16d9257c0a0d412cc.wabfba33f07914a65f = (len(x16d9257c0a0d412cc.w16d9257c0a0d412ce)-1)
        x16d9257c0a0d412ce.a304a4f0f8c90403ce = a304a4f0f8c904o3ce
        x16d9257c0a0d412ce.name = a304a4f0f8c904o3ce
        return {"FINISHED"}
class u16d9257c0a0d412ca(Operator):
    bl_idname = "object.skc_transfer"
    bl_label = "Transfer Shape Key"
    def invoke(self, context, event):
        x16d9257c0a0d412cc = context.active_object
        bpy.ops.object.shape_key_transfer()
        a304a4f0f8c904o3ce = x16d9257c0a0d412cc.data.shape_keys.key_blocks[-1].name
        x16d9257c0a0d412ce = x16d9257c0a0d412cc.w16d9257c0a0d412cc.add()
        x16d9257c0a0d412cc.wabfba33f07914a65d = (len(x16d9257c0a0d412cc.w16d9257c0a0d412cc)-1)
        x16d9257c0a0d412ce.name = a304a4f0f8c904o3ce
        x16d9257c0a0d412ce = x16d9257c0a0d412cc.w16d9257c0a0d412ce.add()
        x16d9257c0a0d412cc.wabfba33f07914a65f = (len(x16d9257c0a0d412cc.w16d9257c0a0d412ce)-1)
        x16d9257c0a0d412ce.a304a4f0f8c90403ce = a304a4f0f8c904o3ce
        x16d9257c0a0d412ce.name = a304a4f0f8c904o3ce
        return {"FINISHED"}
class uabfba33f07914a65b(Operator):
    bl_idname = "object.skc_remove_all"
    bl_label = "Delete All Shape Keys"
    def invoke(self, context, event):
        x16d9257c0a0d412cc = context.object
        bpy.ops.object.shape_key_remove(all=True, apply_mix=False)
        x16d9257c0a0d412cc.w16d9257c0a0d412cc.clear()
        x16d9257c0a0d412cc.w16d9257c0a0d412ce.clear()
        return {"FINISHED"}
class u16d9257c0a0d412cc(Operator):
    bl_idname = "object.skc_apply_all"
    bl_label = "Apply All Shape Keys"
    def invoke(self, context, event):
        x16d9257c0a0d412cc = context.object
        bpy.ops.object.shape_key_remove(all=True, apply_mix=True)
        x16d9257c0a0d412cc.w16d9257c0a0d412cc.clear()
        x16d9257c0a0d412cc.w16d9257c0a0d412ce.clear()
        return {"FINISHED"}
class u16d9257c0a0d412ce(Operator):
    """Open all folders present on this object"""
    bl_idname = "object.skc_folder_open"
    bl_label = "Open All Folders"
    def invoke(self, context, event):
        x16d9257c0a0d412cc = context.object
        while True:
            yabfba33f07914a65f = False
            for x16d9257c0a0d412ce in x16d9257c0a0d412cc.w16d9257c0a0d412cc:
                if x16d9257c0a0d412ce.zabfba33f07914a65f and not x16d9257c0a0d412ce.a304a4f0f8c90403ca:
                    try:
                        y16d9257c0a0d412ce = x16d9257c0a0d412cc.w16d9257c0a0d412ce[x16d9257c0a0d412ce.name]
                        index = x16d9257c0a0d412cc.w16d9257c0a0d412ce[:].index(y16d9257c0a0d412ce)
                    except:
                        pass
                    else:
                        bpy.ops.object.collections_toggle(xabfba33f07914a65d=index)
                        yabfba33f07914a65f = True
                        break
            if not yabfba33f07914a65f:
                break
        return {"FINISHED"}
class uabfba33f07914a65f(Operator):
    """Close all folders present on this object"""
    bl_idname = "object.skc_folder_close"
    bl_label = "Close All Folders"
    def invoke(self, context, event):
        x16d9257c0a0d412cc = context.object
        while True:
            yabfba33f07914a65f = False
            for x16d9257c0a0d412ce in reversed(x16d9257c0a0d412cc.w16d9257c0a0d412cc):
                if x16d9257c0a0d412ce.zabfba33f07914a65f and x16d9257c0a0d412ce.a304a4f0f8c90403ca:
                    try:
                        y16d9257c0a0d412ce = x16d9257c0a0d412cc.w16d9257c0a0d412ce[x16d9257c0a0d412ce.name]
                        index = x16d9257c0a0d412cc.w16d9257c0a0d412ce[:].index(y16d9257c0a0d412ce)
                    except:
                        pass
                    else:
                        bpy.ops.object.collections_toggle(xabfba33f07914a65d=index)
                        yabfba33f07914a65f = True
                        break
            if not yabfba33f07914a65f:
                break
        return {"FINISHED"}
class SKC_TRACK_APPLY_menu(Operator):
    """Start tracking any shape keys added by 'Save/Apply from Modifier'"""
    bl_idname = "object.skc_toggle_track_keys"
    bl_label = "Track 'Applied Keys'"
    action: BoolProperty()
    def invoke(self, context, event):
        x16d9257c0a0d412cc = context.active_object
        tracked_keys = x16d9257c0a0d412cc.tracked_keys
        key_blocks = x16d9257c0a0d412cc.data.shape_keys.key_blocks
        if len(tracked_keys) == 0:
            self.report({'INFO'}, "You may now 'Apply Shape Keys' from modifiers; disable this to see new shape keys")
            for shape_key in key_blocks:
                tracked_keys.add().name = shape_key.name
        else:
            xabfba33f07914a65d = 0
            for ca1a2abcfa89317efb23 in key_blocks:
                if ca1a2abcfa89317efb23.name in tracked_keys:
                    continue
                x16d9257c0a0d412ce = x16d9257c0a0d412cc.w16d9257c0a0d412cc.add()
                x16d9257c0a0d412cc.wabfba33f07914a65d = (len(x16d9257c0a0d412cc.w16d9257c0a0d412cc)-1)
                x16d9257c0a0d412ce.name = ca1a2abcfa89317efb23.name
                x16d9257c0a0d412ce = x16d9257c0a0d412cc.w16d9257c0a0d412ce.add()
                x16d9257c0a0d412cc.wabfba33f07914a65f = (len(x16d9257c0a0d412cc.w16d9257c0a0d412ce)-1)
                x16d9257c0a0d412ce.a304a4f0f8c90403ce = ca1a2abcfa89317efb23.name
                x16d9257c0a0d412ce.name = ca1a2abcfa89317efb23.name
                xabfba33f07914a65d += 1
            self.report({'INFO'}, "No longer tracking shape keys 'Applied' from modifiers. {} new keys added".format(xabfba33f07914a65d))
            tracked_keys.clear()
        return {"FINISHED"}
class uabfba33f07914a65d(Operator):
    """Shape Keys from V2 of this script found\nClick to update to V3"""
    bl_idname = "object.skc_refresh"
    bl_label = "Update to V3"
    def invoke(self, context, event):
        x16d9257c0a0d412cc = context.object
        while True:
            yabfba33f07914a65f = False
            for x16d9257c0a0d412ce in x16d9257c0a0d412cc.f9be46a2c881b406ac:
                if x16d9257c0a0d412ce.zabfba33f07914a65f and not x16d9257c0a0d412ce.a304a4f0f8c90403ca:
                    try:
                        y16d9257c0a0d412ce = x16d9257c0a0d412cc.f9be46a2c881b406ac[x16d9257c0a0d412ce.name]
                        index = x16d9257c0a0d412cc.f9be46a2c881b406ac[:].index(y16d9257c0a0d412ce)
                    except:
                        pass
                    else:
                        bpy.ops.object.folder_toggle(Index=index)
                        yabfba33f07914a65f = True
                        break
            if not yabfba33f07914a65f:
                break
        global z16d9257c0a0d412ca
        z16d9257c0a0d412ca = True
        for zabfba33f07914a65b in x16d9257c0a0d412cc.f9be46a2c881b406ac:
            if zabfba33f07914a65b.zabfba33f07914a65f:
                x16d9257c0a0d412ce = x16d9257c0a0d412cc.x16d9257c0a0d412ca.add()
                x16d9257c0a0d412ce.name = zabfba33f07914a65b.name
            x16d9257c0a0d412ce = x16d9257c0a0d412cc.w16d9257c0a0d412cc.add()
            x16d9257c0a0d412ce.z16d9257c0a0d412cc = zabfba33f07914a65b.folder
            x16d9257c0a0d412ce.name = zabfba33f07914a65b.name
            x16d9257c0a0d412ce.z16d9257c0a0d412ce = zabfba33f07914a65b.l1b406ay67
            x16d9257c0a0d412ce.zabfba33f07914a65f = zabfba33f07914a65b.l1b406ay65
            x16d9257c0a0d412cc.wabfba33f07914a65d = (len(x16d9257c0a0d412cc.w16d9257c0a0d412cc)-1)
            x16d9257c0a0d412ce = x16d9257c0a0d412cc.w16d9257c0a0d412ce.add()
            x16d9257c0a0d412ce.a304a4f0f8c90403ce = zabfba33f07914a65b.name
            x16d9257c0a0d412ce.name = zabfba33f07914a65b.name
            x16d9257c0a0d412cc.wabfba33f07914a65f = (len(x16d9257c0a0d412cc.w16d9257c0a0d412ce)-1)
        x16d9257c0a0d412cc.f9be46a2c881b406ac.clear()
        z16d9257c0a0d412ca = False
        xabfba33f07914a65b(x16d9257c0a0d412cc)
        return {"FINISHED"}
z16d9257c0a0d412ca = False
class vabfba33f07914a65b(PropertyGroup):
    def a304a4f0f8c90403cc(self, context):
        global z16d9257c0a0d412ca
        if z16d9257c0a0d412ca:
            return
        x16d9257c0a0d412cc = context.active_object
        def c304a4f0f8c90403cc(z16d9257c0a0d412cc, hide):
            xabfba33f07914a65d = x16d9257c0a0d412cc.w16d9257c0a0d412cc[:].index(z16d9257c0a0d412cc)
            for x16d9257c0a0d412ce in x16d9257c0a0d412cc.w16d9257c0a0d412cc[xabfba33f07914a65d+1:]:
                already_spawned = x16d9257c0a0d412ce.aa1a2abcfa89317efb == hide
                if x16d9257c0a0d412ce.z16d9257c0a0d412ce <= z16d9257c0a0d412cc.z16d9257c0a0d412ce:
                    break
                elif x16d9257c0a0d412ce.z16d9257c0a0d412ce == z16d9257c0a0d412cc.z16d9257c0a0d412ce +1 and not already_spawned:
                    x16d9257c0a0d412ce.aa1a2abcfa89317efb = hide
                    if x16d9257c0a0d412ce.zabfba33f07914a65f and x16d9257c0a0d412ce.a304a4f0f8c90403ca:
                        c304a4f0f8c90403cc(x16d9257c0a0d412ce, hide)
                else:
                    pass
        if not self.aa1a2abcfa89317efb:
            x16d9257c0a0d412ce = x16d9257c0a0d412cc.w16d9257c0a0d412ce.add()
            active_idx = (len(x16d9257c0a0d412cc.w16d9257c0a0d412ce)-1)
            x16d9257c0a0d412ce.name = self.name
            hide_fix = 0
            for xabfba33f07914a65d, ca1a2abcfa89317efb22 in enumerate(x16d9257c0a0d412cc.w16d9257c0a0d412cc):
                if ca1a2abcfa89317efb22.name == self.name:
                    x16d9257c0a0d412cc.w16d9257c0a0d412ce.move(active_idx, xabfba33f07914a65d - hide_fix)
                    if ca1a2abcfa89317efb22.zabfba33f07914a65f and ca1a2abcfa89317efb22.a304a4f0f8c90403ca:
                        c304a4f0f8c90403cc(ca1a2abcfa89317efb22, False)
                    break
                elif ca1a2abcfa89317efb22.aa1a2abcfa89317efb:
                    hide_fix += 1
        else:
            try:
                y16d9257c0a0d412ce = x16d9257c0a0d412cc.w16d9257c0a0d412ce[self.name]
            except KeyError:
                pass
            else:
                xabfba33f07914a65d = x16d9257c0a0d412cc.w16d9257c0a0d412ce[:].index(y16d9257c0a0d412ce)
                x16d9257c0a0d412cc.w16d9257c0a0d412ce.remove(xabfba33f07914a65d)
            ca1a2abcfa89317efb21 = x16d9257c0a0d412cc.w16d9257c0a0d412cc[self.name]
            if ca1a2abcfa89317efb21.zabfba33f07914a65f and ca1a2abcfa89317efb21.a304a4f0f8c90403ca:
                c304a4f0f8c90403cc(ca1a2abcfa89317efb21, True)
    def DISPLAY_update_parent(self, context):
        global z16d9257c0a0d412ca
        if z16d9257c0a0d412ca:
            return
        x16d9257c0a0d412cc = context.active_object
        self_index = x16d9257c0a0d412cc.w16d9257c0a0d412cc[:].index(self)
        move_list = [(self.name, self.z16d9257c0a0d412ce)]
        if self.z16d9257c0a0d412cc != '':
            target_folder = x16d9257c0a0d412cc.w16d9257c0a0d412cc[self.z16d9257c0a0d412cc]
            target_folder_index = x16d9257c0a0d412cc.w16d9257c0a0d412cc[:].index(target_folder)
            if not context.scene.skc_add_to_top:
                for test_target in x16d9257c0a0d412cc.w16d9257c0a0d412cc[target_folder_index+1:]:
                    if test_target.z16d9257c0a0d412ce <= target_folder.z16d9257c0a0d412ce:
                        target_folder_index = x16d9257c0a0d412cc.w16d9257c0a0d412cc[:].index(test_target)-1
                        break
                else:
                    target_folder_index = len(x16d9257c0a0d412cc.w16d9257c0a0d412cc)-1
            target_folder_indent = target_folder.z16d9257c0a0d412ce
            target_folder_hidden = (not target_folder.a304a4f0f8c90403ca or target_folder.aa1a2abcfa89317efb)
        else:
            target_folder_index = len(x16d9257c0a0d412cc.w16d9257c0a0d412cc)-1
            target_folder_indent = -1
            target_folder_hidden = False
        self.aa1a2abcfa89317efb = target_folder_hidden
        if self.zabfba33f07914a65f:
            for child in x16d9257c0a0d412cc.w16d9257c0a0d412cc[self_index+1:]:
                if child.z16d9257c0a0d412ce <= self.z16d9257c0a0d412ce:
                    break
                else:
                    child.aa1a2abcfa89317efb = target_folder_hidden
                    move_list.append((child.name, child.z16d9257c0a0d412ce))
        index_offset = 0
        for x16d9257c0a0d412ce in move_list:
            y16d9257c0a0d412ce = x16d9257c0a0d412cc.w16d9257c0a0d412cc[x16d9257c0a0d412ce[0]]
            y16d9257c0a0d412ce.z16d9257c0a0d412ce = x16d9257c0a0d412ce[1] + target_folder_indent - move_list[0][1] +1
            xabfba33f07914a65d = x16d9257c0a0d412cc.w16d9257c0a0d412cc[:].index(y16d9257c0a0d412ce)
            if xabfba33f07914a65d > target_folder_index + index_offset:
                index_offset += 1
            x16d9257c0a0d412cc.w16d9257c0a0d412cc.move(xabfba33f07914a65d, target_folder_index +index_offset)
        xabfba33f07914a65b(x16d9257c0a0d412cc)
    def update_name(self, context):
        xabfba33f07914a65b(context.active_object)
    name:  StringProperty(
        name="Name",
        update = update_name,
        description="Shape Key Name",
        default='Folder')
    z16d9257c0a0d412cc: StringProperty(
        name="Parent Folder",
        update = DISPLAY_update_parent,
        description="Reference to Folder this Shape Key belongs to")
    z16d9257c0a0d412ce: IntProperty(
        name="Indent",
        max=10,
        min=0,
        description="")
    zabfba33f07914a65f: BoolProperty(
        name="Folder",
        description="",
        default=False)
    a304a4f0f8c90403ca: BoolProperty(
        name="Folder Status",
        description="",
        default=True)
    aa1a2abcfa89317efb: BoolProperty(
        name="Folder Status",
        update = a304a4f0f8c90403cc,
        description="",
        default=False)
class vabfba33f07914a65f(PropertyGroup):
    def DISPLAY_name_update(self, context):
        x16d9257c0a0d412cc = context.active_object
        xabfba33f07914a65f = self.name
        aa1a2abcfa89317efd = self.a304a4f0f8c90403ce
        try:
            if x16d9257c0a0d412cc.w16d9257c0a0d412cc[aa1a2abcfa89317efd].zabfba33f07914a65f:
                y16d9257c0a0d412ce = x16d9257c0a0d412cc.x16d9257c0a0d412ca[aa1a2abcfa89317efd]
                y16d9257c0a0d412ce.name = xabfba33f07914a65f
                for x16d9257c0a0d412ce in x16d9257c0a0d412cc.w16d9257c0a0d412cc:
                    if x16d9257c0a0d412ce.z16d9257c0a0d412cc == aa1a2abcfa89317efd:
                        x16d9257c0a0d412ce.z16d9257c0a0d412cc = xabfba33f07914a65f
            else:
                x16d9257c0a0d412cc.data.shape_keys.key_blocks[aa1a2abcfa89317efd].name = xabfba33f07914a65f
            x16d9257c0a0d412cc.w16d9257c0a0d412cc[aa1a2abcfa89317efd].name = xabfba33f07914a65f
            self.a304a4f0f8c90403ce = xabfba33f07914a65f
        except KeyError:
            pass
    name:  StringProperty(
        description="name",
        update=DISPLAY_name_update)
    a304a4f0f8c90403ce:  StringProperty()
class wabfba33f07914a65b(PropertyGroup):
    name:  StringProperty()
class TRACK_KEYS_list(PropertyGroup):
    name:  StringProperty()
class vabfba33f07914a65d(Operator):
    """Move items up and down, add and remove"""
    bl_idname = "object.collections_actions"
    bl_label = "Collection Actions"
    bl_description = "Add or Remove items from this list, or move them up or down"
    action: EnumProperty(
        items=(
            ('UP', "Up", ""),
            ('DOWN', "Down", ""),
            ('REMOVE', "Remove", ""),
            ('ADD', "Add", ""),
            ('FOLDER', "Folder", "")))
    ca1a2abcfa89317efb3: BoolProperty(
        default=False)
    @classmethod
    def poll(cls, context):
        return context.area.type == 'PROPERTIES'
    def invoke(self, context, event):
        x16d9257c0a0d412cc = context.active_object
        xabfba33f07914a65d = x16d9257c0a0d412cc.wabfba33f07914a65d
        new_loc = None
        if self.ca1a2abcfa89317efb3:
            yabfba33f07914a65d = x16d9257c0a0d412cc.data.shape_keys.key_blocks[:]
            for block in yabfba33f07914a65d:
                x16d9257c0a0d412ce = x16d9257c0a0d412cc.w16d9257c0a0d412cc.add()
                x16d9257c0a0d412cc.wabfba33f07914a65d = (len(x16d9257c0a0d412cc.w16d9257c0a0d412cc)-1)
                x16d9257c0a0d412ce.name = block.name
                x16d9257c0a0d412ce = x16d9257c0a0d412cc.w16d9257c0a0d412ce.add()
                x16d9257c0a0d412cc.wabfba33f07914a65f = (len(x16d9257c0a0d412cc.w16d9257c0a0d412ce)-1)
                x16d9257c0a0d412ce.a304a4f0f8c90403ce = block.name
                x16d9257c0a0d412ce.name = block.name
        elif self.action == 'DOWN' and xabfba33f07914a65d < len(x16d9257c0a0d412cc.w16d9257c0a0d412cc) - 1:
            x16d9257c0a0d412ce = x16d9257c0a0d412cc.w16d9257c0a0d412cc[xabfba33f07914a65d]
            aa1a2abcfa89317eff = x16d9257c0a0d412cc.w16d9257c0a0d412cc[xabfba33f07914a65d+1]
            b304a4f0f8c90403ca = x16d9257c0a0d412ce.z16d9257c0a0d412ce == aa1a2abcfa89317eff.z16d9257c0a0d412ce
            ba1a2abcfa89317efb = x16d9257c0a0d412ce.z16d9257c0a0d412ce < aa1a2abcfa89317eff.z16d9257c0a0d412ce
            try:
                b304a4f0f8c90403cc = x16d9257c0a0d412cc.w16d9257c0a0d412cc[xabfba33f07914a65d+2]
                ba1a2abcfa89317efd = b304a4f0f8c90403cc.z16d9257c0a0d412cc == aa1a2abcfa89317eff.name and aa1a2abcfa89317eff.z16d9257c0a0d412ce <= x16d9257c0a0d412ce.z16d9257c0a0d412ce
            except IndexError:
                ba1a2abcfa89317efd = False
            if b304a4f0f8c90403ca and not ba1a2abcfa89317efd:
                x16d9257c0a0d412cc.w16d9257c0a0d412cc.move(xabfba33f07914a65d, xabfba33f07914a65d+1)
                x16d9257c0a0d412cc.wabfba33f07914a65d += 1
            elif ba1a2abcfa89317efd:
                target_idx = xabfba33f07914a65d+1
                ba1a2abcfa89317eff = False
                for c304a4f0f8c90403ccc in x16d9257c0a0d412cc.w16d9257c0a0d412cc[xabfba33f07914a65d+2:]:
                    if c304a4f0f8c90403ccc.z16d9257c0a0d412ce <= x16d9257c0a0d412ce.z16d9257c0a0d412ce:
                        x16d9257c0a0d412cc.w16d9257c0a0d412cc.move(xabfba33f07914a65d, target_idx)
                        x16d9257c0a0d412cc.wabfba33f07914a65d = target_idx
                        ba1a2abcfa89317eff = True
                        break
                    elif c304a4f0f8c90403ccc.z16d9257c0a0d412ce > x16d9257c0a0d412ce.z16d9257c0a0d412ce:
                        target_idx += 1
                    else:
                        pass
                if not ba1a2abcfa89317eff:
                    x16d9257c0a0d412cc.w16d9257c0a0d412cc.move(xabfba33f07914a65d, len(x16d9257c0a0d412cc.w16d9257c0a0d412cc)-1)
                    x16d9257c0a0d412cc.wabfba33f07914a65d = (len(x16d9257c0a0d412cc.w16d9257c0a0d412cc)-1)
            elif ba1a2abcfa89317efb:
                target_idx = xabfba33f07914a65d+1
                starting_name = x16d9257c0a0d412ce.name
                def c304a4f0f8c90403cc(source):
                    ca1a2abcfa89317efb = 1
                    for x16d9257c0a0d412ce in x16d9257c0a0d412cc.w16d9257c0a0d412cc[xabfba33f07914a65d+1:]:
                        if x16d9257c0a0d412ce.z16d9257c0a0d412ce == x16d9257c0a0d412cc.w16d9257c0a0d412cc[xabfba33f07914a65d].z16d9257c0a0d412ce:
                            c304a4f0f8c90403ca = x16d9257c0a0d412ce.zabfba33f07914a65f and x16d9257c0a0d412ce.z16d9257c0a0d412ce <= source.z16d9257c0a0d412ce
                            return c304a4f0f8c90403ca, ca1a2abcfa89317efb
                        ca1a2abcfa89317efb += 1
                try:
                    c304a4f0f8c90403ca, ca1a2abcfa89317efb = c304a4f0f8c90403cc(x16d9257c0a0d412ce)
                except TypeError:
                    pass
                else:
                    if c304a4f0f8c90403ca:
                        above_folder = x16d9257c0a0d412cc.w16d9257c0a0d412cc[x16d9257c0a0d412cc.wabfba33f07914a65d]
                        x16d9257c0a0d412cc.wabfba33f07914a65d += ca1a2abcfa89317efb
                        idx_new = x16d9257c0a0d412cc.wabfba33f07914a65d
                        item_new = x16d9257c0a0d412cc.w16d9257c0a0d412cc[idx_new]
                        if above_folder.z16d9257c0a0d412ce == item_new.z16d9257c0a0d412ce:
                            target_idx = x16d9257c0a0d412cc.w16d9257c0a0d412cc[:].index(above_folder)
                            x16d9257c0a0d412cc.w16d9257c0a0d412cc.move(idx_new, target_idx)
                            x16d9257c0a0d412cc.wabfba33f07914a65d = target_idx
                            for iteration, c304a4f0f8c90403ccc in enumerate(x16d9257c0a0d412cc.w16d9257c0a0d412cc[idx_new+1:]):
                                iteration += 1
                                target_ind = x16d9257c0a0d412cc.w16d9257c0a0d412cc[xabfba33f07914a65d].z16d9257c0a0d412ce
                                if c304a4f0f8c90403ccc.z16d9257c0a0d412ce > target_ind:
                                    x16d9257c0a0d412cc.w16d9257c0a0d412cc.move(idx_new+iteration, target_idx+iteration)
                                else:
                                    break
                    else:
                        for c304a4f0f8c90403ccc in x16d9257c0a0d412cc.w16d9257c0a0d412cc[xabfba33f07914a65d+2:]:
                            if c304a4f0f8c90403ccc.z16d9257c0a0d412ce == x16d9257c0a0d412ce.z16d9257c0a0d412ce:
                                target_name = c304a4f0f8c90403ccc.name
                                target_ind = c304a4f0f8c90403ccc.z16d9257c0a0d412ce
                                x16d9257c0a0d412cc.w16d9257c0a0d412cc.move(xabfba33f07914a65d, target_idx+1)
                                x16d9257c0a0d412cc.wabfba33f07914a65d = target_idx-1
                                while True:
                                    if x16d9257c0a0d412cc.w16d9257c0a0d412cc[xabfba33f07914a65d].z16d9257c0a0d412ce > target_ind:
                                        x16d9257c0a0d412cc.w16d9257c0a0d412cc.move(xabfba33f07914a65d, target_idx +1)
                                    else:
                                        break
                                break
                            elif c304a4f0f8c90403ccc.z16d9257c0a0d412ce > x16d9257c0a0d412ce.z16d9257c0a0d412ce:
                                target_idx += 1
                            else:
                                return {"CANCELLED"}
                    for xabfba33f07914a65d, c304a4f0f8c90403ccc in enumerate(x16d9257c0a0d412cc.w16d9257c0a0d412cc):
                        if c304a4f0f8c90403ccc.name == starting_name:
                            x16d9257c0a0d412cc.wabfba33f07914a65d = xabfba33f07914a65d
                            break
        elif self.action == 'UP' and xabfba33f07914a65d >= 1:
            x16d9257c0a0d412ce = x16d9257c0a0d412cc.w16d9257c0a0d412cc[xabfba33f07914a65d]
            above = x16d9257c0a0d412cc.w16d9257c0a0d412cc[xabfba33f07914a65d-1]
            target_ind = x16d9257c0a0d412cc.w16d9257c0a0d412cc[xabfba33f07914a65d].z16d9257c0a0d412ce
            b304a4f0f8c90403ca = x16d9257c0a0d412ce.z16d9257c0a0d412ce == above.z16d9257c0a0d412ce
            ba1a2abcfa89317efb = x16d9257c0a0d412ce.z16d9257c0a0d412ce < above.z16d9257c0a0d412ce
            try:
                aa1a2abcfa89317eff = x16d9257c0a0d412cc.w16d9257c0a0d412cc[xabfba33f07914a65d+1]
                ba1a2abcfa89317efd = aa1a2abcfa89317eff.z16d9257c0a0d412cc == x16d9257c0a0d412ce.name
            except IndexError:
                ba1a2abcfa89317efd = False
            if b304a4f0f8c90403ca:
                x16d9257c0a0d412cc.w16d9257c0a0d412cc.move(xabfba33f07914a65d, xabfba33f07914a65d-1)
                x16d9257c0a0d412cc.wabfba33f07914a65d -= 1
                if ba1a2abcfa89317efd:
                    target_idx = xabfba33f07914a65d
                    for c304a4f0f8c90403ccc in x16d9257c0a0d412cc.w16d9257c0a0d412cc[xabfba33f07914a65d+1:]:
                        if c304a4f0f8c90403ccc.z16d9257c0a0d412ce > target_ind:
                            x16d9257c0a0d412cc.w16d9257c0a0d412cc.move(target_idx, target_idx+1)
                            target_idx += 1
                        else:
                            break
            elif ba1a2abcfa89317efb:
                above_folder = x16d9257c0a0d412cc.w16d9257c0a0d412cc[above.z16d9257c0a0d412cc]
                if above_folder.z16d9257c0a0d412ce == x16d9257c0a0d412ce.z16d9257c0a0d412ce:
                    target_idx = x16d9257c0a0d412cc.w16d9257c0a0d412cc[:].index(above_folder)
                else:
                    for above_folder in reversed(x16d9257c0a0d412cc.w16d9257c0a0d412cc[:xabfba33f07914a65d]):
                        if above_folder.z16d9257c0a0d412ce == x16d9257c0a0d412ce.z16d9257c0a0d412ce:
                            target_idx = x16d9257c0a0d412cc.w16d9257c0a0d412cc[:].index(above_folder)
                            break
                x16d9257c0a0d412cc.w16d9257c0a0d412cc.move(xabfba33f07914a65d, target_idx)
                x16d9257c0a0d412cc.wabfba33f07914a65d = target_idx
                if ba1a2abcfa89317efd:
                    for iteration, c304a4f0f8c90403ccc in enumerate(x16d9257c0a0d412cc.w16d9257c0a0d412cc[xabfba33f07914a65d+1:]):
                        iteration += 1
                        if c304a4f0f8c90403ccc.z16d9257c0a0d412ce > target_ind:
                            x16d9257c0a0d412cc.w16d9257c0a0d412cc.move(xabfba33f07914a65d+iteration, target_idx+iteration)
                        else:
                            break
        elif self.action == 'REMOVE':
            x16d9257c0a0d412ce = x16d9257c0a0d412cc.w16d9257c0a0d412cc[x16d9257c0a0d412cc.wabfba33f07914a65d]
            startindent = x16d9257c0a0d412ce.z16d9257c0a0d412ce
            zabfba33f07914a65f = x16d9257c0a0d412ce.zabfba33f07914a65f
            name = x16d9257c0a0d412ce.name
            z16d9257c0a0d412cc = x16d9257c0a0d412ce.z16d9257c0a0d412cc
            wabfba33f07914a65f = x16d9257c0a0d412cc.wabfba33f07914a65f
            if not zabfba33f07914a65f:
                x16d9257c0a0d412ce = x16d9257c0a0d412cc.active_shape_key
                y16d9257c0a0d412ce = x16d9257c0a0d412cc.w16d9257c0a0d412cc[x16d9257c0a0d412ce.name]
                xabfba33f07914a65d = x16d9257c0a0d412cc.w16d9257c0a0d412cc[:].index(y16d9257c0a0d412ce)
                x16d9257c0a0d412cc.w16d9257c0a0d412cc.remove(xabfba33f07914a65d)
                y16d9257c0a0d412ce = x16d9257c0a0d412cc.w16d9257c0a0d412ce[x16d9257c0a0d412ce.name]
                xabfba33f07914a65d = x16d9257c0a0d412cc.w16d9257c0a0d412ce[:].index(y16d9257c0a0d412ce)
                x16d9257c0a0d412cc.w16d9257c0a0d412ce.remove(xabfba33f07914a65d)
                x16d9257c0a0d412cc.shape_key_remove(x16d9257c0a0d412ce)
            if zabfba33f07914a65f:
                y16d9257c0a0d412ce = x16d9257c0a0d412cc.x16d9257c0a0d412ca[x16d9257c0a0d412ce.name]
                xabfba33f07914a65d = x16d9257c0a0d412cc.x16d9257c0a0d412ca[:].index(y16d9257c0a0d412ce)
                x16d9257c0a0d412cc.x16d9257c0a0d412ca.remove(xabfba33f07914a65d)
                if not x16d9257c0a0d412ce.a304a4f0f8c90403ca:
                    number = -1
                    internal = x16d9257c0a0d412cc.w16d9257c0a0d412cc[x16d9257c0a0d412cc.wabfba33f07914a65d]
                    for _ in range(len(x16d9257c0a0d412cc.w16d9257c0a0d412cc)):
                        if x16d9257c0a0d412cc.wabfba33f07914a65d >= len(x16d9257c0a0d412cc.w16d9257c0a0d412cc):
                            break
                        internal = x16d9257c0a0d412cc.w16d9257c0a0d412cc[x16d9257c0a0d412cc.wabfba33f07914a65d]
                        if internal.z16d9257c0a0d412ce <= startindent and internal.name != name:
                            break
                        if internal.zabfba33f07914a65f and internal.name in x16d9257c0a0d412cc.x16d9257c0a0d412ca:
                            y16d9257c0a0d412ce = x16d9257c0a0d412cc.x16d9257c0a0d412ca[internal.name]
                            xabfba33f07914a65d = x16d9257c0a0d412cc.x16d9257c0a0d412ca[:].index(y16d9257c0a0d412ce)
                            x16d9257c0a0d412cc.x16d9257c0a0d412ca.remove(xabfba33f07914a65d)
                        else:
                            yabfba33f07914a65b = x16d9257c0a0d412cc.data.shape_keys.key_blocks[internal.name]
                            x16d9257c0a0d412cc.shape_key_remove(yabfba33f07914a65b)
                        number += 1
                        x16d9257c0a0d412cc.w16d9257c0a0d412cc.remove(x16d9257c0a0d412cc.wabfba33f07914a65d)
                    if number != 0:
                        self.report({'INFO'}, f'Deleting {number} shape keys from this folder')
                elif x16d9257c0a0d412ce.a304a4f0f8c90403ca:
                    try:
                        y16d9257c0a0d412ce = x16d9257c0a0d412cc.x16d9257c0a0d412ca[internal.name]
                        xabfba33f07914a65d = x16d9257c0a0d412cc.x16d9257c0a0d412ca[:].index(y16d9257c0a0d412ce)
                        x16d9257c0a0d412cc.x16d9257c0a0d412ca.remove(xabfba33f07914a65d)
                    except:
                        pass
                    x16d9257c0a0d412cc.w16d9257c0a0d412cc.remove(x16d9257c0a0d412cc.wabfba33f07914a65d)
                    try:
                        for _ in x16d9257c0a0d412cc.w16d9257c0a0d412cc:
                            child = x16d9257c0a0d412cc.w16d9257c0a0d412cc[x16d9257c0a0d412cc.wabfba33f07914a65d]
                            if child.z16d9257c0a0d412cc == name:
                                child.z16d9257c0a0d412cc = z16d9257c0a0d412cc
                        for xabfba33f07914a65d, child in enumerate(x16d9257c0a0d412cc.w16d9257c0a0d412cc):
                            child = x16d9257c0a0d412cc.w16d9257c0a0d412cc[xabfba33f07914a65d]
                            if child.z16d9257c0a0d412cc == name:
                                child.z16d9257c0a0d412cc = z16d9257c0a0d412cc
                    except IndexError:
                        pass
                x16d9257c0a0d412cc.w16d9257c0a0d412ce.remove(wabfba33f07914a65f)
            if x16d9257c0a0d412cc.wabfba33f07914a65f == 0:
                x16d9257c0a0d412cc.wabfba33f07914a65f = 0
                new_loc = 0
            else:
                x16d9257c0a0d412cc.wabfba33f07914a65f = x16d9257c0a0d412cc.wabfba33f07914a65f -1
                new_loc = x16d9257c0a0d412cc.wabfba33f07914a65f
        elif self.action == 'ADD':
            x16d9257c0a0d412cc.shape_key_add(name='NewKey', from_mix=False)
            x16d9257c0a0d412cc.active_shape_key_index = (len(x16d9257c0a0d412cc.data.shape_keys.key_blocks)-1)
            a304a4f0f8c904o3ce = x16d9257c0a0d412cc.active_shape_key.name
            x16d9257c0a0d412ce = x16d9257c0a0d412cc.w16d9257c0a0d412cc.add()
            x16d9257c0a0d412cc.wabfba33f07914a65d = (len(x16d9257c0a0d412cc.w16d9257c0a0d412cc)-1)
            x16d9257c0a0d412ce.name = a304a4f0f8c904o3ce
            x16d9257c0a0d412ce = x16d9257c0a0d412cc.w16d9257c0a0d412ce.add()
            x16d9257c0a0d412cc.wabfba33f07914a65f = (len(x16d9257c0a0d412cc.w16d9257c0a0d412ce)-1)
            x16d9257c0a0d412ce.a304a4f0f8c90403ce = a304a4f0f8c904o3ce
            x16d9257c0a0d412ce.name = a304a4f0f8c904o3ce
        elif self.action == 'FOLDER':
            a304a4f0f8c904o3ce = 'Folder'
            ca1a2abcfa89317efb4 = 0
            while True:
                a304a4f0f8c904o3ce = 'Folder' + '_' + str(ca1a2abcfa89317efb4)
                ca1a2abcfa89317efb4 += 1
                if a304a4f0f8c904o3ce not in x16d9257c0a0d412cc.x16d9257c0a0d412ca:
                    break
            x16d9257c0a0d412ce = x16d9257c0a0d412cc.w16d9257c0a0d412cc.add()
            x16d9257c0a0d412cc.wabfba33f07914a65d = (len(x16d9257c0a0d412cc.w16d9257c0a0d412cc)-1)
            x16d9257c0a0d412ce.zabfba33f07914a65f = True
            x16d9257c0a0d412ce.name = a304a4f0f8c904o3ce
            x16d9257c0a0d412ce = x16d9257c0a0d412cc.w16d9257c0a0d412ce.add()
            x16d9257c0a0d412cc.wabfba33f07914a65f = (len(x16d9257c0a0d412cc.w16d9257c0a0d412ce)-1)
            x16d9257c0a0d412ce.a304a4f0f8c90403ce = a304a4f0f8c904o3ce
            x16d9257c0a0d412ce.name = a304a4f0f8c904o3ce
            x16d9257c0a0d412ce = x16d9257c0a0d412cc.x16d9257c0a0d412ca.add()
            x16d9257c0a0d412ce.name = a304a4f0f8c904o3ce
        xabfba33f07914a65b(x16d9257c0a0d412cc)
        if new_loc != None:
            x16d9257c0a0d412cc.wabfba33f07914a65f = new_loc
        return {"FINISHED"}
class v16d9257c0a0d412ce(Operator):
    """Open and close this folder"""
    bl_idname = "object.collections_toggle"
    bl_label = "Collection Folder Toggle"
    bl_description = "Open or close this folder, hiding or unhiding its contents"
    xabfba33f07914a65d: IntProperty()
    @classmethod
    def poll(cls, context):
        return context.area.type == 'PROPERTIES'
    def execute(self, context):
        x16d9257c0a0d412cc = context.object
        name = x16d9257c0a0d412cc.w16d9257c0a0d412ce[self.xabfba33f07914a65d].name
        y16d9257c0a0d412ce = x16d9257c0a0d412cc.w16d9257c0a0d412cc[name]
        xabfba33f07914a65d = x16d9257c0a0d412cc.w16d9257c0a0d412cc[:].index(y16d9257c0a0d412ce)
        c304a4f0f8c90403ca = not x16d9257c0a0d412cc.w16d9257c0a0d412cc[xabfba33f07914a65d].a304a4f0f8c90403ca
        x16d9257c0a0d412cc.w16d9257c0a0d412cc[xabfba33f07914a65d].a304a4f0f8c90403ca = c304a4f0f8c90403ca
        for x16d9257c0a0d412ce in x16d9257c0a0d412cc.w16d9257c0a0d412cc[xabfba33f07914a65d+1:]:
            if x16d9257c0a0d412ce.z16d9257c0a0d412ce > x16d9257c0a0d412cc.w16d9257c0a0d412cc[xabfba33f07914a65d].z16d9257c0a0d412ce +1:
                pass
            elif x16d9257c0a0d412ce.z16d9257c0a0d412ce <= x16d9257c0a0d412cc.w16d9257c0a0d412cc[xabfba33f07914a65d].z16d9257c0a0d412ce:
                break
            else:
                x16d9257c0a0d412ce.aa1a2abcfa89317efb = not c304a4f0f8c90403ca
        x16d9257c0a0d412cc.wabfba33f07914a65f = self.xabfba33f07914a65d
        return {"FINISHED"}
class MeshButtonsPanel:
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "data"
class v16d9257c0a0d412cc(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout
        for _ in range(item.z16d9257c0a0d412ce):
            row.label(text='', icon='BLANK1')
        if item.zabfba33f07914a65f:
            row.label(text='', icon='X')
        else:
            row.label(text='', icon='SHAPEKEY_DATA')
        row.label(text = item.name)
        row.label(text = item.z16d9257c0a0d412cc)
        ico = 'HIDE_OFF' if not item.aa1a2abcfa89317efb else 'HIDE_ON'
        row.prop(item, "aa1a2abcfa89317efb", emboss=False, text='', icon=ico)
class w16d9257c0a0d412ca(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout
        layout.enabled = len(bpy.context.active_object.tracked_keys) == 0
        x16d9257c0a0d412cc = context.active_object
        c304a4f0f8c90403ccc = x16d9257c0a0d412cc.w16d9257c0a0d412cc[item.name]
        real_blocks = x16d9257c0a0d412cc.data.shape_keys.key_blocks
        split = row.split(factor=0.5)
        row1 = split.row()
        row2 = split.row()
        row3 = split.row()
        for _ in range(c304a4f0f8c90403ccc.z16d9257c0a0d412ce):
            row1.label(text='', icon='BLANK1')
        if c304a4f0f8c90403ccc.zabfba33f07914a65f:
            ico = 'TRIA_DOWN' if c304a4f0f8c90403ccc.a304a4f0f8c90403ca else 'TRIA_RIGHT'
            row1.operator(v16d9257c0a0d412ce.bl_idname, icon=ico, text="").xabfba33f07914a65d = index
            row1.prop(item, 'name', emboss=False, text='')
            row2.prop_search(c304a4f0f8c90403ccc, "z16d9257c0a0d412cc", x16d9257c0a0d412cc, 'x16d9257c0a0d412ca', text='', icon='DISCLOSURE_TRI_RIGHT')
        else:
            root_key = x16d9257c0a0d412cc.data.shape_keys.key_blocks[0].name
            real_key = x16d9257c0a0d412cc.data.shape_keys.key_blocks[c304a4f0f8c90403ccc.name]
            if item.name != root_key:
                row1.prop(real_key, 'mute', text='', icon='CHECKBOX_HLT', emboss=False)
                row1.prop(item, "name", emboss=False, text='')
                row2.prop_search(c304a4f0f8c90403ccc, "z16d9257c0a0d412cc", x16d9257c0a0d412cc, 'x16d9257c0a0d412ca', text='', icon='DISCLOSURE_TRI_RIGHT')
                try:
                    if item.name.endswith('_Main'):
                        real_l = real_blocks[item.name[:-5] + '_Left']
                        real_r = real_blocks[item.name[:-5] + '_Right']
                        row3.prop(real_l, "value", emboss=False, text='')
                        row3.prop(real_r, "value", emboss=False, text='')
                        if x16d9257c0a0d412cc.show_2split:
                            row3.alert = True
                            row3.prop(real_key, "value", emboss=False, text='')
                            row3.alert = False
                    else:
                        row3.prop(real_key, "value", emboss=False, text='')
                except KeyError:
                    row3.prop(real_key, "value", emboss=False, text='')
            else:
                row1.prop(item, "name", emboss=False, text='', icon='LOCKED')
                row1.label(text='(Basis)')
                row2.prop_search(c304a4f0f8c90403ccc, "z16d9257c0a0d412cc", x16d9257c0a0d412cc, 'x16d9257c0a0d412ca', text='', icon='DISCLOSURE_TRI_RIGHT')
class DATA_PT_shape_keys(MeshButtonsPanel, Panel):
    bl_label = "Shape Keys"
    @classmethod
    def poll(cls, context):
        return context.object.type in ('MESH', 'LATTICE')
    def draw(self, context):
        layout = self.layout
        x16d9257c0a0d412cc = context.active_object
        main = layout.column()
        try:
            if len(x16d9257c0a0d412cc.f9be46a2c881b406ac) != 0:
                layout.row().operator(uabfba33f07914a65d.bl_idname, icon='FILE_REFRESH', text="Update Collectiosn to V3")
                return
        except:
            pass
        def ca1a2abcfa89317efb6():
            row = main.row()
            col = row.column()
            col.label(text='Real - Blender Default')
            ca1a2abcfa89317efb23 = x16d9257c0a0d412cc.data.shape_keys
            col.template_list("MESH_UL_shape_keys", "", ca1a2abcfa89317efb23, "key_blocks", x16d9257c0a0d412cc, "active_shape_key_index")
        def ca1a2abcfa89317efb7():
            row = main.row()
            col = row.column()
            col.label(text='Internal - where data is stored')
            col.template_list("v16d9257c0a0d412cc", "", x16d9257c0a0d412cc, "w16d9257c0a0d412cc", x16d9257c0a0d412cc, "wabfba33f07914a65d")
        def ca1a2abcfa89317efb8():
            row = main.row()
            mo_list = row.row()
            button_a = row.column()
            button_a.enabled = context.mode != 'EDIT_MESH'
            button = button_a.column(align=True)
            button2 = button_a.column()
            button3 = button_a.column(align=True)
            button.enabled =  len(bpy.context.active_object.tracked_keys) == 0
            button3.enabled = len(bpy.context.active_object.tracked_keys) == 0
            ca1a2abcfa89317efb4 = button.operator(vabfba33f07914a65d.bl_idname, icon='ADD', text="")
            ca1a2abcfa89317efb4.action = 'ADD'
            remove = button.operator(vabfba33f07914a65d.bl_idname, icon='REMOVE', text="")
            remove.action = 'REMOVE'
            if x16d9257c0a0d412cc.data.shape_keys != None:
                button2.menu("tabfba33f07914a65d", icon='DOWNARROW_HLT', text="")
                U = button3.operator(vabfba33f07914a65d.bl_idname, icon='TRIA_UP', text="")
                U.action = 'UP'
                D = button3.operator(vabfba33f07914a65d.bl_idname, icon='TRIA_DOWN', text="")
                D.action = 'DOWN'
                button3.separator()
                F = button3.operator(vabfba33f07914a65d.bl_idname, icon='FILE_FOLDER', text="")
                F.action = 'FOLDER'
            else:
                remove = None
            if len(x16d9257c0a0d412cc.w16d9257c0a0d412cc) == 0 and x16d9257c0a0d412cc.data.shape_keys != None:
                ca1a2abcfa89317efb23 = x16d9257c0a0d412cc.data.shape_keys
                mo_list.template_list("MESH_UL_shape_keys", "", ca1a2abcfa89317efb23, "key_blocks", x16d9257c0a0d412cc, "active_shape_key_index")
                ca1a2abcfa89317efb4.ca1a2abcfa89317efb3 = True
                remove.ca1a2abcfa89317efb3 = True
                U.ca1a2abcfa89317efb3 = True
                D.ca1a2abcfa89317efb3 = True
                F.ca1a2abcfa89317efb3 = True
            else:
                mo_list.template_list("w16d9257c0a0d412ca", "", x16d9257c0a0d412cc, "w16d9257c0a0d412ce", x16d9257c0a0d412cc, "wabfba33f07914a65f")
                ca1a2abcfa89317efb4.ca1a2abcfa89317efb3 = False
                remove.ca1a2abcfa89317efb3 = False
                U.ca1a2abcfa89317efb3 = False
                D.ca1a2abcfa89317efb3 = False
                F.ca1a2abcfa89317efb3 = False
        obj = context.active_object
        name = ''
        try:
            name = obj.w16d9257c0a0d412ce[obj.wabfba33f07914a65f].name
        except IndexError:
            pass
        def found_dupe(name):
            yabfba33f07914a65f = False
            for id in obj.w16d9257c0a0d412cc:
                if id.name == name:
                    if yabfba33f07914a65f:
                        return True
                    else:
                        yabfba33f07914a65f = True
        if debug:
            ca1a2abcfa89317efb6()
            ca1a2abcfa89317efb7()
        if found_dupe(name):
                    mo_list = layout.row()
                    mo_list.alert=True
                    mo_list.label(text='Duplicate of "{}" yabfba33f07914a65f, Undo this change, or suffer greatly on the road ahead'.format(name))
        ca1a2abcfa89317efb8()
        ca1a2abcfa89317efb23 = x16d9257c0a0d412cc.data.shape_keys
        ca1a2abcfa89317efb1 = x16d9257c0a0d412cc.active_shape_key
        if ca1a2abcfa89317efb23 == None or ca1a2abcfa89317efb1 == None:
            return
        enable_edit = x16d9257c0a0d412cc.mode != 'EDIT'
        enable_edit_value = False
        enable_pin = False
        if enable_edit or (x16d9257c0a0d412cc.use_shape_key_edit_mode and x16d9257c0a0d412cc.type == 'MESH'):
            enable_pin = True
            if x16d9257c0a0d412cc.show_only_shape_key is False:
                enable_edit_value = True
        split = layout.split(factor=0.4)
        row = split.row()
        row.enabled = enable_edit
        row.prop(ca1a2abcfa89317efb23, "use_relative")
        row = split.row()
        row.alignment = 'RIGHT'
        sub = row.row(align=True)
        sub.label()
        subsub = sub.row(align=True)
        subsub.active = enable_pin
        subsub.prop(x16d9257c0a0d412cc, "show_only_shape_key", text="")
        sub.prop(x16d9257c0a0d412cc, "use_shape_key_edit_mode", text="")
        sub = row.row()
        if ca1a2abcfa89317efb23.use_relative:
            sub.operator("object.shape_key_clear", icon='X', text="")
        else:
            sub.operator("object.shape_key_retime", icon='RECOVER_LAST', text="")
        layout.use_property_split = True
        if ca1a2abcfa89317efb23.use_relative:
            if x16d9257c0a0d412cc.active_shape_key_index != 0:
                row = layout.row()
                row.active = enable_edit_value
                row.prop(ca1a2abcfa89317efb1, "value")
                col = layout.column()
                sub.active = enable_edit_value
                sub = col.column(align=True)
                sub.prop(ca1a2abcfa89317efb1, "slider_min", text="Range Min")
                sub.prop(ca1a2abcfa89317efb1, "slider_max", text="Max")
                col.prop_search(ca1a2abcfa89317efb1, "vertex_group", x16d9257c0a0d412cc, "vertex_groups", text="Vertex Group")
                col.prop_search(ca1a2abcfa89317efb1, "relative_key", ca1a2abcfa89317efb23, "key_blocks", text="Relative To")
        else:
            layout.prop(ca1a2abcfa89317efb1, "interpolation")
            row = layout.column()
            row.active = enable_edit_value
            row.prop(ca1a2abcfa89317efb23, "eval_time")
        layout.prop(x16d9257c0a0d412cc, "add_rest_position_attribute")
classes = (
        tabfba33f07914a65d,
        t16d9257c0a0d412ce,
        tabfba33f07914a65f,
        u16d9257c0a0d412ca,
        uabfba33f07914a65b,
        u16d9257c0a0d412cc,
        uabfba33f07914a65d,
        u16d9257c0a0d412ce,
        uabfba33f07914a65f,
        SKC_TRACK_APPLY_menu,
        DATA_PT_shape_keys,
        vabfba33f07914a65b,
        v16d9257c0a0d412cc,
        vabfba33f07914a65d,
        v16d9257c0a0d412ce,
        vabfba33f07914a65f,
        w16d9257c0a0d412ca,
        wabfba33f07914a65b,
        TRACK_KEYS_list,
    )
def register():
    for cls in classes:
        register_class(cls)
    Object.w16d9257c0a0d412cc = CollectionProperty(type=vabfba33f07914a65b)
    Object.wabfba33f07914a65d = IntProperty(name = "List Index", default = 0, options = set())
    Object.w16d9257c0a0d412ce = CollectionProperty(type=vabfba33f07914a65f)
    Object.wabfba33f07914a65f = IntProperty(name = "List Index", default = 0, update=ca1a2abcfa89317efb9, options = set())
    Object.x16d9257c0a0d412ca = CollectionProperty(type=wabfba33f07914a65b)
    Object.tracked_keys = CollectionProperty(type=TRACK_KEYS_list)
    Object.show_2split = BoolProperty(default=False, name='Show Main Key', description="Show or hide the 'base' value of a 2-split shape key value\n\nA 2-split is made by adding '_Main', '_Left', and '_Right' on the end of the name of three shape keys\nAll three of these must appear: no more; no less, for a 2-split to occur")
    Scene.skc_add_to_top = BoolProperty(name="Add Items to Top of Folder", default=False, description="When adding new items to a folder, the item will be added to the top of the folder chain instead of to the bottom")
def unregister():
    for cls in reversed(classes):
        unregister_class(cls)
    del Object.w16d9257c0a0d412cc
    del Object.wabfba33f07914a65d
    del Object.w16d9257c0a0d412ce
    del Object.wabfba33f07914a65f
    del Object.x16d9257c0a0d412ca
    del Object.tracked_keys
    del Scene.skc_add_to_top
if __name__ == "__main__":
    register()